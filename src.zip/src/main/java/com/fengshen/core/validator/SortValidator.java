//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.validator;

import java.util.ArrayList;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class SortValidator implements ConstraintValidator<Sort, String> {
    private List<String> valueList;

    public SortValidator() {
    }

    public void initialize(final Sort sort) {
        this.valueList = new ArrayList();
        String[] accepts;
        int length = (accepts = sort.accepts()).length;

        for (int i = 0; i < length; ++i) {
            String val = accepts[i];
            this.valueList.add(val.toUpperCase());
        }

    }

    public boolean isValid(final String s, final ConstraintValidatorContext constraintValidatorContext) {
        return this.valueList.contains(s.toUpperCase());
    }
}
