package com.fengshen.core.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

@Service
public class SpringBeanUtils implements ApplicationContextAware {
    private static ApplicationContext applicationContext;

    public SpringBeanUtils() {
    }

    public static Object getBean(String beanName) {
        Object obj = applicationContext.getBean(beanName);
        return obj;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationcontext) throws BeansException {
        applicationContext = applicationcontext;
    }

    public static <T> T getBean(Class<?> classzz) {
        return (T) applicationContext.getBean(classzz);
    }
}
