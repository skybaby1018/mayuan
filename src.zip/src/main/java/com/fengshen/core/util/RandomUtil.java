package com.fengshen.core.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class RandomUtil {
    public static int randomInt(final int s, final int e) {
        final int i = (int) (s + Math.random() * (e - s + 1));
        return i;
    }

    public static float randomFloat(final float s, final float e) {
        return new Random().nextFloat() * (e - s) + s;
    }

    public static double randomDouble(final double s, final double e) {
        return new Random().nextDouble() * (e - s) + s;
    }

    public static boolean checkSuccess(final float rate) {
        final float random = randomFloat(0.0f, 100.0f);
        return random < rate;
    }

    public static int randomInt(final int max) {
        return ThreadLocalRandom.current().nextInt(max);
    }

    public static int randomNotZeroInt(final int max) {
        return randomInt(max) + 1;
    }
}
