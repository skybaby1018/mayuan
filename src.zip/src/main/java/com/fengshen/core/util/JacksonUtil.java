//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JacksonUtil {
    private static final Logger logger = LoggerFactory.getLogger(JacksonUtil.class);

    public JacksonUtil() {
    }

    public static String parseString(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            JsonNode leaf = node.get(field);
            if (leaf != null) {
                return leaf.asText();
            }
        } catch (IOException var5) {
            logger.error("解析字为符串失败", var5);
        }

        return null;
    }

    public static List<String> parseStringList(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            JsonNode leaf = node.get(field);
            if (leaf != null) {
                return (List) mapper.convertValue(leaf, new TypeReference<List<String>>() {
                });
            }
        } catch (IOException var5) {
            logger.error("字符串解析为字符串列表失败", var5);
        }

        return null;
    }

    public static Integer parseInteger(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            JsonNode leaf = node.get(field);
            if (leaf != null) {
                return leaf.asInt();
            }
        } catch (IOException var5) {
            logger.error("字符串解析为整数失败", var5);
        }

        return null;
    }

    public static List<Integer> parseIntegerList(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            JsonNode leaf = node.get(field);
            if (leaf != null) {
                return (List) mapper.convertValue(leaf, new TypeReference<List<Integer>>() {
                });
            }
        } catch (IOException var5) {
            logger.error("字符串解析为整数列表失败", var5);
        }

        return null;
    }

    public static Boolean parseBoolean(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            JsonNode leaf = node.get(field);
            if (leaf != null) {
                return leaf.asBoolean();
            }
        } catch (IOException var5) {
            logger.error("字符串解析为布尔值失败", var5);
        }

        return null;
    }

    public static Short parseShort(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;
        System.out.println("字符串解析为短整形失败");
//        try {
//            node = mapper.readTree(body);
//            JsonNode leaf = node.get(field);
//            if (leaf != null) {
//                Integer value = leaf.asInt();
//                return Short.valueOf(value);
//            }
//        } catch (IOException var6) {
//            logger.error("字符串解析为短整形失败", var6);
//        }

        return null;
    }

    public static Byte parseByte(final String body, final String field) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;
        System.out.println("字符串解析为字节失败");
//        try {
//            node = mapper.readTree(body);
//            JsonNode leaf = node.get(field);
//            if (leaf != null) {
//                Integer value = leaf.asInt();
//                return (Byte)value;
//            }
//        } catch (IOException var6) {
//            logger.error("字符串解析为字节失败", var6);
//        }

        return null;
    }

    public static <T> T parseObject(final String body, final String field, final Class<T> clazz) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = null;

        try {
            node = mapper.readTree(body);
            node = node.get(field);
            return mapper.treeToValue(node, clazz);
        } catch (IOException var6) {
            logger.error("字符串解析为对象失败", var6);
            return null;
        }
    }

    public static Object toNode(final String json) {
        if (json == null) {
            return null;
        } else {
            ObjectMapper mapper = new ObjectMapper();

            try {
                JsonNode jsonNode = mapper.readTree(json);
                return jsonNode;
            } catch (IOException var3) {
                logger.error("Json转换成对象失败", var3);
                return null;
            }
        }
    }
}
