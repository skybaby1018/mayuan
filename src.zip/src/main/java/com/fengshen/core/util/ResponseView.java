//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import com.fengshen.core.exception.SuperException;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.HashMap;

public class ResponseView extends HashMap<String, Object> {
    private static final long serialVersionUID = 1L;
    private static String retmsg = "请求成功";

    public ResponseView() {
    }

    public static ResponseView ok(ResponseView rv) {
        init(rv);
        return rv;
    }

    public static ResponseView ok(Object data) {
        ResponseView rv = new ResponseView();
        if (data != null) {
            rv.put("data", data);
        }

        init(rv);
        return rv;
    }

    public static ResponseView ok(String retmsg) {
        ResponseView rv = new ResponseView();
        rv.put("retmsg", retmsg);
        initPassMessage(rv);
        return rv;
    }

    public static ResponseView ok() {
        ResponseView rv = new ResponseView();
        initPass(rv);
        return rv;
    }

    public static ResponseView fail(ResponseView rv) {
        initFial(rv);
        return rv;
    }

    public static ResponseView fail(String retmsg) {
        ResponseView rv = new ResponseView();
        rv.put("retmsg", retmsg);
        initFial(rv);
        return rv;
    }

    public static ResponseView unauthorized(String retmsg) {
        return initUnauthorized(retmsg);
    }

    public static ResponseView unauthorized() {
        return initUnauthorized("对不起,您无权访问!");
    }

    private static ResponseView initUnauthorized(String retmsg) {
        ResponseView rv = new ResponseView();
        rv.put("retmsg", retmsg);
        rv.put("currentTime", (new Date()).getTime());
        rv.put("status", ErrorCode.UNAUTHORIZED);
        rv.put("retcode", ErrorCode.UNAUTHORIZED);
        throw new SuperException(rv);
    }

    private static void init(ResponseView rv) {
        rv.put("retmsg", retmsg);
        rv.put("currentTime", (new Date()).getTime());
        rv.put("status", ErrorCode.SUCCESS);
        rv.put("retcode", 0);
    }

    private static void initPass(ResponseView rv) {
        rv.put("retmsg", retmsg);
        rv.put("currentTime", (new Date()).getTime());
        rv.put("status", ErrorCode.SUCCESS);
        rv.put("retcode", 0);
    }

    private static void initPassMessage(ResponseView rv) {
        if (rv.get("retmsg") == null) {
            rv.put("retmsg", retmsg);
        } else {
            rv.put("retmsg", rv.get("retmsg"));
        }

        rv.put("currentTime", (new Date()).getTime());
        rv.put("status", ErrorCode.SUCCESS);
        rv.put("retcode", 0);
    }

    private static void initFial(ResponseView rv) {
        if (rv.get("retmsg") != null) {
            String retcodeName = getErrorCodeName((String) rv.get("retmsg"));
            if (retcodeName != "") {
                rv.put("retcode", retcodeName);
            } else {
                rv.put("retcode", ErrorCode.ERROR);
            }
        }

        rv.put("currentTime", (new Date()).getTime());
        rv.put("status", ErrorCode.ERROR);
        throw new SuperException(rv);
    }

    public static String getErrorCodeName(String errorInfo) {
        ErrorCode error = new ErrorCode();
        Class c = error.getClass();
        Field[] fields = c.getFields();
        String codeName = "";
        Field[] var8 = fields;
        int var7 = fields.length;

        for (int var6 = 0; var6 < var7; ++var6) {
            Field f = var8[var6];

            try {
                if (f.get(error) instanceof String) {
                    String info = (String) f.get(error);
                    if (info.equals(errorInfo)) {
                        codeName = f.getName();
                    }
                }
            } catch (IllegalAccessException | IllegalArgumentException var10) {
                return "";
            }
        }

        return codeName.replace("E", "");
    }
}
