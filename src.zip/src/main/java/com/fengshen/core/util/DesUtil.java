//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class DesUtil {
    public DesUtil() {
    }

    public static String byteArr2HexStr(final byte[] paramArrayOfByte) throws Exception {
        int i = 0;
        int k = paramArrayOfByte.length;

        StringBuffer localStringBuffer;
        for (localStringBuffer = new StringBuffer(k * 2); i < k; ++i) {
            int j;
            for (j = paramArrayOfByte[i]; j < 0; j += 256) {
                ;
            }

            if (j < 16) {
                localStringBuffer.append("0");
            }

            localStringBuffer.append(Integer.toString(j, 16));
        }

        return localStringBuffer.toString();
    }

    public static String decrypt(String value, final String paramString2) {
        Key key = getKey(paramString2.getBytes());

        try {
            value = new String(decrypt(hexStr2ByteArr(value), key));
            return value;
        } catch (Exception var4) {
            var4.printStackTrace();
            return "";
        }
    }

    public static byte[] decrypt(final byte[] paramArrayOfByte, final Key paramKey) throws Exception {
        Cipher localCipher = Cipher.getInstance("DES");
        localCipher.init(2, paramKey);
        return localCipher.doFinal(paramArrayOfByte);
    }

    public static String encrypt(String value, final String paramString2) {
        Key key = getKey(paramString2.getBytes());

        try {
            value = byteArr2HexStr(encrypt(value.getBytes(), key));
            return value;
        } catch (Exception var4) {
            var4.printStackTrace();
            return "";
        }
    }

    public static byte[] encrypt(final byte[] paramArrayOfByte, final Key paramKey) throws Exception {
        Cipher localCipher = Cipher.getInstance("DES");
        localCipher.init(1, paramKey);
        return localCipher.doFinal(paramArrayOfByte);
    }

    private static Key getKey(final byte[] paramArrayOfByte) {
        byte[] arrayOfByte = new byte[8];

        for (int i = 0; i < paramArrayOfByte.length && i < arrayOfByte.length; ++i) {
            arrayOfByte[i] = paramArrayOfByte[i];
        }

        return new SecretKeySpec(arrayOfByte, "DES");
    }

    public static byte[] hexStr2ByteArr(final String paramString) throws Exception {
        byte[] bytes = paramString.getBytes();
        int i = 0;
        int j = bytes.length;

        byte[] arrayOfByte;
        for (arrayOfByte = new byte[j / 2]; i < j; i += 2) {
            String str = new String(bytes, i, 2);
            arrayOfByte[i / 2] = (byte) Integer.parseInt(str, 16);
        }

        return arrayOfByte;
    }

    public static void main(final String[] args) throws Exception {
        String decrypt = decrypt("662a14bd16bef3c6d5ab3e907fafed5c587972a801bbd9654a300432c064aaef9f0ee9f43e1b8507a66b27b42eb539c8d5ab3e907fafed5c587972a801bbd9654a300432c064aaef9f0ee9f43e1b85071ff931365e29f1dc786b86486a478d5e4dee9fb0a48d7048001da479db439205ca4d726e84ae920d4ab5221c3ac889366703ed9343a8f6894dee9fb0a48d7048363ce1796f3049f58c907508e93460f3289206ce63c11e7e4827a053ab834371174f63ab17ba4e1ed16ff15bbd359665a17161018c3474320683b531800838004827a053ab834371baa36248330badd00e59a4299782e0848a4500e4739869bd20aa1a1048adc78534ff333c10c15cbb7833be98804326e8f0a8ca4595d315da418c857071e9f76b8573b93db19fcde35cbf6b6e78c9a321fb9d0b54e57de69e3e38ce876ac5c034855abd6b46fe9c1ac968d5196ffb294b0799357c737eea7112f20de7cc6ed7a99bf3d22bc9dca11282529a1752cf8cb90fc95175e0c5246b2a5aba5105e2968e7fb967e4ae85b51903ceb1d184580f369144c36fff8b12061cf770a847e266342d397bc70c6aa5eb396f4533233c0b623e38ce876ac5c034c930cfe585f53cfc10283de4361001a0ec13a7e0a012f2aa62d82209e08e0325120854ff2317d17a67c8caed31af07f7cce56d26f7af44517d6fdfe91dde23bb7e8593f7220a6dfb36ae1a030ea20dc5c62070fa5e0ce9a5b77a8bf16f9d9c52604e7718ca7288096430a1f259796f6ff2d749a39dd13ae6396fffa28504de326bc6bf6c4c3292c169db8992dc6ea8b4b177695b9a3bfdcb516341283ec20a93e05bf43c82b03513591066bece480b6816b62b6d2dfcf50730121bddc6d5734e2adf8c52f98080dee266b616af11e2bbdd81b5fcde4d4b9229ee93f7a15ae36c18b7d0cffaf8fd56a4cf486be37b47c7484757ccc943cdf125d2ff4a4c2d32f323c810fae7b9ff305c786a1db3282671422d856c95b4e4cb3bbfdc06692d26ec7105cc465211ce33c8d1f6710f160c4dc8fbc8d3e00d4a8ee7268592a4886ee93edff72b912fdc1f29ee93f7a15ae36c876c85ed0a201c5a70468dcc2296f14b67ae4527abb23a99859951ae74288344b1908640d5b598babae48a4165a821e6d399a2c1afc51c14151e61ec7374b8bdc9939d6db1eb583a21066ddc0c3ccfdf446eb0e05f334c2ab95d6883f0825fd243d5021d2ebdcdbfb8ff98f0bcf510bd19c003682442d52be7ebcf03e4dac20afc898dd2e2d3a980e95dad21e1208253e3d7c5bc872f7c094dcde5839bc5f617e781c93630e3d4821044a21099fb6a70059231aa4ccf4e60ef0605b3dea6145729ee93f7a15ae36c8624b1c9972e0fed8d2fc84230d1c0d56ef5db3d43371cde638d2131dfeeafdb6bb464265a3d62679e0a7a48fb5aaba69ca6220a8b39bc392466885409327b27de1c408fbfea7f6cc862d510c4664e4d93574904a9e8ff8c772d138623c0e30fc73891c2c5bf01ea9b1856d3bfd82b53b1b230ae90a40988d9142f13ec7b633fe5a7a57c11ecd087e0cbc9beb9688ccaac80fc4a86e1a31d73654be863559e39ebc2ccce7ce7f4aa388118f1ee4c306384b3590a7ce0a047ad12484bfb26e7cd1a974d02022892401c96ec17af4bf96a6da0c585ad714dea67ca1df339d7190eaa38ea649bc307d42adf8c52f98080de47b127206e1219c03baccb4ea896646c8718b61c72690a0f6d79dc0387c8a81a19c003682442d52bb692e940626c0e857a07e6402d748eab7d64bea9f43aff7c9dabc86100fcf532a8f8a0fd428ab249d4f00d0fc886f2bd280ee0511bbf060f93e6efea6766b630fe2721b8773c4cbad6f02778ec9b80393e3b062b3c92596ad717586ea636838948e8306380fd77002e2fb31319a97284956f9a3d9820dc20", "548711fdc20a2129");
        System.out.println(decrypt);
    }
}
