//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;

public class ExecutorsUtils {
    private static final ExecutorService pool;

    static {
        pool = new ThreadPoolExecutor(5, 200, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(1024), (new ThreadFactoryBuilder()).setNameFormat("pool-%d").build(), new AbortPolicy());
    }

    public ExecutorsUtils() {
    }

    public static ExecutorService getExecutorPools() {
        return pool;
    }
}
