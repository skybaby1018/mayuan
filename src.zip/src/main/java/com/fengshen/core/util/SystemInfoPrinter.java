//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class SystemInfoPrinter {
    public static final String CREATE_PART_COPPER = "XOXOXOXOX";
    private static int maxSize = 0;

    public SystemInfoPrinter() {
    }

    public static void printInfo(final String title, final Map<String, String> infos) {
        setMaxSize(infos);
        printHeader(title);
        Iterator var3 = infos.entrySet().iterator();

        while (var3.hasNext()) {
            Entry<String, String> entry = (Entry) var3.next();
            printLine((String) entry.getKey(), (String) entry.getValue());
        }

        printEnd();
    }

    private static void setMaxSize(final Map<String, String> infos) {
        Iterator var2 = infos.entrySet().iterator();

        while (var2.hasNext()) {
            Entry<String, String> entry = (Entry) var2.next();
            if (entry.getValue() != null) {
                int size = ((String) entry.getKey()).length() + ((String) entry.getValue()).length();
                if (size > maxSize) {
                    maxSize = size;
                }
            }
        }

        maxSize += 30;
    }

    private static void printHeader(final String title) {
        System.out.println(getLineCopper());
        System.out.println("");
        System.out.println("              " + title);
        System.out.println("");
    }

    private static void printEnd() {
        System.out.println("  ");
        System.out.println(getLineCopper());
    }

    private static String getLineCopper() {
        String copper = "";

        for (int i = 0; i < maxSize; ++i) {
            copper = String.valueOf(copper) + "=";
        }

        return copper;
    }

    private static void printLine(final String head, final String line) {
        if (line != null) {
            if (head.startsWith("XOXOXOXOX")) {
                System.out.println("");
                System.out.println("    [[  " + line + "  ]]");
                System.out.println("");
            } else {
                System.out.println("    " + head + "        ->        " + line);
            }

        }
    }
}
