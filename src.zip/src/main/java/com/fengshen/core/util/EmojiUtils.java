

package com.fengshen.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmojiUtils {
    public static final String unicodeReg = "[一-龿䷀-䷿\u0000-\u007f\u0080-ÿĀ-ſƀ-ɏɐ-ʯʰ-˿̀-ͯͰ-ϿЀ-ӿԀ-\u052f\u0530-֏\u0590-\u05ff\u0600-ۿ܀-ݏݐ-ݿހ-\u07bfࠀ-\u085f\u0860-\u087f\u0880-\u08afऀ-ॿ\u0980-\u09ff\u0a00-\u0a7f\u0a80-\u0aff\u0b00-\u0b7f\u0b80-\u0bff\u0c00-౿\u0c80-\u0cff\u0d00-ൿ\u0d80-\u0dff\u0e00-\u0e7f\u0e80-\u0effༀ-\u0fffက-႟Ⴀ-ჿᄀ-ᇿሀ-\u137fᎀ-\u139fᎠ-\u13ff᐀-ᙿ -\u169fᚠ-\u16ffᜀ-\u171fᜠ-\u173fᝀ-\u175fᝠ-\u177fក-\u17ff᠀-\u18afᢰ-\u18ffᤀ-᥏ᥐ-\u197fᦀ-᧟᧠-᧿ᨀ-᨟ᨠ-\u1a5f᪀-\u1aefᬀ-\u1b7fᮀ-᮰ᯀ-᯿ᰀ-ᱏ᱐-᱿\u1c80-᳟ᴀ-ᵿᶀ-ᶿ᷀-᷿Ḁ-ỿἀ-\u1fff -\u206f⁰-\u209f₠-\u20cf⃐-\u20ff℀-⅏⅐-\u218f←-⇿∀-⋿⌀-\u23ff␀-\u243f⑀-\u245f①-⓿─-╿▀-▟■-◿☀-⛿\u2700-➿⟀-⟯⟰-⟿⠀-⣿⤀-⥿⦀-⧿⨀-⫿⬀-\u2bffⰀ-\u2c5fⱠ-ⱿⲀ-⳿ⴀ-\u2d2fⴰ-⵿ⶀ-\u2ddf⸀-\u2e7f⺀-\u2eff⼀-\u2fdf⿰-\u2fff　-〿\u3040-ゟ゠-ヿ\u3100-\u312f\u3130-\u318f㆐-㆟ㆠ-\u31bf㇀-\u31efㇰ-ㇿ㈀-\u32ff㌀-㏿㐀-\u4dbf䷀-䷿一-龿ꀀ-\ua48f꒐-\ua4cfꔀ-ꘟꙠ-\ua6ff꜀-ꜟ꜠-ꟿꠀ-\ua82fꡀ-\ua87fꢀ-\ua8df꤀-\ua97fꦀ-꧟ꨀ-\uaa3fꩀ-ꩯꪀ-꫟\uab00-\uab5f\uab80-\uaba0가-\ud7af\ue000-\uf8ff豈-\ufaffﬀ-ﭏﭐ-\ufdff︀-️︐-\ufe1f︠-\ufe2f︰-﹏﹐-\ufe6fﹰ-\ufeff\uff00-\uffef\ufff0-\uffff]";

    public EmojiUtils() {
    }

    public static String convert(String str) {
        str = str == null ? "" : str;
        StringBuffer sb = new StringBuffer(1000);
        sb.setLength(0);

        for (int i = 0; i < str.length(); ++i) {
            char c = str.charAt(i);
            sb.append("\\u");
            int j = c >>> 8;
            String tmp = Integer.toHexString(j);
            if (tmp.length() == 1) {
                sb.append("0");
            }

            sb.append(tmp);
            j = c & 255;
            tmp = Integer.toHexString(j);
            if (tmp.length() == 1) {
                sb.append("0");
            }

            sb.append(tmp);
        }

        return (new String(sb)).toUpperCase();
    }

    public static String revert(String str) {
        str = str == null ? "" : str;
        if (str.indexOf("\\u") == -1) {
            return str;
        } else {
            StringBuffer sb = new StringBuffer(1000);

            for (int i = 0; i < str.length() - 6; i += 6) {
                String strTemp = str.substring(i, i + 6);
                String value = strTemp.substring(2);
                int c = 0;

                for (int j = 0; j < value.length(); ++j) {
                    char tempChar = value.charAt(j);
                    int t = 0;
                    switch (tempChar) {
                        case 'a':
                            t = 10;
                            break;
                        case 'b':
                            t = 11;
                            break;
                        case 'c':
                            t = 12;
                            break;
                        case 'd':
                            t = 13;
                            break;
                        case 'e':
                            t = 14;
                            break;
                        case 'f':
                            t = 15;
                            break;
                        default:
                            t = tempChar - 48;
                    }

                    c += t * (int) Math.pow(16.0D, (double) (value.length() - j - 1));
                }

                sb.append((char) c);
            }

            return sb.toString();
        }
    }

    public static String emojiChange(String string) {
        try {
            Pattern pattern = Pattern.compile("[一-龿䷀-䷿\u0000-\u007f\u0080-ÿĀ-ſƀ-ɏɐ-ʯʰ-˿̀-ͯͰ-ϿЀ-ӿԀ-\u052f\u0530-֏\u0590-\u05ff\u0600-ۿ܀-ݏݐ-ݿހ-\u07bfࠀ-\u085f\u0860-\u087f\u0880-\u08afऀ-ॿ\u0980-\u09ff\u0a00-\u0a7f\u0a80-\u0aff\u0b00-\u0b7f\u0b80-\u0bff\u0c00-౿\u0c80-\u0cff\u0d00-ൿ\u0d80-\u0dff\u0e00-\u0e7f\u0e80-\u0effༀ-\u0fffက-႟Ⴀ-ჿᄀ-ᇿሀ-\u137fᎀ-\u139fᎠ-\u13ff᐀-ᙿ -\u169fᚠ-\u16ffᜀ-\u171fᜠ-\u173fᝀ-\u175fᝠ-\u177fក-\u17ff᠀-\u18afᢰ-\u18ffᤀ-᥏ᥐ-\u197fᦀ-᧟᧠-᧿ᨀ-᨟ᨠ-\u1a5f᪀-\u1aefᬀ-\u1b7fᮀ-᮰ᯀ-᯿ᰀ-ᱏ᱐-᱿\u1c80-᳟ᴀ-ᵿᶀ-ᶿ᷀-᷿Ḁ-ỿἀ-\u1fff -\u206f⁰-\u209f₠-\u20cf⃐-\u20ff℀-⅏⅐-\u218f←-⇿∀-⋿⌀-\u23ff␀-\u243f⑀-\u245f①-⓿─-╿▀-▟■-◿☀-⛿\u2700-➿⟀-⟯⟰-⟿⠀-⣿⤀-⥿⦀-⧿⨀-⫿⬀-\u2bffⰀ-\u2c5fⱠ-ⱿⲀ-⳿ⴀ-\u2d2fⴰ-⵿ⶀ-\u2ddf⸀-\u2e7f⺀-\u2eff⼀-\u2fdf⿰-\u2fff　-〿\u3040-ゟ゠-ヿ\u3100-\u312f\u3130-\u318f㆐-㆟ㆠ-\u31bf㇀-\u31efㇰ-ㇿ㈀-\u32ff㌀-㏿㐀-\u4dbf䷀-䷿一-龿ꀀ-\ua48f꒐-\ua4cfꔀ-ꘟꙠ-\ua6ff꜀-ꜟ꜠-ꟿꠀ-\ua82fꡀ-\ua87fꢀ-\ua8df꤀-\ua97fꦀ-꧟ꨀ-\uaa3fꩀ-ꩯꪀ-꫟\uab00-\uab5f\uab80-\uaba0가-\ud7af\ue000-\uf8ff豈-\ufaffﬀ-ﭏﭐ-\ufdff︀-️︐-\ufe1f︠-\ufe2f︰-﹏﹐-\ufe6fﹰ-\ufeff\uff00-\uffef\ufff0-\uffff]");
            StringBuffer sbBuffer = new StringBuffer();

            for (int i = 0; i < string.length(); ++i) {
                char c = string.charAt(i);
                String temp = String.valueOf(c);
                Matcher matcher = pattern.matcher(temp);
                if (matcher.find()) {
                    sbBuffer.append(temp);
                } else {
                    sbBuffer.append("□");
                }
            }

            return sbBuffer.toString();
        } catch (Exception var7) {
            var7.printStackTrace();
            return "";
        }
    }
}
