//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DateUtil {
    private static final Object lockObj = new Object();
    private static Map<String, ThreadLocal<SimpleDateFormat>> sdfMap = new HashMap();

    public DateUtil() {
    }

    public static SimpleDateFormat getSdf(final String pattern) {
        ThreadLocal<SimpleDateFormat> tl = (ThreadLocal) sdfMap.get(pattern);
        if (tl == null) {
            Object var2 = lockObj;
            synchronized (lockObj) {
                tl = (ThreadLocal) sdfMap.get(pattern);
                if (tl == null) {
                    tl = new ThreadLocal<SimpleDateFormat>() {
                        protected SimpleDateFormat initialValue() {
                            return new SimpleDateFormat(pattern);
                        }
                    };
                    sdfMap.put(pattern, tl);
                }
            }
        }

        return (SimpleDateFormat) tl.get();
    }

    public static String format(Date date, String pattern) {
        return getSdf(pattern).format(date);
    }

    public static Date parse(String dateStr, String pattern) {
        try {
            return getSdf(pattern).parse(dateStr);
        } catch (ParseException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static long getMin(String start, String end) {
        SimpleDateFormat sdf = getSdf("yyyy-MM-dd");
        start = sdf.format(new Date()) + " " + start + ":" + "00";
        end = sdf.format(new Date()) + " " + end + ":" + "00";
        SimpleDateFormat sdf2 = getSdf("yyyy-MM-dd HH:mm:ss");
        long min = 0L;

        try {
            min = sdf2.parse(end).getTime() - sdf2.parse(start).getTime();
        } catch (ParseException var7) {
            ;
        }

        return min;
    }

    public static Date getPastDate(int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(6, calendar.get(6) - past);
        Date today = calendar.getTime();
        return today;
    }

    public static Date getFetureDate(int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(6, calendar.get(6) + past);
        Date today = calendar.getTime();
        return today;
    }

    public static Date getPastDate(Date date, int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(6, calendar.get(6) - past);
        Date today = calendar.getTime();
        return today;
    }

    public static Date getFetureDate(Date date, int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(6, calendar.get(6) + past);
        Date today = calendar.getTime();
        return today;
    }

    public static void main(String[] args) {
        System.out.println(getMin("11:21", "11:30"));
    }

    public static Date getWebsiteDatetime() {
        try {
            URL url = new URL("https://www.baidu.com");
            URLConnection uc = url.openConnection();
            uc.connect();
            long ld = uc.getDate();
            Date date = new Date(ld);
            return date;
        } catch (MalformedURLException var5) {
            var5.printStackTrace();
        } catch (IOException var6) {
            var6.printStackTrace();
        }

        return null;
    }
}
