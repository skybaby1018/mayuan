//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FieldFilterUtil {
    private static final Logger log = LoggerFactory.getLogger(FieldFilterUtil.class);

    public FieldFilterUtil() {
    }

    public static synchronized void filterField(Object obj, String... values) {
        Class<?> classzz = obj.getClass();
        String[] var6 = values;
        int var5 = values.length;

        for (int var4 = 0; var4 < var5; ++var4) {
            String v = var6[var4];

            try {
                Field f = classzz.getDeclaredField(v);
                f.setAccessible(true);
                f.set(obj, (Object) null);
            } catch (NoSuchFieldException var8) {
                log.error(var8.getMessage());
            } catch (SecurityException var9) {
                log.error(var9.getMessage());
            } catch (IllegalArgumentException var10) {
                log.error(var10.getMessage());
            } catch (IllegalAccessException var11) {
                log.error(var11.getMessage());
            }
        }

    }

    public static synchronized void filterField(List<?> obj, String... values) {
        Iterator var3 = obj.iterator();

        while (var3.hasNext()) {
            Object o = var3.next();
            Class<?> classzz = o.getClass();
            String[] var8 = values;
            int var7 = values.length;

            for (int var6 = 0; var6 < var7; ++var6) {
                String v = var8[var6];

                try {
                    Field f = classzz.getDeclaredField(v);
                    f.setAccessible(true);
                    f.set(o, (Object) null);
                } catch (NoSuchFieldException var10) {
                    log.error(var10.getMessage());
                } catch (SecurityException var11) {
                    log.error(var11.getMessage());
                } catch (IllegalArgumentException var12) {
                    log.error(var12.getMessage());
                } catch (IllegalAccessException var13) {
                    log.error(var13.getMessage());
                }
            }
        }

    }

    public static synchronized void includeField(Object obj, String... values) {
        if (obj != null) {
            Class<?> classzz = obj.getClass();
            Field[] dfs = classzz.getDeclaredFields();
            Map<String, String> data = new HashMap();
            String[] var8 = values;
            int var7 = values.length;

            int var6;
            for (var6 = 0; var6 < var7; ++var6) {
                String v = var8[var6];
                data.put(v, v);
            }

            Field[] var14 = dfs;
            var7 = dfs.length;

            for (var6 = 0; var6 < var7; ++var6) {
                Field f = var14[var6];
                f.setAccessible(true);
                String name = f.getName();
                if (data.get(name) == null) {
                    try {
                        f.set(obj, (Object) null);
                    } catch (IllegalArgumentException var11) {
                        log.error(var11.getMessage());
                    } catch (IllegalAccessException var12) {
                        log.error(var12.getMessage());
                    }
                }
            }

        }
    }

    public static synchronized void includeFields(List<?> objs, String... values) {
        if (objs != null) {
            Iterator var3 = objs.iterator();

            while (var3.hasNext()) {
                Object o = var3.next();
                Class<?> classzz = o.getClass();
                Field[] dfs = classzz.getDeclaredFields();
                Map<String, String> data = new HashMap();
                String[] var10 = values;
                int var9 = values.length;

                int var8;
                for (var8 = 0; var8 < var9; ++var8) {
                    String v = var10[var8];
                    data.put(v, v);
                }

                Field[] var15 = dfs;
                var9 = dfs.length;

                for (var8 = 0; var8 < var9; ++var8) {
                    Field f = var15[var8];
                    f.setAccessible(true);
                    String name = f.getName();
                    if (data.get(name) == null) {
                        try {
                            f.set(o, (Object) null);
                        } catch (IllegalArgumentException var13) {
                            log.error(var13.getMessage());
                        } catch (IllegalAccessException var14) {
                            log.error(var14.getMessage());
                        }
                    }
                }
            }

        }
    }
}
