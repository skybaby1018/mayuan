//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import com.qcloud.cos.utils.StringUtils;
import com.sun.management.OperatingSystemMXBean;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

@Component
public class Utils {
    private static final Logger log = LoggerFactory.getLogger(Utils.class);
    private static final char[] HEXES = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    @Value("${spring.datasource.game.username}")
    private String username;
    @Value("${spring.datasource.game.password}")
    private String password;
    @Value("${spring.datasource.game.url}")
    private String url;
    @Value("${spring.datasource.game.driverClassName}")
    private String driverClassName;
    public static final String authName = "admin";
    public static final String authPassword = "admin123";

    public Utils() {
    }

    public static boolean compareHourOfMinute(String time) {
        boolean flag = false;
        if (!StringUtils.isNullOrEmpty(time)) {
            String currTime = DateUtil.format(new Date(), "H:mm:ss");
            if (currTime.equals(time)) {
                flag = true;
            }
        }

        return flag;
    }

    public static boolean compareHourOfMinute(String time, String pattern) {
        boolean flag = false;
        if (!StringUtils.isNullOrEmpty(time)) {
            String currTime = DateUtil.format(new Date(), pattern);
            if (currTime.equals(time)) {
                flag = true;
            }
        }

        return flag;
    }

    public static String getWeek() {
        String week = "";
        Date today = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(today);
        int weekday = c.get(7);
        if (weekday == 1) {
            week = "周日";
        } else if (weekday == 2) {
            week = "周一";
        } else if (weekday == 3) {
            week = "周二";
        } else if (weekday == 4) {
            week = "周三";
        } else if (weekday == 5) {
            week = "周四";
        } else if (weekday == 6) {
            week = "周五";
        } else if (weekday == 7) {
            week = "周六";
        }

        return week;
    }

    public static File getResFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            //file = new File("config/" + filename);
            file = new File(filename);
        }

        FileSystemResource resource = new FileSystemResource(file);
        if (!resource.exists()) {
            try {
                file = ResourceUtils.getFile("classpath:" + filename);
            } catch (FileNotFoundException var4) {
                log.error("读取{}文件失败", filename);
            }
        }

        return file;
    }

    private static final String[] windowsCommand = { "ipconfig", "/all" };
    private static final String[] linuxCommand = { "/sbin/ifconfig", "-a" };
    private static final Pattern macPattern = Pattern.compile(".*((:?[0-9a-f]{2}[-:]){5}[0-9a-f]{2}).*",
            Pattern.CASE_INSENSITIVE);
    /**
     * 获取多个网卡地址
     *
     * @return
     * @throws IOException
     */
    private final static List<String> getMacAddressList() throws IOException {
        final ArrayList<String> macAddressList = new ArrayList<String>();
        final String os = System.getProperty("os.name");
        final String command[];

        if (os.startsWith("Windows")) {
            command = windowsCommand;
        } else if (os.startsWith("Linux")) {
            command = linuxCommand;
        } else {
            throw new IOException("Unknow operating system:" + os);
        }
        // 执行命令
        final Process process = Runtime.getRuntime().exec(command);

        BufferedReader bufReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        for (String line = null; (line = bufReader.readLine()) != null;) {
            Matcher matcher = macPattern.matcher(line);
            if (matcher.matches()) {
//                macAddressList.add(matcher.group(1));
                 macAddressList.add(matcher.group(1).replaceAll("[-:]", "").toUpperCase());//去掉MAC中的“-”
            }
        }
        process.destroy();
        bufReader.close();
        return macAddressList;
    }


    public static String getLocalMac() {
        StringBuffer sb = new StringBuffer(); // 存放多个网卡地址用，目前只取一个非0000000000E0隧道的值
        try {
            List<String> macList = getMacAddressList();
            for (Iterator<String> iter = macList.iterator(); iter.hasNext();) {
                String amac = iter.next();
                if (!amac.equals("0000000000E0")) {
                    sb.append(amac);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
//        byte[] mac = null;
//
//        try {
//            InetAddress localHost = InetAddress.getLocalHost();
//            mac = NetworkInterface.getByInetAddress(localHost).getHardwareAddress();
//        } catch (Exception var5) {
//            ;
//        }
//
//        StringBuffer sb = new StringBuffer("");
//
//        for (int i = 0; i < mac.length; ++i) {
//            int temp = mac[i] & 255;
//            String str = Integer.toHexString(temp);
//            if (str.length() == 1) {
//                sb.append("0" + str);
//            } else {
//                sb.append(str);
//            }
//        }
//        return sb.toString().toUpperCase();
    }

    public static Map<String, Long> calculationTime(Date lockTime) {
        long nd = 86400000L;
        long nh = 3600000L;
        long nm = 60000L;
        long ns = 1000L;
        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long day = 0L;
        long hour = 0L;
        HashMap timeMap = new HashMap();

        try {
            long diff = sd.parse(sd.format(new Date())).getTime() - sd.parse(sd.format(lockTime)).getTime();
            day = diff / nd;
            hour = diff % nd / nh;
            long min = diff % nd % nh / nm;
            long sec = diff % nd % nh % nm / ns;
            timeMap.put("day", day);
            timeMap.put("hours", day * 24L + hour);
            timeMap.put("hour", hour);
            timeMap.put("min", min);
            timeMap.put("sec", sec);
            Iterator var22 = timeMap.entrySet().iterator();

            while (var22.hasNext()) {
                Entry<String, Long> s = (Entry) var22.next();
            }
        } catch (ParseException var23) {
            var23.printStackTrace();
        }

        return timeMap;
    }

    public static String getGapTime(long time) {
        long hours = time / 3600000L;
        long minutes = (time - hours * 3600000L) / 60000L;
        String diffTime = "";
        if (minutes < 10L) {
            diffTime = hours + "小时" + minutes + "分钟";
        } else {
            diffTime = hours + "小时" + minutes + "分钟";
        }

        return diffTime;
    }

    public static String read(InputStream is) {
        BufferedReader br = null;

        try {
            InputStreamReader fr = new InputStreamReader(is, "UTF-8");
            br = new BufferedReader(fr);
        } catch (IOException var3) {
            log.error("读取文件失败,{}", var3.getMessage());
            System.exit(0);
        }

        StringBuilder sb = new StringBuilder();
        br.lines().forEach((f) -> {
            sb.append(f);
        });
        return sb.toString();
    }

    public static String replaceBom(String str) {
        char[] bomChar = str.toCharArray();
        char[] noneBomchar = new char[bomChar.length - 1];

        for (int j = 0; j < noneBomchar.length; ++j) {
            noneBomchar[j] = bomChar[j + 1];
        }

        return String.valueOf(noneBomchar);
    }

    public static void removeDuplicateWithOrder(List list) {
        Set set = new HashSet();
        List newList = new ArrayList();
        Iterator iter = list.iterator();

        while (iter.hasNext()) {
            Object element = iter.next();
            if (set.add(element)) {
                newList.add(element);
            }
        }

        list.clear();
        list.addAll(newList);
    }

    public static boolean isNumber(String number) {
        return StringUtils.isNullOrEmpty(number) ? false : number.matches("^[-\\+]?[\\d]*$");
    }

    public static boolean isAlpha(String alpha) {
        return alpha == null ? false : alpha.matches("[a-zA-Z]+");
    }

    public static boolean isChinese(String chineseContent) {
        return chineseContent == null ? false : chineseContent.matches("[A-Za-z0-9\\u4e00-\\u9fa5]");
    }

    public static boolean validateNickName(String nickName) {
        boolean flag = false;
        if (isNumber(nickName) && isAlpha(nickName) && isChinese(nickName)) {
            flag = true;
        }

        return flag;
    }

    public static int getAvailableRam() {
        OperatingSystemMXBean mem = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        return (int) (mem.getFreePhysicalMemorySize() / 1024L / 1024L);
    }

    public static int findNumber(String str) {
        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return Integer.valueOf(m.replaceAll(""));
    }

    public static String bytes2Hex(byte[] bytes) {
        if (bytes != null && bytes.length != 0) {
            StringBuilder hex = new StringBuilder();
            byte[] var5 = bytes;
            int var4 = bytes.length;

            for (int var3 = 0; var3 < var4; ++var3) {
                byte b = var5[var3];
                hex.append(HEXES[b >> 4 & 15]);
                hex.append(HEXES[b & 15]);
                hex.append(" ");
            }

            return hex.toString().toUpperCase();
        } else {
            return null;
        }
    }

    public static String autoGenericCode(String code, int num) {
        String result = "";
        result = String.format("%0" + num + "d", Integer.parseInt(code));
        return result;
    }

    public static void printStack(StackTraceElement[] stacks) {
        StackTraceElement[] var4 = stacks;
        int var3 = stacks.length;

        for (int var2 = 0; var2 < var3; ++var2) {
            StackTraceElement s = var4[var2];
            System.out.println("方法名：dao" + s.getMethodName() + "类名dao：" + s.getClassName() + "行数：" + s.getLineNumber() + "文件名：" + s.getFileName() + "----" + s);
        }

    }

    public static boolean exportDatabaseTool(String hostIP, String userName, String password, String savePath, String fileName, String databaseName) throws InterruptedException {
        File saveFile = new File(savePath);
        if (!saveFile.exists()) {
            saveFile.mkdirs();
        }

        if (!savePath.endsWith(File.separator)) {
            savePath = savePath + File.separator;
        }

        PrintWriter printWriter = null;
        BufferedReader bufferedReader = null;

        try {
            printWriter = new PrintWriter(new OutputStreamWriter(new FileOutputStream(savePath + fileName), "utf8"));
            Process process = Runtime.getRuntime().exec(" mysqldump -h" + hostIP + " -u" + userName + " -p" + password + " --set-charset=UTF8 " + databaseName);
            InputStreamReader inputStreamReader = new InputStreamReader(process.getInputStream(), "utf8");
            bufferedReader = new BufferedReader(inputStreamReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                printWriter.println(line);
            }

            printWriter.flush();
            if (process.waitFor() != 0) {
                return false;
            }
        } catch (IOException var21) {
            var21.printStackTrace();
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }

                if (printWriter != null) {
                    printWriter.close();
                }
            } catch (IOException var20) {
                var20.printStackTrace();
            }

        }

        return true;
    }

    public static Map<String, Object> objectToMap(Object obj) throws IllegalAccessException {
        Map<String, Object> map = new HashMap();
        Class<?> clazz = obj.getClass();
        Field[] var6;
        int var5 = (var6 = clazz.getDeclaredFields()).length;

        for (int var4 = 0; var4 < var5; ++var4) {
            Field field = var6[var4];
            field.setAccessible(true);
            String fieldName = field.getName();
            Object value = field.get(obj);
            map.put(fieldName, value);
        }

        return map;
    }
}
