//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.util.Collections;
import java.util.List;

public class CollectionsUtil {
    public CollectionsUtil() {
    }

    public static <T> void swap1(List<T> list, int oldPosition, int newPosition) {
        if (list == null) {
            throw new IllegalStateException("The list can not be empty...");
        } else {
            T tempElement = list.get(oldPosition);
            int i;
            if (oldPosition < newPosition) {
                for (i = oldPosition; i < newPosition; ++i) {
                    list.set(i, list.get(i + 1));
                }

                list.set(newPosition, tempElement);
            }

            if (oldPosition > newPosition) {
                for (i = oldPosition; i > newPosition; --i) {
                    list.set(i, list.get(i - 1));
                }

                list.set(newPosition, tempElement);
            }

        }
    }

    public static <T> void swap2(List<T> list, int oldPosition, int newPosition) {
        if (list == null) {
            throw new IllegalStateException("The list can not be empty...");
        } else {
            int i;
            if (oldPosition < newPosition) {
                for (i = oldPosition; i < newPosition; ++i) {
                    Collections.swap(list, i, i + 1);
                }
            }

            if (oldPosition > newPosition) {
                for (i = oldPosition; i > newPosition; --i) {
                    Collections.swap(list, i, i - 1);
                }
            }

        }
    }
}
