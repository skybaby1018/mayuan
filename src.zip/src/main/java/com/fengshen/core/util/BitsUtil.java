package com.fengshen.core.util;

public class BitsUtil {
    public static boolean isSet(int value, int bitIndex) {
        //bitIndex 的取值范围是0~31
        int bitValue = 1 << bitIndex;
        return (value & bitValue) == bitValue;
    }

    public static int setBits(int value, int bitIndex) {
        //bitIndex 的取值范围是0~31
        int bitValue = 1 << bitIndex;
        return (value | bitValue);
    }

    public static void main(String[] args) {
        int attrib = 1;
        attrib = setBits(attrib, 3);
        System.out.println(attrib);
////        System.out.println(attrib);
//        attrib = setBits(attrib, 14);
//        System.out.println(attrib);
////        attrib = setBits(attrib, 6);
////        System.out.println(attrib);
////        attrib = setBits(attrib, 9);
////        System.out.println(attrib);

    }

}
