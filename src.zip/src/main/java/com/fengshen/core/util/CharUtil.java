//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.util;

import java.util.Random;

public class CharUtil {
    public CharUtil() {
    }

    public static String getRandomString(final Integer num) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < num; ++i) {
            int number = random.nextInt("abcdefghijklmnopqrstuvwxyz0123456789".length());
            sb.append("abcdefghijklmnopqrstuvwxyz0123456789".charAt(number));
        }

        return sb.toString();
    }

    public static String getRandomNum(final Integer num) {
        String base = "0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < num; ++i) {
            int number = random.nextInt("0123456789".length());
            sb.append("0123456789".charAt(number));
        }

        return sb.toString();
    }
}
