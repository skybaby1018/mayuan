//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.exception;

import com.fengshen.core.util.ResponseView;

public class UnauthorizedException extends SuperException {
    private static final long serialVersionUID = 7147829327106595761L;

    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(ResponseView rv) {
        super(rv);
    }

    public UnauthorizedException() {
    }
}
