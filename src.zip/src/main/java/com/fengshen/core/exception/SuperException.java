//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.core.exception;

import com.fengshen.core.util.ResponseView;

import java.util.Map;

public class SuperException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private Map<String, Object> resultMap;
    private String retmsg;
    private ResponseView rv;

    public SuperException(String message) {
        super(message);
    }

    public SuperException(ResponseView rv) {
        super((String) rv.get("retmsg"));
        this.retmsg = (String) rv.get("retmsg");
        this.rv = rv;
    }

    public SuperException(Map<String, Object> resultMap) {
        this.resultMap = resultMap;
    }

    public SuperException() {
    }

    public Map<String, Object> getResultMap() {
        return this.resultMap;
    }

    public void setResultMap(Map<String, Object> resultMap) {
        this.resultMap = resultMap;
    }

    public String getRetmsg() {
        return this.retmsg;
    }

    public void setRetmsg(String retmsg) {
        this.retmsg = retmsg;
    }

    public ResponseView getRv() {
        return this.rv;
    }

    public void setRv(ResponseView rv) {
        this.rv = rv;
    }
}
