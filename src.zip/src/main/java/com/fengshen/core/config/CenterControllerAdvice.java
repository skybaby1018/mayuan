package com.fengshen.core.config;

import com.fengshen.core.exception.SuperException;
import com.fengshen.core.exception.UnauthorizedException;
import com.fengshen.core.util.ErrorCode;
import com.fengshen.core.util.ResponseView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.util.NestedServletException;

@RestControllerAdvice
public class CenterControllerAdvice {
    private static final Logger log = LoggerFactory.getLogger(CenterControllerAdvice.class);

    @ExceptionHandler({SuperException.class})
    public ResponseView handlerException(HttpServletRequest request, SuperException ex) {
        ResponseView rv = ex.getRv();
        if (rv == null) {
            rv = new ResponseView();
            if (ex.getMessage() == null) {
                rv.put("retmsg", "系统异常");
            }

            rv.put("status", ErrorCode.ERROR);
            rv.put("retcode", ErrorCode.ERROR);
        }

        ex.setRetmsg((String) rv.get("retmsg"));
        log.error((String) rv.get("retmsg"), ex);
        return rv;
    }

    @ExceptionHandler({NestedServletException.class, HttpMediaTypeNotAcceptableException.class})
    public ResponseView handlerException(HttpServletRequest request, HttpServletResponse response, NestedServletException ex) {
        log.error("service not found", ex);
        return this.settings("service not found");
    }

    @ExceptionHandler({UnauthorizedException.class})
    public ResponseView handlerException(HttpServletRequest request, HttpServletResponse response, UnauthorizedException ex) {
        ResponseView rv = ex.getRv();
        if (rv == null) {
            rv = new ResponseView();
            if (ex.getMessage() == null) {
                rv.put("retmsg", "系统异常");
            }

            rv.put("status", ErrorCode.UNAUTHORIZED);
            rv.put("retcode", ErrorCode.UNAUTHORIZED);
        }

        response.setStatus(401);
        ex.setRetmsg((String) rv.get("retmsg"));
        log.error((String) rv.get("retmsg"), ex);
        return rv;
    }

    @ExceptionHandler({DataIntegrityViolationException.class})
    public ResponseView handlerException(HttpServletRequest request, DataIntegrityViolationException exception) {
        String errorMsg = exception.getMessage();
        if (errorMsg.indexOf("ORA-02291") >= 0) {
            errorMsg = "删除失败，该条记录被引用";
        } else if (errorMsg.indexOf("ORA-02292") >= 0) {
            errorMsg = "添加失败，引用记录不存在";
        } else if (errorMsg.indexOf("MySQLIntegrityConstraintViolationException") >= 0) {
            errorMsg = "添加失败，相同记录已存在";
        } else {
            errorMsg = "数据存取失败，请检查数据正确性";
        }

        log.error("数据违反唯一约束条件", exception);
        return this.settings(errorMsg);
    }

    @ExceptionHandler({CannotGetJdbcConnectionException.class})
    public ResponseView handlerExpcetion(HttpServletRequest request, CannotGetJdbcConnectionException exception) {
        log.error("数据库连接超时", exception);
        return this.settings("数据库连接超时");
    }

    @ExceptionHandler({MissingServletRequestParameterException.class})
    public ResponseView handlerException(HttpServletRequest request, MissingServletRequestParameterException exception) {
        log.error("系统异常", exception);
        ResponseView rv = new ResponseView();
        rv.put("status", ErrorCode.ERROR);
        rv.put("successResponse", false);
        String retmsg = exception.getMessage().replaceAll("[^一-龥]", "");
        rv.put("retmsg", retmsg);
        rv.put("retcode", ResponseView.getErrorCodeName(retmsg));
        return rv;
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    public ResponseView handlerException(HttpServletRequest request, HttpRequestMethodNotSupportedException exception) {
        log.error("请求类型不正确", exception);
        return this.settings("请求类型不正确");
    }

    @ExceptionHandler({BindException.class})
    public ResponseView handlerException(BindException exception) {
        log.error("参数类型错误", exception);
        return this.settings("参数类型错误");
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    public ResponseView handlerException(HttpServletRequest request, HttpMessageNotReadableException exception) {
        log.error(exception.getMessage());
        ResponseView rv = new ResponseView();
        rv.put("title", "json数据序列化错误.");
        rv.put("retmsg", exception.getMessage());
        rv.put("retcode", 107);
        rv.put("status", 500);
        return rv;
    }

    @ExceptionHandler({RuntimeException.class})
    public ResponseView handlerException(HttpServletRequest request, RuntimeException exception) {
        log.error("业务方法执行异常:", exception);
        return this.settings("系统异常");
    }

    @ExceptionHandler({Exception.class})
    public ResponseView handlerException(HttpServletRequest request, Exception e) {
        log.error("系统异常", e);
        return this.settings("系统异常");
    }

    @ExceptionHandler({Throwable.class})
    public ResponseView handlerException(HttpServletRequest request, Throwable e) {
        log.error("系统异常", e);
        return this.settings("系统异常");
    }

    public ResponseView settings(String retmsg) {
        ResponseView rv = new ResponseView();
        rv.put("retmsg", retmsg);
        rv.put("status", ErrorCode.ERROR);
        rv.put("retcode", ResponseView.getErrorCodeName(retmsg));
        return rv;
    }

    protected final class SQLExceptionMsgConst {
        public static final String MSG_DELETE_FAILED_REFERENCED = "删除失败，该条记录被引用";
        public static final String MSG_INSERT_FAILED_NOPARENT = "添加失败，引用记录不存在";
        public static final String MSG_INSERT_FAILED_NOTUNIQUE = "添加失败，相同记录已存在";
        public static final String E102 = "数据存取失败，请检查数据正确性";

        protected SQLExceptionMsgConst() {
        }
    }
}
