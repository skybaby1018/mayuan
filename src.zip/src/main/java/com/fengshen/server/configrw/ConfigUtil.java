package com.fengshen.server.configrw;

import com.fengshen.db.domain.SysConfig;
import com.fengshen.server.game.GameData;

import java.lang.reflect.Field;
import java.util.List;

public class ConfigUtil {
    public static RewardConfig reward;
    public static StartConfig start;
    public static RenwuConfig renwu;
    public static RegConfig reg;
    public static OtherConfig other;

    public static void InitConfig() {
        try {
            ConfigUtil.start = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("start-config"), StartConfig.class);
            ConfigUtil.other = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("other-config"), OtherConfig.class);
            ConfigUtil.reg = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("reg-config"), RegConfig.class);
            ConfigUtil.renwu = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("renwu-config"), RenwuConfig.class);
            ConfigUtil.reward = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("reward-config"), RewardConfig.class);
        } catch (Exception ex) {
        }
    }

    public static <T> T LoadConfig(List<SysConfig> sysConfigs, Class<T> toClass) throws Exception {
        final Field[] declaredFields = toClass.getDeclaredFields();
        final T config = toClass.newInstance();
        for (SysConfig sysConfig : sysConfigs) {
            for (Field field : declaredFields) {
                field.setAccessible(true);
                if (field.getName().equals(sysConfig.getKey())) {
                    String type = field.getType().toString();
                    Object value = null;
                    if (type.equals("class java.lang.String")) {
                        value = String.valueOf(sysConfig.getValue());
                    } else if (type.equals("class java.lang.Integer")) {
                        value = Integer.valueOf(sysConfig.getValue());
                    } else if (type.equals("int")) {
                        value = Integer.valueOf(sysConfig.getValue());
                    } else if (type.equals("boolean")) {
                        value = Boolean.valueOf(sysConfig.getValue());
                    } else if (type.equals("double")) {
                        value = Double.valueOf(sysConfig.getValue());
                    }
                    field.set(config, value);
                }
            }
        }
        return config;
    }

    public static void reloadConfig(String parentKey) {
        try {
            final List<SysConfig> sysConfigs = GameData.that.sysConfig.getSysConfigByParentKey(parentKey);
            if (parentKey.indexOf("start") != -1) {
                ConfigUtil.start = LoadConfig(sysConfigs, StartConfig.class);
            } else if (parentKey.indexOf("other") != -1) {
                ConfigUtil.other = LoadConfig(sysConfigs, OtherConfig.class);
            } else if (parentKey.indexOf("reg") != -1) {
                ConfigUtil.reg = LoadConfig(sysConfigs, RegConfig.class);
            } else if (parentKey.indexOf("renwu") != -1) {
                ConfigUtil.renwu = LoadConfig(sysConfigs, RenwuConfig.class);
            } else if (parentKey.indexOf("reward") != -1) {
                ConfigUtil.reward = LoadConfig(sysConfigs, RewardConfig.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
