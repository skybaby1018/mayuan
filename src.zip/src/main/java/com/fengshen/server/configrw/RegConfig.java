package com.fengshen.server.configrw;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component("RegConfig")
@ConfigurationProperties(prefix = "reg-config")
public class RegConfig {
    private int extra_life;
    private int gold_coin;
    private int shadow_self;
    private int reg_length;
    private int reg_jifen;
}
