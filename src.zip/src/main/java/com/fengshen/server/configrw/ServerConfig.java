package com.fengshen.server.configrw;

public interface ServerConfig {
    public static final String SERVER = "http://47.105.122.53";
}
