package com.fengshen.server.configrw;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 数据库config配置 每天5点刷新
 */
@Data
@Component("renwuConfig")
@ConfigurationProperties(prefix = "renwu-config")
public class RenwuConfig {
    private int resetTime;
    private int pkguaiwuNum;
    private int shimenNum;
    private int fubenNum;
    private int tttNum;
    private int tttTp;
    private int chubaoNum;
    private int xiuxingNum;
    private int shuadaoNum;
    private int baibangmangNum;
    private int baxianNum;
    private int fabaoNum;
    private String petfly;
    private String persionfly;
    private String shidaoDays;
    private int shidao_min_level;
    private String shidaoTimes;
    private String shidaojdTimes;
    private boolean shidaodebug;
    private String boss_flush_time;
    private int partyNum;
    private String taskMap;
    private int licai_Sigin;
    private int partyFightNum;
    private int party_large_amount;
    private int party_small_amount;
    private int zhengdaodiancishu;//证道殿挑战次数
    private int mapguardcishu; //地图守护神
    private int pkdaohang;
    private int pkqianneng;
    private int pkjingyan;
    private int pkjifen;
    private int haidaocishu; //海盗次数
    private int shanggucishu;//上古次数
    private int leaderTodayFailNum;//掌门挑战次数
    private int xingtiaozhancishu;//星挑战次数
    private int gongchengbooscishu;//攻城boos挑战次数
    private int heropubcishu;//英雄会次数
    private int laofangtime;//坐牢结束时间
}
