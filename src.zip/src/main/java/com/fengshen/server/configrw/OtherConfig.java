package com.fengshen.server.configrw;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component("otherConfig")
@ConfigurationProperties(prefix = "other-config")
public class OtherConfig {
    private int pet_max_level;
    private int persion_max_level;
    private int yy_max_level;
    private int fy_length;
    private String fy_char;
    private String fy_replace;
    private int fy_level;
    private double cj_time;
    private String wudao_xiaohaos;
    private String wudao_shuxings;
    private boolean openRank;
    private boolean openWuxing;
    private String wuxing_gailv;
    private String menpai_tab_xiaohao;
    private int max_menpai_tab_num;
    private int max_request_count;
    private int goods_jinhua_max;
    private double fs_bs_bei;
    private double fa_panel_bei;
    private double wu_panel_bei;
    private double xue_panel_bei;
    private double lan_panel_bei;
    private double su_panel_bei;
    private double fang_panel_bei;
    private double pet_fa_panel_bei;
    private double pet_wu_panel_bei;
    private double pet_xue_panel_bei;
    private double pet_lan_panel_bei;
    private double pet_su_panel_bei;
    private double pet_fang_panel_bei;
    private int ss_qh_addvalue;
    private int card_time;
    private boolean zb_gz_success;
    private Boolean is_open_chargefy;
    private int pet_max_qh;
    private int charge_money_fy;
}
