package com.fengshen.server.configrw;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("rewardConfig")
@ConfigurationProperties(prefix = "reward-config")
@Data
public class RewardConfig {
    private double shimen_timesJingyan;
    private int tttTimes;
    private int fbTimes;
    private double timesJingyan;
    private double timesDaohang;
    private String tttReward;
    private String tttgtReward;
    private String tttSuccessReward;
    private String fubenReward;
    private String bossReward;
    private String qishaReward;
    private String shidao_one_reward;
    private String shidao_two_reward;
    private String shidao_three_reward;
    private String lc_charge_text;
    private int charge_addCjNum;
    private String wabao_tedeng_reward;
    private String wabao_yideng_reward;
    private String wabao_erdeng_reward;
    private String wabao_sandeng_reward;
    private double wabao_te_gailv;
    private double wabao_yi_gailv;
    private double wabao_er_gailv;
    private double wabao_san_gailv;
    private int yaowang_max_num;
    private String sg_reward;
    private int sg_exp_ten;
    private double sg_out_gailv;
    private String yuanmo_reward;
    private String duihuanchenghao;//怒气值兑换称号
    private String duihuanjingguai;//怒气值兑换精怪
    private int qiangsha_increase_nuqizhi;//强杀每次增加怒气值
    private int qiangsha_reduce_nuqizhi;//强杀每次减少怒气值
    private int qiangsha_taopao_jifen;//强杀逃跑
    private int qiangsha_baoshi_reduce;//保释消耗积分
    private String zhashenlong_xiaobailong;//炸小白龙奖励
    private String zhashenlong_honglong;//炸红龙奖励

    /**
     * 擂台奖励
     */
    private String leitai_2000_reward;
    private String leitai_4000_reward;
    private String leitai_7000_reward;
    private String leitai_13000_reward;
    private String leitai_11_100_reward;
    private String leitai_1_10_reward;

    private int leitai_jifen; //擂台积分

    private int leitai_pk_reduce_jifen;//擂台PK减少多少积分
    private int leitai_pk_increase_jifen;//擂台增加多少积分

    private int TodayChallengeNum;//竞技场挑战次数

    private int yuanyqiehuan;//元婴切换消耗积分

    private String moren_chenhao;//默认称号

    private int jingyanbaishu;//经验倍数

    private int qiannengbeishu;//潜能倍数

    private int daohangbeishu; //道行倍数

    private int sg_mial_date; //上古存活时间，或者，选中人邮件存活时间

    private int diyibo_haidao_num;//第一波海盗数量

    private int dierbo_haidao_num;//第二波海盗数量

    private int disanbo_haidao_num;//第三波海盗数量

    private int dierbo_haidao_date;//第二波海盗入侵时间

    private int disanbo_haidao_date;//第三波海盗入侵时间

    private int haidao_duiwu_renshu;//海盗队伍人数
    private int kaiqi_qiangsha; //开启强P消耗积分

    private int fabao_qinmi_dianshu;

    /**
     * \
     * 海盗奖励
     */
    private String haidao_60_jiangli;
    private String haidao_70_jiangli;
    private String haidao_80_jiangli;
    private String haidao_90_jiangli;
    private String haidao_100_jiangli;
    private String haidao_110_jiangli;
    private String haidao_120_jiangli;
    private String haidao_130_jiangli;
    private String haidao_140_jiangli;

    /**
     * 海盗死亡惩罚
     */
    private int haidao_siw_chengfa_jingy;
    private int haidao_siw_chengfa_daoh;
    private int haidao_siw_chengfa_qiann;
    private int suipian_duihuan_caifeng;//碎片兑换彩凤
    private int wendaoqing_duihuan; //问道情消耗兑换
    private String wendaoqing_duihuan_jiangli;  //问道情兑换奖励
    private int zhouniandangao_duihuan;//周年蛋糕消耗兑换
    private String zhouniandangao_duihuan_jiangli; //周年蛋糕兑换奖励
    private String xinshoufuli;//新手福利
    private String jiangli_qiegao;//刷道而外奖励
    private String jiangli_wendaoqing;//而外奖励问道情

    //充值排行榜奖励
    private String charge_ranking_first_reward;
    private String charge_ranking_two_reward;
    private String charge_ranking_third_reward;
    private String charge_ranking_four_reward;
    private String charge_ranking_five_reward;
    //单笔充值奖励
    private String single_charge_text;
}
