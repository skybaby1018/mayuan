package com.fengshen.server.configrw;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component("startConfig")
@ConfigurationProperties(prefix = "start-config")
public class StartConfig {
    private int lineNum;
    private boolean isOpenJs;
    private boolean cmdDebug;
    private boolean moveDebug;
    private boolean lenDebug;
    private boolean msgDebug;
    private boolean getDebug;
}
