package com.fengshen.server.auth;

import javax.swing.Icon;

import com.fengshen.core.util.Utils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.boot.CommandLineRunner;

@Component
@Order(0)
public class ProjectStarterSuccess implements CommandLineRunner {
    public void run(final String... args) throws Exception {
        if (Utils.getLocalMac().equals("488AD2BD5FE8") && Utils.getLocalMac().equals("005056C00001")) {
            LoginAuth.success.setIcon(null);
            LoginAuth.success.setText("欢迎使用-" + LoginAuth.gameName);
            LoginAuth.openManage.setVisible(true);
            LoginAuth.timeOutError.cancel();
        }
    }
}
