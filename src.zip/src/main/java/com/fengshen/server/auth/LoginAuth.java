package com.fengshen.server.auth;

import java.awt.HeadlessException;
import java.io.InputStream;

import com.fengshen.server.game.*;
import org.springframework.boot.SpringApplication;
import com.fengshen.GameServerApplication;

import javax.swing.ImageIcon;
import java.io.ByteArrayOutputStream;

import com.fengshen.server.util.GameConfig;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.util.Date;
import java.io.File;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

import com.fengshen.server.job.SaveCharaTimes;

import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import javax.imageio.ImageIO;

import org.springframework.core.io.ClassPathResource;

import java.util.List;

import com.fengshen.server.data.write.MSG_KICK_OFF;

import java.util.TimerTask;

import com.fengshen.core.util.DateUtil;
import com.alibaba.fastjson.JSONObject;

import java.io.IOException;
import javax.swing.JOptionPane;
import java.nio.file.Files;

import com.fengshen.core.util.Utils;
import org.slf4j.LoggerFactory;

import java.util.Timer;
import java.awt.TrayIcon;
import java.awt.SystemTray;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.image.BufferedImage;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Container;
import javax.swing.JFrame;

import org.slf4j.Logger;

public class LoginAuth {
    private static final Logger log;
    public static JFrame jFrame;
    private Container c;
    private JTextField username;
    private JPasswordField password;
    private BufferedImage image;
    private JPanel titlePanel;
    private JPanel fieldPanel;
    private JPanel buttonPanel;
    private static String locaMac;
    public static JLabel lable;
    public static JLabel success;
    public static JButton openManage;
    private SystemTray systemTray;
    private TrayIcon trayIcon;
    public static Timer timeOutError;
    public static String gameName;

    static {
        log = LoggerFactory.getLogger(LoginAuth.class);
        LoginAuth.jFrame = new JFrame("登录");
        LoginAuth.gameName = "";
    }

    public LoginAuth() {
        this.c = LoginAuth.jFrame.getContentPane();
        this.username = new JTextField();
        this.password = new JPasswordField();
        this.image = null;
    }

    public void run() throws Exception {
        LoginAuth.gameName = "稳如泰山";
        String jsonStr = "";
        try {
            final File resFile = Utils.getResFile("secret.key");
            final byte[] readAllBytes = Files.readAllBytes(resFile.toPath());
            jsonStr = new String(readAllBytes);
        } catch (IOException e2) {
            JOptionPane.showMessageDialog(null, "启动失败,授权文件不存在,程序即将退出", "授权失败", 0);
            System.exit(-1);
        }
        try {
            final JSONObject parseObject = JSONObject.parseObject(GameCommonUtil.abc(jsonStr));
            LoginAuth.locaMac = parseObject.getString("mac");
            final String endTime = parseObject.getString("endTime");
            final Date parse = DateUtil.getSdf("yyyy-MM-dd H:mm").parse(endTime);
            if (parse == null) {
                JOptionPane.showMessageDialog(null, "授权时间已过期", "授权失败", 0);
                System.exit(-1);
                return;
            }
            final long currentTime = DateUtil.getWebsiteDatetime().getTime();
            if (currentTime > parse.getTime()) {
                JOptionPane.showMessageDialog(null, "授权时间已过期", "授权失败", 0);
                return;
            }
            final long time = parse.getTime() - currentTime;
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    try {
                        GameCore.isExpire.set(true);
                        final List<GameObjectChar> all = GameObjectCharMng.getAll();
                        for (final GameObjectChar game : all) {
                            GameUtil.kickOff(game);
                        }
                    } finally {
                        JOptionPane.showMessageDialog(null, "授权时间已过期", "授权失败", 0);
                        System.exit(-1);
                    }
                    JOptionPane.showMessageDialog(null, "授权时间已过期", "授权失败", 0);
                    System.exit(-1);
                }
            }, time);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "授权文件异常,程序即将退出", "授权失败", 0);
            System.exit(-1);
            return;
        }
        if (SystemTray.isSupported()) {
            this.systemTray = SystemTray.getSystemTray();
            (this.trayIcon = new TrayIcon(ImageIO.read(new ClassPathResource("game.png").getInputStream()))).setImageAutoSize(true);
            this.systemTray.add(this.trayIcon);
            this.trayIcon.setToolTip(LoginAuth.gameName);
            LoginAuth.jFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowIconified(final WindowEvent e) {
                    LoginAuth.jFrame.dispose();
                }

                @Override
                public void windowClosing(final WindowEvent e) {
                    LoginAuth.success.setText("正在存档，请勿强制关闭,,");
                    final int response = JOptionPane.showConfirmDialog(null, "确认关闭吗？", "关闭程序", 0);
                    if (response == 0) {
                        LoginAuth.jFrame.setDefaultCloseOperation(3);
                        final List<GameObjectChar> all = GameObjectCharMng.getAll();
                        for (final GameObjectChar gameSession : all) {
                            if (gameSession.chara != null) {
                                SaveCharaTimes.saveCharaInfo(gameSession);
                            }
                        }
                        System.exit(0);
                    } else {
                        LoginAuth.jFrame.setDefaultCloseOperation(0);
                        LoginAuth.success.setText("欢迎使用-" + LoginAuth.gameName);
                    }
                }
            });
            this.trayIcon.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(final MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        LoginAuth.jFrame.setExtendedState(0);
                    }
                    LoginAuth.jFrame.setVisible(true);
                }
            });
        }
        try {
            final ClassPathResource c = new ClassPathResource("game.png");
            this.image = ImageIO.read(c.getInputStream());
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        LoginAuth.jFrame.setIconImage(this.image);
        LoginAuth.jFrame.setSize(320, 220);
        final Toolkit kit = Toolkit.getDefaultToolkit();
        final Dimension screenSize = kit.getScreenSize();
        final int screenWidth = screenSize.width / 2;
        final int screenHeight = screenSize.height / 2;
        final int height = LoginAuth.jFrame.getHeight();
        final int width = LoginAuth.jFrame.getWidth();
        LoginAuth.jFrame.setLocation(screenWidth - width / 2, screenHeight - height / 2);
        this.c.setLayout(new BorderLayout());
        LoginAuth.jFrame.setDefaultCloseOperation(3);
        this.init();
        LoginAuth.jFrame.setVisible(true);
        LoginAuth.jFrame.setResizable(false);
    }

    public void init() throws IOException {
        (this.titlePanel = new JPanel()).setLayout(new FlowLayout());
        this.titlePanel.add(new JLabel(LoginAuth.gameName));
        this.c.add(this.titlePanel, "North");
        this.fieldPanel = new JPanel();
        final String getLocaMac = Utils.getLocalMac().trim();
        LoginAuth.locaMac = LoginAuth.locaMac.trim();
        final String locaMac2 = Utils.replaceBom(LoginAuth.locaMac);
//        if (!locaMac2.equals(getLocaMac)) {
//            JOptionPane.showMessageDialog(null, "请使用指定机器登录(" + Utils.getLocalMac() + ")", "机器认证失败(" + LoginAuth.locaMac.toUpperCase() + ")", 0);
//            System.exit(0);
//            return;
//        }
        this.titlePanel.setVisible(false);
        final File resFile2 = Utils.getResFile("config.json");
        final byte[] readAllBytes2 = Files.readAllBytes(resFile2.toPath());
        final JSONObject jsonObject = JSONObject.parseObject(new String(readAllBytes2, "UTF-8"));
        final JSONObject baseConfig = jsonObject.getJSONObject("baseConfig");
        String customeName = baseConfig.getString("gameName");
        if (customeName == null) {
            customeName = "";
        } else {
            customeName = "(" + customeName + ")";
        }
        LoginAuth.jFrame.setTitle(String.valueOf(LoginAuth.gameName) + "-" + GameCommonUtil.gameVersion + customeName);
        this.trayIcon.setToolTip(LoginAuth.jFrame.getTitle());
        final JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        (LoginAuth.openManage = new JButton()).setLayout(null);
        LoginAuth.openManage.setVisible(false);
        LoginAuth.openManage.setText("进入后台");
        LoginAuth.openManage.setLocation(20, 100);
        LoginAuth.openManage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                try {
                    Runtime.getRuntime().exec("cmd /c start " + GameConfig.config.getBaseConfig().getManageLink());
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        });
        buttonPanel.add(LoginAuth.openManage);
        this.c.add(buttonPanel, "South");
        final InputStream load = new ClassPathResource("loading-2.gif").getInputStream();
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        final byte[] buffer = new byte[4096];
        int n = 0;
        while (-1 != (n = load.read(buffer))) {
            output.write(buffer, 0, n);
        }
        final ImageIcon i = new ImageIcon(buffer);
        LoginAuth.lable = new JLabel(i);
        this.c.add(LoginAuth.lable);
        (LoginAuth.success = new JLabel(i)).setText("正在启动项目");
        this.c.add(LoginAuth.success);
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                SpringApplication.run(GameServerApplication.class, new String[0]);
            }
        }, 2000L);
        (LoginAuth.timeOutError = new Timer()).schedule(new TimerTask() {
            @Override
            public void run() {
                LoginAuth.success.setIcon(null);
                LoginAuth.success.setText("启动失败,请联系开发者");
                LoginAuth.log.error("启动失败...");
            }
        }, 180000L);
    }

    public void login() throws HeadlessException, Exception {
        final String usernameText = this.username.getText();
        final String passwordText = new String(this.password.getPassword());
        final String getLocaMac = Utils.getLocalMac().trim();
        LoginAuth.locaMac = LoginAuth.locaMac.trim();
        final String locaMac2 = Utils.replaceBom(LoginAuth.locaMac);
        if (!locaMac2.equals(getLocaMac)) {
            JOptionPane.showMessageDialog(null, "请使用指定机器登录(" + Utils.getLocalMac() + ")", "机器认证失败(" + LoginAuth.locaMac.toUpperCase() + ")", 0);
        } else if ("admin".equals(usernameText) && "admin123".equals(passwordText)) {
            JOptionPane.showMessageDialog(null, "成功登录", "认证成功", -1);
            this.titlePanel.setVisible(false);
            this.fieldPanel.setVisible(false);
            this.buttonPanel.setVisible(false);
            final File resFile2 = Utils.getResFile("config.json");
            final byte[] readAllBytes2 = Files.readAllBytes(resFile2.toPath());
            final JSONObject jsonObject = JSONObject.parseObject(new String(readAllBytes2, "UTF-8"));
            final JSONObject baseConfig = jsonObject.getJSONObject("baseConfig");
            String customeName = baseConfig.getString("gameName");
            if (customeName == null) {
                customeName = "";
            } else {
                customeName = "(" + customeName + ")";
            }
            LoginAuth.jFrame.setTitle(String.valueOf(LoginAuth.gameName) + "-" + GameCommonUtil.gameVersion + customeName);
            this.trayIcon.setToolTip(LoginAuth.jFrame.getTitle());
            final JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());
            (LoginAuth.openManage = new JButton()).setLayout(null);
            LoginAuth.openManage.setVisible(false);
            LoginAuth.openManage.setText("进入后台");
            LoginAuth.openManage.setLocation(20, 100);
            LoginAuth.openManage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(final ActionEvent e) {
                    try {
                        Runtime.getRuntime().exec("cmd /c start " + GameConfig.config.getBaseConfig().getManageLink());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            });
            buttonPanel.add(LoginAuth.openManage);
            this.c.add(buttonPanel, "South");
            final InputStream load = new ClassPathResource("loading-2.gif").getInputStream();
            final ByteArrayOutputStream output = new ByteArrayOutputStream();
            final byte[] buffer = new byte[4096];
            int n = 0;
            while (-1 != (n = load.read(buffer))) {
                output.write(buffer, 0, n);
            }
            final ImageIcon i = new ImageIcon(buffer);
            LoginAuth.lable = new JLabel(i);
            this.c.add(LoginAuth.lable);
            (LoginAuth.success = new JLabel(i)).setText("正在启动项目");
            this.c.add(LoginAuth.success);
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    SpringApplication.run(GameServerApplication.class, new String[0]);
                }
            }, 2000L);
            (LoginAuth.timeOutError = new Timer()).schedule(new TimerTask() {
                @Override
                public void run() {
                    LoginAuth.success.setIcon(null);
                    LoginAuth.success.setText("启动失败,请联系开发者");
                    LoginAuth.log.error("启动失败...");
                }
            }, 180000L);
        } else {
            JOptionPane.showMessageDialog(null, "授权失败,用户名或密码错误", "认证失败", 0);
        }
    }

    static /* synthetic */ Logger access$0() {
        return LoginAuth.log;
    }
}
