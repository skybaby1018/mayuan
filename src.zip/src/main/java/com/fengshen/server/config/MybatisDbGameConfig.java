package com.fengshen.server.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.WebStatFilter;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;
import java.sql.SQLException;

@Configuration
@MapperScan(basePackages = {"com.fengshen.db.dao"}, sqlSessionFactoryRef = "sqlSessionFactoryGame")
public class MybatisDbGameConfig {
    @Value("${spring.datasource.game.username}")
    private String username;
    @Value("${spring.datasource.game.password}")
    private String password;
    @Value("${spring.datasource.game.url}")
    private String url;
    @Value("${spring.datasource.game.driverClassName}")
    private String driverClassName;
    @Value("${spring.datasource.game.initialSize}")
    private int initialSize;
    @Value("${spring.datasource.game.minIdle}")
    private int minIdle;
    @Value("${spring.datasource.game.maxActive}")
    private int maxActive;
    @Value("${spring.datasource.game.maxWait}")
    private int maxWait;
    @Value("${spring.datasource.game.timeBetweenEvictionRunsMillis}")
    private int timeBetweenEvictionRunsMillis;
    @Value("${spring.datasource.game.minEvictableIdleTimeMillis}")
    private int minEvictableIdleTimeMillis;
    @Value("${spring.datasource.game.validationQuery}")
    private String validationQuery;
    @Value("${spring.datasource.game.testWhileIdle}")
    private boolean testWhileIdle;
    @Value("${spring.datasource.game.poolPreparedStatements}")
    private boolean poolPreparedStatements;
    @Value("${spring.datasource.game.maxPoolPreparedStatementPerConnectionSize}")
    private int maxPoolPreparedStatementPerConnectionSize;
    @Value("${spring.datasource.game.filters}")
    private String filters;
    @Value("${spring.datasource.game.connectionProperties}")
    private String connectionProperties;

    @Bean(name = {"gameDataSource"})
    public DataSource gameDataSource() {
        final DruidDataSource datasource = new DruidDataSource();
        datasource.setUrl(this.url);
        datasource.setUsername(this.username);
        datasource.setPassword(this.password);
        datasource.setDriverClassName(this.driverClassName);
        datasource.setInitialSize(this.initialSize);
        datasource.setMinIdle(this.minIdle);
        datasource.setMaxActive(this.maxActive);
        datasource.setMaxWait((long) this.maxWait);
        datasource.setTimeBetweenEvictionRunsMillis((long) this.timeBetweenEvictionRunsMillis);
        datasource.setMinEvictableIdleTimeMillis((long) this.minEvictableIdleTimeMillis);
        datasource.setValidationQuery(this.validationQuery);
        datasource.setTestWhileIdle(this.testWhileIdle);
        datasource.setPoolPreparedStatements(this.poolPreparedStatements);
        datasource.setMaxPoolPreparedStatementPerConnectionSize(this.maxPoolPreparedStatementPerConnectionSize);
        try {
            datasource.setFilters(this.filters);
        } catch (SQLException ex) {
        }
        datasource.setConnectionProperties(this.connectionProperties);
        return (DataSource) datasource;
    }

    @Bean
    public FilterRegistrationBean<WebStatFilter> filterRegistrationBean() {
        final FilterRegistrationBean<WebStatFilter> filterRegistrationBean = (FilterRegistrationBean<WebStatFilter>) new FilterRegistrationBean();
        filterRegistrationBean.setFilter(new WebStatFilter());
        filterRegistrationBean.addUrlPatterns(new String[]{"/*"});
        filterRegistrationBean.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*");
        return filterRegistrationBean;
    }

    @Bean
    public SqlSessionFactory sqlSessionFactoryGame() throws Exception {
        final SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(this.gameDataSource());
        return factoryBean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplateGame() throws Exception {
        final SqlSessionTemplate template = new SqlSessionTemplate(this.sqlSessionFactoryGame());
        return template;
    }
}
