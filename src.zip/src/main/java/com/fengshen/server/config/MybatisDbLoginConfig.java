package com.fengshen.server.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;
import java.sql.SQLException;

/**
 * @author Administrator
 */
@Configuration
@MapperScan(basePackages = {"com.fengshen.db.auth"}, sqlSessionFactoryRef = "sqlSessionFactory")
public class MybatisDbLoginConfig {
    @Value("${spring.datasource.login.username}")
    private String username;
    @Value("${spring.datasource.login.password}")
    private String password;
    @Value("${spring.datasource.login.url}")
    private String url;
    @Value("${spring.datasource.login.driverClassName}")
    private String driverClassName;
    @Value("${spring.datasource.login.initialSize}")
    private int initialSize;
    @Value("${spring.datasource.login.minIdle}")
    private int minIdle;
    @Value("${spring.datasource.login.maxActive}")
    private int maxActive;
    @Value("${spring.datasource.login.maxWait}")
    private int maxWait;
    @Value("${spring.datasource.login.timeBetweenEvictionRunsMillis}")
    private int timeBetweenEvictionRunsMillis;
    @Value("${spring.datasource.login.minEvictableIdleTimeMillis}")
    private int minEvictableIdleTimeMillis;
    @Value("${spring.datasource.login.validationQuery}")
    private String validationQuery;
    @Value("${spring.datasource.login.testWhileIdle}")
    private boolean testWhileIdle;
    @Value("${spring.datasource.login.poolPreparedStatements}")
    private boolean poolPreparedStatements;
    @Value("${spring.datasource.login.maxPoolPreparedStatementPerConnectionSize}")
    private int maxPoolPreparedStatementPerConnectionSize;
    @Value("${spring.datasource.login.filters}")
    private String filters;
    @Value("${spring.datasource.login.connectionProperties}")
    private String connectionProperties;

    @Bean(name = {"loginDataSource"})
    public DataSource loginDataSource() {
        final DruidDataSource datasource = new DruidDataSource();
        datasource.setUrl(this.url);
        datasource.setUsername(this.username);
        datasource.setPassword(this.password);
        datasource.setDriverClassName(this.driverClassName);
        datasource.setInitialSize(this.initialSize);
        datasource.setMinIdle(this.minIdle);
        datasource.setMaxActive(this.maxActive);
        datasource.setMaxWait((long) this.maxWait);
        datasource.setTimeBetweenEvictionRunsMillis((long) this.timeBetweenEvictionRunsMillis);
        datasource.setMinEvictableIdleTimeMillis((long) this.minEvictableIdleTimeMillis);
        datasource.setValidationQuery(this.validationQuery);
        datasource.setTestWhileIdle(this.testWhileIdle);
        datasource.setPoolPreparedStatements(this.poolPreparedStatements);
        datasource.setMaxPoolPreparedStatementPerConnectionSize(this.maxPoolPreparedStatementPerConnectionSize);
        try {
            datasource.setFilters(this.filters);
        } catch (SQLException ex) {
        }
        datasource.setConnectionProperties(this.connectionProperties);
        return (DataSource) datasource;
    }

    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        final SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(this.loginDataSource());
        return factoryBean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate() throws Exception {
        final SqlSessionTemplate template = new SqlSessionTemplate(this.sqlSessionFactory());
        return template;
    }
}
