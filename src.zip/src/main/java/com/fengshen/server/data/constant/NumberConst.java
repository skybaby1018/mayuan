package com.fengshen.server.data.constant;

public interface NumberConst {
    public static final Integer MAX_NUMBER = Math.toIntExact(2000000000L);
}
