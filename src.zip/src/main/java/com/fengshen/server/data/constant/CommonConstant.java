package com.fengshen.server.data.constant;

public interface CommonConstant {
    public static final String ON_LEI_TAI_CHARA_LIST = "OnLeiTaiCharaList";
}
