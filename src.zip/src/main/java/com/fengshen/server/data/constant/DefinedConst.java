package com.fengshen.server.data.constant;

public class DefinedConst {
    public static final int MAX_LEVEL = 115;
    public static final int YUANYING_MAX_LEVEL = 115;
    public static final int MAX_WUXUELILIAN_TASK_COUNT = 70;
    public static final int PET_MAX_LEVEL = 125;
    public static final int PLAYER_MAX_LEVEL = 130;
    public static final String GOLD_STALL_PREFIX = "GOLDSTALL";
    public static final String CHANGE_CARD = "CHANGE_CARD";

    public enum BAXIAN_STATUS {
        BAXIAN_STATUS_NORMAL,
        BAXIAN_STATUS_PLAYING,
        BAXIAN_STATUS_FINISH;
    }

    public enum CHILD_TYPE {
        NO_CHILD,
        YUANYING,
        XUEYING,
        UPGRADE_IMMORTAL,
        UPGRADE_MAGIC;
    }

    public enum FLY_TYPE {
        FLY_TYPE_NORMAL,
        FLY_TYPE_STRARTFLY,
        FLY_TYPE_TIANJILAOR,
        FLY_TYPE_NANHUAZHENR_PET_FIGHT,
        FLY_TYPE_LINPIAN_FIGHT,
        FLY_TYPE_XUE_FIGHT,
        FLY_TYPE_FLY,
        FLY_TYPE_FINISH;
    }

    public enum MOUNT_TYPE {
        MOUNT_TYPE_NORMAL,
        MOUNT_TYPE_JINGGUAI,
        MOUNT_TYPE_YULING;
    }

    public enum MSG_CONFIRM_TYPE {
        MSG_CONFIRM_TYPE_NORMAL,
        MSG_CONFIRM_TYPE_REQUEST_TEAM_LEADER,
        MSG_CONFIRM_TYPE_YUANYING_FLY;
    }

    public enum PET_RANK {
        PET_RANK_NORMAL,
        PET_RANK_WILD,
        PET_RANK_BABY,
        PET_RANK_ELITE,
        PET_RANK_EPIC,
        PET_RANK_GUARD;
    }

    public enum SUBMIT_PET_TYPE {
        SUBMIT_PET_TYPE_NORMAL(1),
        SUBMIT_PET_TYPE_FEISHENG(2),
        SUBMIT_PET_TYPE_FEED(3),
        SUBMIT_PET_TYPE_INNER_ALLCHEMY(4),
        SUBMIT_PET_TYPE_BUYBACK(100);

        int value;

        private SUBMIT_PET_TYPE(final int tag) {
            this.value = tag;
        }

        public int getValue() {
            return this.value;
        }

        public void setValue(final int value) {
            this.value = value;
        }
    }

    public enum WUXUE_STATUS {
        WUXUE_STATUS_NORMAL,
        WUXUE_STATUS_PLAYING,
        WUXUE_STATUS_FINISH;
    }
}
