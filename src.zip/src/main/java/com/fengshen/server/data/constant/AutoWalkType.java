package com.fengshen.server.data.constant;

public enum AutoWalkType {
    CHUYAO(Integer.valueOf(1), "降妖"),
    FUMO(Integer.valueOf(2), "伏魔"),
    FEIXIANDUXIE(Integer.valueOf(3), "飞仙渡邪"),
    WEIMINGCHUBAO(Integer.valueOf(4), "为民除暴"),
    XIUXING(Integer.valueOf(5), "修行"),
    SHIJUE(Integer.valueOf(6), "十绝阵"),
    巡逻(Integer.valueOf(7), "巡逻"),
    ERJIECHUYAO(Integer.valueOf(8), "二阶降妖"),
    ERJIEFUMO(Integer.valueOf(9), "二阶伏魔"),
    ERJIEFEIXIANDUXIE(Integer.valueOf(10), "二阶飞仙渡邪");

    private int type;
    private String name;

    private AutoWalkType(final Integer type, final String name) {
        this.name = name;
        this.type = type;
    }

    public static String getValueByKey(final int type) {
        PartyType[] values;
        for (int length = (values = PartyType.values()).length, i = 0; i < length; ++i) {
            final PartyType p = values[i];
            if (p.getType() == type) {
                return p.getName();
            }
        }
        return "";
    }

    public static int getKeyByValue(final String name) {
        PartyType[] values;
        for (int length = (values = PartyType.values()).length, i = 0; i < length; ++i) {
            final PartyType s = values[i];
            if (s.getName().equals(name)) {
                return s.getType();
            }
        }
        return 0;
    }

    public int getType() {
        return this.type;
    }

    public void setType(final int type) {
        this.type = type;
    }

    public String getName() {
        return this.name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
