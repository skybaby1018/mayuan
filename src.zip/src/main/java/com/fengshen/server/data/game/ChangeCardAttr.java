package com.fengshen.server.data.game;

public class ChangeCardAttr {
    private String field;
    private String name;
    private Integer value;

    public String getField() {
        return this.field;
    }

    public String getName() {
        return this.name;
    }

    public Integer getValue() {
        return this.value;
    }

    public void setField(final String field) {
        this.field = field;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setValue(final Integer value) {
        this.value = value;
    }
}
