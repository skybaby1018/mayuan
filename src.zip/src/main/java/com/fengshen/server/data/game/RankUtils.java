package com.fengshen.server.data.game;

import com.fengshen.server.domain.Chara;

public class RankUtils {
    public static String[] rankTypeArray;

    static {
        RankUtils.rankTypeArray = new String[]{"rank_type:101", "rank_type:102:45-79", "rank_type:102:80-89", "rank_type:102:90-99", "rank_type:102:100-109", "rank_type:102:110-119", "rank_type:102:120-129", "rank_type:103", "rank_type:104", "rank_type:105", "rank_type:106"};
    }

    public static int getRankValue(final Chara chara, final int type) {
        int value = 0;
        switch (type) {
            case 101: {
                value = chara.level;
                break;
            }
            case 102: {
                value = chara.tao;
                break;
            }
            case 103: {
                value = chara.accurate;
                break;
            }
            case 104: {
                value = chara.mana;
                break;
            }
            case 105: {
                value = chara.parry;
                break;
            }
            case 106: {
                value = chara.wiz;
                break;
            }
        }
        return value;
    }
}
