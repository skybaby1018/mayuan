package com.fengshen.server.data.constant;

public class MapConst {
    public static final Integer PENGLAI_MAP_ID;

    static {
        PENGLAI_MAP_ID = 17000;
    }
}
