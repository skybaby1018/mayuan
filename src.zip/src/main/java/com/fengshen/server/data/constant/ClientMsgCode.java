package com.fengshen.server.data.constant;

public class ClientMsgCode {
    public static final int MSG_DUNGEON_LIST = 45058;
}
