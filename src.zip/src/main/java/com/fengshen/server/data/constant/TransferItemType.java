package com.fengshen.server.data.constant;

public enum TransferItemType {
    OTHER("无", 0),
    CASH("金钱", 1),
    PET("宠物", 2),
    CHARGE("收费道具", 3),
    NOT_COMBINE("不可叠加道具", 4),
    COMBINE("可叠加道具", 5);

    private String name;
    private int value;

    private TransferItemType(final String name, final int value) {
        this.name = name;
        this.value = value;
    }

    private TransferItemType(final Integer value) {
        this.value = value;
    }

    public static int getValue(final String name) {
        final TransferItemType[] values = values();
        TransferItemType[] array;
        for (int length = (array = values).length, i = 0; i < length; ++i) {
            final TransferItemType v = array[i];
            if (v.name.equals(name)) {
                return v.value;
            }
        }
        return 7;
    }
}
