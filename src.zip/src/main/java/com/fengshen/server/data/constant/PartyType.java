package com.fengshen.server.data.constant;

public enum PartyType {
    BANGZHU(Integer.valueOf(700), "帮主"),
    CHUANWEI(Integer.valueOf(200), "传位"),
    FUBANGZHU(Integer.valueOf(600), "副帮主"),
    QINGLONGZHANGLAO(Integer.valueOf(504), "青龙长老"),
    BAOHUZHANGLAO(Integer.valueOf(503), "白虎长老"),
    ZHUQUEZHANGLAO(Integer.valueOf(502), "朱雀长老"),
    XUANWUZHANGLAO(Integer.valueOf(501), "玄武长老"),
    CANGLANHUFA(Integer.valueOf(405), "苍龙护法"),
    YUANLEIHUFA(Integer.valueOf(404), "远雷护法"),
    JIANFENGHUFA(Integer.valueOf(403), "尖峰护法"),
    YEFUHUFA(Integer.valueOf(402), "夜伏护法"),
    YUNHAIHUFA(Integer.valueOf(401), "云海护法"),
    DEXINTANGZHU(Integer.valueOf(308), "德馨堂主"),
    SUXIATANGZHU(Integer.valueOf(307), "素侠堂主"),
    HANLONGTANGZHU(Integer.valueOf(306), "暗龙堂主"),
    HUWEITANGZHU(Integer.valueOf(305), "虎威堂主"),
    ZIYUNTANGZHU(Integer.valueOf(304), "紫云堂主"),
    TINGXUETANGZHU(Integer.valueOf(303), "听雪堂主"),
    MENGXITANGZHU(Integer.valueOf(302), "梦溪堂主"),
    XUANFENGTANGZHU(Integer.valueOf(301), "玄风堂主"),
    BANGPAIJINGYING(Integer.valueOf(150), "帮派精英"),
    BANGZHONG(Integer.valueOf(100), "帮众");

    private int type;
    private String name;

    private PartyType(final Integer type, final String name) {
        this.name = name;
        this.type = type;
    }

    public static String getValueByKey(final int type) {
        PartyType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final PartyType p = values[i];
            if (p.getType() == type) {
                return p.getName();
            }
        }
        return "";
    }

    public static int getKeyByValue(final String name) {
        PartyType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final PartyType s = values[i];
            if (s.getName().equals(name)) {
                return s.getType();
            }
        }
        return 0;
    }

    public int getType() {
        return this.type;
    }

    public void setType(final int type) {
        this.type = type;
    }

    public String getName() {
        return this.name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
