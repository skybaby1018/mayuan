package com.fengshen.server.data.constant;

public enum StallRecordType {
    STALL("集市", 0),
    GOLD_STALL("珍宝", 1);

    private String name;
    private int value;

    private StallRecordType(final String name, final int value) {
        this.name = name;
        this.value = value;
    }

    private StallRecordType(final Integer value) {
        this.value = value;
    }

    public static int getValue(final String name) {
        final StallRecordType[] values = values();
        StallRecordType[] array;
        for (int length = (array = values).length, i = 0; i < length; ++i) {
            final StallRecordType v = array[i];
            if (v.name.equals(name)) {
                return v.value;
            }
        }
        return 0;
    }
}
