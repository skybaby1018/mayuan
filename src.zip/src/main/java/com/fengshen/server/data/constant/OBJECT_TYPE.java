package com.fengshen.server.data.constant;

public class OBJECT_TYPE {
    public static int CHAR = 1;
    public static int MONSTER = 2;
    public static int NPC = 4;
    public static int ITEM = 8;
    public static int CHILD = 16;
    public static int GUARD = 32;
    public static int SPECIAL_NPC = 64;
    public static int GATHER_NPC = 128;
    public static int FOLLOW_NPC = 256;
    public static int MOVE_NPC = 512;
    public static int CELESTIAL = 1024;
    public static int QT_NPC = 2048;
    public static int MAP_NPC = 4096;
    public static int RETINUE = 8192;
    public static int PET = 32768;
    public static int MAID_NPC = 65536;
    public static int INN_GUEST = 131072;
    public static int  FLY = 262144;
    public static int FLY_CONTAINER = 524288;
}
