package com.fengshen.server.data.game;

import java.io.InputStream;

import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.Reader;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Collection;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.io.BufferedReader;

import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.slf4j.Logger;
import org.springframework.core.io.ResourceLoader;

public class PetAndHelpSkillUtils {
    public static String skillJson;
    private static ResourceLoader resourceLoader;
    private static Logger log;

    static {
        PetAndHelpSkillUtils.skillJson = null;
        PetAndHelpSkillUtils.resourceLoader = (ResourceLoader) new DefaultResourceLoader();
        PetAndHelpSkillUtils.log = LoggerFactory.getLogger(PetAndHelpSkillUtils.class);
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
    }

    public static int getMaxSkill(final int attrib) {
        final int maxSkill = (int) (attrib * 1.6);
        return maxSkill;
    }

    public static List<JSONObject> getNomelSkills(final int pet, final int pMetal, final int attrib, final boolean isMagic) throws JSONException {
        return getNomelSkills(pet, pMetal, attrib, isMagic, "");
    }

    public static List<JSONObject> getNomelSkills(final int pet, final int pMetal, final int attrib, final boolean isMagic, final String skill_value) throws JSONException {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        final int[] sh_gj = {1, 19, 32, 50, 100};
        int sh_gj_count = 0;
        for (int i = sh_gj.length - 1; i >= 0; --i) {
            if (attrib >= sh_gj[i]) {
                sh_gj_count = i + 1;
                break;
            }
        }
        final List<JSONObject> sh_gj_list = new ArrayList<JSONObject>();
        final int[] sh_fz = {1, 1, 1, 50, 100};
        int sh_fz_count = 0;
        for (int j = sh_fz.length - 1; j >= 0; --j) {
            if (attrib >= sh_fz[j]) {
                sh_fz_count = j + 1;
                break;
            }
        }
        final List<JSONObject> sh_fz_list = new ArrayList<JSONObject>();
        final List<JSONObject> pet_gj_list = new ArrayList<JSONObject>();
        final int[] pet_gj = {20, 40, 60};
        final List<Integer> pet_gj_counts = new ArrayList<Integer>();
        int k = pet_gj.length - 1;
        while (k >= 0) {
            if (attrib >= pet_gj[k]) {
                if (k == 2) {
                    pet_gj_counts.add(1);
                    pet_gj_counts.add(2);
                    pet_gj_counts.add(4);
                    break;
                }
                if (k == 1) {
                    pet_gj_counts.add(1);
                    pet_gj_counts.add(2);
                    break;
                }
                pet_gj_counts.add(1);
                break;
            } else {
                --k;
            }
        }
        if (pet == 2 && (skill_value == null || skill_value.isEmpty())) {
            for (k = 0; k < jsonArray.length(); ++k) {
                JSONObject jsonObject = jsonArray.optJSONObject(k);
                final int metal = jsonObject.optInt("metal");
                final String skillType = jsonObject.optString("skillType");
                final int skillIndex = jsonObject.optInt("skillIndex");
                if (skillType.contentEquals("FS") && pMetal == metal && (pMetal == 1 || pMetal == 2 || pMetal == 3) && skillIndex <= sh_gj_count) {
                    final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(attrib));
                    jsonObject.put("skillNum", skillNum_round[0]);
                    jsonObject.put("skillRound", skillNum_round[1]);
                    jsonObject.put("skillLevel", getMaxSkill(attrib));
                    jsonObject.remove("skillUse");
                    jsonObject = appendBP(jsonObject, skillType, skillIndex, attrib);
                    sh_gj_list.add(jsonObject);
                } else if (skillType.contentEquals("WS") && pMetal == metal && (pMetal == 4 || pMetal == 5) && skillIndex <= sh_gj_count) {
                    final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(attrib));
                    jsonObject.put("skillNum", skillNum_round[0]);
                    jsonObject.put("skillRound", skillNum_round[1]);
                    jsonObject.put("skillLevel", getMaxSkill(attrib));
                    jsonObject.remove("skillUse");
                    jsonObject = appendBP(jsonObject, skillType, skillIndex, attrib);
                    sh_gj_list.add(jsonObject);
                } else if (skillType.contentEquals("FZ") && pMetal == metal && skillIndex <= sh_fz_count) {
                    final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(attrib));
                    jsonObject.put("skillNum", skillNum_round[0]);
                    jsonObject.put("skillRound", skillNum_round[1]);
                    jsonObject.put("skillLevel", getMaxSkill(attrib));
                    jsonObject.remove("skillUse");
                    jsonObject = appendBP(jsonObject, skillType, skillIndex, attrib);
                    sh_fz_list.add(jsonObject);
                }
            }
            sh_gj_list.addAll(sh_fz_list);
            return sh_gj_list;
        }
        if (pet == 1 && isMagic && (skill_value == null || skill_value.isEmpty())) {
            for (k = 0; k < jsonArray.length(); ++k) {
                JSONObject jsonObject = jsonArray.optJSONObject(k);
                final int metal = jsonObject.optInt("metal");
                final String skillType = jsonObject.optString("skillType");
                final int skillIndex = jsonObject.optInt("skillIndex");
                if (pet_gj_counts.contains(skillIndex) && skillType.contentEquals("FS") && pMetal == metal) {
                    final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(attrib));
                    jsonObject.put("skillNum", skillNum_round[0]);
                    jsonObject.put("skillRound", skillNum_round[1]);
                    jsonObject.put("skillLevel", getMaxSkill(attrib));
                    jsonObject.remove("skillUse");
                    jsonObject.remove("skillRound");
                    jsonObject = appendBP(jsonObject, skillType, skillIndex, attrib);
                    pet_gj_list.add(jsonObject);
                }
            }
            return pet_gj_list;
        }
        if (skill_value != null && !skill_value.isEmpty()) {
            for (k = 0; k < jsonArray.length(); ++k) {
                JSONObject jsonObject = jsonArray.optJSONObject(k);
                final int metal = jsonObject.optInt("metal");
                final String skillType = jsonObject.optString("skillType");
                final int skillIndex = jsonObject.optInt("skillIndex");
                final String skillType_skillIndex = String.format("%s_%d", skillType, skillIndex);
                if (skill_value.contains(skillType_skillIndex) && pMetal == metal) {
                    final int[] skillNum_round2 = skillNum(jsonObject, getMaxSkill(attrib));
                    jsonObject.put("skillNum", skillNum_round2[0]);
                    jsonObject.put("skillRound", skillNum_round2[1]);
                    jsonObject.put("skillLevel", getMaxSkill(attrib));
                    jsonObject.remove("skillUse");
                    jsonObject = appendBP(jsonObject, skillType, skillIndex, attrib);
                    if (skillIndex == 5) {
                        if (sh_gj_count >= 5) {
                            pet_gj_list.add(jsonObject);
                        }
                    } else {
                        pet_gj_list.add(jsonObject);
                    }
                }
            }
            return pet_gj_list;
        }
        return sh_gj_list;
    }

    private static JSONObject appendBP(final JSONObject jsonObject, final String skillType, final int skillIndex, final int attrib) throws JSONException {
        final int[] bp = getBlueAndPoints(skillType, skillIndex, attrib);
        jsonObject.put("skillBlue", bp[0]);
        jsonObject.put("skillPoint", bp[1]);
        return jsonObject;
    }

    private static int[] getBlueAndPoints(final String skillType, final int skillIndex, final int attrib) {
        final int[] bp = {1, 1};
        if (attrib == 1) {
            return bp;
        }
        if (skillType.contentEquals("WS")) {
            bp[0] = (int) (attrib * 17.5);
            bp[1] = attrib * attrib * 60;
        } else {
            final Hashtable<String, Double> addHashtable = new Hashtable<String, Double>();
            addHashtable.put("FS", 0.0);
            addHashtable.put("ZA", 0.3);
            addHashtable.put("FZ", 0.4);
            addHashtable.put("BD", 0.5);
            Double add = addHashtable.get(skillType);
            if (add == null) {
                add = 0.0;
            }
            switch (skillIndex) {
                case 1: {
                    bp[0] = (int) (attrib * (10.7 + add));
                    bp[1] = (int) (attrib * attrib * (15.7 + add));
                    break;
                }
                case 2: {
                    bp[0] = (int) (attrib * (13.5 + add));
                    bp[1] = (int) (attrib * attrib * (14.0 + add));
                    break;
                }
                case 3: {
                    bp[0] = (int) (attrib * (15.5 + add));
                    bp[1] = (int) (attrib * attrib * (22.0 + add));
                    break;
                }
                case 4: {
                    bp[0] = (int) (attrib * (25.0 + add));
                    bp[1] = (int) (attrib * attrib * (33.0 + add));
                    break;
                }
                case 5: {
                    bp[0] = (int) (attrib * (28.0 + add));
                    bp[1] = (int) (attrib * attrib * (43.0 + add));
                    break;
                }
            }
        }
        return bp;
    }

    public static int[] skillNum(final JSONObject skillObject, final int skill) {
        final JSONArray jsonArray = skillObject.optJSONArray("skillUse");
        final JSONArray jsonArrayRound = skillObject.optJSONArray("skillRound");
        final int[] num_round = new int[2];
        if (jsonArray == null || jsonArray.length() == 0) {
            num_round[0] = 1;
        }
        if (jsonArrayRound == null || jsonArrayRound.length() == 0) {
            num_round[1] = 1;
        }
        if (num_round[0] == 0) {
            for (int i = 0; i < jsonArray.length(); ++i) {
                final JSONObject jsonObject = jsonArray.optJSONObject(i);
                final int skillLevelMin = jsonObject.optInt("skillLevelMin");
                final int skillLevel = jsonObject.optInt("skillLevel");
                final int skillNum = jsonObject.optInt("skillNum");
                if (skill >= skillLevelMin && skill <= skillLevel) {
                    num_round[0] = skillNum;
                }
            }
        }
        if (num_round[0] == 0) {
            num_round[0] = 1;
        }
        if (num_round[1] == 0) {
            for (int i = 0; i < jsonArrayRound.length(); ++i) {
                final JSONObject jsonObject = jsonArrayRound.optJSONObject(i);
                final int skillLevelMin = jsonObject.optInt("skillLevelMin");
                final int skillLevel = jsonObject.optInt("skillLevel");
                final int skillRound = jsonObject.optInt("skillRound");
                if (skill >= skillLevelMin && skill <= skillLevel) {
                    num_round[1] = skillRound;
                }
            }
        }
        if (num_round[1] == 0) {
            num_round[1] = 1;
        }
        return num_round;
    }

    public static BufferedReader getResFile() {
        final Resource resource = PetAndHelpSkillUtils.resourceLoader.getResource("classpath:static/user_skill.json");
        BufferedReader br = null;
        try {
            final InputStream inputStream = resource.getInputStream();
            final InputStreamReader fr = new InputStreamReader(inputStream, "UTF-8");
            br = new BufferedReader(fr);
        } catch (IOException e) {
            PetAndHelpSkillUtils.log.error("", (Throwable) e);
        }
        return br;
    }

    public static JSONObject jsonArray(final int skillNo) {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        for (int i = 0; i < jsonArray.length(); ++i) {
            final JSONObject jsonObject = jsonArray.optJSONObject(i);
            final int no = jsonObject.optInt("skillNo");
            if (no == skillNo) {
                return jsonObject;
            }
        }
        return null;
    }

    public static int skillNummax(final int skillNo, final int skill) {
        final JSONObject skillObject = jsonArray(skillNo);
        final JSONArray jsonArray = skillObject.optJSONArray("skillUse");
        if (jsonArray == null || jsonArray.length() == 0) {
            return 1;
        }
        for (int i = 0; i < jsonArray.length(); ++i) {
            final JSONObject jsonObject = jsonArray.optJSONObject(i);
            final int skillLevelMin = jsonObject.optInt("skillLevelMin");
            final int skillLevel = jsonObject.optInt("skillLevel");
            final int skillNum = jsonObject.optInt("skillNum");
            if (skill >= skillLevelMin && skill <= skillLevel) {
                return skillNum;
            }
        }
        return 1;
    }

    public static int[] getBlueAndPointsLan(final int skillNo, final int attrib) {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        String leixing = null;
        int skillIndex = 0;
        for (int i = 0; i < jsonArray.length(); ++i) {
            final JSONObject jsonObject = jsonArray.optJSONObject(i);
            final int no = jsonObject.optInt("skillNo");
            if (no == skillNo) {
                leixing = jsonObject.optString("skillType");
                skillIndex = jsonObject.optInt("skillIndex");
                break;
            }
        }
        final int[] bp = {1, 1};
        if (attrib == 1) {
            return bp;
        }
        if (leixing != null) {
            if (leixing.contentEquals("WS")) {
                bp[0] = (int) (attrib * 17.5);
                bp[1] = attrib * attrib * 60;
            } else {
                final Hashtable<String, Double> addHashtable = new Hashtable<String, Double>();
                addHashtable.put("FS", 0.0);
                addHashtable.put("ZA", 0.3);
                addHashtable.put("FZ", 0.4);
                addHashtable.put("BD", 0.5);
                Double add = addHashtable.get(leixing);
                if (add == null) {
                    add = 0.0;
                }
                switch (skillIndex) {
                    case 1: {
                        bp[0] = (int) (attrib * (10.7 + add));
                        bp[1] = (int) (attrib * attrib * (15.7 + add));
                        break;
                    }
                    case 2: {
                        bp[0] = (int) (attrib * (13.5 + add));
                        bp[1] = (int) (attrib * attrib * (14.0 + add));
                        break;
                    }
                    case 3: {
                        bp[0] = (int) (attrib * (15.5 + add));
                        bp[1] = (int) (attrib * attrib * (22.0 + add));
                        break;
                    }
                    case 4: {
                        bp[0] = (int) (attrib * (25.0 + add));
                        bp[1] = (int) (attrib * attrib * (33.0 + add));
                        break;
                    }
                    case 5: {
                        bp[0] = (int) (attrib * (28.0 + add));
                        bp[1] = (int) (attrib * attrib * (43.0 + add));
                        break;
                    }
                }
                if (leixing.contentEquals("BD")) {
                    bp[1] = attrib * 70000 + 140000;
                }
            }
        }
        return bp;
    }

    public static List<JSONObject> getSkills(final int pMetal, final int level, final String skill_value) throws JSONException {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        final List<JSONObject> result = new ArrayList<JSONObject>();
        if (skill_value == null || skill_value.isEmpty()) {
            return result;
        }
        final List<String> skillNameList = new ArrayList<String>();
        String[] split;
        for (int length = (split = skill_value.split(",")).length, j = 0; j < length; ++j) {
            final String name = split[j];
            skillNameList.add(name);
        }
        for (int i = 0; i < jsonArray.length(); ++i) {
            JSONObject jsonObject = jsonArray.optJSONObject(i);
            final int metal = jsonObject.optInt("metal");
            final String skillType = jsonObject.optString("skillType");
            final String skillName = jsonObject.optString("skillName");
            final int skillIndex = jsonObject.optInt("skillIndex");
            if (pMetal == metal && skill_value.contains(skillName)) {
                final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(level));
                jsonObject.put("skillNum", skillNum_round[0]);
                jsonObject.put("skillRound", skillNum_round[1]);
                jsonObject.put("skillLevel", getMaxSkill(level));
                jsonObject.remove("skillUse");
                jsonObject = appendBP(jsonObject, skillType, skillIndex, level);
                result.add(jsonObject);
                skillNameList.remove(skillName);
            }
        }
        skillNameList.isEmpty();
        return result;
    }

    public static List<JSONObject> getSkills(final int level, final String skill_value) throws JSONException {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        final List<JSONObject> result = new ArrayList<JSONObject>();
        if (skill_value == null || skill_value.isEmpty()) {
            return result;
        }
        final List<String> skillNameList = new ArrayList<String>();
        String[] split;
        for (int length = (split = skill_value.split(",")).length, j = 0; j < length; ++j) {
            final String name = split[j];
            skillNameList.add(name);
        }
        for (int i = 0; i < jsonArray.length(); ++i) {
            JSONObject jsonObject = jsonArray.optJSONObject(i);
            final String skillType = jsonObject.optString("skillType");
            final String skillName = jsonObject.optString("skillName");
            final int skillIndex = jsonObject.optInt("skillIndex");
            if (skill_value.contains(skillName)) {
                final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(level));
                jsonObject.put("skillNum", skillNum_round[0]);
                jsonObject.put("skillRound", skillNum_round[1]);
                jsonObject.put("skillLevel", getMaxSkill(level));
                jsonObject.remove("skillUse");
                jsonObject = appendBP(jsonObject, skillType, skillIndex, level);
                result.add(jsonObject);
                skillNameList.remove(skillName);
            }
        }
        return result;
    }

    public static List<JSONObject> getFightObjectSkills(final int level, final String skill_value) {
        if (PetAndHelpSkillUtils.skillJson == null) {
            final BufferedReader br = getResFile();
            final StringBuilder strb = new StringBuilder();
            br.lines().forEach(f -> strb.append(f));
            PetAndHelpSkillUtils.skillJson = strb.toString();
        }
        final JSONArray jsonArray = new JSONArray(PetAndHelpSkillUtils.skillJson);
        final List<JSONObject> result = new ArrayList<JSONObject>();
        if (skill_value == null || skill_value.isEmpty()) {
            return result;
        }
        final List<String> skillNameList = new ArrayList<String>();
        String[] split;
        for (int length = (split = skill_value.split(",")).length, k = 0; k < length; ++k) {
            final String name = split[k];
            skillNameList.add(name);
        }
        for (int i = 0; i < jsonArray.length(); ++i) {
            JSONObject jsonObject = jsonArray.optJSONObject(i);
            final String skillType = jsonObject.optString("skillType");
            final String skillName = jsonObject.optString("skillName");
            final int skillIndex = jsonObject.optInt("skillIndex");
            if (skill_value.contains(skillName)) {
                final JSONObject skillUse = jsonObject.getJSONArray("skillUse").getJSONObject(0);
                final int skillNum = skillUse.getInt("skillNum");
                if (!jsonObject.isNull("skillRound")) {
                    final JSONArray skillRounds = jsonObject.getJSONArray("skillRound");
                    for (int j = 0; j < skillRounds.length(); ++j) {
                        final JSONObject skillRound = skillRounds.getJSONObject(j);
                        if (level >= skillRound.getInt("skillLevelMin") && level <= skillRound.getInt("skillLevel")) {
                            jsonObject.put("skillRound", skillRound.getInt("skillRound"));
                            break;
                        }
                    }
                    jsonObject.put("skillNum", skillNum);
                    jsonObject.put("skillLevel", level);
                } else {
                    final int[] skillNum_round = skillNum(jsonObject, getMaxSkill(level));
                    jsonObject.put("skillNum", skillNum_round[0]);
                    jsonObject.put("skillRound", skillNum_round[1]);
                    jsonObject.put("skillLevel", getMaxSkill(level));
                }
                jsonObject.remove("skillUse");
                jsonObject = appendBP(jsonObject, skillType, skillIndex, level);
                result.add(jsonObject);
                skillNameList.remove(skillName);
            }
        }
        return result;
    }
}
