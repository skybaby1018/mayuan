package com.fengshen.server.data.constant;

public enum PolarType {
    METAL,
    WOOD,
    WATER,
    FIRE,
    EARTH;
}
