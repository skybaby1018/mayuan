package com.fengshen.server.data.game;

import java.util.Hashtable;

public class ConsumeMoneyUtils {
    private int[] appraisalMoney(final int eqType, int eq_attrib) {
        final int[] min_max = new int[2];
        if (eq_attrib <= 40) {
            return min_max;
        }
        if (eq_attrib > 120) {
            eq_attrib = 120;
        }
        if (eqType == 1 || eqType == 3) {
            final int[] moneys = {50000, 100000, 150000, 250000, 300000, 35000, 500000, 750000};
            min_max[0] = moneys[eq_attrib / 10 - 5];
            min_max[1] = min_max[0] * 5;
        }
        if (eqType == 10 || eqType == 2) {
            final int[] moneys = {35000, 50000, 75000, 100000, 200000, 300000, 400000, 500000};
            min_max[0] = moneys[eq_attrib / 10 - 5];
            min_max[1] = min_max[0] * 5;
        }
        return min_max;
    }

    public static int appraisalMoney(final int dst_eq_attrib) {
        final Hashtable<Integer, Integer> hashtable = new Hashtable<Integer, Integer>();
        hashtable.put(35, 0);
        hashtable.put(50, 25000);
        hashtable.put(60, 30000);
        hashtable.put(70, 35000);
        hashtable.put(80, 480000);
        hashtable.put(90, 540000);
        hashtable.put(100, 600000);
        hashtable.put(110, 1100000);
        hashtable.put(120, 1200000);
        hashtable.put(130, 1300000);
        return hashtable.get(dst_eq_attrib);
    }

    public static int createMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        return (eq_attrib / 10 - 7) * 10000 + 75000;
    }

    public static int removeMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        return (eq_attrib / 10 - 7) * 700 + 5200;
    }

    public static int pinkMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        if (eq_attrib > 120) {
            return 235400;
        }
        final int[] moneys = {83400, 107400, 134600, 165000, 198600, 235400};
        return moneys[eq_attrib / 10 - 7];
    }

    public static int remakeMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        if (eq_attrib > 120) {
            return 235400;
        }
        final int[] moneys = {83400, 107400, 134600, 165000, 198600, 235400};
        return moneys[eq_attrib / 10 - 7];
    }

    public static int yellowMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        if (eq_attrib > 120) {
            return 353100;
        }
        final int[] moneys = {125100, 161100, 201900, 247500, 297900, 353100};
        return moneys[eq_attrib / 10 - 7];
    }

    public static int appendEqMoney(final int eq_attrib) {
        if (eq_attrib < 70) {
            return 0;
        }
        if (eq_attrib > 120) {
            return 353100;
        }
        final int[] moneys = {125100, 161100, 201900, 247500, 297900, 353100};
        return moneys[eq_attrib / 10 - 7];
    }
}
