package com.fengshen.server.data.game;

public class SuitEffectUtils {
    public static int[] suit(final int sex, final int attrib, final int polar, final int eq_polar) {
//        final int[] suit_light_effects = {10026, 10027, 10028, 10029, 10030};
        final int[] suit_light_effects = {7001, 7002, 7003, 7004, 7005};
        final int[] effect_suit = {0, suit_light_effects[eq_polar - 1]};
        if (attrib <= 79) {
            final int[][] suit_icons = {{860701, 870702, 870703, 860704, 860705}, {870701, 860702, 860703, 870704, 870705}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 89) {
            final int[][] suit_icons = {{860801, 870802, 870803, 860804, 860805}, {870801, 860802, 860803, 860804, 860805}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 99) {
            final int[][] suit_icons = {{860901, 870902, 870903, 860904, 860905}, {870901, 860902, 860903, 870904, 870905}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 109) {
            final int[][] suit_icons = {{861001, 871002, 871003, 861004, 861005}, {871001, 861002, 861003, 871004, 871005}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 119) {
            final int[][] suit_icons = {{861101, 871102, 871103, 861104, 861105}, {871101, 861102, 861103, 871104, 871105}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 129) {
            final int[][] suit_icons = {{861201, 871202, 871203, 861204, 861205}, {871201, 861202, 861203, 871204, 871205}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else if (attrib <= 139) {
            final int[][] suit_icons = {{861301, 871302, 871303, 861304, 861305}, {871301, 861302, 861303, 871304, 871305}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        } else {
            final int[][] suit_icons = {{861301, 871302, 871303, 861304, 861305}, {871301, 861302, 861303, 871304, 871305}};
            effect_suit[0] = suit_icons[sex][polar - 1];
        }
        return effect_suit;
    }
}
