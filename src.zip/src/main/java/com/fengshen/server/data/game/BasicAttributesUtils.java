package com.fengshen.server.data.game;

import com.fengshen.server.domain.Chara;
import com.fengshen.server.domain.PetShuXing;

public class BasicAttributesUtils {
    public static int[] calculationAttributes(final int attrib, final int constitution, final int mag_power, final int phy_power, final int speed, final int wood, final int water, final int fire, final int earth, final int resist_metal) {
        final int[] attributes = {100, 80, 40, 40, 48, 20};
        final int accurate_phy_power = phy_power * 5 + 40;
        final int accurate_resist_metal = (int) (phy_power * 0.45 * resist_metal);
        final int accurate_all = accurate_phy_power + accurate_resist_metal;
        final int mana_mag_power = mag_power * 5 + 40;
        final int mana_wood = (int) (mag_power * 0.16 * wood);
        final int mana_all = mana_mag_power + mana_wood;
        final int wiz_constitution = constitution * 5 + 20;
        final int wiz_fire = (int) (constitution * 0.25 * fire);
        final int wiz_all = wiz_constitution + wiz_fire;
        final int parry_speed = speed * 2 + 48;
        final int parry_earth = (int) (speed * 0.023 * earth);
        final int parry_all = parry_speed + parry_earth;
        final int dex_constitution_per = (int) ((attrib - 2) * 0.3 + 4.0);
        final int dex_constitution = dex_constitution_per * mag_power;
        final int[] dex_attribs = {80, 239, 452, 699, 983, 1303, 1658, 2049, 2476, 2939, 3337, 3861, 4421, 5018};
        int dex_attrib = dex_attribs[0];
        if (attrib >= 130) {
            dex_attrib = dex_attribs[13] + 60 * (attrib - 130);
        } else if (attrib > 1) {
            final int index = attrib / 10;
            dex_attrib = dex_attribs[index] + (dex_attribs[index + 1] - dex_attribs[index]) / 10 * (attrib % 10);
        }
        final int dex_water = (int) (mag_power * 0.657 * water);
        final int dex_all = dex_constitution + dex_attrib + dex_water;
        final int def_constitution_per = (int) ((attrib - 2) * 0.3 + 5.0);
        final int def_constitution = def_constitution_per * constitution;
        final int[] def_attribs = {100, 359, 727, 1177, 1712, 2281, 2971, 3746, 4604, 5546, 6571, 7569, 8751, 10016};
        int def_attrib = def_attribs[0];
        if (attrib >= 130) {
            def_attrib = def_attribs[13] + 127 * (attrib - 130);
        } else if (attrib > 1) {
            final int index2 = attrib / 10;
            def_attrib = def_attribs[index2] + (def_attribs[index2 + 1] - def_attribs[index2]) / 10 * (attrib % 10);
        }
        final int def_water = (int) (constitution * 1.4 * water);
        final int def_all = def_constitution + def_attrib + def_water;
        attributes[0] = def_all;
        attributes[1] = dex_all;
        attributes[2] = accurate_all * 2;
        attributes[3] = mana_all * 2;
        attributes[4] = parry_all;
        attributes[5] = wiz_all * 6 / 5;
        return attributes;
    }

    public static void petshuxing(final PetShuXing petShuXing) {
        final boolean fagong = petShuXing.rank > petShuXing.pet_mag_shape;
        final int[] attributes = PetAttributesUtils.petAttributes(fagong, petShuXing.skill, petShuXing.life, petShuXing.mag_power, petShuXing.phy_power, petShuXing.speed, petShuXing.pet_mana_shape, petShuXing.pet_speed_shape, petShuXing.pet_phy_shape, petShuXing.pet_mag_shape, petShuXing.rank);
        if (petShuXing.max_life >= petShuXing.def) {
            petShuXing.max_life = petShuXing.def;
        }
        if (petShuXing.max_mana >= petShuXing.dex) {
            petShuXing.max_mana = petShuXing.dex;
        }
        petShuXing.def = attributes[0];
        petShuXing.dex = attributes[1];
        petShuXing.accurate = attributes[2];
        petShuXing.mana = attributes[3];
        petShuXing.parry = attributes[4];
        petShuXing.wiz = attributes[5];
        petShuXing.accurate += petShuXing.qinmiAccurate;
        petShuXing.mana += petShuXing.qinmiMana;
        petShuXing.parry += petShuXing.qinmiParry;
        petShuXing.wiz += petShuXing.qinmiWiz;
    }

    public static void shuxing(final Chara chara) {
        final int[] attributes = calculationAttributes(chara.level, chara.life + chara.zbAttribute.life, chara.mag_power + chara.zbAttribute.mag_power, chara.phy_power + chara.zbAttribute.phy_power, chara.speed + chara.zbAttribute.speed, chara.metal + chara.zbAttribute.wood, chara.wood + chara.zbAttribute.water, chara.water + chara.zbAttribute.fire, chara.fire + chara.zbAttribute.earth, chara.earth + chara.zbAttribute.resist_metal);
        chara.def = attributes[0];
        chara.dex = attributes[1];
        if (chara.max_life > chara.def) {
            chara.max_life = chara.def + chara.zbAttribute.def;
        }
        if (chara.max_mana > chara.dex) {
            chara.max_mana = chara.dex + chara.zbAttribute.dex;
        }
        chara.accurate = attributes[2];
        chara.mana = attributes[3];
        chara.parry = attributes[4];
        chara.wiz = attributes[5];
    }

    public static void shuxingToYuanying(final Chara chara) {
        final int[] attributes = calculationAttributes(chara.upgrade_level, chara.life + chara.zbAttribute.life, chara.mag_power + chara.zbAttribute.mag_power, chara.phy_power + chara.zbAttribute.phy_power, chara.speed + chara.zbAttribute.speed, chara.metal + chara.zbAttribute.wood, chara.wood + chara.zbAttribute.water, chara.water + chara.zbAttribute.fire, chara.fire + chara.zbAttribute.earth, chara.earth + chara.zbAttribute.resist_metal);
        chara.def = attributes[0];
        chara.dex = attributes[1];
        if (chara.max_life > chara.def) {
            chara.max_life = chara.def + chara.zbAttribute.def;
        }
        if (chara.max_mana > chara.dex) {
            chara.max_mana = chara.dex + chara.zbAttribute.dex;
        }
        chara.accurate = attributes[2];
        chara.mana = attributes[3];
        chara.parry = attributes[4];
        chara.wiz = attributes[5];
    }

    public static int[] changeCalculationAttributes(final int attrib, final int constitution, final int mag_power, final int phy_power, final int speed) {
        final int accurate_all = phy_power * 5;
        final int mana_all = mag_power * 5;
        final int wiz_all = constitution * 5;
        final int parry_all = speed * 2;
        final int dex_constitution_per = (int) ((attrib - 2) * 0.3 + 4.0);
        final int dex_all = dex_constitution_per * mag_power;
        final int def_constitution_per = (int) ((attrib - 2) * 0.3 + 5.0);
        final int def_all = def_constitution_per * constitution;
        final int[] attributes = {def_all, dex_all, accurate_all, mana_all, parry_all, wiz_all};
        return attributes;
    }

    public static int[] changeRelAttributes(final int attrib, final int constitution, final int mag_power, final int phy_power, final int speed, final int wood, final int water, final int fire, final int earth, final int resist_metal) {
        final int accurate_all = (int) (phy_power * 0.45 * resist_metal);
        final int mana_all = (int) (mag_power * 0.16 * wood);
        final int wiz_all = (int) (constitution * 0.25 * fire);
        final int parry_all = (int) (speed * 0.023 * earth);
        final int dex_all = (int) (mag_power * 0.657 * water);
        final int def_all = (int) (constitution * 1.4 * water);
        final int[] attributes = {def_all, dex_all, accurate_all, mana_all, parry_all, wiz_all};
        return attributes;
    }

    public static int[] calculationHelpAttributes(final int attrib, final int constitution, final int mag_power, final int phy_power, final int speed, final int wood, final int water, final int fire, final int earth, final int resist_metal, final int polar) {
        final int[] attributes = {100, 80, 40, 40, 48, 20};
        final int accurate_phy_power = phy_power * 5 + 40;
        final int accurate_resist_metal = (int) (phy_power * 0.45 * resist_metal);
        final int accurate_all = accurate_phy_power + accurate_resist_metal;
        final int mana_mag_power = mag_power * 5 + 40;
        final int mana_wood = (int) (mag_power * 0.16 * wood);
        final int mana_all = mana_mag_power + mana_wood;
        final int wiz_constitution = constitution * 5 + 20;
        final int wiz_fire = (int) (constitution * 0.25 * fire);
        final int wiz_all = wiz_constitution + wiz_fire;
        final int parry_speed = speed * 2 + 48;
        final int parry_earth = (int) (speed * 0.023 * earth);
        final int parry_all = parry_speed + parry_earth;
        final int dex_constitution_per = (int) ((attrib - 2) * 0.3 + 4.0);
        final int dex_constitution = dex_constitution_per * mag_power;
        final int[] dex_attribs = {80, 239, 452, 699, 983, 1303, 1658, 2049, 2476, 2939, 3337, 3861, 4421, 5018};
        int dex_attrib = dex_attribs[0];
        if (attrib >= 130) {
            dex_attrib = dex_attribs[13] + 60 * (attrib - 130);
        } else if (attrib > 1) {
            final int index = attrib / 10;
            dex_attrib = dex_attribs[index] + (dex_attribs[index + 1] - dex_attribs[index]) / 10 * (attrib % 10);
        }
        final int dex_water = (int) (mag_power * 0.657 * water);
        final int dex_all = dex_constitution + dex_attrib + dex_water;
        final int def_constitution_per = (int) ((attrib - 2) * 0.3 + 5.0);
        final int def_constitution = def_constitution_per * constitution;
        final int[] def_attribs = {100, 359, 727, 1177, 1712, 2281, 2971, 3746, 4604, 5546, 6571, 7569, 8751, 10016};
        int def_attrib = def_attribs[0];
        if (attrib >= 130) {
            def_attrib = def_attribs[13] + 127 * (attrib - 130);
        } else if (attrib > 1) {
            final int index2 = attrib / 10;
            def_attrib = def_attribs[index2] + (def_attribs[index2 + 1] - def_attribs[index2]) / 10 * (attrib % 10);
        }
        final int def_water = (int) (constitution * 1.4 * water);
        final int def_all = def_constitution + def_attrib + def_water;
        final double[][] hs = {{2.0, 8.0, 4.0, 2.0, 10.0}, {1.3, 8.0, 9.0, 2.0, 2.6}, {1.3, 6.0, 3.0, 2.0, 3.0}, {2.0, 1.7, 7.0, 2.0, 6.3}, {1.5, 2.1, 13.0, 2.0, 7.0}};
        attributes[0] = (int) (def_all * hs[polar - 1][0]);
        attributes[1] = (int) (dex_all * hs[polar - 1][0]);
        attributes[2] = (int) (accurate_all * hs[polar - 1][1]);
        attributes[3] = (int) (mana_all * hs[polar - 1][2]);
        attributes[4] = (int) (parry_all * hs[polar - 1][3]);
        attributes[5] = (int) (wiz_all * hs[polar - 1][4]);
        return attributes;
    }
}
