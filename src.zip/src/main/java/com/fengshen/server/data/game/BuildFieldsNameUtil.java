package com.fengshen.server.data.game;

import com.fengshen.core.util.RandomUtil;

import java.util.Hashtable;

public class BuildFieldsNameUtil {
    private static Hashtable<String, String> hashtable = new Hashtable<>();

    static {
        hashtable.put("物伤", "phy_power");
        hashtable.put("法伤", "mag_power");
        hashtable.put("气血", "max_life");
        hashtable.put("防御", "def");
        hashtable.put("速度", "speed");
        hashtable.put("力量", "str");
        hashtable.put("灵力", "wiz");
        hashtable.put("敏捷", "dex");
        hashtable.put("体质", "con");
        hashtable.put("所有属性", "all_attrib");
        hashtable.put("物理必杀率", "stunt_rate");
        hashtable.put("法术必杀率", "mstunt_rate");
        hashtable.put("抗物理必杀", "resist_stunt_rate");
        hashtable.put("抗法术必杀", "resist_mstunt_rate");
        hashtable.put("反震度", "damage_sel");
        hashtable.put("反震率", "damage_sel_rate");
        hashtable.put("反击次数", "counter_attack");
        hashtable.put("反击率", "counter_attack_rate");
        hashtable.put("破防", "penetrate");
        hashtable.put("破防率", "penetrate_rate");
        hashtable.put("物理连击次数", "double_hit");
        hashtable.put("物理连击率", "double_hit_rate");
        hashtable.put("抗物理连击", "resist_double_hit_rate");
        hashtable.put("忽视目标抗金", "ignore_resist_metal");
        hashtable.put("忽视目标抗木", "ignore_resist_wood");
        hashtable.put("忽视目标抗水", "ignore_resist_water");
        hashtable.put("忽视目标抗火", "ignore_resist_fire");
        hashtable.put("忽视目标抗土", "ignore_resist_earth");
        hashtable.put("忽视所有抗性", "ignore_all_resist_polar");
        hashtable.put("忽视所有抗异常", "ignore_all_resist_except");
        hashtable.put("忽视目标抗遗忘", "ignore_resist_forgotten");
        hashtable.put("忽视目标抗中毒", "ignore_resist_poison");
        hashtable.put("忽视目标抗冰冻", "ignore_resist_frozen");
        hashtable.put("忽视目标抗昏睡", "ignore_resist_sleep");
        hashtable.put("忽视目标抗混乱", "ignore_resist_confusion");
        hashtable.put("金抗性", "resist_metal");
        hashtable.put("木抗性", "resist_wood");
        hashtable.put("水抗性", "resist_water");
        hashtable.put("火抗性", "resist_fire");
        hashtable.put("土抗性", "resist_earth");
        hashtable.put("所有抗性", "all_resist_polar");
        hashtable.put("所有抗异常", "all_resist_except");
        hashtable.put("抗遗忘", "resist_forgotten");
        hashtable.put("抗中毒", "resist_poison");
        hashtable.put("抗冰冻", "resist_frozen");
        hashtable.put("抗昏睡", "resist_sleep");
        hashtable.put("抗混乱", "resist_confusion");
        hashtable.put("几率解除遗忘状态", "release_forgotten");
        hashtable.put("几率解除中毒状态", "release_poison");
        hashtable.put("几率解除冰冻状态", "release_frozen");
        hashtable.put("几率解除昏睡状态", "release_sleep");
        hashtable.put("几率解除混乱状态", "release_confusion");
        hashtable.put("几率躲避障碍", "C_skill_dodge");
        hashtable.put("忽视目标躲避障碍", "ignore_C_skill_dodge");
        hashtable.put("几率偷取辅助状态", "steal_buff_rate");
        hashtable.put("抗辅助状态偷取", "ignore_steal_buff_rate");
        hashtable.put("复活率", "relive_rate");
        hashtable.put("忽视目标复活", "ignore_relive_rate");
        hashtable.put("吸血率", "suck_blood_rate");
        hashtable.put("抗吸血", "ignore_suck_blood_rate");
        hashtable.put("致残率", "cripple_rate");
        hashtable.put("抗致残", "ignore_cripple_rate");
        hashtable.put("以守为攻", "defence_to_attack");
        hashtable.put("攻其不备", "phy_attack_by_surprise");
        hashtable.put("出其不意", "mag_attack_by_surprise");
    }

    public static String getAttrKey(String name) {
        return hashtable.get(name);
    }

    public static Integer getValue(String name) {
        int mintValue = 10;
        int maxValue = 100;
        if ("物伤".equals(name)) {
            mintValue = 224;
            maxValue = 1124;
        } else if ("法伤".equals(name)) {
            mintValue = 207;
            maxValue = 1036;
        } else if ("气血".equals(name)) {
            mintValue = 986;
            maxValue = 4934;
        } else if ("防御".equals(name)) {
            mintValue = 657;
            maxValue = 3289;
        } else if ("速度".equals(name)) {
            mintValue = 56;
            maxValue = 282;
        } else if ("力量".equals(name) || "灵力".equals(name) || "敏捷".equals(name) || "体质".equals(name)) {
            mintValue = 6;
            maxValue = 31;
        } else if ("所有属性".equals(name)) {
            mintValue = 3;
            maxValue = 18;
        } else if ("物理必杀率".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("法术必杀率".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("抗物理必杀".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗法术必杀".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("反震度".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("反震率".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("反击次数".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("反击率".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("破防".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("破防率".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("物理连击次数".equals(name)) {
            mintValue = 2;
            maxValue = 12;
        } else if ("物理连击率".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗物理连击".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗金".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗木".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗水".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗火".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗土".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视所有抗性".equals(name)) {
            mintValue = 4;
            maxValue = 20;
        } else if ("忽视所有抗异常".equals(name)) {
            mintValue = 4;
            maxValue = 20;
        } else if ("忽视目标抗遗忘".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗中毒".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗冰冻".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗昏睡".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("忽视目标抗混乱".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("金抗性".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("木抗性".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("水抗性".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("火抗性".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("土抗性".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("所有抗性".equals(name)) {
            mintValue = 4;
            maxValue = 20;
        } else if ("所有抗异常".equals(name)) {
            mintValue = 4;
            maxValue = 20;
        } else if ("抗遗忘".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗中毒".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗冰冻".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗昏睡".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("抗混乱".equals(name)) {
            mintValue = 6;
            maxValue = 30;
        } else if ("几率解除遗忘状态".equals(name)) {
            mintValue = 3;
            maxValue = 15;
        } else if ("几率解除中毒状态".equals(name)) {
            mintValue = 3;
            maxValue = 15;
        } else if ("几率解除冰冻状态".equals(name)) {
            mintValue = 3;
            maxValue = 15;
        } else if ("几率解除昏睡状态".equals(name)) {
            mintValue = 3;
            maxValue = 15;
        } else if ("几率解除混乱状态".equals(name)) {
            mintValue = 3;
            maxValue = 15;
        } else if ("几率躲避障碍".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("忽视目标躲避障碍".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("几率偷取辅助状态".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("抗辅助状态偷取".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("复活率".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("忽视目标复活".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("吸血率".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("抗吸血".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("致残率".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("抗致残".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("以守为攻".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("攻其不备".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        } else if ("出其不意".equals(name)) {
            mintValue = 2;
            maxValue = 10;
        }
        return RandomUtil.randomInt(mintValue, maxValue);
    }
}
