package com.fengshen.server.data.constant;

public class NpcConst {
    public static final Integer PENGLAI_XIANREN;
    public static final int YIN_LU_TONG_ZI = 11338;
    public static final int LINGSHOUYIR_TIANYONGCHENG = 979;

    static {
        PENGLAI_XIANREN = 906;
    }
}
