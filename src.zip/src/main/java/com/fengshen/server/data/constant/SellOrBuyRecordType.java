package com.fengshen.server.data.constant;

public enum SellOrBuyRecordType {
    SELL("出售", 0),
    BUY("购买", 1);

    private String name;
    private int value;

    private SellOrBuyRecordType(final String name, final int value) {
        this.name = name;
        this.value = value;
    }

    private SellOrBuyRecordType(final Integer value) {
        this.value = value;
    }

    public static int getValue(final String name) {
        final SellOrBuyRecordType[] values = values();
        SellOrBuyRecordType[] array;
        for (int length = (array = values).length, i = 0; i < length; ++i) {
            final SellOrBuyRecordType v = array[i];
            if (v.name.equals(name)) {
                return v.value;
            }
        }
        return 7;
    }
}
