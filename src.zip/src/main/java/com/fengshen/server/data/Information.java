package com.fengshen.server.data;

public class Information {
    public String type;
    public String content;
    public String numbertype;
}
