package com.fengshen.server.data.constant;

public enum BonusType {
    EXP("exp"),
    TAO("tao");

    public String type;

    private BonusType(final String type) {
        this.type = type;
    }
}
