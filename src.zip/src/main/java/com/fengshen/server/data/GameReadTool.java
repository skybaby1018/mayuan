package com.fengshen.server.data;

import io.netty.buffer.Unpooled;
import io.netty.buffer.ByteBuf;

import java.nio.charset.Charset;

public class GameReadTool {
    public static Charset DEFAULT_CHARSET;

    static {
        GameReadTool.DEFAULT_CHARSET = Charset.forName("GBK");
    }

    public static String readString(final ByteBuf buff) throws IndexOutOfBoundsException {
        final int lenght = readUnsignedByte(buff);
        if (lenght == 0) {
            return "";
        }
        if (lenght > 0 && lenght <= buff.readableBytes()) {
            final byte[] strByte = new byte[lenght];
            buff.readBytes(strByte);
            return readString(strByte);
        }
        throw new IndexOutOfBoundsException("字符串长度不够 ! ");
    }

    public static String readString2(final ByteBuf buff) throws IndexOutOfBoundsException {
        final int lenght = buff.readUnsignedShort();
        if (lenght == 0) {
            return "";
        }
        if (lenght > 0 && lenght <= buff.readableBytes()) {
            final byte[] strByte = new byte[lenght];
            buff.readBytes(strByte);
            return readString(strByte);
        }
        throw new IndexOutOfBoundsException("字符串长度不够 ! ");
    }

    private static String readString(final byte[] bytes) {
        return new String(bytes, GameReadTool.DEFAULT_CHARSET);
    }

    public static String readString(final byte[] bytes, final int length) {
        return new String(bytes, 0, length, GameReadTool.DEFAULT_CHARSET);
    }

    public static int readUnsignedByte(final ByteBuf buff) {
        final short readUnsignedByte = buff.readUnsignedByte();
        return readUnsignedByte;
    }

    public static int readInt(final ByteBuf buff) {
        final int readInt = buff.readInt();
        return readInt;
    }

    public static long readLong(final ByteBuf buff) {
        final long readLong = buff.readLong();
        return readLong;
    }

    public static int readByte(final ByteBuf buff) {
        final short readUnsignedByte = buff.readUnsignedByte();
        return readUnsignedByte;
    }

    public static int readShort(final ByteBuf buff) {
        int readUnsignedShort = buff.readUnsignedShort();
        return readUnsignedShort;
    }

    public static ByteBuf readLenBuffer2(final ByteBuf buff) {
        final int len = buff.readUnsignedShort();
        final ByteBuf byteBuf = Unpooled.buffer(len);
        buff.readBytes(byteBuf);
        return byteBuf;
    }
}
