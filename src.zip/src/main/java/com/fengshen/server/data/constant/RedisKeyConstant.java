package com.fengshen.server.data.constant;

public interface RedisKeyConstant {
    String LEI_TAI_RANK = "LeiTaiRank";
}
