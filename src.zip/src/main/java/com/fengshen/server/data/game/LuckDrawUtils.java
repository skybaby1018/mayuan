package com.fengshen.server.data.game;

import com.alibaba.fastjson.JSONObject;
import com.fengshen.core.util.Utils;
import com.fengshen.db.domain.*;
import com.fengshen.server.data.write.pet.MSG_UPDATE_PETS;
import com.fengshen.server.domain.Chara;
import com.fengshen.server.domain.GoodsLanSe;
import com.fengshen.server.domain.PetShuXing;
import com.fengshen.server.domain.Petbeibao;
import com.fengshen.server.domain.config.ChoujiangConfig;
import com.fengshen.server.game.*;
import com.fengshen.server.util.GameConfig;
import com.mysql.jdbc.StringUtils;
import io.netty.util.internal.ThreadLocalRandom;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

public class LuckDrawUtils {
    public static void main(final String[] args) {
        String awardStr = "#I首饰|七星手链$指定$35#I";
        awardStr = awardStr.substring(2, awardStr.length() - 2);
        final String[] award = awardStr.split("\\|");
        System.out.println(Arrays.toString(award[1].split("\\$")));
    }

    public static String[] luckDraw(final boolean isSenior) {
        String[] result = null;
        final ChoujiangConfig config = GameConfig.choujiangConfig;
        int baseNumber = config.getBaseNumber();
        if (!isSenior) {
            baseNumber *= 100;
        }
        final double randomLevel = ThreadLocalRandom.current().nextDouble((double) ((baseNumber == 0) ? 100 : baseNumber));
        int level = -1;
        if (randomLevel < config.getNo0()) {
            level = 0;
        } else if (randomLevel < config.getNo1()) {
            level = 1;
        } else if (randomLevel < config.getNo2()) {
            level = 2;
        } else if (isSenior) {
            level = 3;
        } else if (randomLevel < config.getNo3()) {
            level = 3;
        } else {
            level = 4;
        }
        final List<Choujiang> findByLevel = (List<Choujiang>) GameData.that.baseChoujiangService.findByLevel(Integer.valueOf(level));
        final Choujiang choujiang = findByLevel.get(ThreadLocalRandom.current().nextInt(findByLevel.size()));
        String awardStr = choujiang.getDesc();
        awardStr = awardStr.substring(2, awardStr.length() - 2);
        final String[] award = awardStr.split("\\|");
        if ("物品".equals(award[0])) {
            final String item = award[1];
            final String[] split = item.split("#");
            result = new String[]{split[0], "物品", choujiang.getDesc(), String.valueOf(choujiang.getLevel())};
        } else if ("宠物".equals(award[0])) {
            final String nameAndType = award[1].split("\\$")[0];
            final String[] str = nameAndType.split("\\(");
            final String name = str[0];
            final String petType = str[1].replace(")", "");
            result = new String[]{name, petType, choujiang.getDesc(), String.valueOf(choujiang.getLevel())};
        } else if ("首饰".equals(award[0])) {
            // result = new String[]{award[1], "首饰", choujiang.getDesc(), String.valueOf(choujiang.getLevel())};
        } else if ("装备".equals(award[0])) {
            final String[] equipType = award[1].split("\\$");
            result = new String[]{equipType[0], "装备", choujiang.getDesc(), String.valueOf(choujiang.getLevel())};
        }
        return result;
    }

    public static String[] npcLuckDraw() {
        String[] result = null;
        final Example example = new Example(ConfigInfo.class);
        example.selectProperties(new String[]{"data"});
        example.createCriteria().andEqualTo("keyName", "抽奖大使配置信息");
        final ConfigInfo ci = (ConfigInfo) GameData.that.configInfoService.selectOneByExample(example);
        final ChoujiangConfig config = (ChoujiangConfig) JSONObject.parseObject(ci.getData(), ChoujiangConfig.class);
        final int baseNumber = config.getBaseNumber();
        final double randomLevel = ThreadLocalRandom.current().nextDouble((double) ((baseNumber == 0) ? 100 : baseNumber));
        int level = 4;
        if (randomLevel < config.getNo0()) {
            level = 0;
        } else if (randomLevel < config.getNo1()) {
            level = 1;
        } else if (randomLevel < config.getNo2()) {
            level = 2;
        } else if (randomLevel < config.getNo3()) {
            level = 3;
        }
        final List<LuckDrawItem> findByLevel = (List<LuckDrawItem>) GameData.that.luckDrawItemService.getLuckByLevel(level);
        final LuckDrawItem choujiang = findByLevel.get(ThreadLocalRandom.current().nextInt(findByLevel.size()));
        String awardStr = choujiang.getItem();
        awardStr = awardStr.substring(2, awardStr.length() - 2);
        final String[] award = awardStr.split("\\|");
        if ("#I潜能".equals(award[0])) {
            award[0] = "潜能";
        }
        if ("物品".equals(award[0])) {
            final String item = award[1];
            final String[] split = item.split("#");
            result = new String[]{split[0], "物品", choujiang.getItem(), String.valueOf(choujiang.getLevel())};
        } else if ("宠物".equals(award[0])) {
            final String nameAndType = award[1].split("\\$")[0];
            final String[] str = nameAndType.split("\\(");
            final String name = str[0];
            final String petType = str[1].replace(")", "");
            result = new String[]{name, petType, choujiang.getItem(), String.valueOf(choujiang.getLevel())};
        } else if ("首饰".equals(award[0])) {
            result = new String[]{award[1].split("\\$")[0], "首饰", choujiang.getItem(), String.valueOf(choujiang.getLevel())};
        } else if ("装备".equals(award[0])) {
            final String[] equipType = award[1].split("\\$");
            result = new String[]{equipType[0], "装备", choujiang.getItem(), String.valueOf(choujiang.getLevel())};
        } else if ("经验".equals(award[0]) || "潜能".equals(award[0]) || "道行".equals(award[0])) {
            final String[] equipType = award[1].split("\\$");
            result = new String[]{equipType[0], award[0], choujiang.getItem(), String.valueOf(choujiang.getLevel())};
        }
        return result;
    }

    public static void huodechoujiang(final String[] strings, final GameObjectChar gameObjectChar, final String typeName) {
        final Chara chara = gameObjectChar.chara;
        String msg = "#W喜从天降！恭喜#Y" + chara.name + "在#R" + typeName + "#W中幸运的抽中了#R%s#W获得了#R%s#W";
        if (strings[1].equals("变异")) {
            final Pet pet = GameData.that.basePetService.findOneByName(strings[0]);
            final Petbeibao petbeibao = new Petbeibao();
            petbeibao.PetCreate(pet, chara, 0, 3, typeName);
            final List<Petbeibao> list = new ArrayList<Petbeibao>();
            chara.pets.add(petbeibao);
            list.add(petbeibao);
            GameObjectChar.send(new MSG_UPDATE_PETS(), list);
        } else if (strings[1].equals("神兽")) {
            final Pet pet = GameData.that.basePetService.findOneByName(strings[0]);
            final Petbeibao petbeibao = new Petbeibao();
            petbeibao.PetCreate(pet, chara, 0, 4, typeName);
            final List<Petbeibao> list = new ArrayList<Petbeibao>();
            chara.pets.add(petbeibao);
            list.add(petbeibao);
            GameObjectChar.send(new MSG_UPDATE_PETS(), list);
        } else if (strings[1].equals("精怪")) {
            final int jieshu = stageMounts(strings[0]);
            final Pet pet2 = GameData.that.basePetService.findOneByName(strings[0]);
            final Petbeibao petbeibao2 = new Petbeibao();
            petbeibao2.PetCreate(pet2, chara, 0, 2, typeName);
            final List<Petbeibao> list2 = new ArrayList<Petbeibao>();
            chara.pets.add(petbeibao2);
            list2.add(petbeibao2);
            (petbeibao2.petShuXing.get(0)).enchant_nimbus = 0;
            (petbeibao2.petShuXing.get(0)).max_enchant_nimbus = 0;
            (petbeibao2.petShuXing.get(0)).suit_light_effect = 1;
            (petbeibao2.petShuXing.get(0)).hide_mount = jieshu;
            final PetShuXing shuXing = new PetShuXing();
            shuXing.no = 23;
            shuXing.type1 = 2;
            shuXing.accurate = 4 * (jieshu - 1);
            shuXing.mana = 4 * (jieshu - 1);
            shuXing.wiz = 3 * (jieshu - 1);
            shuXing.all_polar = 0;
            shuXing.upgrade_magic = 0;
            shuXing.upgrade_total = 0;
            petbeibao2.petShuXing.add(shuXing);
            GameObjectChar.send(new MSG_UPDATE_PETS(), list2);
        } else if (strings[1].equals("物品")) {
            final StoreInfo info = GameData.that.baseStoreInfoService.findOneByName(strings[0]);
            GameUtil.huodedaoju(gameObjectChar, info, 1);
        } else if (strings[1].equals("首饰")) {
            final String[] split = strings[0].split("\\$");
            final String name = split[0];
            String type = "";
            if (split.length > 1) {
                type = split[1];
                if (Utils.isNumber(type)) {
                    type = "";
                }
            }
            if (StringUtils.isNullOrEmpty(type) || type.startsWith("随机属性")) {
                GameCommonUtil.randomShouShiAttri(chara, name);
            } else if (type.startsWith("满属性")) {
                GameCommonUtil.randomShouShiAllAttri(chara, name);
            } else if (type.equals("所有相五")) {
                GameUtil.jifendengjishoushi(chara, new String[]{name});
            }
        } else if (strings[1].equals("装备")) {
            final Random random = new Random();
            final int[] eqType = {1, 2, 10, 3};
            final int leixing = eqType[random.nextInt(4)];
            final String zhuangbname = zhuangbname(chara, leixing);
            final List<Hashtable<String, Integer>> hashtables = equipmentLuckDraw(chara.level, leixing);
            if (hashtables.size() > 0) {
                final ZhuangbeiInfo zhuangbeiInfo = GameData.that.baseZhuangbeiInfoService.findOneByStr(zhuangbname);
                for (final Hashtable<String, Integer> maps : hashtables) {
                    if (maps.get("groupNo") == 2) {
                        maps.put("groupType", 2);
                        final GoodsLanSe gooodsLanSe = (GoodsLanSe) JSONObject.parseObject(JSONObject.toJSONString(maps), GoodsLanSe.class);
                        GameUtil.getBlueEquipGoods(chara, zhuangbeiInfo, 0, 1, gooodsLanSe);
                    }
                }
            }
        } else if ("经验".equals(strings[1])) {
            GameUtil.huodejingyan(chara, Integer.valueOf(strings[0]), new String[0]);
        } else if ("道行".equals(strings[1])) {
            GameDaoHangUtil.addDaoHang(chara, Integer.valueOf(strings[0]) * 1440, "充值好礼");
        } else if ("潜能".equals(strings[1])) {
            final Chara chara2 = chara;
            chara2.addPot(Integer.valueOf(strings[0]));
        }
        if ("0".equals(strings[3])) {
            msg = String.format(msg, "特等奖", strings[0]);
            GameUtil.sendYaoYan(msg);
        } else if ("1".equals(strings[3])) {
            msg = String.format(msg, "一等奖", strings[0]);
            GameUtil.sendYaoYan(msg);
        }
    }

    private static int stageMounts(final String name) {
        final int[] mounts_stage = {2, 4, 5, 5, 5, 6, 6, 6, 6, 8, 8};
        final String[] mounts_name = {"仙阳剑", "赤焰葫芦", "玉豹", "仙葫芦", "无极熊", "岳麓剑", "古鹿", "北极熊", "筋斗云", "太极熊", "墨麒麟"};
        for (int i = 0; i < mounts_name.length; ++i) {
            if (mounts_name[i].equalsIgnoreCase(name)) {
                return mounts_stage[i];
            }
        }
        return 0;
    }

    private static List<Hashtable<String, Integer>> equipmentLuckDraw(int eq_attrib, final int leixing) {
        if (eq_attrib < 70) {
            eq_attrib = 70;
        } else {
            eq_attrib = eq_attrib / 10 * 10;
        }
        final List<Hashtable<String, Integer>> hashtables = ForgingEquipmentUtils.appraisalEquipment(leixing, eq_attrib, 10);
        final String[] rareAttributes = {"all_resist_except", "all_resist_polar", "all_polar", "all_skill", "ignore_all_resist_except", "mstunt_rate", "release_forgotten"};
        for (final Hashtable<String, Integer> hashtable : hashtables) {
            String[] array;
            for (int length = (array = rareAttributes).length, i = 0; i < length; ++i) {
                final String key = array[i];
                if (hashtable.contains(key)) {
                    final Random random = new Random();
                    final String[] replaceAttributes = {"mag_power", "phy_power", "speed", "life"};
                    final List<Hashtable<String, Integer>> appraisalList = new ArrayList<Hashtable<String, Integer>>();
                    final Hashtable<String, Integer> key_vlaue_tab = new Hashtable<String, Integer>();
                    key_vlaue_tab.put("groupNo", 2);
                    key_vlaue_tab.put(replaceAttributes[random.nextInt(4)], eq_attrib / 4);
                    appraisalList.add(key_vlaue_tab);
                    return appraisalList;
                }
            }
        }
        return hashtables;
    }

    public static String zhuangbname(final Chara chara, final int leixing) {
        int eq_attrib = 0;
        if (chara.level < 70) {
            eq_attrib = 70;
        } else {
            eq_attrib = chara.level / 10 * 10;
        }
        final List<ZhuangbeiInfo> byAttrib = (List<ZhuangbeiInfo>) GameData.that.baseZhuangbeiInfoService.findByAttrib(Integer.valueOf(eq_attrib));
        for (int j = 0; j < byAttrib.size(); ++j) {
            if (leixing == 1 && byAttrib.get(j).getMetal() == chara.polar && byAttrib.get(j).getAmount() == leixing) {
                return byAttrib.get(j).getStr();
            }
            if ((leixing == 2 || leixing == 3) && byAttrib.get(j).getMaster() == chara.sex && byAttrib.get(j).getAmount() == leixing) {
                return byAttrib.get(j).getStr();
            }
            if (leixing == 10 && byAttrib.get(j).getAmount() == leixing) {
                return byAttrib.get(j).getStr();
            }
        }
        return "";
    }
}
