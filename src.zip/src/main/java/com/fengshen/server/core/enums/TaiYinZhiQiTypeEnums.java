package com.fengshen.server.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 太阴之气
 */
@AllArgsConstructor
public enum TaiYinZhiQiTypeEnums {
    TYZQ_BLUE("蓝色", 1),
    TYZQ_PINK("粉色", 2),
    TYZQ_GOLD("金色", 3)
    ;
    @Getter
    private String typeName;
    @Getter
    private Integer type;


    public static Integer getType(String typeName) {
        TaiYinZhiQiTypeEnums[] values = values();
        for (TaiYinZhiQiTypeEnums taiYinZhiQiTypeEnums : values) {
            if (taiYinZhiQiTypeEnums.getTypeName().equals(typeName)) {
                return taiYinZhiQiTypeEnums.getType();
            }
        }
        return TaiYinZhiQiTypeEnums.TYZQ_BLUE.getType();
    }
}
