package com.fengshen.server.core.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum FlyTypeEnums {
    TYPE_LOTUS("梦荷", 1),
    TYPE_YU_TIAN_SUO("御天梭", 2),
    TYPE_MO_YAN_FEI_JIA("魔炎飞甲", 3),
    TYPE_MO_WU_QING_YUN("墨舞青云", 4),
    TYPE_LIE_HAI_LONG_JING("裂海龙鲸", 5);
    @Getter
    private String typeName;
    @Getter
    private Integer type;

    public static Integer getType(String typeName) {
        FlyTypeEnums[] values = values();
        for (FlyTypeEnums flyTypeEnums : values) {
            if (flyTypeEnums.getTypeName().equals(typeName)) {
                return flyTypeEnums.getType();
            }
        }
        return FlyTypeEnums.TYPE_LOTUS.getType();
    }
}
