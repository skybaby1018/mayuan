package com.fengshen.server.core.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum PlayInstructionEnums {
    TYPE_3(3, ""),
    TYPE_19(19, "一级装备新手指引"),
    TYPE_20(20, "二级道具新手指引"),
    TYPE_17(17, "宠物战斗的新手指引"),
    TYPE_30(30, "高物伤新手指引"),
    TYPE_31(31, "高法伤新手指引"),
    TYPE_38(38, "学习技能新手指引"),
    ;
    @Getter
    private Integer type;
    @Getter
    private String typeName;
}
