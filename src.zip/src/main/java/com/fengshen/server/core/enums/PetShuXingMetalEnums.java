package com.fengshen.server.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum PetShuXingMetalEnums {
    NULL(0, "无"),
    TYPE_JIE(1, "金"),
    TYPE_NU(2, "木"),
    TYPE_SHUI(3, "水"),
    TYPE_HUO(4, "火"),
    TYPE_TU(5, "土"),;
    @Getter
    private Integer type;
    @Getter
    private String typeName;

    public static Integer getType(String typeName) {
        PetShuXingMetalEnums[] values = values();
        for (PetShuXingMetalEnums petShuXingMetalEnums : values) {
            if (petShuXingMetalEnums.getTypeName().equals(typeName)) {
                return petShuXingMetalEnums.getType();
            }
        }
        return PetShuXingMetalEnums.NULL.getType();
    }
}
