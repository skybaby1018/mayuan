package com.fengshen.server.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author cl
 * @version 2021年03月2021/3/27日 18时49分
 */
@AllArgsConstructor
public enum MoLongTunTianEnums {
    TYPE_MO_LONG_TAIL(1, "魔龙之尾"),
    TYPE_MO_LONG_CLAW(2, "魔龙之爪"),
    TYPE_MO_LONG_LEADER(3, "魔龙之首"),
    TYPE_MO_LONG_DRAGON(4, "魔龙吞天"),
    TYPE_MO_LONG_NU(5, "魔龙吞天·怒");
    @Getter
    private Integer type;
    @Getter
    private String typeName;

    public static Integer getType(String typeName) {
        MoLongTunTianEnums[] values = values();
        for (MoLongTunTianEnums moLongTunTianEnums : values) {
            if (moLongTunTianEnums.getTypeName().equals(typeName)) {
                return moLongTunTianEnums.getType();
            }
        }
        return MoLongTunTianEnums.TYPE_MO_LONG_TAIL.getType();
    }

    public static String getTypeName(int type) {
        return values()[type - 1].getTypeName();
    }
}
