//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.server.choujiang;

import com.alibaba.fastjson.JSONObject;
import com.fengshen.db.domain.StoreInfo;
import com.fengshen.server.data.vo.Vo_40964_0;
import com.fengshen.server.data.write.M40964_0;
import com.fengshen.server.data.write.M65525_0;
import com.fengshen.server.domain.Chara;
import com.fengshen.server.domain.Goods;
import com.fengshen.server.domain.GoodsInfo;
import com.fengshen.server.game.GameDaoHangUtil;
import com.fengshen.server.game.GameData;
import com.fengshen.server.game.GameObjectCharMng;
import com.fengshen.server.game.GameUtil;
import com.fengshen.server.mng.GameJIfenZhuangbei;
import com.fengshen.server.util.backPackUtil;

import java.util.*;

public class GameNpcChouJiang {
    private static Map<String, Npc_Choujiang> ncs = new HashMap();

    public GameNpcChouJiang() {
    }

    public static synchronized Npc_Choujiang getNpc_Choujiang(String name) {
        Npc_Choujiang nc = (Npc_Choujiang) ncs.get(name);
        if (nc != null) {
            return nc;
        } else {
            Npc_Choujiang npc_cj = GameData.that.npc_choujiang.getNpc_ChoujiangByName(name);
            ncs.put(name, npc_cj);
            return npc_cj;
        }
    }

    public static synchronized List<Npc_Choujiang> getNpc_Choujiangs() {
        List<Npc_Choujiang> npc_cj = GameData.that.npc_choujiang.getNpc_ChoujiangByNames();
        return npc_cj;

    }

    public static void flushNpcChouJiang(String name) {
        Npc_Choujiang npc_cj = GameData.that.npc_choujiang.getNpc_ChoujiangByName(name);
        ncs.put(name, npc_cj);
    }

    public static String huodechoujiang(JSONObject jiangli, Chara chara) {
        if (jiangli.size() == 0) {
            return "未中奖";
        } else {
            String jname = "";
            boolean has = false;
            Iterator var4 = jiangli.keySet().iterator();

            while (var4.hasNext()) {
                String key = (String) var4.next();
                byte var7 = -1;
                switch (key.hashCode()) {
                    case -652108106:
                        if (key.equals("随机装备礼包")) {
                            var7 = 4;
                        }
                        break;
                    case -508011922:
                        if (key.equals("随机首饰礼包")) {
                            var7 = 5;
                        }
                        break;
                    case 929656:
                        if (key.equals("物品")) {
                            var7 = 6;
                        }
                        break;
                    case 1045917:
                        if (key.equals("经验")) {
                            var7 = 3;
                        }
                        break;
                    case 1180249:
                        if (key.equals("道行")) {
                            var7 = 2;
                        }
                        break;
                    case 1174386324:
                        if (key.equals("随机宠物")) {
                            var7 = 0;
                        }
                        break;
                    case 1174517043:
                        if (key.equals("随机法宝")) {
                            var7 = 1;
                        }
                }

                switch (var7) {
                    case 0:
                        String[] cws = jiangli.getString(key).split(",");
                        int rcw = (new Random()).nextInt(cws.length);
                        String[] cw = cws[rcw].split("#");
                        jname = jname + cw[0] + ";";
                        GameUtil.huodechoujiangs(cw, chara, "npc抽奖随机宠物");
                        has = true;
                        break;
                    case 1:
                        String[] fabaos = jiangli.getString(key).split(",");
                        int rfb = (new Random()).nextInt(fabaos.length);
                        String[] fabao = fabaos[rfb].split("#");
                        jname = jname + fabao[1] + "(" + fabao[0] + "级" + fabao[2] + "相性);";
                        sendTreasure(fabao[1], fabao[2], Integer.parseInt(fabao[0]), chara);
                        has = true;
                        break;
                    case 2:
                        String daohang = jiangli.getString(key);
                        jname = jname + "道行" + daohang + "年;";
                        GameDaoHangUtil.addDaoHang(chara, Integer.parseInt(daohang));
                        break;
                    case 3:
                        String jingyan = jiangli.getString(key);
                        jname = jname + "经验" + jingyan + ";";
                        GameUtil.huodejingyan(chara, Integer.parseInt(jingyan));
                        break;
                    case 4:
                        String[] zblibaonames = jiangli.getString(key).split(",");
                        int rzb = (new Random()).nextInt(zblibaonames.length);
                        String zblibaoname = zblibaonames[rzb];
                        GameJIfenZhuangbei.huodezhuangbei(chara, zblibaoname);
                        jname = jname + zblibaoname + ";";
                        has = true;
                        break;
                    case 5:
                        String[] sslibaonames = jiangli.getString(key).split(",");
                        int rss = (new Random()).nextInt(sslibaonames.length);
                        String sslibaoname = sslibaonames[rss];
                        jname = jname + sslibaoname + ";";
                        GameJIfenZhuangbei.huodeshoushi(chara, sslibaoname);
                        has = true;
                        break;
                    case 6:
                        String rewardStr = jiangli.getString(key);
                        String[] strings = rewardStr.split("\\|");
                        if (rewardStr.indexOf("范围") != -1) {
                            jname = jname + strings[2] + strings[1] + "个;";
                        } else {
                            jname = jname + strings[0] + strings[2] + "个;";
                        }

                        GameUtil.huodechoujiangs(strings, chara, "npc抽奖物品");
                }
            }

            if (has) {
                GameUtil.sendGongGaoMsg("恭喜#Y" + chara.name + "#n在积分抽奖中获得#R" + jname + "#n真是可喜可贺呀！");
            }

            return jname;
        }
    }


    public static void sendTreasure(String tname, String xiangx, int level, Chara chara) {
        StoreInfo info = GameData.that.baseStoreInfoService.findOneByName(tname);
        if (info == null) {
            GameUtil.sendMsg("没有#R" + tname + "#n这个法宝", chara.getId());
        } else {
            int xx = xiangx.equals("金") ? 1 : (xiangx.equals("木") ? 2 : (xiangx.equals("水") ? 3 : (xiangx.equals("火") ? 4 : (xiangx.equals("土") ? 5 : 0))));
            Goods goods = new Goods();
            goods.pos = backPackUtil.getBackpackEmptyPos(chara);
            goods.goodsInfo = new GoodsInfo();
            if (info.getQuality() != null) {
                goods.goodsInfo.quality = info.getQuality();
            }

            if (info.getSilverCoin() != null) {
                goods.goodsInfo.silver_coin = info.getSilverCoin();
            }

            goods.goodsInfo.type = info.getType();
            goods.goodsInfo.attrib = 0;
            goods.goodsInfo.shape = 0;
            goods.goodsInfo.str = info.getName();
            goods.goodsInfo.nick = 0;
            goods.goodsInfo.recognize_recognized = info.getRecognizeRecognized();
            goods.goodsInfo.auto_fight = UUID.randomUUID().toString();
            goods.goodsInfo.total_score = info.getTotalScore();
            goods.goodsInfo.rebuild_level = 50000;
            goods.goodsInfo.value = info.getValue();
            goods.goodsInfo.degree_32 = 1;
            goods.goodsInfo.owner_id = 1;
            goods.goodsInfo.pot = 0;
            goods.goodsInfo.damage_sel_rate = 400976;
            goods.goodsInfo.diandqk_frozen_round = 3;
            goods.goodsInfo.skill = level;
            goods.goodsInfo.amount = 9;
            goods.goodsInfo.resist_poison = 1830;
            goods.goodsInfo.shuadao_ziqihongmeng = xx;
            chara.backpack.add(goods);
            GameObjectCharMng.getGameObjectChar(chara.getId()).sendOne(new M65525_0(), GameUtil.putList(new Object[]{goods}));
            Vo_40964_0 vo_40964_0 = new Vo_40964_0();
            vo_40964_0.type = 1;
            vo_40964_0.name = tname;
            vo_40964_0.param = "20691134";
            vo_40964_0.rightNow = 0;
            GameObjectCharMng.getGameObjectChar(chara.getId()).sendOne(new M40964_0(), vo_40964_0);
        }
    }
}
