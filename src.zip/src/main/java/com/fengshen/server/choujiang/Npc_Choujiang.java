package com.fengshen.server.choujiang;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fengshen.core.util.RandomUtil;

import java.util.Random;

public class Npc_Choujiang {
    private int id;
    private String name;
    private String config;
    private int jifen;
    private JSONArray jconfig;

    public Npc_Choujiang() {
    }

    public void setConfig(String config) {
        this.config = config;
        this.jconfig = JSONArray.parseArray(config);
    }

    public JSONObject choujiang() {
        float min = 100.0F;
        float randomFloat = RandomUtil.randomFloat(0.0F, 100.0F);
        JSONObject jiangli = new JSONObject();

        for (int i = 0; i < this.jconfig.size(); ++i) {
            String str = this.jconfig.getString(i);
            JSONObject jb = JSONObject.parseObject(str);
            float gl = jb.getFloat("概率").floatValue();
            if (randomFloat < gl && min > gl) {
                min = gl;
                jiangli = jb;
            }
        }

        return jiangli;
    }

    public static void main(String[] args) {
        String config = "[{\"概率\":5,\"装备\":{\"法\":[{\"type\":\"武器\",\"lan1\":\"所有相性\",\"lan1value\":\"5\",\"lan2\":\"伤害\",\"lan2value\":\"3700\",\"lan3\":\"金相性\",\"lan3value\":\"5\",\"fen\":\"所有相性\",\"fenvalue\":\"5\",\"huang\":\"伤害\",\"huangvalue\":\"3700\",\"lv\":\"强金法伤害\",\"lvvalue\":\"10\"},{\"type\":\"帽子\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"灵力\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"灵力\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"灵力\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"灵力\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"灵力\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"灵力\",\"huangvalue\":\"37\",\"lv\":\"几率躲避攻击\",\"lvvalue\":\"30\"}],\"力\":[{\"type\":\"武器\",\"lan1\":\"所有相性\",\"lan1value\":\"5\",\"lan2\":\"伤害\",\"lan2value\":\"3700\",\"lan3\":\"土相性\",\"lan3value\":\"5\",\"fen\":\"所有相性\",\"fenvalue\":\"5\",\"huang\":\"伤害\",\"huangvalue\":\"3700\",\"lv\":\"强物理伤害\",\"lvvalue\":\"10\"},{\"type\":\"帽子\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"力量\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"力量\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"力量\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"力量\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"力量\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"灵力\",\"huangvalue\":\"37\",\"lv\":\"几率躲避攻击\",\"lvvalue\":\"30\"}],\"敏\":[{\"type\":\"武器\",\"lan1\":\"所有相性\",\"lan1value\":\"5\",\"lan2\":\"忽视所有抗异常\",\"lan2value\":\"20\",\"lan3\":\"火相性\",\"lan3value\":\"5\",\"fen\":\"所有相性\",\"fenvalue\":\"5\",\"huang\":\"忽视所有抗异常\",\"huangvalue\":\"20\",\"lv\":\"忽视目标抗遗忘,忽视目标抗中毒,忽视目标抗冰冻,忽视目标抗昏睡,忽视目标抗混乱\",\"lvvalue\":\"30\"},{\"type\":\"帽子\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"几率躲避攻击\",\"lvvalue\":\"30\"}],\"体\":[{\"type\":\"武器\",\"lan1\":\"所有相性\",\"lan1value\":\"5\",\"lan2\":\"水相性\",\"lan2value\":\"20\",\"lan3\":\"木相性\",\"lan3value\":\"5\",\"fen\":\"所有相性\",\"fenvalue\":\"5\",\"huang\":\"水相性\",\"huangvalue\":\"5\",\"lv\":\"忽视目标抗遗忘,忽视目标抗中毒,忽视目标抗冰冻,忽视目标抗昏睡,忽视目标抗混乱\",\"lvvalue\":\"30\"},{\"type\":\"帽子\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"抗中毒\",\"lvvalue\":\"20\"},{\"type\":\"衣服\",\"lan1\":\"所有属性\",\"lan1value\":\"27\",\"lan2\":\"敏捷\",\"lan2value\":\"37\",\"lan3\":\"体质\",\"lan3value\":\"37\",\"fen\":\"所有属性\",\"fenvalue\":\"27\",\"huang\":\"敏捷\",\"huangvalue\":\"37\",\"lv\":\"几率躲避攻击\",\"lvvalue\":\"30\"}]}},{\"概率\":10,\"法宝\":\"24#番天印#金,24#混元金斗#土,24#定海珠#火\"},{\"概率\":15,\"宠物\":\"妈祖,程咬金,罗汉王,后羿\"},{\"概率\":70,\"道行\":\"100\"},{\"概率\":80,\"经验\":\"9999999\"}]";
        JSONArray parseArray = JSONArray.parseArray(config);
        new JSONObject();
        int nextInt = (new Random()).nextInt(100);
        int min = 100;

        for (int i = 0; i < parseArray.size(); ++i) {
            String str = parseArray.getString(i);
            JSONObject jb = JSONObject.parseObject(str);
            Integer gl = jb.getInteger("概率");
            if (nextInt < gl.intValue() && min > gl.intValue()) {
                min = gl.intValue();
            }
        }

    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getConfig() {
        return this.config;
    }

    public int getJifen() {
        return this.jifen;
    }

    public JSONArray getJconfig() {
        return this.jconfig;
    }
}
