package com.fengshen;

import com.alibaba.fastjson.JSON;
import com.fengshen.core.util.Utils;
import com.fengshen.server.auth.LoginAuth;
import com.fengshen.server.disruptor.EventConsumer;
import com.fengshen.server.disruptor.GlobalQueue;
import com.fengshen.server.disruptor.World;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import tk.mybatis.spring.annotation.MapperScan;

import java.lang.reflect.Method;

/**
 * @author mint
 */
@SpringBootApplication(
        scanBasePackages = {"com.fengshen"},
        exclude = {DataSourceAutoConfiguration.class}
)
@EnableTransactionManagement(
        proxyTargetClass = true
)
@MapperScan({"com.fengshen.db.dao"})
@EnableScheduling
@EnableAsync
@ServletComponentScan
@EnableCaching
public class GameServerApplication implements ApplicationRunner {

    @Autowired
    private World world;
    private GlobalQueue globalQueue;

    public GameServerApplication() {
    }

    public static void main(final String[] args) throws Exception {
        SpringApplication.run(GameServerApplication.class, args);
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        this.globalQueue = new GlobalQueue(new EventConsumer(this.world));
    }

    @Bean(
            name = {"cacheAutoKey"}
    )
    public KeyGenerator myKeyGenerator() {
        return new KeyGenerator() {
            @Override
            public Object generate(Object target, Method method, Object... params) {
                StringBuilder sb = new StringBuilder();
                sb.append(target.getClass().getName());
                sb.append(method.getName());
                sb.append("&");
                Object[] var8 = params;
                int var7 = params.length;

                for (int var6 = 0; var6 < var7; ++var6) {
                    Object obj = var8[var6];
                    if (obj != null) {
                        sb.append(obj.getClass().getName());
                        sb.append("&");
                        sb.append(JSON.toJSONString(obj));
                        sb.append("&");
                    }
                }

                return DigestUtils.sha256Hex(sb.toString());
            }
        };
    }
}
