//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.mybatis;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonStringArrayTypeHandler extends BaseTypeHandler<String[]> {
    private static final ObjectMapper mapper = new ObjectMapper();
    private final Logger logger = LoggerFactory.getLogger(JsonStringArrayTypeHandler.class);

    public JsonStringArrayTypeHandler() {
    }

    public void setNonNullParameter(final PreparedStatement ps, final int i, final String[] parameter, final JdbcType jdbcType) throws SQLException {
        ps.setString(i, this.toJson(parameter));
    }

    public String[] getNullableResult(final ResultSet rs, final String columnName) throws SQLException {
        return this.toObject(rs.getString(columnName));
    }

    public String[] getNullableResult(final ResultSet rs, final int columnIndex) throws SQLException {
        return this.toObject(rs.getString(columnIndex));
    }

    public String[] getNullableResult(final CallableStatement cs, final int columnIndex) throws SQLException {
        return this.toObject(cs.getString(columnIndex));
    }

    private String toJson(final String[] params) {
        try {
            return mapper.writeValueAsString(params);
        } catch (Exception var3) {
            this.logger.error("", var3);
            return "[]";
        }
    }

    private String[] toObject(final String content) {
        if (content != null && !content.isEmpty()) {
            try {
                return (String[]) mapper.readValue(content, String[].class);
            } catch (Exception var3) {
                this.logger.error("", var3);
                throw new RuntimeException(var3);
            }
        } else {
            return null;
        }
    }
}
