package com.fengshen.db.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapUtil {
    public static Map setMap(final Object... data) {
        final Map<String, Object> map = new LinkedHashMap<String, Object>();
        for (int i = 0; i < data.length; i += 2) {
            map.put(String.valueOf(data[i]), data[i + 1]);
        }
        return map;
    }

    public static <T> T get(final Map<Object, Object> map, final String key, final Class<T> t) {
        return (T) map.get(key);
    }
}
