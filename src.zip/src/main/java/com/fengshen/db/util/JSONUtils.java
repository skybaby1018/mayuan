package com.fengshen.db.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JSONUtils {
    private static final ObjectMapper mapper;
    private static Logger log;

    public static String toJSONString(final Object data) {
        String str = null;
        try {
            str = JSONUtils.mapper.writeValueAsString(data);
        } catch (Exception e) {
            JSONUtils.log.error("data: " + data, (Throwable) e);
        }
        return str;
    }

    public static <T> T parseObject(final String jsonData, final Class<T> beanType) {
        try {
            return (T) JSONUtils.mapper.readValue(jsonData, (Class) beanType);
        } catch (Exception e) {
            JSONUtils.log.error("data: " + jsonData, (Throwable) e);
            return null;
        }
    }

    static {
        mapper = new ObjectMapper();
        JSONUtils.log = LoggerFactory.getLogger((Class) JSONUtils.class);
    }
}
