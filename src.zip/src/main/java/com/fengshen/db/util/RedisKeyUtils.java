package com.fengshen.db.util;

/**
 * Date:2020/3/6 0006
 * Time:下午 9:11
 */
public class RedisKeyUtils {
    public static String getCharacKey(int charaId) {
        return "Chara_" + charaId;
    }
}
