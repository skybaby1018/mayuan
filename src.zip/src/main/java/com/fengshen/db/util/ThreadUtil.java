package com.fengshen.db.util;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadUtil {
    public static void Sleep(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void RunOneThread(final Runnable command) {
        Executors.newSingleThreadExecutor().execute(command);
    }

    public static void RunManyThread(final Runnable command, final int num) {
        Executors.newFixedThreadPool(num).execute(command);
    }

    public static void RunCacheThread(final Runnable command) {
        Executors.newCachedThreadPool().execute(command);
    }

    public static void RunScheduledThread(final Runnable command, final int num, final long sleep) {
        Executors.newScheduledThreadPool(num).schedule(command, sleep, TimeUnit.SECONDS);
    }
}
