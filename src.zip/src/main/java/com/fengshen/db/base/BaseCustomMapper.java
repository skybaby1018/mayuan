package com.fengshen.db.base;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

public interface BaseCustomMapper<T> extends SelectMapper<T>, Mapper<T> {
}
