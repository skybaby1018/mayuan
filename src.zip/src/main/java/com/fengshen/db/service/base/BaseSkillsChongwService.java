//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.SkillsChongwMapper;
import com.fengshen.db.domain.SkillsChongw;
import com.fengshen.db.domain.example.SkillsChongwExample;
import com.fengshen.db.domain.example.SkillsChongwExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseSkillsChongwService {
    @Autowired
    protected SkillsChongwMapper mapper;

    public BaseSkillsChongwService() {
    }

    public SkillsChongw findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public SkillsChongw findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final SkillsChongw skillsChongw) {
        skillsChongw.setAddTime(LocalDateTime.now());
        skillsChongw.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(skillsChongw);
    }

    public int updateById(final SkillsChongw skillsChongw) {
        skillsChongw.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(skillsChongw);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<SkillsChongw> findByOwnerid(final String ownerid) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andOwneridEqualTo(ownerid);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkllCwid(final String skllCwid) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkllCwidEqualTo(skllCwid);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkillIdHex(final String skillIdHex) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillIdHexEqualTo(skillIdHex);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkillName(final String skillName) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillNameEqualTo(skillName);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkillReqpolar(final Integer skillReqpolar) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillReqpolarEqualTo(skillReqpolar);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkillLevel(final Integer skillLevel) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillLevelEqualTo(skillLevel);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findBySkillMubiao(final Integer skillMubiao) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillMubiaoEqualTo(skillMubiao);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findByTianshuId(final String tianshuId) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTianshuIdEqualTo(tianshuId);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findByTianshuName(final String tianshuName) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTianshuNameEqualTo(tianshuName);
        return this.mapper.selectByExample(example);
    }

    public SkillsChongw findOneByOwnerid(final String ownerid) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andOwneridEqualTo(ownerid);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkllCwid(final String skllCwid) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkllCwidEqualTo(skllCwid);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkillIdHex(final String skillIdHex) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillIdHexEqualTo(skillIdHex);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkillName(final String skillName) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillNameEqualTo(skillName);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkillReqpolar(final Integer skillReqpolar) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillReqpolarEqualTo(skillReqpolar);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkillLevel(final Integer skillLevel) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillLevelEqualTo(skillLevel);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneBySkillMubiao(final Integer skillMubiao) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSkillMubiaoEqualTo(skillMubiao);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneByTianshuId(final String tianshuId) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTianshuIdEqualTo(tianshuId);
        return this.mapper.selectOneByExample(example);
    }

    public SkillsChongw findOneByTianshuName(final String tianshuName) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTianshuNameEqualTo(tianshuName);
        return this.mapper.selectOneByExample(example);
    }

    public List<SkillsChongw> findAll(final int page, final int size, final String sort, final String order) {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<SkillsChongw> findAll() {
        SkillsChongwExample example = new SkillsChongwExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }
}
