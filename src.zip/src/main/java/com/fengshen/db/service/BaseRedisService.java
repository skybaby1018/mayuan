//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.service;

import com.alibaba.fastjson.JSONObject;
import com.fengshen.core.util.JSONUtils;
import com.fengshen.server.configrw.ConfigUtil;
import com.fengshen.server.util.GameConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Component
public class BaseRedisService {
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    public BaseRedisService() {
    }

    private String portNameKey(Object key) {
        return GameConfig.lineName + ":" + key.toString();
    }

    public void setString(String key, Object data, Long timeout) {
        if (data instanceof String) {
            String value = (String) data;
            this.stringRedisTemplate.opsForValue().set(key, value);
        }

        if (timeout != null) {
            this.stringRedisTemplate.expire(key, timeout, TimeUnit.SECONDS);
        }

    }

    public void setObject(Object key, Object object, Long timeout) {
        try {
            String jsonString = JSONUtils.toJSONString(object);
            this.setString(this.portNameKey(key), jsonString, timeout);
        } catch (Exception var5) {
        }

    }

    public void setObject(Object key, Object object) {
        try {
            String k = this.portNameKey(key);
            String jsonString = JSONUtils.toJSONString(object);
            if (k.indexOf("CharaId") == -1 && k.indexOf("AccountsKeyId") == -1) {
                this.setString(k, jsonString, (Long) null);
                return;
            }

            this.setString(k, jsonString, (Long) null);
        } catch (Exception var5) {
        }

    }

    public String getString(String key) {
        Object data = this.stringRedisTemplate.opsForValue().get(this.portNameKey(key));
        return data == null ? null : data.toString();
    }

    public Set<String> keys(String pattern) {
        Set<String> keys = this.stringRedisTemplate.keys(this.portNameKey(pattern));
        return keys;
    }

    public <T> T getObject(Object key, Class<T> clazz) {
        try {
            String string = (String) this.stringRedisTemplate.opsForValue().get(this.portNameKey(key));
            if (string != null) {
                return JSONObject.parseObject(string, clazz);
            }
        } catch (Exception var4) {
        }

        return null;
    }

    public <T> List<T> getList(String key, Class<T> clazz) {
        String string = this.getString(key);
        if (string != null) {
            List<T> parseArray = JSONObject.parseArray(string, clazz);
            return parseArray;
        } else {
            return null;
        }
    }

    public void delKey(String key) {
        try {
            this.stringRedisTemplate.delete(this.portNameKey(key));
        } catch (Exception var3) {
        }

    }

    public void flushdb() {
        Set<String> keys = this.stringRedisTemplate.keys(this.portNameKey("*"));
        Iterator var2 = keys.iterator();

        while (var2.hasNext()) {
            String key = (String) var2.next();
            this.stringRedisTemplate.delete(key);
        }

    }
}
