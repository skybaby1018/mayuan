//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.SysUserMapper;
import com.fengshen.db.domain.sys.SysUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class SysUserService implements BaseServiceSupport<SysUser> {
    @Autowired
    private SysUserMapper sum;

    public SysUserService() {
    }

    public SysUser login(String username, String password) {
        Example example = new Example(SysUser.class);
        example.createCriteria().andEqualTo("password", password).andEqualTo("userName", username);
        SysUser login = (SysUser) this.sum.selectOneByExample(example);
        return login;
    }

    public int addSysUser(SysUser su) {
        return this.sum.insertSelective(su);
    }

    public int changePassword(SysUser su) {
        return this.sum.updateByPrimaryKeySelective(su);
    }

    public SysUser getUserById(Long id) {
        return (SysUser) this.sum.selectByPrimaryKey(id);
    }

    public BaseCustomMapper<SysUser> getBaseMapper() {
        return this.sum;
    }
}
