//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.shidao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.ShidaoHistoryMapper;
import com.fengshen.db.domain.ShidaoHistory;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShidaoHistoryService implements BaseServiceSupport<ShidaoHistory> {
    @Autowired
    private ShidaoHistoryMapper shs;

    public ShidaoHistoryService() {
    }

    public BaseCustomMapper<ShidaoHistory> getBaseMapper() {
        return this.shs;
    }
}
