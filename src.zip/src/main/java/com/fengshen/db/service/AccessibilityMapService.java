//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.AccessibilityMapMapper;
import com.fengshen.db.domain.AccessibilityMap;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccessibilityMapService implements BaseServiceSupport<AccessibilityMap> {
    @Autowired
    private AccessibilityMapMapper am;

    public AccessibilityMapService() {
    }

    @Override
    public BaseCustomMapper<AccessibilityMap> getBaseMapper() {
        return this.am;
    }

    public List<AccessibilityMap> getRandomData(AccessibilityMap map) {
        if (map.getX() == null || map.getX() == 0) {
            map.setX(1);
        }

        return this.am.getRandomData(map);
    }

    public List<AccessibilityMap> getRandomData(Integer size) {
        return this.am.randomData(size);
    }
}
