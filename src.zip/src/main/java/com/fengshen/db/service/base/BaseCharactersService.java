//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.CharactersMapper;
import com.fengshen.db.domain.Characters;
import com.mysql.jdbc.StringUtils;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class BaseCharactersService implements BaseServiceSupport<Characters> {
    @Autowired
    protected CharactersMapper mapper;

    public BaseCharactersService() {
    }

    public Characters findById(final int id) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("id", id);
        return (Characters) this.mapper.selectByPrimaryKey(id);
    }

    public Characters findByIdContainsDelete(final int id) {
        return (Characters) this.mapper.selectByPrimaryKey(id);
    }

    public void add(final Characters characters) {
        characters.setAddTime(new Date());
        characters.setUpdateTime(new Date());
        this.mapper.insertSelective(characters);
    }

    public int updateById(final Characters characters) {
        characters.setUpdateTime(new Date());
        return this.mapper.updateByPrimaryKeySelective(characters);
    }

    public int updateSelective(final Characters characters) {
        characters.setUpdateTime(new Date());
        return this.mapper.updateByPrimaryKeySelective(characters);
    }

    public void deleteById(final int id) {
        //this.mapper.deleteByPrimaryKey(id);
    }

    public List<Characters> findByName(final String name) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("name", name);
        return this.mapper.selectByExample(example);
    }

    public List<Characters> findByAccountId(final Integer accountId) {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("accountId", accountId);
        return this.mapper.selectByExample(example);
    }

    public List<Characters> findByGid(final String gid) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("gid", gid);
        return this.mapper.selectByExample(example);
    }

    public Characters findOneByName(final String name) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("name", name.replaceAll("\\s*", ""));
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters findOneBlobByName(final String name) {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("name", name.replaceAll("\\s*", ""));
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters login(int accountId, String name) {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("name", name.replaceAll("\\s*", "")).andEqualTo("accountId", accountId);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters findOneByNameSelectProperties(final String name, String... propString) {
        Example example = new Example(Characters.class);
        example.selectProperties(propString);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("name", name.replaceAll("\\s*", ""));
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters findOneByGidSelectProperties(final String gid, String... propString) {
        Example example = new Example(Characters.class);
        example.selectProperties(propString);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("gid", gid);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters findOneByIdSelectProperties(final Integer id, String... propString) {
        Example example = new Example(Characters.class);
        example.selectProperties(propString);
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("id", id);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public List<Characters> findByObjSelectProperties(Characters chara, String... propString) {
        Example example = new Example(Characters.class);
        example.selectProperties(propString);
        if (chara != null) {
            example.createCriteria().andEqualTo(chara);
        }
        return this.mapper.selectByExample(example);
    }

    public Characters findOneByAccountId(final Integer accountId) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("accountId", accountId);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public Characters findOneByGid(final String gid) {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false).andEqualTo("gid", gid);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public List<Characters> findAll() {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("deleted", false);
        return this.mapper.selectByExample(example);
    }

    public List<Characters> findAllByBolb() {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("deleted", false);
        return this.mapper.selectByExample(example);
    }

    public Characters findOneByGid2(String gid) {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("gid", gid);
        return (Characters) this.mapper.selectOneByExample(example);
    }

    public long getOnlines() {
        Example example = new Example(Characters.class);
        example.excludeProperties(new String[]{"data", "cangku", "shizhuang", "genchong", "texiao", "backpack", "listshouhu", "cardStore"});
        example.createCriteria().andEqualTo("online", 1).andEqualTo("xiaozi", 0);
        return (long) this.mapper.selectCountByExample(example);
    }

    @Override
    public BaseCustomMapper<Characters> getBaseMapper() {
        return this.mapper;
    }

    public List<Characters> selectAll(String name) {
        Example example = new Example(Characters.class);
        example.orderBy("online").desc();
        Criteria createCriteria = example.createCriteria();
        if (!StringUtils.isNullOrEmpty(name)) {
            createCriteria.andLike("name", "%" + name + "%");
        }

        return this.mapper.selectByExample(example);
    }
}
