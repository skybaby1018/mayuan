//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.NpcPointMapper;
import com.fengshen.db.domain.NpcPoint;
import com.fengshen.db.domain.example.NpcPointExample;
import com.fengshen.db.domain.example.NpcPointExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseNpcPointService {
    @Autowired
    protected NpcPointMapper mapper;

    public BaseNpcPointService() {
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcPoint findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey",
            condition = "#result.deleted == 0"
    )
    public NpcPoint findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"NpcPoint"},
            allEntries = true
    )
    public void add(final NpcPoint npcPoint) {
        npcPoint.setAddTime(LocalDateTime.now());
        npcPoint.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(npcPoint);
    }

    @CachePut(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public int updateById(final NpcPoint npcPoint) {
        npcPoint.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(npcPoint);
    }

    @CacheEvict(
            cacheNames = {"NpcPoint"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcPoint> findByMapname(final String mapnames) {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMapnameEqualTo(mapnames);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcPoint> findByDoorname(final String doornames) {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDoornameEqualTo(doornames);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcPoint findOneByMapname(final String mapname) {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMapnameEqualTo(mapname);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcPoint findOneByDoorname(final String doorname) {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDoornameEqualTo(doorname);
        return this.mapper.selectOneByExample(example);
    }

    public List<NpcPoint> findAll(final int page, final int size, final String sort, final String order) {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcPoint"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcPoint> findAll() {
        NpcPointExample example = new NpcPointExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"NpcPoint"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
