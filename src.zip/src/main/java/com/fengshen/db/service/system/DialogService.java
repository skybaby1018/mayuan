//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.system;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.DialogMapper;
import com.fengshen.db.domain.Dialog;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DialogService implements BaseServiceSupport<Dialog> {
    @Autowired
    private DialogMapper dm;

    public DialogService() {
    }

    @Override
    public BaseCustomMapper<Dialog> getBaseMapper() {
        return this.dm;
    }
}
