//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.PetMapper;
import com.fengshen.db.domain.Pet;
import com.fengshen.db.domain.example.PetExample;
import com.fengshen.db.domain.example.PetExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BasePetService {
    @Autowired
    protected PetMapper mapper;

    public BasePetService() {
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @CacheEvict(
            cacheNames = {"Pet"},
            allEntries = true
    )
    public Pet findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"Pet"},
            allEntries = true
    )
    public void add(final Pet pet) {
        pet.setAddTime(LocalDateTime.now());
        pet.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(pet);
    }

    @CacheEvict(
            cacheNames = {"Pet"},
            allEntries = true
    )
    public int updateById(final Pet pet) {
        pet.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(pet);
    }

    @CacheEvict(
            cacheNames = {"Pet"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Pet> findByPolar(final String polars) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPolarEqualTo(polars);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Pet> findByZoon(final String zoons) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andZoonEqualTo(zoons);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Pet> findByIcon(final Integer icons) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIconEqualTo(icons);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Pet> findByName(final String names) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findOneByLevelReq(final Integer levelReq) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLevelReqEqualTo(levelReq);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findOneByPolar(final String polar) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPolarEqualTo(polar);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findOneByZoon(final String zoon) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andZoonEqualTo(zoon);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findOneByIcon(final Integer icon) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIconEqualTo(icon);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public Pet findOneByName(final String name) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    public List<Pet> findAll(final int page, final int size, final String sort, final String order) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Pet"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Pet> findAll() {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<Pet> selectAll(Pet pet) {
        PetExample example = new PetExample();
        Criteria criteria = example.createCriteria();
        if (pet.getName() != null) {
            criteria.andNameEqualTo(pet.getName());
        }

        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"Pet"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
