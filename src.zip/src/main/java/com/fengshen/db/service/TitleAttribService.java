package com.fengshen.db.service;

import com.fengshen.db.dao.TitleAttribMapper;
import com.fengshen.db.domain.TitleAttrib;
import com.fengshen.server.game.GameData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TitleAttribService {
    @Autowired
    private TitleAttribMapper mapper;

    public TitleAttrib getTitleAttrib(final String name) {
        final TitleAttrib cache = (TitleAttrib) GameData.that.Redis.getObject((Object) ("TitleAttribKeyName:" + name), (Class) TitleAttrib.class);
        if (cache != null) {
            return cache;
        }
        TitleAttrib titleAttrib = this.mapper.getTitleAttrib(name);
        if (titleAttrib == null) {
            titleAttrib = new TitleAttrib();
            titleAttrib.setName(name);
            titleAttrib.setAttribs("{}");
        }
        GameData.that.Redis.setObject((Object) ("TitleAttribKeyName:" + name), (Object) titleAttrib);
        return titleAttrib;
    }

    public List<TitleAttrib> getAllTitleAttribs() {
        List<TitleAttrib> titleAttrib = this.mapper.getAllTitleAttribs();
        return titleAttrib;
    }

}
