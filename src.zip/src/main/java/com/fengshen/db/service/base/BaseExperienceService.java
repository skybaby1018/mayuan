//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.ExperienceMapper;
import com.fengshen.db.domain.Experience;
import com.fengshen.db.domain.example.ExperienceExample;
import com.fengshen.db.domain.example.ExperienceExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseExperienceService {
    @Autowired
    protected ExperienceMapper mapper;

    public BaseExperienceService() {
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public Experience findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey",
            condition = "#result.deleted == 0"
    )
    public Experience findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"ExperienceTreasure"},
            allEntries = true
    )
    public void add(final Experience experience) {
        experience.setAddTime(LocalDateTime.now());
        experience.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(experience);
    }

    @CacheEvict(
            cacheNames = {"ExperienceTreasure"},
            allEntries = true
    )
    public int updateById(final Experience experience) {
        experience.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(experience);
    }

    @CacheEvict(
            cacheNames = {"ExperienceTreasure"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Experience> findByAttrib(final Integer attrib) {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAttribEqualTo(attrib);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Experience> findByMaxLevel(final Integer maxLevel) {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMaxLevelEqualTo(maxLevel);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public Experience findOneByAttrib(final Integer attrib) {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAttribEqualTo(attrib);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public Experience findOneByMaxLevel(final Integer maxLevel) {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMaxLevelEqualTo(maxLevel);
        return this.mapper.selectOneByExample(example);
    }

    public List<Experience> findAll(final int page, final int size, final String sort, final String order) {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Experience"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Experience> findAll() {
        ExperienceExample example = new ExperienceExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"Experience"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
