//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.CharaTrailMapper;
import com.fengshen.db.domain.CharaTrail;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class CharaTrailService implements BaseServiceSupport<CharaTrail> {
    @Autowired
    private CharaTrailMapper ctm;


    @Override
    public BaseCustomMapper<CharaTrail> getBaseMapper() {
        return this.ctm;
    }

    public int addCharaTrail(CharaTrail c) {
        c.setAddTime(new Date());
        return this.ctm.insertSelective(c);
    }

    public Map<Object, Object> getCount(Map<String, Object> map) {
        return this.ctm.getCount(map);
    }

    public List<CharaTrail> queryTrailList(int id) {
        Example example = new Example(CharaTrail.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("cid", id);
        criteria.andEqualTo("state", 0);
        return ctm.selectByExample(example);
    }
}
