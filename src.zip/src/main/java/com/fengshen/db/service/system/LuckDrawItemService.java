//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.system;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.LuckDrawItemMapper;
import com.fengshen.db.domain.LuckDrawItem;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class LuckDrawItemService implements BaseServiceSupport<LuckDrawItem> {
    @Autowired
    private LuckDrawItemMapper ldim;

    public LuckDrawItemService() {
    }

    @Override
    public BaseCustomMapper<LuckDrawItem> getBaseMapper() {
        return this.ldim;
    }

    @Cacheable(
            cacheNames = {"LuckDrawItem"},
            keyGenerator = "cacheAutoKey"
    )
    public List<LuckDrawItem> getAll() {
        return this.ldim.selectAll();
    }

    @Cacheable(
            cacheNames = {"LuckDrawItem"},
            keyGenerator = "cacheAutoKey"
    )
    public LuckDrawItem getLuckOneByItem(String item) {
        Example example = new Example(LuckDrawItem.class);
        example.createCriteria().andEqualTo("item", item);
        return (LuckDrawItem) this.ldim.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"LuckDrawItem"},
            keyGenerator = "cacheAutoKey"
    )
    public List<LuckDrawItem> getLuckByLevel(int level) {
        Example example = new Example(LuckDrawItem.class);
        example.createCriteria().andEqualTo("level", level);
        return this.ldim.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"LuckDrawItem"},
            allEntries = true
    )
    public int add(LuckDrawItem item) {
        item.setAddTime(new Date());
        return this.ldim.insertSelective(item);
    }

    @CacheEvict(
            cacheNames = {"LuckDrawItem"},
            allEntries = true
    )
    public int deleteById(int id) {
        return this.ldim.deleteByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"LuckDrawItem"},
            allEntries = true
    )
    public int updateById(LuckDrawItem item) {
        return this.ldim.updateByPrimaryKeySelective(item);
    }

    @CacheEvict(
            cacheNames = {"LuckDrawItem"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
