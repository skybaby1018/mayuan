/*    */
package com.fengshen.db.service.zhenbao;
/*    */
/*    */

import com.fengshen.db.base.BaseCustomMapper;
/*    */ import com.fengshen.db.dao.GoldStallNineGoodsMapper;
/*    */ import com.fengshen.db.domain.GoldStallNineGoods;
/*    */ import com.fengshen.db.service.base.BaseServiceSupport;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;

/*    */
/*    */
@Service
/*    */ public class GoldStallNineGoodsService
        /*    */ implements BaseServiceSupport<GoldStallNineGoods>
        /*    */ {
    /*    */
    @Autowired
    /*    */ private GoldStallNineGoodsMapper mapper;

    /*    */
    /*    */
    public BaseCustomMapper<GoldStallNineGoods> getBaseMapper()
    /*    */ {
        /* 19 */
        return this.mapper;
        /*    */
    }
    /*    */
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\service\zhenbao\GoldStallNineGoodsService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */