
package com.fengshen.db.service.base;

import com.fengshen.db.dao.ShowTasksMapper;
import com.fengshen.db.domain.ShowTasks;
import com.fengshen.db.domain.example.ShowTasksExample;
import com.fengshen.db.domain.example.ShowTasksExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseShowTasksService {
    @Autowired
    protected ShowTasksMapper mapper;

    public BaseShowTasksService() {
    }

    public ShowTasks findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public ShowTasks findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final ShowTasks showTasks) {
        showTasks.setAddTime(LocalDateTime.now());
        showTasks.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(showTasks);
    }

    public int updateById(final ShowTasks showTasks) {
        showTasks.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(showTasks);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<ShowTasks> findByTaskType(final String taskType) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskTypeEqualTo(taskType);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByTaskDesc(final String taskDesc) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskDescEqualTo(taskDesc);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByTaskPrompt(final String taskPrompt) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskPromptEqualTo(taskPrompt);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByRefresh(final Integer refresh) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRefreshEqualTo(refresh);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByTaskEndTime(final Integer taskEndTime) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskEndTimeEqualTo(taskEndTime);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByAttrib(final Integer attrib) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAttribEqualTo(attrib);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByReward(final String reward) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRewardEqualTo(reward);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByShowName(final String showName) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andShowNameEqualTo(showName);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByTasktaskExtraPara(final String tasktaskExtraPara) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTasktaskExtraParaEqualTo(tasktaskExtraPara);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findByTasktaskState(final Integer tasktaskState) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTasktaskStateEqualTo(tasktaskState);
        return this.mapper.selectByExample(example);
    }

    public ShowTasks findOneByTaskType(final String taskType) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskTypeEqualTo(taskType);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByTaskDesc(final String taskDesc) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskDescEqualTo(taskDesc);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByTaskPrompt(final String taskPrompt) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskPromptEqualTo(taskPrompt);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByRefresh(final Integer refresh) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRefreshEqualTo(refresh);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByTaskEndTime(final Integer taskEndTime) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskEndTimeEqualTo(taskEndTime);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByAttrib(final Integer attrib) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAttribEqualTo(attrib);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByReward(final String reward) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRewardEqualTo(reward);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByShowName(final String showName) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andShowNameEqualTo(showName);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByTasktaskExtraPara(final String tasktaskExtraPara) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTasktaskExtraParaEqualTo(tasktaskExtraPara);
        return this.mapper.selectOneByExample(example);
    }

    public ShowTasks findOneByTasktaskState(final Integer tasktaskState) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTasktaskStateEqualTo(tasktaskState);
        return this.mapper.selectOneByExample(example);
    }

    public List<ShowTasks> findAll(final int page, final int size, final String sort, final String order) {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<ShowTasks> findAll() {
        ShowTasksExample example = new ShowTasksExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }
}
