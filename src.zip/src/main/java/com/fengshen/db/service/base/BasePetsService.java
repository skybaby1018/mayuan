//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.PetsMapper;
import com.fengshen.db.domain.Pets;
import com.fengshen.db.domain.example.PetsExample;
import com.fengshen.db.domain.example.PetsExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BasePetsService {
    @Autowired
    protected PetsMapper mapper;

    public BasePetsService() {
    }

    public Pets findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public Pets findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final Pets pets) {
        pets.setAddTime(LocalDateTime.now());
        pets.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(pets);
    }

    public int updateById(final Pets pets) {
        pets.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(pets);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<Pets> findByOwnerid(final String ownerid) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andOwneridEqualTo(ownerid);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByPetid(final String petid) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPetidEqualTo(petid);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByNickname(final String nickname) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNicknameEqualTo(nickname);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByName(final String name) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByHorsetype(final Integer horsetype) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andHorsetypeEqualTo(horsetype);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByType(final Integer type) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(type);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByLevel(final Integer level) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLevelEqualTo(level);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByLiliang(final Integer liliang) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLiliangEqualTo(liliang);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByMinjie(final Integer minjie) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMinjieEqualTo(minjie);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByLingli(final Integer lingli) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLingliEqualTo(lingli);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByTili(final Integer tili) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTiliEqualTo(tili);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByDianhualx(final Integer dianhualx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhualxEqualTo(dianhualx);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByDianhuazd(final Integer dianhuazd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhuazdEqualTo(dianhuazd);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByDianhuazx(final Integer dianhuazx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhuazxEqualTo(dianhuazx);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByYuhualx(final Integer yuhualx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhualxEqualTo(yuhualx);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByYuhuazd(final Integer yuhuazd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhuazdEqualTo(yuhuazd);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByYuhuazx(final Integer yuhuazx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhuazxEqualTo(yuhuazx);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwjyzx(final Integer cwjyzx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwjyzxEqualTo(cwjyzx);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwjyzd(final Integer cwjyzd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwjyzdEqualTo(cwjyzd);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByFeisheng(final Integer feisheng) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andFeishengEqualTo(feisheng);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByFsudu(final Integer fsudu) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andFsuduEqualTo(fsudu);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByQhcwWg(final Integer qhcwWg) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQhcwWgEqualTo(qhcwWg);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByQhcwFg(final Integer qhcwFg) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQhcwFgEqualTo(qhcwFg);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwXiangxing(final Integer cwXiangxing) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwXiangxingEqualTo(cwXiangxing);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwWuxue(final Integer cwWuxue) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwWuxueEqualTo(cwWuxue);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwIcon(final String cwIcon) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwIconEqualTo(cwIcon);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwXinfa(final Integer cwXinfa) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwXinfaEqualTo(cwXinfa);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findByCwQinmi(final Integer cwQinmi) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwQinmiEqualTo(cwQinmi);
        return this.mapper.selectByExample(example);
    }

    public Pets findOneByOwnerid(final String ownerid) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andOwneridEqualTo(ownerid);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByPetid(final String petid) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPetidEqualTo(petid);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByNickname(final String nickname) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNicknameEqualTo(nickname);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByName(final String name) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByHorsetype(final Integer horsetype) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andHorsetypeEqualTo(horsetype);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByType(final Integer type) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(type);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByLevel(final Integer level) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLevelEqualTo(level);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByLiliang(final Integer liliang) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLiliangEqualTo(liliang);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByMinjie(final Integer minjie) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMinjieEqualTo(minjie);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByLingli(final Integer lingli) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLingliEqualTo(lingli);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByTili(final Integer tili) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTiliEqualTo(tili);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByDianhualx(final Integer dianhualx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhualxEqualTo(dianhualx);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByDianhuazd(final Integer dianhuazd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhuazdEqualTo(dianhuazd);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByDianhuazx(final Integer dianhuazx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andDianhuazxEqualTo(dianhuazx);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByYuhualx(final Integer yuhualx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhualxEqualTo(yuhualx);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByYuhuazd(final Integer yuhuazd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhuazdEqualTo(yuhuazd);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByYuhuazx(final Integer yuhuazx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuhuazxEqualTo(yuhuazx);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwjyzx(final Integer cwjyzx) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwjyzxEqualTo(cwjyzx);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwjyzd(final Integer cwjyzd) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwjyzdEqualTo(cwjyzd);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByFeisheng(final Integer feisheng) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andFeishengEqualTo(feisheng);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByFsudu(final Integer fsudu) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andFsuduEqualTo(fsudu);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByQhcwWg(final Integer qhcwWg) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQhcwWgEqualTo(qhcwWg);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByQhcwFg(final Integer qhcwFg) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQhcwFgEqualTo(qhcwFg);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwXiangxing(final Integer cwXiangxing) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwXiangxingEqualTo(cwXiangxing);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwWuxue(final Integer cwWuxue) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwWuxueEqualTo(cwWuxue);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwIcon(final String cwIcon) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwIconEqualTo(cwIcon);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwXinfa(final Integer cwXinfa) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwXinfaEqualTo(cwXinfa);
        return this.mapper.selectOneByExample(example);
    }

    public Pets findOneByCwQinmi(final Integer cwQinmi) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCwQinmiEqualTo(cwQinmi);
        return this.mapper.selectOneByExample(example);
    }

    public List<Pets> findAll(final int page, final int size, final String sort, final String order) {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<Pets> findAll() {
        PetsExample example = new PetsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }
}
