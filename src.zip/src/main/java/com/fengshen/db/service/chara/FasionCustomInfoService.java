//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.FasionCustomInfoMapper;
import com.fengshen.db.domain.FasionCustomInfo;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class FasionCustomInfoService implements BaseServiceSupport<FasionCustomInfo> {
    @Autowired
    private FasionCustomInfoMapper pcim;


    @Override
    public BaseCustomMapper<FasionCustomInfo> getBaseMapper() {
        return this.pcim;
    }

    @Cacheable(
            cacheNames = {"FasionCustomInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<FasionCustomInfo> getFasionCustomInfoByCategory(int type) {
        Example example = new Example(FasionCustomInfo.class);
        example.createCriteria().andEqualTo("category", type).andEqualTo("deleted", 0);
        return this.pcim.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"FasionCustomInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public FasionCustomInfo getOneFasionCustomInfoByName(String name) {
        Example example = new Example(FasionCustomInfo.class);
        example.createCriteria().andEqualTo("name", name).andEqualTo("deleted", 0);
        return (FasionCustomInfo) this.pcim.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"FasionCustomInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<FasionCustomInfo> findByInStrs(List<String> names) {
        Example example = new Example(FasionCustomInfo.class);
        example.createCriteria().andIn("name", names).andEqualTo("deleted", 0);
        return this.pcim.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"FasionCustomInfo"},
            allEntries = true
    )
    public int updateById(FasionCustomInfo fci) {
        fci.setUpdateTime(new Date());
        return this.pcim.updateByPrimaryKeySelective(fci);
    }

    @CacheEvict(
            cacheNames = {"FasionCustomInfo"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
