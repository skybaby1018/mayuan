//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.ChargeConfigMapper;
import com.fengshen.db.domain.ChargeConfig;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChargeConfigService implements BaseServiceSupport<ChargeConfig> {
    @Autowired
    private ChargeConfigMapper cm;

    @Override
    public BaseCustomMapper<ChargeConfig> getBaseMapper() {
        return this.cm;
    }
}
