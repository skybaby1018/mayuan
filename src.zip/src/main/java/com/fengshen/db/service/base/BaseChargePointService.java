//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.ChargePointMapper;
import com.fengshen.db.domain.ChargePoint;
import com.fengshen.db.domain.ChargePointExample;
import com.fengshen.db.domain.ChargePointExample.Criteria;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BaseChargePointService {
    @Autowired
    protected ChargePointMapper mapper;

    public BaseChargePointService() {
    }

    public List<ChargePoint> findAll() {
        ChargePointExample example = new ChargePointExample();
        return this.mapper.selectByExample(example);
    }

    public ChargePoint findByNo(int no) {
        ChargePointExample example = new ChargePointExample();
        Criteria criteria = example.createCriteria();
        criteria.andNoEqualTo(no);
        List<ChargePoint> list = this.mapper.selectByExample(example);
        return list != null && !list.isEmpty() ? (ChargePoint) list.get(0) : null;
    }

    public int update(ChargePoint chargePoint) {
        return this.mapper.updateByPrimaryKey(chargePoint);
    }

    public int updateById(ChargePoint chargePoint) {
        return this.mapper.updateByPrimaryKeySelective(chargePoint);
    }

    public int add(ChargePoint chargePoint) {
        return this.mapper.insertSelective(chargePoint);
    }

    public int deleteById(ChargePoint chargePoint) {
        return this.mapper.deleteByPrimaryKey(chargePoint.getId());
    }
}
