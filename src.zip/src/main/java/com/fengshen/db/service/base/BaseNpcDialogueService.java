//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.NpcDialogueMapper;
import com.fengshen.db.domain.NpcDialogue;
import com.fengshen.db.domain.example.NpcDialogueExample;
import com.fengshen.db.domain.example.NpcDialogueExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseNpcDialogueService {
    @Autowired
    protected NpcDialogueMapper mapper;

    public BaseNpcDialogueService() {
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogue findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey",
            condition = "#result.deleted == 0"
    )
    public NpcDialogue findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogue"},
            allEntries = true
    )
    public void add(final NpcDialogue npcDialogue) {
        npcDialogue.setAddTime(LocalDateTime.now());
        npcDialogue.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(npcDialogue);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogue"},
            allEntries = true
    )
    public int updateById(final NpcDialogue npcDialogue) {
        npcDialogue.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(npcDialogue);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogue"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogue> findByName(final String names) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogue> findByIdname(final String idnames) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIdnameEqualTo(idnames);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogue findOneByName(final String name) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogue findOneByTaskType(final String taskType) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTaskTypeEqualTo(taskType);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogue findOneByIdname(final String idname) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIdnameEqualTo(idname);
        return this.mapper.selectOneByExample(example);
    }

    public List<NpcDialogue> findAll(final int page, final int size, final String sort, final String order) {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogue"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogue> findAll() {
        NpcDialogueExample example = new NpcDialogueExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<NpcDialogue> selectAll() {
        NpcDialogueExample example = new NpcDialogueExample();
        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogue"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
