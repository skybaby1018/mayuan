

package com.fengshen.db.service;

import com.fengshen.db.dao.StatMapper;

import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

@Service
public class StatService {
    @Resource
    private StatMapper statMapper;

    public StatService() {
    }

    public List<Map> statUser() {
        return this.statMapper.statUser();
    }

    public List<Map> statOrder() {
        return this.statMapper.statOrder();
    }

    public List<Map> statGoods() {
        return this.statMapper.statGoods();
    }
}
