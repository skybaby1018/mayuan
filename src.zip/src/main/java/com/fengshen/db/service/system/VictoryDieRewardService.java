//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.system;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.VictoryDieRewardMapper;
import com.fengshen.db.domain.VictoryDieReward;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class VictoryDieRewardService implements BaseServiceSupport<VictoryDieReward> {
    @Autowired
    private VictoryDieRewardMapper vm;

    public VictoryDieRewardService() {
    }

    public BaseCustomMapper<VictoryDieReward> getBaseMapper() {
        return this.vm;
    }

    @Cacheable(
            cacheNames = {"VictoryDieReward"},
            key = "#name+'_'+#type"
    )
    public VictoryDieReward victoryOrDieInfo(String name, int type) {
        Example example = new Example(VictoryDieReward.class);
        example.createCriteria().andEqualTo("name", name).andEqualTo("type", type).andEqualTo("deleted", 0);
        return (VictoryDieReward) this.vm.selectOneByExample(example);
    }

    @CacheEvict(
            cacheNames = {"VictoryDieReward"},
            allEntries = true
    )
    public int updateByRecord(VictoryDieReward record) {
        return this.vm.updateByPrimaryKeySelective(record);
    }

    @CacheEvict(
            cacheNames = {"VictoryDieReward"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
