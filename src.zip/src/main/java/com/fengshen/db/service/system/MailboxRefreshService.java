//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.system;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.MailboxRefreshMapper;
import com.fengshen.db.domain.MailboxRefresh;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MailboxRefreshService implements BaseServiceSupport<MailboxRefresh> {
    @Autowired
    private MailboxRefreshMapper m;

    public MailboxRefreshService() {
    }

    @Override
    public BaseCustomMapper<MailboxRefresh> getBaseMapper() {
        return this.m;
    }
}
