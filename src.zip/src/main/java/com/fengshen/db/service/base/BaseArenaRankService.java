
package com.fengshen.db.service.base;

import com.fengshen.db.dao.Arena_RankMapper;
import com.fengshen.db.domain.Arena_Rank;
import com.fengshen.db.domain.Arena_RankExample;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BaseArenaRankService {
    @Autowired
    private Arena_RankMapper mapper;
    @Value("${serverId}")
    private String serverId;
    /**
     * key:rank
     */
    private final Int2ObjectMap<Arena_Rank> rankAndCache = new Int2ObjectOpenHashMap<>();
    /**
     * key:charaId
     */
    private final Int2ObjectMap<Arena_Rank> charaIdAndCache = new Int2ObjectOpenHashMap<>();

    public BaseArenaRankService() {
    }

    public void init() {
        List<Arena_Rank> list = findAll();
        for (Arena_Rank arena_rank : list) {
            putCache(arena_rank);
        }
    }

    private void putCache(Arena_Rank arena_rank) {
        rankAndCache.put(arena_rank.getRank(), arena_rank);
        charaIdAndCache.put(arena_rank.getCharaid(), arena_rank);
    }

    public List<Arena_Rank> findAll() {
        Arena_RankExample example = new Arena_RankExample();
        Arena_RankExample.Criteria criteria = example.createCriteria();
        criteria.andServeridEqualTo(serverId);
        return this.mapper.selectByExample(example);
    }

    public Arena_Rank getArenaRankByCharaId(int charaId) {
        if (charaIdAndCache.containsKey(charaId)) {
            return charaIdAndCache.get(charaId);
        }

        return null;
    }

    public Arena_Rank getArenaRankByRank(int rank) {
        if (rankAndCache.containsKey(rank)) {
            return rankAndCache.get(rank);
        }

        return null;
    }

    public void insert(Arena_Rank arena_rank) {
        arena_rank.setServerid(serverId);
        putCache(arena_rank);
        this.mapper.insert(arena_rank);
    }

    public void delete(Arena_Rank arena_rank) {
        rankAndCache.remove(arena_rank.getRank());
        charaIdAndCache.remove(arena_rank.getCharaid());
        this.mapper.deleteByPrimaryKey(arena_rank.getId());
    }

    @CachePut(
            cacheNames = {"Arena_Rank_CharaId"},
            key = "#arena_rank.id"
    )
    public int updateCharaId(Arena_Rank arena_rank, int charaId) {
        charaIdAndCache.remove(arena_rank.getCharaid());
        arena_rank.setCharaid(charaId);
        charaIdAndCache.put(charaId, arena_rank);
        Arena_RankExample example = new Arena_RankExample();
        Arena_RankExample.Criteria criteria = example.createCriteria();
        criteria.andServeridEqualTo(serverId);
        criteria.andRankEqualTo(arena_rank.getRank());
        return this.mapper.updateByExampleSelective(arena_rank, example);
    }

    @CachePut(
            cacheNames = {"Arena_Rank_Rank"},
            key = "#arena_rank.id"
    )
    public int updateRank(Arena_Rank arena_rank, int rank) {
        rankAndCache.remove(arena_rank.getRank());
        arena_rank.setRank(rank);
        rankAndCache.put(rank, arena_rank);
        Arena_RankExample example = new Arena_RankExample();
        Arena_RankExample.Criteria criteria = example.createCriteria();
        criteria.andCharaidEqualTo(arena_rank.getCharaid());
        return this.mapper.updateByExampleSelective(arena_rank, example);
    }
}
