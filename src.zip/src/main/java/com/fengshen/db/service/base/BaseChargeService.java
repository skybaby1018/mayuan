//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.auth.ChargeMapper;
import com.fengshen.db.domain.Charge;
import com.fengshen.db.domain.example.ChargeExample;
import com.fengshen.db.domain.example.ChargeExample.Criteria;
import com.fengshen.db.vo.ChargeRankVo;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BaseChargeService {
    @Autowired
    protected ChargeMapper mapper;

    public BaseChargeService() {
    }

    public Charge findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public Charge findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final Charge charge) {
        charge.setAddTime(LocalDateTime.now());
        charge.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(charge);
    }

    public int updateById(final Charge charge) {
        charge.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(charge);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<Charge> findByAccountname(final String accountname, String serverId) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAccountnameEqualTo(accountname).andServerIdEqualToColumn(serverId);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findBLingquname(String lingquren) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLingqurenEqualTo(lingquren);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findCharaId(Integer charaId, String serverId) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andStateEqualTo(1).andCharaIdEqualToColumn(charaId).andServerIdEqualToColumn(serverId);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findCharaIdAndMoney(Integer charaId, String serverId, Integer money) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andStateEqualTo(1).andCharaIdEqualToColumn(charaId).andServerIdEqualToColumn(serverId).andMoneyEqualTo(money);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findByAccountname(String accountname, int state, String serverId) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAccountnameEqualTo(accountname).andStateEqualTo(state).andServerIdEqualToColumn(serverId);
        return this.mapper.selectByExample(example);
    }


    public List<Charge> findByAccountNameServerId(String accountname, String serverId) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAccountnameEqualTo(accountname).andServerIdEqualToColumn(serverId);
        return this.mapper.selectByExample(example);
    }


    public List<Charge> findByCoin(final Integer coin) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCoinEqualTo(coin);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findByState(final Integer state) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andStateEqualTo(state);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findByMoney(final Integer money) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMoneyEqualTo(money);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findByCode(final String code) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCodeEqualTo(code);
        return this.mapper.selectByExample(example);
    }

    public Charge findOneByAccountname(final String accountname) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andAccountnameEqualTo(accountname);
        return this.mapper.selectOneByExample(example);
    }

    public Charge findOneByCoin(final Integer coin) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCoinEqualTo(coin);
        return this.mapper.selectOneByExample(example);
    }

    public Charge findOneByState(final Integer state) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andStateEqualTo(state);
        return this.mapper.selectOneByExample(example);
    }

    public Charge findOneByMoney(final Integer money) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMoneyEqualTo(money);
        return this.mapper.selectOneByExample(example);
    }

    public Charge findOneByCode(final String code) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andCodeEqualTo(code);
        return this.mapper.selectOneByExample(example);
    }

    public List<Charge> findAll(final int page, final int size, final String sort, final String order) {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<Charge> findAll() {
        ChargeExample example = new ChargeExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<ChargeRankVo> queryChargeTop10(String serverId) {
        return this.mapper.queryChargeTop10(serverId);
    }

    /**
     * 查出当前198充值的用户
     *
     * @return
     */
    public Charge findOneByAccountAndDate(String accountName, String serverId) {
        return this.mapper.queryChargeByFirst(accountName, serverId);
    }
}
