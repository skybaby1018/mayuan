package com.fengshen.db.service.base;

import com.fengshen.db.dao.T_FightObjectsMapper;
import com.fengshen.db.domain.example.T_FightObjectExample;
import com.fengshen.server.domain.T_FightObject;
import com.fengshen.server.game.GameData;
import org.springframework.stereotype.*;
import org.springframework.beans.factory.annotation.*;

import java.util.*;

import org.springframework.util.*;
import com.github.pagehelper.*;

@Service
public class BaseFightObjectServices {
    @Autowired
    protected T_FightObjectsMapper mapper;

    public List<T_FightObject> findByName(final String name) {
        final T_FightObjectExample example = new T_FightObjectExample();
        final T_FightObjectExample.Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andNameEqualTo(name);
        return this.mapper.selectByExample(example);
    }

    public T_FightObject findOneByName(final String name) {
        final T_FightObject cache = (T_FightObject) GameData.that.Redis.getObject((Object) ("T_FightObjectKeyName:" + name), (Class) T_FightObject.class);
        if (cache != null) {
            return cache;
        }
        final List<T_FightObject> list = this.findByName(name);
        if (list.isEmpty()) {
            return null;
        }
        GameData.that.Redis.setObject((Object) ("T_FightObjectKeyName:" + name), (Object) list.get(0));
        return list.get(0);
    }

    public List<T_FightObject> findByID(final Integer id) {
        final T_FightObjectExample example = new T_FightObjectExample();
        final T_FightObjectExample.Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andIdEqualTo(id);
        return this.mapper.selectByExample(example);
    }

    public T_FightObject findOneByID(final Integer id) {
        final List<T_FightObject> list = this.findByID(id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public List<T_FightObject> findAll(final int page, final int size, final String sort, final String order) {
        final T_FightObjectExample example = new T_FightObjectExample();
        final T_FightObjectExample.Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        if (!StringUtils.isEmpty((Object) sort) && !StringUtils.isEmpty((Object) order)) {
            example.setOrderByClause(sort + " " + order);
        }
        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<T_FightObject> findAll() {
        final T_FightObjectExample example = new T_FightObjectExample();
        final T_FightObjectExample.Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        return this.mapper.selectByExample(example);
    }
}
