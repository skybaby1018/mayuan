//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.StoreInfoMapper;
import com.fengshen.db.domain.StoreInfo;
import com.fengshen.db.domain.example.StoreInfoExample;
import com.fengshen.db.domain.example.StoreInfoExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseStoreInfoService {
    @Autowired
    protected StoreInfoMapper mapper;

    public BaseStoreInfoService() {
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreInfo findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @CacheEvict(
            cacheNames = {"StoreInfo"},
            allEntries = true
    )
    public StoreInfo findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"StoreInfo"},
            allEntries = true
    )
    public void add(final StoreInfo storeInfo) {
        storeInfo.setAddTime(LocalDateTime.now());
        storeInfo.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(storeInfo);
    }

    @CacheEvict(
            cacheNames = {"StoreInfo"},
            allEntries = true
    )
    public int updateById(final StoreInfo storeInfo) {
        storeInfo.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(storeInfo);
    }

    @CacheEvict(
            cacheNames = {"StoreInfo"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findByQuality(final String qualitys) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQualityEqualTo(qualitys);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findByName(final String names) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findByRecognizeRecognized(final Integer recognizeRecognizeds) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRecognizeRecognizedEqualTo(recognizeRecognizeds);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findByRebuildLevel(final Integer rebuildLevels) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andRebuildLevelEqualTo(rebuildLevels);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findBySilverCoin(final Integer silverCoins) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andSilverCoinEqualTo(silverCoins);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreInfo findOneByQuality(final String quality) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andQualityEqualTo(quality);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreInfo findOneByName(final String name) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    public List<StoreInfo> findAll(final int page, final int size, final String sort, final String order) {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreInfo"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreInfo> findAll() {
        StoreInfoExample example = new StoreInfoExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<StoreInfo> selectAll(StoreInfo info) {
        StoreInfoExample example = new StoreInfoExample();
        if (info.getName() != null) {
            Criteria criteria = example.createCriteria();
            criteria.andNameEqualTo(info.getName());
        }

        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"StoreInfo"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
