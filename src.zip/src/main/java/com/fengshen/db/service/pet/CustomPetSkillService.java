
package com.fengshen.db.service.pet;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.CustomPetSkillMapper;
import com.fengshen.db.domain.CustomPetSkill;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class CustomPetSkillService implements BaseServiceSupport<CustomPetSkill> {
    @Autowired
    private CustomPetSkillMapper cpsm;

    public CustomPetSkillService() {
    }

    public BaseCustomMapper<CustomPetSkill> getBaseMapper() {
        return this.cpsm;
    }

    @CacheEvict(
            cacheNames = {"CustomPetSkill"},
            allEntries = true
    )
    public int addCustomPetSkill(CustomPetSkill cps) {
        cps.setAddTime(new Date());
        return this.cpsm.insertSelective(cps);
    }

    @Cacheable(
            cacheNames = {"CustomPetSkill"},
            keyGenerator = "cacheAutoKey"
    )
    public List<CustomPetSkill> getCustomPetSkillByPetName(String petName) {
        Example example = new Example(CustomPetSkill.class);
        example.createCriteria().andEqualTo("petName", petName);
        return this.cpsm.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"CustomPetSkill"},
            allEntries = true
    )
    public int deleteById(int id) {
        return this.cpsm.deleteByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"CustomPetSkill"},
            allEntries = true
    )
    public int updateCustomPetSkillById(CustomPetSkill cs) {
        return this.cpsm.updateByPrimaryKeySelective(cs);
    }

    @CacheEvict(
            cacheNames = {"CustomPetSkill"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
