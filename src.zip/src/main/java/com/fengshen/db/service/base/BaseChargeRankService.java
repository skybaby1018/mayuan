package com.fengshen.db.service.base;

import com.fengshen.db.dao.ChargeRankMapper;
import com.fengshen.db.domain.ChargeRank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BaseChargeRankService {
    @Autowired
    protected ChargeRankMapper mapper;

    public List<ChargeRank> queryChargeRankList() {
        return this.mapper.queryChargeRankList();
    }

    public ChargeRank queryByCharaId(Integer charaId) {
        return this.mapper.queryByCharaId(charaId);
    }

    public void update(ChargeRank chargeRank) {
        mapper.updateByPrimaryKey(chargeRank);
    }
}
