//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.base.BaseCustomMapper;

import java.util.List;

import org.apache.ibatis.session.RowBounds;

public interface BaseServiceSupport<T> extends BaseCustomMapper<T> {
    default T selectOne(T record) {
        return this.getBaseMapper().selectOne(record);
    }

    default List<T> select(T record) {
        return this.getBaseMapper().select(record);
    }

    default List<T> selectAll() {
        return this.getBaseMapper().selectAll();
    }

    default int selectCount(T record) {
        return this.getBaseMapper().selectCount(record);
    }

    default T selectByPrimaryKey(Object key) {
        return this.getBaseMapper().selectByPrimaryKey(key);
    }

    default int insert(T record) {
        return this.getBaseMapper().insert(record);
    }

    default int insertSelective(T record) {
        return this.getBaseMapper().insertSelective(record);
    }

    default int updateByPrimaryKey(T record) {
        return this.getBaseMapper().updateByPrimaryKey(record);
    }

    default int updateByPrimaryKeySelective(T record) {
        return this.getBaseMapper().updateByPrimaryKeySelective(record);
    }

    default int delete(T record) {
        return this.getBaseMapper().delete(record);
    }

    default int deleteByPrimaryKey(Object key) {
        return this.getBaseMapper().deleteByPrimaryKey(key);
    }

    default List<T> selectByExample(Object example) {
        return this.getBaseMapper().selectByExample(example);
    }

    default int selectCountByExample(Object example) {
        return this.getBaseMapper().selectCountByExample(example);
    }

    default int deleteByExample(Object example) {
        return this.getBaseMapper().deleteByExample(example);
    }

    default int updateByExample(T record, Object example) {
        return this.getBaseMapper().updateByExample(record, example);
    }

    default int updateByExampleSelective(T record, Object example) {
        return this.getBaseMapper().updateByExampleSelective(record, example);
    }

    default List<T> selectByExampleAndRowBounds(Object example, RowBounds rowBounds) {
        return this.getBaseMapper().selectByExampleAndRowBounds(example, rowBounds);
    }

    default List<T> selectByRowBounds(T record, RowBounds rowBounds) {
        return this.getBaseMapper().selectByRowBounds(record, rowBounds);
    }

    @Override
    default boolean existsWithPrimaryKey(Object key) {
        return this.getBaseMapper().existsWithPrimaryKey(key);
    }

    default T selectOneByExample(Object example) {
        return this.getBaseMapper().selectOneByExample(example);
    }

    BaseCustomMapper<T> getBaseMapper();
}
