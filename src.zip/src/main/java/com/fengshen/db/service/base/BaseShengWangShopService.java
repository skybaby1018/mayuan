//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.T_shengwang_shopMapper;
import com.fengshen.db.domain.T_shengwang_shop;
import com.fengshen.db.domain.T_shengwang_shopExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BaseShengWangShopService {
    @Autowired
    protected T_shengwang_shopMapper mapper;

    public BaseShengWangShopService() {
    }

    public List<T_shengwang_shop> findAll() {
        T_shengwang_shopExample example = new T_shengwang_shopExample();
        T_shengwang_shopExample.Criteria criteria = example.createCriteria();
        return this.mapper.selectByExample(example);
    }

    public T_shengwang_shop getByKey(String key) {
        T_shengwang_shopExample example = new T_shengwang_shopExample();
        T_shengwang_shopExample.Criteria criteria = example.createCriteria();
        criteria.andKey1EqualTo(key);
        List<T_shengwang_shop> list = this.mapper.selectByExample(example);
        return list.get(0);
    }
}
