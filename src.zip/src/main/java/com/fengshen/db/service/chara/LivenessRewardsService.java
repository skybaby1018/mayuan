//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.LivenessRewardsMapper;
import com.fengshen.db.domain.LivenessRewards;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class LivenessRewardsService implements BaseServiceSupport<LivenessRewards> {
    @Autowired
    private LivenessRewardsMapper lrm;

    @Override
    public BaseCustomMapper<LivenessRewards> getBaseMapper() {
        return this.lrm;
    }

    public Map<Integer, List<LivenessRewards>> getLivenessRewardsByActiveToDay(String gid) {
        Example example = new Example(LivenessRewards.class);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String format = dateTimeFormatter.format(LocalDateTime.now());
        example.createCriteria().andCondition("DATE_FORMAT(add_time,\"%Y-%m-%d\")=", format).andEqualTo("gid", gid);
        List<LivenessRewards> list = this.lrm.selectByExample(example);
        Map<Integer, List<LivenessRewards>> collect = (Map) list.stream().collect(Collectors.groupingBy(LivenessRewards::getActivity));
        return collect;
    }

    public int getLivenessRewardsIsGet(String gid, int activity) {
        Example example = new Example(LivenessRewards.class);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String format = dateTimeFormatter.format(LocalDateTime.now());
        example.createCriteria().andCondition("DATE_FORMAT(add_time,\"%Y-%m-%d\")=", format).andEqualTo("gid", gid).andEqualTo("activity", activity);
        return this.lrm.selectCountByExample(example);
    }
}
