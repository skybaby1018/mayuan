//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.ChangeCardMapper;
import com.fengshen.db.domain.ChangeCard;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChangeCardService implements BaseServiceSupport<ChangeCard> {
    @Autowired
    private ChangeCardMapper cm;

    @Override
    public BaseCustomMapper<ChangeCard> getBaseMapper() {
        return this.cm;
    }
}
