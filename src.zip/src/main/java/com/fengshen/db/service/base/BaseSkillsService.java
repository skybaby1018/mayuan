/*     */
package com.fengshen.db.service.base;
/*     */
/*     */

import com.fengshen.db.dao.SkillsMapper;
/*     */ import com.fengshen.db.domain.Skills;
/*     */ import com.fengshen.db.domain.example.SkillsExample;
/*     */ import com.fengshen.db.domain.example.SkillsExample.Criteria;
/*     */ import com.github.pagehelper.PageHelper;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.util.StringUtils;

/*     */
/*     */
@org.springframework.stereotype.Service
/*     */ public class BaseSkillsService
        /*     */ {
    /*     */
    @Autowired
    /*     */ protected SkillsMapper mapper;

    /*     */
    /*     */
    public Skills findById(int id)
    /*     */ {
        /*  21 */
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(Integer.valueOf(id), false);
        /*     */
    }

    /*     */
    /*     */
    public Skills findByIdContainsDelete(int id) {
        /*  25 */
        return this.mapper.selectByPrimaryKey(Integer.valueOf(id));
        /*     */
    }

    /*     */
    /*     */
    public void add(Skills skills) {
        /*  29 */
        skills.setAddTime(LocalDateTime.now());
        /*  30 */
        skills.setUpdateTime(LocalDateTime.now());
        /*  31 */
        this.mapper.insertSelective(skills);
        /*     */
    }

    /*     */
    /*     */
    public int updateById(Skills skills) {
        /*  35 */
        skills.setUpdateTime(LocalDateTime.now());
        /*  36 */
        return this.mapper.updateByPrimaryKeySelective(skills);
        /*     */
    }

    /*     */
    /*     */
    public void deleteById(int id) {
        /*  40 */
        this.mapper.logicalDeleteByPrimaryKey(Integer.valueOf(id));
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillIdHex(String skillIdHex) {
        /*  44 */
        SkillsExample example = new SkillsExample();
        /*  45 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  46 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillIdHexEqualTo(skillIdHex);
        /*  47 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillName(String skillName) {
        /*  51 */
        SkillsExample example = new SkillsExample();
        /*  52 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  53 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillNameEqualTo(skillName);
        /*  54 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillReqpolar(Integer skillReqpolar) {
        /*  58 */
        SkillsExample example = new SkillsExample();
        /*  59 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  60 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillReqpolarEqualTo(skillReqpolar);
        /*  61 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillType(Integer skillType) {
        /*  65 */
        SkillsExample example = new SkillsExample();
        /*  66 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  67 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillTypeEqualTo(skillType);
        /*  68 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillTypeLevel(Integer skillTypeLevel) {
        /*  72 */
        SkillsExample example = new SkillsExample();
        /*  73 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  74 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillTypeLevelEqualTo(skillTypeLevel);
        /*  75 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillMagic(Integer skillMagic) {
        /*  79 */
        SkillsExample example = new SkillsExample();
        /*  80 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  81 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillMagicEqualTo(skillMagic);
        /*  82 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillReqLevel(Integer skillReqLevel) {
        /*  86 */
        SkillsExample example = new SkillsExample();
        /*  87 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  88 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillReqLevelEqualTo(skillReqLevel);
        /*  89 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findBySkillContext(String skillContext) {
        /*  93 */
        SkillsExample example = new SkillsExample();
        /*  94 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /*  95 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillContextEqualTo(skillContext);
        /*  96 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillIdHex(String skillIdHex) {
        /* 100 */
        SkillsExample example = new SkillsExample();
        /* 101 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 102 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillIdHexEqualTo(skillIdHex);
        /* 103 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillName(String skillName) {
        /* 107 */
        SkillsExample example = new SkillsExample();
        /* 108 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 109 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillNameEqualTo(skillName);
        /* 110 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillReqpolar(Integer skillReqpolar) {
        /* 114 */
        SkillsExample example = new SkillsExample();
        /* 115 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 116 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillReqpolarEqualTo(skillReqpolar);
        /* 117 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillType(Integer skillType) {
        /* 121 */
        SkillsExample example = new SkillsExample();
        /* 122 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 123 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillTypeEqualTo(skillType);
        /* 124 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillTypeLevel(Integer skillTypeLevel) {
        /* 128 */
        SkillsExample example = new SkillsExample();
        /* 129 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 130 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillTypeLevelEqualTo(skillTypeLevel);
        /* 131 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillMagic(Integer skillMagic) {
        /* 135 */
        SkillsExample example = new SkillsExample();
        /* 136 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 137 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillMagicEqualTo(skillMagic);
        /* 138 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillReqLevel(Integer skillReqLevel) {
        /* 142 */
        SkillsExample example = new SkillsExample();
        /* 143 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 144 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillReqLevelEqualTo(skillReqLevel);
        /* 145 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Skills findOneBySkillContext(String skillContext) {
        /* 149 */
        SkillsExample example = new SkillsExample();
        /* 150 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 151 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillContextEqualTo(skillContext);
        /* 152 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findAll(int page, int size, String sort, String order) {
        /* 156 */
        SkillsExample example = new SkillsExample();
        /* 157 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 158 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        /* 159 */
        if ((!StringUtils.isEmpty(sort)) && (!StringUtils.isEmpty(order))) {
            /* 160 */
            example.setOrderByClause(String.valueOf(sort) + " " + order);
            /*     */
        }
        /* 162 */
        PageHelper.startPage(page, size);
        /* 163 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Skills> findAll() {
        /* 167 */
        SkillsExample example = new SkillsExample();
        /* 168 */
        SkillsExample.Criteria criteria = example.createCriteria();
        /* 169 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        /* 170 */
        return this.mapper.selectByExample(example);
        /*     */
    }
    /*     */
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\service\base\BaseSkillsService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */