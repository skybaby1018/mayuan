//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.MedicineShopMapper;
import com.fengshen.db.domain.MedicineShop;
import com.fengshen.db.domain.example.MedicineShopExample;
import com.fengshen.db.domain.example.MedicineShopExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseMedicineShopService {
    @Autowired
    protected MedicineShopMapper mapper;

    public BaseMedicineShopService() {
    }

    @Cacheable(
            cacheNames = {"MedicineShop"},
            key = "#id"
    )
    public MedicineShop findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public MedicineShop findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final MedicineShop medicineShop) {
        medicineShop.setAddTime(LocalDateTime.now());
        medicineShop.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(medicineShop);
    }

    public int updateById(final MedicineShop medicineShop) {
        medicineShop.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(medicineShop);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<MedicineShop> findByGoodsNo(final Integer goodsNo) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andGoodsNoEqualTo(goodsNo);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByPayType(final Integer payType) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPayTypeEqualTo(payType);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByName(final String name) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByValue(final Integer value) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andValueEqualTo(value);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByLevel(final Integer level) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLevelEqualTo(level);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByType(final Integer type) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(type);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findByItemcount(final Integer itemcount) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andItemcountEqualTo(itemcount);
        return this.mapper.selectByExample(example);
    }

    public MedicineShop findOneByGoodsNo(final Integer goodsNo) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andGoodsNoEqualTo(goodsNo);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByPayType(final Integer payType) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPayTypeEqualTo(payType);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByName(final String name) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByValue(final Integer value) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andValueEqualTo(value);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByLevel(final Integer level) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andLevelEqualTo(level);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByType(final Integer type) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(type);
        return this.mapper.selectOneByExample(example);
    }

    public MedicineShop findOneByItemcount(final Integer itemcount) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andItemcountEqualTo(itemcount);
        return this.mapper.selectOneByExample(example);
    }

    public List<MedicineShop> findAll(final int page, final int size, final String sort, final String order) {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<MedicineShop> findAll() {
        MedicineShopExample example = new MedicineShopExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }
}
