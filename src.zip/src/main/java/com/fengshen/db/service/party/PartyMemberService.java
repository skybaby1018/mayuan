//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.party;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.PartyMemberMapper;
import com.fengshen.db.domain.PartyMember;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class PartyMemberService implements BaseServiceSupport<PartyMember> {
    @Autowired
    private PartyMemberMapper pm;

    public PartyMemberService() {
    }

    public BaseCustomMapper<PartyMember> getBaseMapper() {
        return this.pm;
    }

    public List<PartyMember> getPartyMemberByPartyId(String partyId) {
        Example example = new Example(PartyMember.class);
        example.createCriteria().andEqualTo("partyId", partyId);
        return this.pm.selectByExample(example);
    }

    public PartyMember getPartyMemberOnePartyName(String name) {
        Example example = new Example(PartyMember.class);
        example.createCriteria().andEqualTo("name", name);
        return (PartyMember) this.pm.selectOneByExample(example);
    }
}
