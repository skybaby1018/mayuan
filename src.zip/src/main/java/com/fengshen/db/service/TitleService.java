package com.fengshen.db.service;

import com.fengshen.db.dao.TitleMapper;
import com.fengshen.db.domain.Title;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class TitleService {
    @Autowired
    private TitleMapper mapper;

    public List<Title> getTiltesByEvent(final String event) {
        return this.mapper.getTiltesByEvent(event);
    }

    public List<Title> getTiltesByTitle(final String title) {
        return this.mapper.getTiltesByTitle(title);
    }

    public Title getTitleBydes(final String des) {
        return this.mapper.getTitleBydes(des);
    }

    public Title getTilteByName(final int name) {
        return this.mapper.getTilteByName(name);
    }

    public int addTitle(final Map<Object, Object> map) {
        return this.mapper.addTitle(map);
    }

    public int delByTitle(final String title) {
        return this.mapper.delByTitle(title);
    }

    public int delByEvent(final String event) {
        return this.mapper.delByEvent(event);
    }

    public int delByDes(final String des) {
        return this.mapper.delByDes(des);
    }
}
