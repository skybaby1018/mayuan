//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.party;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.PartySkillMapper;
import com.fengshen.db.domain.PartySkill;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class PartySkillService implements BaseServiceSupport<PartySkill> {
    @Autowired
    private PartySkillMapper ps;

    public PartySkillService() {
    }

    public BaseCustomMapper<PartySkill> getBaseMapper() {
        return this.ps;
    }

    public List<PartySkill> getPartySkillByPartyId(String party) {
        Example example = new Example(PartySkill.class);
        example.createCriteria().andEqualTo("partyId", party);
        return this.ps.selectByExample(example);
    }
}
