//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.friend;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.FriendMapper;
import com.fengshen.db.domain.Friend;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class FriendService implements BaseServiceSupport<Friend> {
    @Autowired
    private FriendMapper fm;

    public FriendService() {
    }

    public BaseCustomMapper<Friend> getBaseMapper() {
        return this.fm;
    }

    public int addFriend(Friend friend) {
        friend.setAddTime(new Date());
        int insertSelective = this.fm.insertSelective(friend);
        return insertSelective;
    }

    public List<Friend> getFriendByGroupName(String groupId, String gid) {
        Example example = new Example(Friend.class);
        example.createCriteria().andEqualTo("groupId", groupId).andEqualTo("gid", gid);
        return this.fm.selectByExample(example);
    }
}
