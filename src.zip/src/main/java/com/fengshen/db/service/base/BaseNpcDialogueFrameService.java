//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.NpcDialogueFrameMapper;
import com.fengshen.db.domain.NpcDialogueFrame;
import com.fengshen.db.domain.example.NpcDialogueFrameExample;
import com.fengshen.db.domain.example.NpcDialogueFrameExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseNpcDialogueFrameService {
    @Autowired
    protected NpcDialogueFrameMapper mapper;

    public BaseNpcDialogueFrameService() {
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogueFrame findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogueFrame"},
            allEntries = true
    )
    public NpcDialogueFrame findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogueFrame"},
            allEntries = true
    )
    public void add(final NpcDialogueFrame npcDialogueFrame) {
        npcDialogueFrame.setAddTime(LocalDateTime.now());
        npcDialogueFrame.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(npcDialogueFrame);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogueFrame"},
            allEntries = true
    )
    public int updateById(final NpcDialogueFrame npcDialogueFrame) {
        npcDialogueFrame.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(npcDialogueFrame);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogueFrame"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogueFrame> findByPicNo(final Integer picNos) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andPicNoEqualTo(picNos);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogueFrame> findByName(final String names) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogueFrame> findByIdname(final Integer idnames) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIdnameEqualTo(idnames);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogueFrame findOneByName(final String name) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public NpcDialogueFrame findOneByIdname(final Integer idname) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIdnameEqualTo(idname);
        return this.mapper.selectOneByExample(example);
    }

    public List<NpcDialogueFrame> findAll(final int page, final int size, final String sort, final String order) {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"NpcDialogueFrame"},
            keyGenerator = "cacheAutoKey"
    )
    public List<NpcDialogueFrame> findAll() {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<NpcDialogueFrame> selectAll() {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"NpcDialogueFrame"},
            allEntries = true
    )
    public void refreshCache() {
    }


    public NpcDialogueFrame findOneByContent(final String content) {
        final NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        final NpcDialogueFrameExample.Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andContentEqualTo(content);
        return this.mapper.selectOneByExample(example);
    }
}
