//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.ShuxingduiyingMapper;
import com.fengshen.db.domain.Shuxingduiying;
import com.fengshen.db.domain.example.ShuxingduiyingExample;
import com.fengshen.db.domain.example.ShuxingduiyingExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseShuxingduiyingService {
    @Autowired
    protected ShuxingduiyingMapper mapper;

    public BaseShuxingduiyingService() {
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public Shuxingduiying findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey",
            condition = "#result.deleted == 0"
    )
    public Shuxingduiying findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"Shuxingduiying"},
            allEntries = true
    )
    public void add(final Shuxingduiying shuxingduiying) {
        shuxingduiying.setAddTime(LocalDateTime.now());
        shuxingduiying.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(shuxingduiying);
    }

    @CacheEvict(
            cacheNames = {"Shuxingduiying"},
            allEntries = true
    )
    public int updateById(final Shuxingduiying shuxingduiying) {
        shuxingduiying.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(shuxingduiying);
    }

    @CacheEvict(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Shuxingduiying> findByName(final String names) {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Shuxingduiying> findByYingwen(final String yingwens) {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYingwenEqualTo(yingwens);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public Shuxingduiying findOneByName(final String names) {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public Shuxingduiying findOneByYingwen(final String yingwen) {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYingwenEqualTo(yingwen);
        return this.mapper.selectOneByExample(example);
    }

    public List<Shuxingduiying> findAll(final int page, final int size, final String sort, final String order) {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"Shuxingduiying"},
            keyGenerator = "cacheAutoKey"
    )
    public List<Shuxingduiying> findAll() {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"Shuxingduiying"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
