//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service;

import com.fengshen.db.domain.Characters;
import com.fengshen.db.service.base.BaseCharactersService;
import com.github.pagehelper.ISelect;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import java.util.ArrayList;
import java.util.List;

@Service
public class CharacterService extends BaseCharactersService {

    public List<Characters> getResetRenwu(List<String> gids) {
        Example example = new Example(Characters.class);
        example.selectProperties(new String[]{"data", "gid", "id", "name"});
        Criteria createCriteria = example.createCriteria();
        createCriteria.andEqualTo("deleted", false);
        if (gids != null && !gids.isEmpty()) {
            createCriteria.andNotIn("gid", gids);
        }
        return this.mapper.selectByExample(example);
    }

    public List<Characters> findByAccountIdManage(Integer id) {
        Example example = new Example(Characters.class);
        example.createCriteria().andEqualTo("accountId", id);
        return this.mapper.selectByExample(example);
    }

    public List<Characters> findPageList() {
        // 开始分页
        final Example example = new Example(Characters.class);
        example.selectProperties(new String[]{"data", "name", "id", "gid", "sex", "level", "polar", "backpack"});
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("deleted", false);
        criteria.andEqualTo("block", 0);
        criteria.andEqualTo("xiaozi", 0);
        List<Characters> charactersList = selectPageList(example, 1, 200);
        return charactersList;
    }

    /**
     * 根据时间获取旷世考勤数据
     *
     * @return
     */
    public List<Characters> selectPageList(final Example example, int pageNum, int pageSize) {
        List<Characters> recordList = new ArrayList<>();
        listRecord(recordList, example, pageNum, pageSize);
        return recordList;
    }

    private void listRecord(List<Characters> charactersList, final Example example, int pageNum, int pageSize) {
        try {
            Page<Characters> page = PageHelper.startPage(pageNum, pageSize).doSelectPage(() -> mapper.selectByExample(example));
            charactersList.addAll(page.getResult());
            pageNum++;
            if (pageNum <= page.getPages()) {
                listRecord(charactersList, example, pageNum, pageSize);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
