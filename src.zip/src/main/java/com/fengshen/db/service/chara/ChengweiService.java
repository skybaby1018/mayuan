//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.ChengweiMapper;
import com.fengshen.db.domain.Chengwei;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class ChengweiService implements BaseServiceSupport<Chengwei> {
    @Autowired
    private ChengweiMapper cm;

    @Override
    public BaseCustomMapper<Chengwei> getBaseMapper() {
        return this.cm;
    }

    @Cacheable(
            keyGenerator = "cacheAutoKey",
            cacheNames = {"Chengwei"}
    )
    public Chengwei getChengweiByName(String name) {
        if (name == null) {
            return null;
        } else {
            Example example = new Example(Chengwei.class);
            example.createCriteria().andEqualTo("name", name);
            return (Chengwei) this.cm.selectOneByExample(example);
        }
    }

    public List<Chengwei> getChengweiMoney(int money) {
        Example example = new Example(Chengwei.class);
        example.createCriteria().andLessThanOrEqualTo("money", money);
        return this.cm.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"Chengwei"},
            allEntries = true
    )
    public int addChengwei(Chengwei chengwei) {
        chengwei.setAddTime(new Date());
        return this.cm.insertSelective(chengwei);
    }

    @CacheEvict(
            cacheNames = {"Chengwei"},
            allEntries = true
    )
    public int delChengweiById(int id) {
        return this.cm.deleteByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"Chengwei"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
