//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.ReportsMapper;
import com.fengshen.db.domain.Reports;
import com.fengshen.db.domain.example.ReportsExample;
import com.fengshen.db.domain.example.ReportsExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseReportsService {
    @Autowired
    protected ReportsMapper mapper;

    public BaseReportsService() {
    }

    public Reports findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    public Reports findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    public void add(final Reports reports) {
        reports.setAddTime(LocalDateTime.now());
        reports.setUpdateTime(LocalDateTime.now());
        this.mapper.insertSelective(reports);
    }

    public int updateById(final Reports reports) {
        reports.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(reports);
    }

    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    public List<Reports> findByZhanghao(final String zhanghao) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andZhanghaoEqualTo(zhanghao);
        return this.mapper.selectByExample(example);
    }

    public List<Reports> findByYuanbaoshu(final Integer yuanbaoshu) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuanbaoshuEqualTo(yuanbaoshu);
        return this.mapper.selectByExample(example);
    }

    public List<Reports> findByShifouchongzhi(final String shifouchongzhi) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andShifouchongzhiEqualTo(shifouchongzhi);
        return this.mapper.selectByExample(example);
    }

    public Reports findOneByZhanghao(final String zhanghao) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andZhanghaoEqualTo(zhanghao);
        return this.mapper.selectOneByExample(example);
    }

    public Reports findOneByYuanbaoshu(final Integer yuanbaoshu) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andYuanbaoshuEqualTo(yuanbaoshu);
        return this.mapper.selectOneByExample(example);
    }

    public Reports findOneByShifouchongzhi(final String shifouchongzhi) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andShifouchongzhiEqualTo(shifouchongzhi);
        return this.mapper.selectOneByExample(example);
    }

    public List<Reports> findAll(final int page, final int size, final String sort, final String order) {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    public List<Reports> findAll() {
        ReportsExample example = new ReportsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }
}
