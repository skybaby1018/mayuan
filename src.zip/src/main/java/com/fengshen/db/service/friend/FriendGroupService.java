//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.friend;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.FriendGroupMapper;
import com.fengshen.db.domain.FriendGroup;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class FriendGroupService implements BaseServiceSupport<FriendGroup> {
    @Autowired
    private FriendGroupMapper fgm;

    public FriendGroupService() {
    }

    public BaseCustomMapper<FriendGroup> getBaseMapper() {
        return this.fgm;
    }

    public List<FriendGroup> getFriendGroupsByGid(String gid) {
        Example example = new Example(FriendGroup.class);
        example.createCriteria().andEqualTo("gid", gid);
        return this.fgm.selectByExample(example);
    }
}
