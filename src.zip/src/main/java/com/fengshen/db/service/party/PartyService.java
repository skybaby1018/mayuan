//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.party;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.PartyMapper;
import com.fengshen.db.domain.Party;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class PartyService implements BaseServiceSupport<Party> {
    @Autowired
    private PartyMapper pm;

    public PartyService() {
    }

    public BaseCustomMapper<Party> getBaseMapper() {
        return this.pm;
    }

    public Party findByPartyId(String id) {
        Example example = new Example(Party.class);
        example.createCriteria().andEqualTo("partyId", id);
        return (Party) this.pm.selectOneByExample(example);
    }

    public Party findByPartyName(String name) {
        Example example = new Example(Party.class);
        example.createCriteria().andEqualTo("partyName", name);
        return (Party) this.pm.selectOneByExample(example);
    }
}
