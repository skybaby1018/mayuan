package com.fengshen.db.service.arena;

import com.fengshen.db.dao.LeiTaiRankMapper;
import com.fengshen.server.domain.arena.LeiTaiRank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeiTaiRankService {
    @Autowired
    private LeiTaiRankMapper mapper;

    public int insert(LeiTaiRank record) {
        return mapper.insert(record);
    }

    public int delete() {
        return mapper.delete();
    }

    public List<LeiTaiRank> selectAll() {
        return mapper.selectAll();
    }

}
