//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.base;

import com.fengshen.db.dao.StoreGoodsMapper;
import com.fengshen.db.domain.StoreGoods;
import com.fengshen.db.domain.example.StoreGoodsExample;
import com.fengshen.db.domain.example.StoreGoodsExample.Criteria;
import com.github.pagehelper.PageHelper;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BaseStoreGoodsService {
    @Autowired
    protected StoreGoodsMapper mapper;

    public BaseStoreGoodsService() {
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findById(final int id) {
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(id, false);
    }

    @CacheEvict(
            cacheNames = {"StoreGoods"},
            allEntries = true
    )
    public StoreGoods findByIdContainsDelete(final int id) {
        return this.mapper.selectByPrimaryKey(id);
    }

    @CacheEvict(
            cacheNames = {"StoreGoods"},
            allEntries = true
    )
    public void add(final StoreGoods storeGoods) {
        storeGoods.setAddTime(LocalDateTime.now());
        this.mapper.insertSelective(storeGoods);
    }

    @CacheEvict(
            cacheNames = {"StoreGoods"},
            allEntries = true
    )
    public int updateById(final StoreGoods storeGoods) {
        storeGoods.setUpdateTime(LocalDateTime.now());
        return this.mapper.updateByPrimaryKeySelective(storeGoods);
    }

    @CacheEvict(
            cacheNames = {"StoreGoods"},
            allEntries = true
    )
    public void deleteById(final int id) {
        this.mapper.logicalDeleteByPrimaryKey(id);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findByName(final String names) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(names);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findByBarcode(final String barcodes) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andBarcodeEqualTo(barcodes);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findByType(final Integer types) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(types);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findByMustVip(final Integer mustVips) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMustVipEqualTo(mustVips);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findByIsGift(final Integer isGifts) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andIsGiftEqualTo(isGifts);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findOneByName(final String name) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andNameEqualTo(name);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findOneByBarcode(final String barcode) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andBarcodeEqualTo(barcode);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findOneByForSale(final Integer forSale) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andForSaleEqualTo(forSale);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findOneByType(final Integer type) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andTypeEqualTo(type);
        return this.mapper.selectOneByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public StoreGoods findOneByMustVip(final Integer mustVip) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false).andMustVipEqualTo(mustVip);
        return this.mapper.selectOneByExample(example);
    }

    public List<StoreGoods> findAll(final int page, final int size, final String sort, final String order) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            example.setOrderByClause(String.valueOf(sort) + " " + order);
        }

        PageHelper.startPage(page, size);
        return this.mapper.selectByExample(example);
    }

    @Cacheable(
            cacheNames = {"StoreGoods"},
            keyGenerator = "cacheAutoKey"
    )
    public List<StoreGoods> findAll() {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        criteria.andDeletedEqualTo(false);
        return this.mapper.selectByExample(example);
    }

    public List<StoreGoods> selectAll(StoreGoods goods) {
        StoreGoodsExample example = new StoreGoodsExample();
        Criteria criteria = example.createCriteria();
        if (goods.getName() != null) {
            criteria.andNameEqualTo(goods.getName());
        }

        return this.mapper.selectByExample(example);
    }

    @CacheEvict(
            cacheNames = {"StoreGoods"},
            allEntries = true
    )
    public void refreshCache() {
    }
}
