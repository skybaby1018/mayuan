//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.chara;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.ChargeGetRecordMapper;
import com.fengshen.db.domain.ChargeGetRecord;
import com.fengshen.db.service.base.BaseServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class ChargeGetRecordService implements BaseServiceSupport<ChargeGetRecord> {
    @Autowired
    private ChargeGetRecordMapper cm;

    @Override
    public BaseCustomMapper<ChargeGetRecord> getBaseMapper() {
        return this.cm;
    }

    public int getUserChargeGetRecords(String account, int money) {
        Example example = new Example(ChargeGetRecord.class);
        example.createCriteria().andEqualTo("account", account).andEqualTo("money", money);
        return this.cm.selectCountByExample(example);
    }
}
