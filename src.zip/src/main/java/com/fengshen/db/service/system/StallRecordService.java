//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.service.system;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.dao.StallRecordMapper;
import com.fengshen.db.domain.StallRecord;
import com.fengshen.db.service.base.BaseServiceSupport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class StallRecordService implements BaseServiceSupport<StallRecord> {
    @Autowired
    private StallRecordMapper gsrm;

    public StallRecordService() {
    }

    public BaseCustomMapper<StallRecord> getBaseMapper() {
        return this.gsrm;
    }

    public List<StallRecord> getStallRecord(int cid, int status) {
        Example example = new Example(StallRecord.class);
        example.excludeProperties(new String[]{"data"});
        example.createCriteria().andEqualTo("cid", cid).andEqualTo("status", status);
        return this.gsrm.selectByExample(example);
    }

    public List<StallRecord> getStallRecordByStallRecordType(int cid, int stallRecordType) {
        Example example = new Example(StallRecord.class);
        example.excludeProperties(new String[]{"data"});
        example.createCriteria().andEqualTo("cid", cid).andEqualTo("stallRecordType", stallRecordType);
        return this.gsrm.selectByExample(example);
    }

    public StallRecord getOneStallRecordByGoodsId(String goodsId) {
        Example example = new Example(StallRecord.class);
        example.excludeProperties(new String[]{"data"});
        example.createCriteria().andEqualTo("goodsUuid", goodsId);
        return (StallRecord) this.gsrm.selectOneByExample(example);
    }
}
