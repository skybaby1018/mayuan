/*     */
package com.fengshen.db.service.base;
/*     */
/*     */

import com.fengshen.db.dao.SrenwuMapper;
/*     */ import com.fengshen.db.domain.Srenwu;
/*     */ import com.fengshen.db.domain.example.SrenwuExample;
/*     */ import com.fengshen.db.domain.example.SrenwuExample.Criteria;
/*     */ import com.github.pagehelper.PageHelper;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.util.StringUtils;

/*     */
/*     */
@org.springframework.stereotype.Service
/*     */ public class BaseSrenwuService
        /*     */ {
    /*     */
    @Autowired
    /*     */ protected SrenwuMapper mapper;

    /*     */
    /*     */
    public Srenwu findById(int id)
    /*     */ {
        /*  21 */
        return this.mapper.selectByPrimaryKeyWithLogicalDelete(Integer.valueOf(id), false);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findByIdContainsDelete(int id) {
        /*  25 */
        return this.mapper.selectByPrimaryKey(Integer.valueOf(id));
        /*     */
    }

    /*     */
    /*     */
    public void add(Srenwu srenwu) {
        /*  29 */
        srenwu.setAddTime(LocalDateTime.now());
        /*  30 */
        srenwu.setUpdateTime(LocalDateTime.now());
        /*  31 */
        this.mapper.insertSelective(srenwu);
        /*     */
    }

    /*     */
    /*     */
    public int updateById(Srenwu srenwu) {
        /*  35 */
        srenwu.setUpdateTime(LocalDateTime.now());
        /*  36 */
        return this.mapper.updateByPrimaryKeySelective(srenwu);
        /*     */
    }

    /*     */
    /*     */
    public void deleteById(int id) {
        /*  40 */
        this.mapper.logicalDeleteByPrimaryKey(Integer.valueOf(id));
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findByPid(String pid) {
        /*  44 */
        SrenwuExample example = new SrenwuExample();
        /*  45 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  46 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andPidEqualTo(pid);
        /*  47 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findByRid(Integer rid) {
        /*  51 */
        SrenwuExample example = new SrenwuExample();
        /*  52 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  53 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andRidEqualTo(rid);
        /*  54 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findBySkillName(String skillName) {
        /*  58 */
        SrenwuExample example = new SrenwuExample();
        /*  59 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  60 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillNameEqualTo(skillName);
        /*  61 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findBySkillJieshao(String skillJieshao) {
        /*  65 */
        SrenwuExample example = new SrenwuExample();
        /*  66 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  67 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillJieshaoEqualTo(skillJieshao);
        /*  68 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findBySkillDqti(String skillDqti) {
        /*  72 */
        SrenwuExample example = new SrenwuExample();
        /*  73 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  74 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillDqtiEqualTo(skillDqti);
        /*  75 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findBySkillXck(String skillXck) {
        /*  79 */
        SrenwuExample example = new SrenwuExample();
        /*  80 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  81 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillXckEqualTo(skillXck);
        /*  82 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneByPid(String pid) {
        /*  86 */
        SrenwuExample example = new SrenwuExample();
        /*  87 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  88 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andPidEqualTo(pid);
        /*  89 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneByRid(Integer rid) {
        /*  93 */
        SrenwuExample example = new SrenwuExample();
        /*  94 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /*  95 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andRidEqualTo(rid);
        /*  96 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneBySkillName(String skillName) {
        /* 100 */
        SrenwuExample example = new SrenwuExample();
        /* 101 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 102 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillNameEqualTo(skillName);
        /* 103 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneBySkillJieshao(String skillJieshao) {
        /* 107 */
        SrenwuExample example = new SrenwuExample();
        /* 108 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 109 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillJieshaoEqualTo(skillJieshao);
        /* 110 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneBySkillDqti(String skillDqti) {
        /* 114 */
        SrenwuExample example = new SrenwuExample();
        /* 115 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 116 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillDqtiEqualTo(skillDqti);
        /* 117 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public Srenwu findOneBySkillXck(String skillXck) {
        /* 121 */
        SrenwuExample example = new SrenwuExample();
        /* 122 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 123 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false)).andSkillXckEqualTo(skillXck);
        /* 124 */
        return this.mapper.selectOneByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findAll(int page, int size, String sort, String order) {
        /* 128 */
        SrenwuExample example = new SrenwuExample();
        /* 129 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 130 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        /* 131 */
        if ((!StringUtils.isEmpty(sort)) && (!StringUtils.isEmpty(order))) {
            /* 132 */
            example.setOrderByClause(String.valueOf(sort) + " " + order);
            /*     */
        }
        /* 134 */
        PageHelper.startPage(page, size);
        /* 135 */
        return this.mapper.selectByExample(example);
        /*     */
    }

    /*     */
    /*     */
    public List<Srenwu> findAll() {
        /* 139 */
        SrenwuExample example = new SrenwuExample();
        /* 140 */
        SrenwuExample.Criteria criteria = example.createCriteria();
        /* 141 */
        criteria.andDeletedEqualTo(Boolean.valueOf(false));
        /* 142 */
        return this.mapper.selectByExample(example);
        /*     */
    }
    /*     */
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\service\base\BaseSrenwuService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */