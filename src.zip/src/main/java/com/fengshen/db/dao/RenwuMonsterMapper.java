package com.fengshen.db.dao;

import com.fengshen.db.domain.RenwuMonster;
import com.fengshen.db.domain.RenwuMonster.Column;
import com.fengshen.db.domain.example.RenwuMonsterExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface RenwuMonsterMapper {
    public abstract long countByExample(RenwuMonsterExample paramRenwuMonsterExample);

    public abstract int deleteByExample(RenwuMonsterExample paramRenwuMonsterExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(RenwuMonster paramRenwuMonster);

    public abstract int insertSelective(RenwuMonster paramRenwuMonster);

    public abstract RenwuMonster selectOneByExample(RenwuMonsterExample paramRenwuMonsterExample);

    public abstract RenwuMonster selectOneByExampleSelective(@Param("example") RenwuMonsterExample paramRenwuMonsterExample, @Param("selective") RenwuMonster.Column... paramVarArgs);

    public abstract List<RenwuMonster> selectByExampleSelective(@Param("example") RenwuMonsterExample paramRenwuMonsterExample, @Param("selective") RenwuMonster.Column... paramVarArgs);

    public abstract List<RenwuMonster> selectByExample(RenwuMonsterExample paramRenwuMonsterExample);

    public abstract RenwuMonster selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") RenwuMonster.Column... paramVarArgs);

    public abstract RenwuMonster selectByPrimaryKey(Integer paramInteger);

    public abstract RenwuMonster selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") RenwuMonster paramRenwuMonster, @Param("example") RenwuMonsterExample paramRenwuMonsterExample);

    public abstract int updateByExample(@Param("record") RenwuMonster paramRenwuMonster, @Param("example") RenwuMonsterExample paramRenwuMonsterExample);

    public abstract int updateByPrimaryKeySelective(RenwuMonster paramRenwuMonster);

    public abstract int updateByPrimaryKey(RenwuMonster paramRenwuMonster);

    public abstract int logicalDeleteByExample(@Param("example") RenwuMonsterExample paramRenwuMonsterExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);

    public abstract RenwuMonster getOneRandomRenwuMonster(int paramInt);

    public abstract RenwuMonster getOneRandomRenwuMonsterByTypeNotReplace(RenwuMonster paramRenwuMonster);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\RenwuMonsterMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */