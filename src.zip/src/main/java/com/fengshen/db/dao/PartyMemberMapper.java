package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.PartyMember;

public abstract interface PartyMemberMapper
        extends BaseCustomMapper<PartyMember> {
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\PartyMemberMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */