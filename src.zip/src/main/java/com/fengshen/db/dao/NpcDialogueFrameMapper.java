package com.fengshen.db.dao;

import com.fengshen.db.domain.NpcDialogueFrame;
import com.fengshen.db.domain.NpcDialogueFrame.Column;
import com.fengshen.db.domain.example.NpcDialogueFrameExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface NpcDialogueFrameMapper {
    public abstract long countByExample(NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract int deleteByExample(NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(NpcDialogueFrame paramNpcDialogueFrame);

    public abstract int insertSelective(NpcDialogueFrame paramNpcDialogueFrame);

    public abstract NpcDialogueFrame selectOneByExample(NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract NpcDialogueFrame selectOneByExampleSelective(@Param("example") NpcDialogueFrameExample paramNpcDialogueFrameExample, @Param("selective") NpcDialogueFrame.Column... paramVarArgs);

    public abstract List<NpcDialogueFrame> selectByExampleSelective(@Param("example") NpcDialogueFrameExample paramNpcDialogueFrameExample, @Param("selective") NpcDialogueFrame.Column... paramVarArgs);

    public abstract List<NpcDialogueFrame> selectByExample(NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract NpcDialogueFrame selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") NpcDialogueFrame.Column... paramVarArgs);

    public abstract NpcDialogueFrame selectByPrimaryKey(Integer paramInteger);

    public abstract NpcDialogueFrame selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") NpcDialogueFrame paramNpcDialogueFrame, @Param("example") NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract int updateByExample(@Param("record") NpcDialogueFrame paramNpcDialogueFrame, @Param("example") NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract int updateByPrimaryKeySelective(NpcDialogueFrame paramNpcDialogueFrame);

    public abstract int updateByPrimaryKey(NpcDialogueFrame paramNpcDialogueFrame);

    public abstract int logicalDeleteByExample(@Param("example") NpcDialogueFrameExample paramNpcDialogueFrameExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\NpcDialogueFrameMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */