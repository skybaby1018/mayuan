package com.fengshen.db.dao;

import com.fengshen.db.domain.Map;
import com.fengshen.db.domain.Map.Column;
import com.fengshen.db.domain.example.MapExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface MapMapper {
    public abstract long countByExample(MapExample paramMapExample);

    public abstract int deleteByExample(MapExample paramMapExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Map paramMap);

    public abstract int insertSelective(Map paramMap);

    public abstract Map selectOneByExample(MapExample paramMapExample);

    public abstract Map selectOneByExampleSelective(@Param("example") MapExample paramMapExample, @Param("selective") Map.Column... paramVarArgs);

    public abstract List<Map> selectByExampleSelective(@Param("example") MapExample paramMapExample, @Param("selective") Map.Column... paramVarArgs);

    public abstract List<Map> selectByExample(MapExample paramMapExample);

    public abstract Map selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Map.Column... paramVarArgs);

    public abstract Map selectByPrimaryKey(Integer paramInteger);

    public abstract Map selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Map paramMap, @Param("example") MapExample paramMapExample);

    public abstract int updateByExample(@Param("record") Map paramMap, @Param("example") MapExample paramMapExample);

    public abstract int updateByPrimaryKeySelective(Map paramMap);

    public abstract int updateByPrimaryKey(Map paramMap);

    public abstract int logicalDeleteByExample(@Param("example") MapExample paramMapExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\MapMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */