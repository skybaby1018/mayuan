package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.CustomPetSkill;
import org.springframework.stereotype.Repository;

@Repository
public abstract interface CustomPetSkillMapper
        extends BaseCustomMapper<CustomPetSkill> {
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\CustomPetSkillMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */