package com.fengshen.db.dao;

import com.fengshen.db.domain.MedicineShop;
import com.fengshen.db.domain.MedicineShop.Column;
import com.fengshen.db.domain.example.MedicineShopExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface MedicineShopMapper {
    public abstract long countByExample(MedicineShopExample paramMedicineShopExample);

    public abstract int deleteByExample(MedicineShopExample paramMedicineShopExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(MedicineShop paramMedicineShop);

    public abstract int insertSelective(MedicineShop paramMedicineShop);

    public abstract MedicineShop selectOneByExample(MedicineShopExample paramMedicineShopExample);

    public abstract MedicineShop selectOneByExampleSelective(@Param("example") MedicineShopExample paramMedicineShopExample, @Param("selective") MedicineShop.Column... paramVarArgs);

    public abstract List<MedicineShop> selectByExampleSelective(@Param("example") MedicineShopExample paramMedicineShopExample, @Param("selective") MedicineShop.Column... paramVarArgs);

    public abstract List<MedicineShop> selectByExample(MedicineShopExample paramMedicineShopExample);

    public abstract MedicineShop selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") MedicineShop.Column... paramVarArgs);

    public abstract MedicineShop selectByPrimaryKey(Integer paramInteger);

    public abstract MedicineShop selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") MedicineShop paramMedicineShop, @Param("example") MedicineShopExample paramMedicineShopExample);

    public abstract int updateByExample(@Param("record") MedicineShop paramMedicineShop, @Param("example") MedicineShopExample paramMedicineShopExample);

    public abstract int updateByPrimaryKeySelective(MedicineShop paramMedicineShop);

    public abstract int updateByPrimaryKey(MedicineShop paramMedicineShop);

    public abstract int logicalDeleteByExample(@Param("example") MedicineShopExample paramMedicineShopExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\MedicineShopMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */