package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.FriendGroup;

public abstract interface FriendGroupMapper
        extends BaseCustomMapper<FriendGroup> {
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\FriendGroupMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */