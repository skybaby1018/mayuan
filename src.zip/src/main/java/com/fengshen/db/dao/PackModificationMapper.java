package com.fengshen.db.dao;

import com.fengshen.db.domain.PackModification;
import com.fengshen.db.domain.PackModification.Column;
import com.fengshen.db.domain.example.PackModificationExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface PackModificationMapper {
    public abstract long countByExample(PackModificationExample paramPackModificationExample);

    public abstract int deleteByExample(PackModificationExample paramPackModificationExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(PackModification paramPackModification);

    public abstract int insertSelective(PackModification paramPackModification);

    public abstract PackModification selectOneByExample(PackModificationExample paramPackModificationExample);

    public abstract PackModification selectOneByExampleSelective(@Param("example") PackModificationExample paramPackModificationExample, @Param("selective") PackModification.Column... paramVarArgs);

    public abstract List<PackModification> selectByExampleSelective(@Param("example") PackModificationExample paramPackModificationExample, @Param("selective") PackModification.Column... paramVarArgs);

    public abstract List<PackModification> selectByExample(PackModificationExample paramPackModificationExample);

    public abstract PackModification selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") PackModification.Column... paramVarArgs);

    public abstract PackModification selectByPrimaryKey(Integer paramInteger);

    public abstract PackModification selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") PackModification paramPackModification, @Param("example") PackModificationExample paramPackModificationExample);

    public abstract int updateByExample(@Param("record") PackModification paramPackModification, @Param("example") PackModificationExample paramPackModificationExample);

    public abstract int updateByPrimaryKeySelective(PackModification paramPackModification);

    public abstract int updateByPrimaryKey(PackModification paramPackModification);

    public abstract int logicalDeleteByExample(@Param("example") PackModificationExample paramPackModificationExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\PackModificationMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */