package com.fengshen.db.dao;

import com.fengshen.db.domain.Srenwu;
import com.fengshen.db.domain.Srenwu.Column;
import com.fengshen.db.domain.example.SrenwuExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface SrenwuMapper {
    public abstract long countByExample(SrenwuExample paramSrenwuExample);

    public abstract int deleteByExample(SrenwuExample paramSrenwuExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Srenwu paramSrenwu);

    public abstract int insertSelective(Srenwu paramSrenwu);

    public abstract Srenwu selectOneByExample(SrenwuExample paramSrenwuExample);

    public abstract Srenwu selectOneByExampleSelective(@Param("example") SrenwuExample paramSrenwuExample, @Param("selective") Srenwu.Column... paramVarArgs);

    public abstract List<Srenwu> selectByExampleSelective(@Param("example") SrenwuExample paramSrenwuExample, @Param("selective") Srenwu.Column... paramVarArgs);

    public abstract List<Srenwu> selectByExample(SrenwuExample paramSrenwuExample);

    public abstract Srenwu selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Srenwu.Column... paramVarArgs);

    public abstract Srenwu selectByPrimaryKey(Integer paramInteger);

    public abstract Srenwu selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Srenwu paramSrenwu, @Param("example") SrenwuExample paramSrenwuExample);

    public abstract int updateByExample(@Param("record") Srenwu paramSrenwu, @Param("example") SrenwuExample paramSrenwuExample);

    public abstract int updateByPrimaryKeySelective(Srenwu paramSrenwu);

    public abstract int updateByPrimaryKey(Srenwu paramSrenwu);

    public abstract int logicalDeleteByExample(@Param("example") SrenwuExample paramSrenwuExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\SrenwuMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */