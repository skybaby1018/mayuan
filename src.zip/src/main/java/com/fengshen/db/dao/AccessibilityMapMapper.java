package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.AccessibilityMap;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccessibilityMapMapper extends BaseCustomMapper<AccessibilityMap> {
    public abstract List<AccessibilityMap> getRandomData(AccessibilityMap paramAccessibilityMap);

    public abstract List<AccessibilityMap> randomData(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\AccessibilityMapMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */