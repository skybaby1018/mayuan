package com.fengshen.db.dao;

import com.fengshen.db.domain.Experience;
import com.fengshen.db.domain.Experience.Column;
import com.fengshen.db.domain.example.ExperienceExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public abstract interface ExperienceMapper {
    public abstract long countByExample(ExperienceExample paramExperienceExample);

    public abstract int deleteByExample(ExperienceExample paramExperienceExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Experience paramExperience);

    public abstract int insertSelective(Experience paramExperience);

    public abstract Experience selectOneByExample(ExperienceExample paramExperienceExample);

    public abstract Experience selectOneByExampleSelective(@Param("example") ExperienceExample paramExperienceExample, @Param("selective") Experience.Column... paramVarArgs);

    public abstract List<Experience> selectByExampleSelective(@Param("example") ExperienceExample paramExperienceExample, @Param("selective") Experience.Column... paramVarArgs);

    public abstract List<Experience> selectByExample(ExperienceExample paramExperienceExample);

    public abstract Experience selectByPrimaryKeySelective(@Param("attrib") Integer paramInteger, @Param("selective") Experience.Column... paramVarArgs);

    public abstract Experience selectByPrimaryKey(Integer paramInteger);

    public abstract Experience selectByPrimaryKeyWithLogicalDelete(@Param("attrib") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Experience paramExperience, @Param("example") ExperienceExample paramExperienceExample);

    public abstract int updateByExample(@Param("record") Experience paramExperience, @Param("example") ExperienceExample paramExperienceExample);

    public abstract int updateByPrimaryKeySelective(Experience paramExperience);

    public abstract int updateByPrimaryKey(Experience paramExperience);

    public abstract int logicalDeleteByExample(@Param("example") ExperienceExample paramExperienceExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ExperienceMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */