package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.ChargeGetRecord;

public abstract interface ChargeGetRecordMapper extends BaseCustomMapper<ChargeGetRecord> {
}