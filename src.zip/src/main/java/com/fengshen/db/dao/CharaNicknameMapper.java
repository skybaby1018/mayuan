package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.CharaNickname;
import org.springframework.stereotype.Repository;

@Repository
public abstract interface CharaNicknameMapper
        extends BaseCustomMapper<CharaNickname> {
    public abstract CharaNickname randomData(CharaNickname paramCharaNickname);

    public abstract CharaNickname randomData2(CharaNickname paramCharaNickname);
}