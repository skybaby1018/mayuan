package com.fengshen.db.dao;

import com.fengshen.db.domain.Reports;
import com.fengshen.db.domain.Reports.Column;
import com.fengshen.db.domain.example.ReportsExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ReportsMapper {
    public abstract long countByExample(ReportsExample paramReportsExample);

    public abstract int deleteByExample(ReportsExample paramReportsExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Reports paramReports);

    public abstract int insertSelective(Reports paramReports);

    public abstract Reports selectOneByExample(ReportsExample paramReportsExample);

    public abstract Reports selectOneByExampleSelective(@Param("example") ReportsExample paramReportsExample, @Param("selective") Reports.Column... paramVarArgs);

    public abstract List<Reports> selectByExampleSelective(@Param("example") ReportsExample paramReportsExample, @Param("selective") Reports.Column... paramVarArgs);

    public abstract List<Reports> selectByExample(ReportsExample paramReportsExample);

    public abstract Reports selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Reports.Column... paramVarArgs);

    public abstract Reports selectByPrimaryKey(Integer paramInteger);

    public abstract Reports selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Reports paramReports, @Param("example") ReportsExample paramReportsExample);

    public abstract int updateByExample(@Param("record") Reports paramReports, @Param("example") ReportsExample paramReportsExample);

    public abstract int updateByPrimaryKeySelective(Reports paramReports);

    public abstract int updateByPrimaryKey(Reports paramReports);

    public abstract int logicalDeleteByExample(@Param("example") ReportsExample paramReportsExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ReportsMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */