package com.fengshen.db.dao;

import com.fengshen.db.domain.Npc;
import com.fengshen.db.domain.Npc.Column;
import com.fengshen.db.domain.example.NpcExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface NpcMapper {
    public abstract long countByExample(NpcExample paramNpcExample);

    public abstract int deleteByExample(NpcExample paramNpcExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Npc paramNpc);

    public abstract int insertSelective(Npc paramNpc);

    public abstract Npc selectOneByExample(NpcExample paramNpcExample);

    public abstract Npc selectOneByExampleSelective(@Param("example") NpcExample paramNpcExample, @Param("selective") Npc.Column... paramVarArgs);

    public abstract List<Npc> selectByExampleSelective(@Param("example") NpcExample paramNpcExample, @Param("selective") Npc.Column... paramVarArgs);

    public abstract List<Npc> selectByExample(NpcExample paramNpcExample);

    public abstract Npc selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Npc.Column... paramVarArgs);

    public abstract Npc selectByPrimaryKey(Integer paramInteger);

    public abstract Npc selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Npc paramNpc, @Param("example") NpcExample paramNpcExample);

    public abstract int updateByExample(@Param("record") Npc paramNpc, @Param("example") NpcExample paramNpcExample);

    public abstract int updateByPrimaryKeySelective(Npc paramNpc);

    public abstract int updateByPrimaryKey(Npc paramNpc);

    public abstract int logicalDeleteByExample(@Param("example") NpcExample paramNpcExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);

    public abstract Npc randomData();
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\NpcMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */