package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.Characters;
import org.springframework.stereotype.Repository;

@Repository
public interface CharactersMapper extends BaseCustomMapper<Characters> {
}
