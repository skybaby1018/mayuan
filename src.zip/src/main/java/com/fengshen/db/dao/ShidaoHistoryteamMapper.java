package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.ShidaoHistoryteam;

public abstract interface ShidaoHistoryteamMapper
        extends BaseCustomMapper<ShidaoHistoryteam> {
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ShidaoHistoryteamMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */