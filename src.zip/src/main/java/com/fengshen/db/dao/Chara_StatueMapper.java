package com.fengshen.db.dao;

import com.fengshen.db.domain.Chara_Statue;
import com.fengshen.db.domain.Chara_StatueExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public abstract interface Chara_StatueMapper {
    public abstract long countByExample(Chara_StatueExample paramChara_StatueExample);

    public abstract int deleteByExample(Chara_StatueExample paramChara_StatueExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Chara_Statue paramChara_Statue);

    public abstract int insertSelective(Chara_Statue paramChara_Statue);

    public abstract List<Chara_Statue> selectByExampleWithBLOBs(Chara_StatueExample paramChara_StatueExample);

    public abstract List<Chara_Statue> selectByExample(Chara_StatueExample paramChara_StatueExample);

    public abstract Chara_Statue selectByPrimaryKey(Integer paramInteger);

    public abstract int updateByExampleWithBLOBs(@Param("record") Chara_Statue paramChara_Statue, @Param("example") Chara_StatueExample paramChara_StatueExample);

    public abstract int updateByExample(@Param("record") Chara_Statue paramChara_Statue, @Param("example") Chara_StatueExample paramChara_StatueExample);

    public abstract int updateByPrimaryKeySelective(Chara_Statue paramChara_Statue);

    public abstract int updateByPrimaryKeyWithBLOBs(Chara_Statue paramChara_Statue);

    public abstract int updateByPrimaryKey(Chara_Statue paramChara_Statue);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\Chara_StatueMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */