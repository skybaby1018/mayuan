package com.fengshen.db.dao;

import com.fengshen.db.domain.NpcDialogue;
import com.fengshen.db.domain.NpcDialogue.Column;
import com.fengshen.db.domain.example.NpcDialogueExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public abstract interface NpcDialogueMapper {
    public abstract long countByExample(NpcDialogueExample paramNpcDialogueExample);

    public abstract int deleteByExample(NpcDialogueExample paramNpcDialogueExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(NpcDialogue paramNpcDialogue);

    public abstract int insertSelective(NpcDialogue paramNpcDialogue);

    public abstract NpcDialogue selectOneByExample(NpcDialogueExample paramNpcDialogueExample);

    public abstract NpcDialogue selectOneByExampleSelective(@Param("example") NpcDialogueExample paramNpcDialogueExample, @Param("selective") NpcDialogue.Column... paramVarArgs);

    public abstract List<NpcDialogue> selectByExampleSelective(@Param("example") NpcDialogueExample paramNpcDialogueExample, @Param("selective") NpcDialogue.Column... paramVarArgs);

    public abstract List<NpcDialogue> selectByExample(NpcDialogueExample paramNpcDialogueExample);

    public abstract NpcDialogue selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") NpcDialogue.Column... paramVarArgs);

    public abstract NpcDialogue selectByPrimaryKey(Integer paramInteger);

    public abstract NpcDialogue selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") NpcDialogue paramNpcDialogue, @Param("example") NpcDialogueExample paramNpcDialogueExample);

    public abstract int updateByExample(@Param("record") NpcDialogue paramNpcDialogue, @Param("example") NpcDialogueExample paramNpcDialogueExample);

    public abstract int updateByPrimaryKeySelective(NpcDialogue paramNpcDialogue);

    public abstract int updateByPrimaryKey(NpcDialogue paramNpcDialogue);

    public abstract int logicalDeleteByExample(@Param("example") NpcDialogueExample paramNpcDialogueExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\NpcDialogueMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */