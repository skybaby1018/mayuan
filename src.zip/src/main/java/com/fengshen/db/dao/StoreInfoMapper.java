package com.fengshen.db.dao;

import com.fengshen.db.domain.StoreInfo;
import com.fengshen.db.domain.StoreInfo.Column;
import com.fengshen.db.domain.example.StoreInfoExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface StoreInfoMapper {
    public abstract long countByExample(StoreInfoExample paramStoreInfoExample);

    public abstract int deleteByExample(StoreInfoExample paramStoreInfoExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(StoreInfo paramStoreInfo);

    public abstract int insertSelective(StoreInfo paramStoreInfo);

    public abstract StoreInfo selectOneByExample(StoreInfoExample paramStoreInfoExample);

    public abstract StoreInfo selectOneByExampleSelective(@Param("example") StoreInfoExample paramStoreInfoExample, @Param("selective") StoreInfo.Column... paramVarArgs);

    public abstract List<StoreInfo> selectByExampleSelective(@Param("example") StoreInfoExample paramStoreInfoExample, @Param("selective") StoreInfo.Column... paramVarArgs);

    public abstract List<StoreInfo> selectByExample(StoreInfoExample paramStoreInfoExample);

    public abstract StoreInfo selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") StoreInfo.Column... paramVarArgs);

    public abstract StoreInfo selectByPrimaryKey(Integer paramInteger);

    public abstract StoreInfo selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") StoreInfo paramStoreInfo, @Param("example") StoreInfoExample paramStoreInfoExample);

    public abstract int updateByExample(@Param("record") StoreInfo paramStoreInfo, @Param("example") StoreInfoExample paramStoreInfoExample);

    public abstract int updateByPrimaryKeySelective(StoreInfo paramStoreInfo);

    public abstract int updateByPrimaryKey(StoreInfo paramStoreInfo);

    public abstract int logicalDeleteByExample(@Param("example") StoreInfoExample paramStoreInfoExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\StoreInfoMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */