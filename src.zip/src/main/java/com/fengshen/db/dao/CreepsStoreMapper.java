package com.fengshen.db.dao;

import com.fengshen.db.domain.CreepsStore;
import com.fengshen.db.domain.CreepsStore.Column;
import com.fengshen.db.domain.example.CreepsStoreExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface CreepsStoreMapper {
    public abstract long countByExample(CreepsStoreExample paramCreepsStoreExample);

    public abstract int deleteByExample(CreepsStoreExample paramCreepsStoreExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(CreepsStore paramCreepsStore);

    public abstract int insertSelective(CreepsStore paramCreepsStore);

    public abstract CreepsStore selectOneByExample(CreepsStoreExample paramCreepsStoreExample);

    public abstract CreepsStore selectOneByExampleSelective(@Param("example") CreepsStoreExample paramCreepsStoreExample, @Param("selective") CreepsStore.Column... paramVarArgs);

    public abstract List<CreepsStore> selectByExampleSelective(@Param("example") CreepsStoreExample paramCreepsStoreExample, @Param("selective") CreepsStore.Column... paramVarArgs);

    public abstract List<CreepsStore> selectByExample(CreepsStoreExample paramCreepsStoreExample);

    public abstract CreepsStore selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") CreepsStore.Column... paramVarArgs);

    public abstract CreepsStore selectByPrimaryKey(Integer paramInteger);

    public abstract CreepsStore selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") CreepsStore paramCreepsStore, @Param("example") CreepsStoreExample paramCreepsStoreExample);

    public abstract int updateByExample(@Param("record") CreepsStore paramCreepsStore, @Param("example") CreepsStoreExample paramCreepsStoreExample);

    public abstract int updateByPrimaryKeySelective(CreepsStore paramCreepsStore);

    public abstract int updateByPrimaryKey(CreepsStore paramCreepsStore);

    public abstract int logicalDeleteByExample(@Param("example") CreepsStoreExample paramCreepsStoreExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\CreepsStoreMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */