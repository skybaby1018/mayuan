package com.fengshen.db.dao;

import com.fengshen.server.choujiang.Npc_Choujiang;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface Npc_ChoujiangMapper {
    @Select({"select * from npc_choujiang where name = #{name}"})
    Npc_Choujiang getNpc_ChoujiangByName(final String name);

    @Select({"select * from npc_choujiang"})
    List<Npc_Choujiang> getNpc_ChoujiangByNames();

    @Select({"select * from npc_choujiang"})
    List<Npc_Choujiang> getNpc_Choujiangs();

    @Update({"update npc_choujiang set config = #{config} where name = #{name}"})
    Integer editCj(@Param("config") final String config, @Param("name") final String name);

    @Update({"update npc_choujiang set jifen = #{jifen} where name = #{name}"})
    Integer editCjJf(@Param("name") final String name, @Param("jifen") final int jifen);
}
