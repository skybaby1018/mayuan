package com.fengshen.db.dao;

import com.fengshen.db.domain.Pets;
import com.fengshen.db.domain.Pets.Column;
import com.fengshen.db.domain.example.PetsExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface PetsMapper {
    public abstract long countByExample(PetsExample paramPetsExample);

    public abstract int deleteByExample(PetsExample paramPetsExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Pets paramPets);

    public abstract int insertSelective(Pets paramPets);

    public abstract Pets selectOneByExample(PetsExample paramPetsExample);

    public abstract Pets selectOneByExampleSelective(@Param("example") PetsExample paramPetsExample, @Param("selective") Pets.Column... paramVarArgs);

    public abstract List<Pets> selectByExampleSelective(@Param("example") PetsExample paramPetsExample, @Param("selective") Pets.Column... paramVarArgs);

    public abstract List<Pets> selectByExample(PetsExample paramPetsExample);

    public abstract Pets selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Pets.Column... paramVarArgs);

    public abstract Pets selectByPrimaryKey(Integer paramInteger);

    public abstract Pets selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Pets paramPets, @Param("example") PetsExample paramPetsExample);

    public abstract int updateByExample(@Param("record") Pets paramPets, @Param("example") PetsExample paramPetsExample);

    public abstract int updateByPrimaryKeySelective(Pets paramPets);

    public abstract int updateByPrimaryKey(Pets paramPets);

    public abstract int logicalDeleteByExample(@Param("example") PetsExample paramPetsExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\PetsMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */