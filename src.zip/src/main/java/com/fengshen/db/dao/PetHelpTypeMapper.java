package com.fengshen.db.dao;

import com.fengshen.db.domain.PetHelpType;
import com.fengshen.db.domain.PetHelpType.Column;
import com.fengshen.db.domain.example.PetHelpTypeExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface PetHelpTypeMapper {
    public abstract long countByExample(PetHelpTypeExample paramPetHelpTypeExample);

    public abstract int deleteByExample(PetHelpTypeExample paramPetHelpTypeExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(PetHelpType paramPetHelpType);

    public abstract int insertSelective(PetHelpType paramPetHelpType);

    public abstract PetHelpType selectOneByExample(PetHelpTypeExample paramPetHelpTypeExample);

    public abstract PetHelpType selectOneByExampleSelective(@Param("example") PetHelpTypeExample paramPetHelpTypeExample, @Param("selective") PetHelpType.Column... paramVarArgs);

    public abstract List<PetHelpType> selectByExampleSelective(@Param("example") PetHelpTypeExample paramPetHelpTypeExample, @Param("selective") PetHelpType.Column... paramVarArgs);

    public abstract List<PetHelpType> selectByExample(PetHelpTypeExample paramPetHelpTypeExample);

    public abstract PetHelpType selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") PetHelpType.Column... paramVarArgs);

    public abstract PetHelpType selectByPrimaryKey(Integer paramInteger);

    public abstract PetHelpType selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") PetHelpType paramPetHelpType, @Param("example") PetHelpTypeExample paramPetHelpTypeExample);

    public abstract int updateByExample(@Param("record") PetHelpType paramPetHelpType, @Param("example") PetHelpTypeExample paramPetHelpTypeExample);

    public abstract int updateByPrimaryKeySelective(PetHelpType paramPetHelpType);

    public abstract int updateByPrimaryKey(PetHelpType paramPetHelpType);

    public abstract int logicalDeleteByExample(@Param("example") PetHelpTypeExample paramPetHelpTypeExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\PetHelpTypeMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */