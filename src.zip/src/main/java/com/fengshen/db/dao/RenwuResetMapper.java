package com.fengshen.db.dao;

import com.fengshen.db.domain.RenwuReset;

import java.util.List;

public abstract interface RenwuResetMapper {
    public abstract List<RenwuReset> select(RenwuReset paramRenwuReset);

    public abstract int insert(RenwuReset paramRenwuReset);

    public abstract int update(RenwuReset paramRenwuReset);

    public abstract int delete();
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\RenwuResetMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */