package com.fengshen.db.dao;

import com.fengshen.db.domain.Skilldata;
import com.fengshen.db.domain.Skilldata.Column;
import com.fengshen.db.domain.example.SkilldataExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface SkilldataMapper {
    public abstract long countByExample(SkilldataExample paramSkilldataExample);

    public abstract int deleteByExample(SkilldataExample paramSkilldataExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Skilldata paramSkilldata);

    public abstract int insertSelective(Skilldata paramSkilldata);

    public abstract Skilldata selectOneByExample(SkilldataExample paramSkilldataExample);

    public abstract Skilldata selectOneByExampleSelective(@Param("example") SkilldataExample paramSkilldataExample, @Param("selective") Skilldata.Column... paramVarArgs);

    public abstract List<Skilldata> selectByExampleSelective(@Param("example") SkilldataExample paramSkilldataExample, @Param("selective") Skilldata.Column... paramVarArgs);

    public abstract List<Skilldata> selectByExample(SkilldataExample paramSkilldataExample);

    public abstract Skilldata selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Skilldata.Column... paramVarArgs);

    public abstract Skilldata selectByPrimaryKey(Integer paramInteger);

    public abstract Skilldata selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Skilldata paramSkilldata, @Param("example") SkilldataExample paramSkilldataExample);

    public abstract int updateByExample(@Param("record") Skilldata paramSkilldata, @Param("example") SkilldataExample paramSkilldataExample);

    public abstract int updateByPrimaryKeySelective(Skilldata paramSkilldata);

    public abstract int updateByPrimaryKey(Skilldata paramSkilldata);

    public abstract int logicalDeleteByExample(@Param("example") SkilldataExample paramSkilldataExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\SkilldataMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */