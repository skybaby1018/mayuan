package com.fengshen.db.dao;

import com.fengshen.db.domain.GroceriesShop;
import com.fengshen.db.domain.GroceriesShop.Column;
import com.fengshen.db.domain.example.GroceriesShopExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface GroceriesShopMapper {
    public abstract long countByExample(GroceriesShopExample paramGroceriesShopExample);

    public abstract int deleteByExample(GroceriesShopExample paramGroceriesShopExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(GroceriesShop paramGroceriesShop);

    public abstract int insertSelective(GroceriesShop paramGroceriesShop);

    public abstract GroceriesShop selectOneByExample(GroceriesShopExample paramGroceriesShopExample);

    public abstract GroceriesShop selectOneByExampleSelective(@Param("example") GroceriesShopExample paramGroceriesShopExample, @Param("selective") GroceriesShop.Column... paramVarArgs);

    public abstract List<GroceriesShop> selectByExampleSelective(@Param("example") GroceriesShopExample paramGroceriesShopExample, @Param("selective") GroceriesShop.Column... paramVarArgs);

    public abstract List<GroceriesShop> selectByExample(GroceriesShopExample paramGroceriesShopExample);

    public abstract GroceriesShop selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") GroceriesShop.Column... paramVarArgs);

    public abstract GroceriesShop selectByPrimaryKey(Integer paramInteger);

    public abstract GroceriesShop selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") GroceriesShop paramGroceriesShop, @Param("example") GroceriesShopExample paramGroceriesShopExample);

    public abstract int updateByExample(@Param("record") GroceriesShop paramGroceriesShop, @Param("example") GroceriesShopExample paramGroceriesShopExample);

    public abstract int updateByPrimaryKeySelective(GroceriesShop paramGroceriesShop);

    public abstract int updateByPrimaryKey(GroceriesShop paramGroceriesShop);

    public abstract int logicalDeleteByExample(@Param("example") GroceriesShopExample paramGroceriesShopExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\GroceriesShopMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */