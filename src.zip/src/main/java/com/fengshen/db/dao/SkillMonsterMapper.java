package com.fengshen.db.dao;

import com.fengshen.db.domain.SkillMonster;
import com.fengshen.db.domain.SkillMonster.Column;
import com.fengshen.db.domain.example.SkillMonsterExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface SkillMonsterMapper {
    public abstract long countByExample(SkillMonsterExample paramSkillMonsterExample);

    public abstract int deleteByExample(SkillMonsterExample paramSkillMonsterExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(SkillMonster paramSkillMonster);

    public abstract int insertSelective(SkillMonster paramSkillMonster);

    public abstract SkillMonster selectOneByExample(SkillMonsterExample paramSkillMonsterExample);

    public abstract SkillMonster selectOneByExampleSelective(@Param("example") SkillMonsterExample paramSkillMonsterExample, @Param("selective") SkillMonster.Column... paramVarArgs);

    public abstract List<SkillMonster> selectByExampleSelective(@Param("example") SkillMonsterExample paramSkillMonsterExample, @Param("selective") SkillMonster.Column... paramVarArgs);

    public abstract List<SkillMonster> selectByExample(SkillMonsterExample paramSkillMonsterExample);

    public abstract SkillMonster selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") SkillMonster.Column... paramVarArgs);

    public abstract SkillMonster selectByPrimaryKey(Integer paramInteger);

    public abstract SkillMonster selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") SkillMonster paramSkillMonster, @Param("example") SkillMonsterExample paramSkillMonsterExample);

    public abstract int updateByExample(@Param("record") SkillMonster paramSkillMonster, @Param("example") SkillMonsterExample paramSkillMonsterExample);

    public abstract int updateByPrimaryKeySelective(SkillMonster paramSkillMonster);

    public abstract int updateByPrimaryKey(SkillMonster paramSkillMonster);

    public abstract int logicalDeleteByExample(@Param("example") SkillMonsterExample paramSkillMonsterExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\SkillMonsterMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */