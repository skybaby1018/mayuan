package com.fengshen.db.dao;

import com.fengshen.db.domain.ChargePoint;
import com.fengshen.db.domain.ChargePointExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface ChargePointMapper {
    long countByExample(ChargePointExample paramChargePointExample);

    int deleteByExample(ChargePointExample paramChargePointExample);

    int deleteByPrimaryKey(Integer paramInteger);

    int insert(ChargePoint paramChargePoint);

    int insertSelective(ChargePoint paramChargePoint);

    List<ChargePoint> selectByExample(ChargePointExample paramChargePointExample);

    ChargePoint selectByPrimaryKey(Integer paramInteger);

    int updateByExampleSelective(@Param("record") ChargePoint paramChargePoint, @Param("example") ChargePointExample paramChargePointExample);

    int updateByExample(@Param("record") ChargePoint paramChargePoint, @Param("example") ChargePointExample paramChargePointExample);

    int updateByPrimaryKeySelective(ChargePoint paramChargePoint);

    int updateByPrimaryKey(ChargePoint paramChargePoint);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ChargePointMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */