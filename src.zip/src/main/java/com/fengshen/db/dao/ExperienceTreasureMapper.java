package com.fengshen.db.dao;

import com.fengshen.db.domain.ExperienceTreasure;
import com.fengshen.db.domain.ExperienceTreasure.Column;
import com.fengshen.db.domain.example.ExperienceTreasureExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ExperienceTreasureMapper {
    public abstract long countByExample(ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract int deleteByExample(ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(ExperienceTreasure paramExperienceTreasure);

    public abstract int insertSelective(ExperienceTreasure paramExperienceTreasure);

    public abstract ExperienceTreasure selectOneByExample(ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract ExperienceTreasure selectOneByExampleSelective(@Param("example") ExperienceTreasureExample paramExperienceTreasureExample, @Param("selective") ExperienceTreasure.Column... paramVarArgs);

    public abstract List<ExperienceTreasure> selectByExampleSelective(@Param("example") ExperienceTreasureExample paramExperienceTreasureExample, @Param("selective") ExperienceTreasure.Column... paramVarArgs);

    public abstract List<ExperienceTreasure> selectByExample(ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract ExperienceTreasure selectByPrimaryKeySelective(@Param("attrib") Integer paramInteger, @Param("selective") ExperienceTreasure.Column... paramVarArgs);

    public abstract ExperienceTreasure selectByPrimaryKey(Integer paramInteger);

    public abstract ExperienceTreasure selectByPrimaryKeyWithLogicalDelete(@Param("attrib") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") ExperienceTreasure paramExperienceTreasure, @Param("example") ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract int updateByExample(@Param("record") ExperienceTreasure paramExperienceTreasure, @Param("example") ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract int updateByPrimaryKeySelective(ExperienceTreasure paramExperienceTreasure);

    public abstract int updateByPrimaryKey(ExperienceTreasure paramExperienceTreasure);

    public abstract int logicalDeleteByExample(@Param("example") ExperienceTreasureExample paramExperienceTreasureExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ExperienceTreasureMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */