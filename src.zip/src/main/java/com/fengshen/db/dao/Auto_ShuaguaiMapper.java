package com.fengshen.db.dao;

import com.fengshen.server.domain.Auto_Shuaguai;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface Auto_ShuaguaiMapper {
    @Select({"select * from auto_shuaguai"})
    List<Auto_Shuaguai> getAuto_Shuaguais();

    @Insert({"insert into auto_shuaguai(name,`type`,icon,content,btns,guaiwus,reward,mapid,mapname,xys,resttime,pklevel,pkdaohang)values(#{name},#{type},#{icon},#{content},#{btns},#{guaiwus},#{reward},#{mapid},#{mapname},#{xys},#{resttime},#{pklevel},#{pkdaohang})"})
    Integer addBoss(final Map<String, String> params);

    @Update({"update auto_shuaguai set name = #{name},`type`=#{type},icon = #{icon},content=#{content},btns = #{btns},guaiwus=#{guaiwus},reward=#{reward},mapid=#{mapid},mapname=#{mapname},xys=#{xys},resttime=#{resttime},pklevel=#{pklevel},pkdaohang=#{pkdaohang}where id = #{id}"})
    Integer editBoss(final Map<String, String> params);

    @Delete({"delete from auto_shuaguai where id = #{id}"})
    Integer delBoss(final Map<String, String> params);

    @Select({"<script>select * from auto_shuaguai <if test='name !=null and name !=&apos;&apos;'> where `name` like concat('%',#{name},'%') </if>order by id desc</script>"})
    List<Auto_Shuaguai> getAuto_ShuaguaisConfig(final Map<String, String> params);

    @Select({"select * from auto_shuaguai where id = #{id}"})
    Auto_Shuaguai getAuto_ShuaguaiById(final Integer id);
}
