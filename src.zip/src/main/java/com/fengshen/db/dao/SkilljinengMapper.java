package com.fengshen.db.dao;

import com.fengshen.db.domain.Skilljineng;
import com.fengshen.db.domain.Skilljineng.Column;
import com.fengshen.db.domain.example.SkilljinengExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface SkilljinengMapper {
    public abstract long countByExample(SkilljinengExample paramSkilljinengExample);

    public abstract int deleteByExample(SkilljinengExample paramSkilljinengExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Skilljineng paramSkilljineng);

    public abstract int insertSelective(Skilljineng paramSkilljineng);

    public abstract Skilljineng selectOneByExample(SkilljinengExample paramSkilljinengExample);

    public abstract Skilljineng selectOneByExampleSelective(@Param("example") SkilljinengExample paramSkilljinengExample, @Param("selective") Skilljineng.Column... paramVarArgs);

    public abstract List<Skilljineng> selectByExampleSelective(@Param("example") SkilljinengExample paramSkilljinengExample, @Param("selective") Skilljineng.Column... paramVarArgs);

    public abstract List<Skilljineng> selectByExample(SkilljinengExample paramSkilljinengExample);

    public abstract Skilljineng selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Skilljineng.Column... paramVarArgs);

    public abstract Skilljineng selectByPrimaryKey(Integer paramInteger);

    public abstract Skilljineng selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Skilljineng paramSkilljineng, @Param("example") SkilljinengExample paramSkilljinengExample);

    public abstract int updateByExample(@Param("record") Skilljineng paramSkilljineng, @Param("example") SkilljinengExample paramSkilljinengExample);

    public abstract int updateByPrimaryKeySelective(Skilljineng paramSkilljineng);

    public abstract int updateByPrimaryKey(Skilljineng paramSkilljineng);

    public abstract int logicalDeleteByExample(@Param("example") SkilljinengExample paramSkilljinengExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\SkilljinengMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */