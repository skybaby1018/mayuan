package com.fengshen.db.dao;

import java.util.List;
import java.util.Map;

public abstract interface StatMapper {
    public abstract List<Map> statUser();

    public abstract List<Map> statOrder();

    public abstract List<Map> statGoods();
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\StatMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */