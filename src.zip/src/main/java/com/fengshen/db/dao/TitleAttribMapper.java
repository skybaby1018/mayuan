package com.fengshen.db.dao;

import com.fengshen.db.domain.TitleAttrib;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TitleAttribMapper {
    @Select({"select * from title_attrib where title = #{title}"})
    TitleAttrib getTitleAttrib(final String name);

    @Select({"select id,title name,attribs from title_attrib"})
    List<TitleAttrib> getAllTitleAttribs();
}
