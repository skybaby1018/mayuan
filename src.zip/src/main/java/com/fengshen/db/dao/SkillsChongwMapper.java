package com.fengshen.db.dao;

import com.fengshen.db.domain.SkillsChongw;
import com.fengshen.db.domain.SkillsChongw.Column;
import com.fengshen.db.domain.example.SkillsChongwExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface SkillsChongwMapper {
    public abstract long countByExample(SkillsChongwExample paramSkillsChongwExample);

    public abstract int deleteByExample(SkillsChongwExample paramSkillsChongwExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(SkillsChongw paramSkillsChongw);

    public abstract int insertSelective(SkillsChongw paramSkillsChongw);

    public abstract SkillsChongw selectOneByExample(SkillsChongwExample paramSkillsChongwExample);

    public abstract SkillsChongw selectOneByExampleSelective(@Param("example") SkillsChongwExample paramSkillsChongwExample, @Param("selective") SkillsChongw.Column... paramVarArgs);

    public abstract List<SkillsChongw> selectByExampleSelective(@Param("example") SkillsChongwExample paramSkillsChongwExample, @Param("selective") SkillsChongw.Column... paramVarArgs);

    public abstract List<SkillsChongw> selectByExample(SkillsChongwExample paramSkillsChongwExample);

    public abstract SkillsChongw selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") SkillsChongw.Column... paramVarArgs);

    public abstract SkillsChongw selectByPrimaryKey(Integer paramInteger);

    public abstract SkillsChongw selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") SkillsChongw paramSkillsChongw, @Param("example") SkillsChongwExample paramSkillsChongwExample);

    public abstract int updateByExample(@Param("record") SkillsChongw paramSkillsChongw, @Param("example") SkillsChongwExample paramSkillsChongwExample);

    public abstract int updateByPrimaryKeySelective(SkillsChongw paramSkillsChongw);

    public abstract int updateByPrimaryKey(SkillsChongw paramSkillsChongw);

    public abstract int logicalDeleteByExample(@Param("example") SkillsChongwExample paramSkillsChongwExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\SkillsChongwMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */