package com.fengshen.db.dao.custom;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public abstract interface CustomDailiMapper {
    @Select({"select `code`,COUNT(*) as num from accounts WHERE `code` LIKE CONCAT(#{name},'%') group by `code` ;"})
    public abstract List<Map> selectCount(@Param("name") String paramString);

    @Select({"select `code`,SUM(money) as num from charge WHERE `code` LIKE CONCAT(#{name},'%') and DATE(add_time) = DATE(CURDATE()-#{day})  group by `code` ;"})
    public abstract List<Map> selectMoney(@Param("name") String paramString, @Param("day") int paramInt);

    @Select({"select COUNT(*) as num from accounts WHERE `CODE` LIKE CONCAT(#{name},'%') group by `code`;"})
    public abstract List<Map> selectAccount(@Param("name") String paramString);
}