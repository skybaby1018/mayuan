package com.fengshen.db.dao;

import com.fengshen.db.domain.Pet;
import com.fengshen.db.domain.Pet.Column;
import com.fengshen.db.domain.example.PetExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface PetMapper {
    public abstract long countByExample(PetExample paramPetExample);

    public abstract int deleteByExample(PetExample paramPetExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Pet paramPet);

    public abstract int insertSelective(Pet paramPet);

    public abstract Pet selectOneByExample(PetExample paramPetExample);

    public abstract Pet selectOneByExampleSelective(@Param("example") PetExample paramPetExample, @Param("selective") Pet.Column... paramVarArgs);

    public abstract List<Pet> selectByExampleSelective(@Param("example") PetExample paramPetExample, @Param("selective") Pet.Column... paramVarArgs);

    public abstract List<Pet> selectByExample(PetExample paramPetExample);

    public abstract Pet selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Pet.Column... paramVarArgs);

    public abstract Pet selectByPrimaryKey(Integer paramInteger);

    public abstract Pet selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Pet paramPet, @Param("example") PetExample paramPetExample);

    public abstract int updateByExample(@Param("record") Pet paramPet, @Param("example") PetExample paramPetExample);

    public abstract int updateByPrimaryKeySelective(Pet paramPet);

    public abstract int updateByPrimaryKey(Pet paramPet);

    public abstract int logicalDeleteByExample(@Param("example") PetExample paramPetExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\PetMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */