package com.fengshen.db.dao;

import com.fengshen.db.domain.ZhuangbeiInfo;
import com.fengshen.db.domain.ZhuangbeiInfo.Column;
import com.fengshen.db.domain.example.ZhuangbeiInfoExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ZhuangbeiInfoMapper {
    public abstract long countByExample(ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract int deleteByExample(ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(ZhuangbeiInfo paramZhuangbeiInfo);

    public abstract int insertSelective(ZhuangbeiInfo paramZhuangbeiInfo);

    public abstract ZhuangbeiInfo selectOneByExample(ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract ZhuangbeiInfo selectOneByExampleSelective(@Param("example") ZhuangbeiInfoExample paramZhuangbeiInfoExample, @Param("selective") ZhuangbeiInfo.Column... paramVarArgs);

    public abstract List<ZhuangbeiInfo> selectByExampleSelective(@Param("example") ZhuangbeiInfoExample paramZhuangbeiInfoExample, @Param("selective") ZhuangbeiInfo.Column... paramVarArgs);

    public abstract List<ZhuangbeiInfo> selectByExample(ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract ZhuangbeiInfo selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") ZhuangbeiInfo.Column... paramVarArgs);

    public abstract ZhuangbeiInfo selectByPrimaryKey(Integer paramInteger);

    public abstract ZhuangbeiInfo selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") ZhuangbeiInfo paramZhuangbeiInfo, @Param("example") ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract int updateByExample(@Param("record") ZhuangbeiInfo paramZhuangbeiInfo, @Param("example") ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract int updateByPrimaryKeySelective(ZhuangbeiInfo paramZhuangbeiInfo);

    public abstract int updateByPrimaryKey(ZhuangbeiInfo paramZhuangbeiInfo);

    public abstract int logicalDeleteByExample(@Param("example") ZhuangbeiInfoExample paramZhuangbeiInfoExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ZhuangbeiInfoMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */