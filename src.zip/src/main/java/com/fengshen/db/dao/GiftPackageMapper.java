package com.fengshen.db.dao;

import com.fengshen.db.domain.GiftPackage;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface GiftPackageMapper {
    @Select({"select * from gift_package"})
    List<GiftPackage> getGiftPackages();

    @Select({"select * from gift_package where name = #{name}"})
    GiftPackage getGiftPackByName(final String name);

    @Update({"update gift_package set config = #{config} where name = #{name}"})
    Integer editGiftPackage(@Param("name") final String name, @Param("config") final String config);
}
