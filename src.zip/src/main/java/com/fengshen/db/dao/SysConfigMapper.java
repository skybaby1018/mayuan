package com.fengshen.db.dao;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import com.fengshen.db.domain.SysConfig;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface SysConfigMapper {
    @Select({"select * from sys_config where parentKey = #{parentKey}"})
    List<SysConfig> getSysConfigByParentKey(final String parentKey);

    @Select({"<script>select * from sys_config where 1 = 1 <if test='parentKey !=null and parentKey !=&apos;&apos;'>and parentKey=#{parentKey} </if></script>"})
    List<SysConfig> getSysConfigs(final Map<String, String> params);

    @Update({"update sys_config set value = #{value} where id = #{id}"})
    Integer editSys(final Map<String, String> params);
}
