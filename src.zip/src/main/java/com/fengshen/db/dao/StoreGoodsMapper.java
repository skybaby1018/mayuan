package com.fengshen.db.dao;

import com.fengshen.db.domain.StoreGoods;
import com.fengshen.db.domain.StoreGoods.Column;
import com.fengshen.db.domain.example.StoreGoodsExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface StoreGoodsMapper {
    public abstract long countByExample(StoreGoodsExample paramStoreGoodsExample);

    public abstract int deleteByExample(StoreGoodsExample paramStoreGoodsExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(StoreGoods paramStoreGoods);

    public abstract int insertSelective(StoreGoods paramStoreGoods);

    public abstract StoreGoods selectOneByExample(StoreGoodsExample paramStoreGoodsExample);

    public abstract StoreGoods selectOneByExampleSelective(@Param("example") StoreGoodsExample paramStoreGoodsExample, @Param("selective") StoreGoods.Column... paramVarArgs);

    public abstract List<StoreGoods> selectByExampleSelective(@Param("example") StoreGoodsExample paramStoreGoodsExample, @Param("selective") StoreGoods.Column... paramVarArgs);

    public abstract List<StoreGoods> selectByExample(StoreGoodsExample paramStoreGoodsExample);

    public abstract StoreGoods selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") StoreGoods.Column... paramVarArgs);

    public abstract StoreGoods selectByPrimaryKey(Integer paramInteger);

    public abstract StoreGoods selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") StoreGoods paramStoreGoods, @Param("example") StoreGoodsExample paramStoreGoodsExample);

    public abstract int updateByExample(@Param("record") StoreGoods paramStoreGoods, @Param("example") StoreGoodsExample paramStoreGoodsExample);

    public abstract int updateByPrimaryKeySelective(StoreGoods paramStoreGoods);

    public abstract int updateByPrimaryKey(StoreGoods paramStoreGoods);

    public abstract int logicalDeleteByExample(@Param("example") StoreGoodsExample paramStoreGoodsExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\StoreGoodsMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */