package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.ChargeRank;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChargeRankMapper extends BaseCustomMapper<ChargeRank> {

    List<ChargeRank> queryChargeRankList();

    ChargeRank queryByCharaId(@Param("charaId") int charaId);
}
