package com.fengshen.db.dao;

import com.fengshen.db.domain.Shuxingduiying;
import com.fengshen.db.domain.Shuxingduiying.Column;
import com.fengshen.db.domain.example.ShuxingduiyingExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ShuxingduiyingMapper {
    public abstract long countByExample(ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract int deleteByExample(ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Shuxingduiying paramShuxingduiying);

    public abstract int insertSelective(Shuxingduiying paramShuxingduiying);

    public abstract Shuxingduiying selectOneByExample(ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract Shuxingduiying selectOneByExampleSelective(@Param("example") ShuxingduiyingExample paramShuxingduiyingExample, @Param("selective") Shuxingduiying.Column... paramVarArgs);

    public abstract List<Shuxingduiying> selectByExampleSelective(@Param("example") ShuxingduiyingExample paramShuxingduiyingExample, @Param("selective") Shuxingduiying.Column... paramVarArgs);

    public abstract List<Shuxingduiying> selectByExample(ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract Shuxingduiying selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Shuxingduiying.Column... paramVarArgs);

    public abstract Shuxingduiying selectByPrimaryKey(Integer paramInteger);

    public abstract Shuxingduiying selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Shuxingduiying paramShuxingduiying, @Param("example") ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract int updateByExample(@Param("record") Shuxingduiying paramShuxingduiying, @Param("example") ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract int updateByPrimaryKeySelective(Shuxingduiying paramShuxingduiying);

    public abstract int updateByPrimaryKey(Shuxingduiying paramShuxingduiying);

    public abstract int logicalDeleteByExample(@Param("example") ShuxingduiyingExample paramShuxingduiyingExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ShuxingduiyingMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */