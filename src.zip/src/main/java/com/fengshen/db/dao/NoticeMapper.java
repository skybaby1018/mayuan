package com.fengshen.db.dao;

import com.fengshen.db.domain.Notice;
import com.fengshen.db.domain.Notice.Column;
import com.fengshen.db.domain.example.NoticeExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface NoticeMapper {
    public abstract long countByExample(NoticeExample paramNoticeExample);

    public abstract int deleteByExample(NoticeExample paramNoticeExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Notice paramNotice);

    public abstract int insertSelective(Notice paramNotice);

    public abstract Notice selectOneByExample(NoticeExample paramNoticeExample);

    public abstract Notice selectOneByExampleSelective(@Param("example") NoticeExample paramNoticeExample, @Param("selective") Notice.Column... paramVarArgs);

    public abstract List<Notice> selectByExampleSelective(@Param("example") NoticeExample paramNoticeExample, @Param("selective") Notice.Column... paramVarArgs);

    public abstract List<Notice> selectByExample(NoticeExample paramNoticeExample);

    public abstract Notice selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Notice.Column... paramVarArgs);

    public abstract Notice selectByPrimaryKey(Integer paramInteger);

    public abstract Notice selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Notice paramNotice, @Param("example") NoticeExample paramNoticeExample);

    public abstract int updateByExample(@Param("record") Notice paramNotice, @Param("example") NoticeExample paramNoticeExample);

    public abstract int updateByPrimaryKeySelective(Notice paramNotice);

    public abstract int updateByPrimaryKey(Notice paramNotice);

    public abstract int logicalDeleteByExample(@Param("example") NoticeExample paramNoticeExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\NoticeMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */