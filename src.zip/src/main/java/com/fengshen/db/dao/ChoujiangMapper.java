package com.fengshen.db.dao;

import com.fengshen.db.domain.Choujiang;
import com.fengshen.db.domain.Choujiang.Column;
import com.fengshen.db.domain.example.ChoujiangExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ChoujiangMapper {
    public abstract long countByExample(ChoujiangExample paramChoujiangExample);

    public abstract int deleteByExample(ChoujiangExample paramChoujiangExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Choujiang paramChoujiang);

    public abstract int insertSelective(Choujiang paramChoujiang);

    public abstract Choujiang selectOneByExample(ChoujiangExample paramChoujiangExample);

    public abstract Choujiang selectOneByExampleSelective(@Param("example") ChoujiangExample paramChoujiangExample, @Param("selective") Choujiang.Column... paramVarArgs);

    public abstract List<Choujiang> selectByExampleSelective(@Param("example") ChoujiangExample paramChoujiangExample, @Param("selective") Choujiang.Column... paramVarArgs);

    public abstract List<Choujiang> selectByExample(ChoujiangExample paramChoujiangExample);

    public abstract Choujiang selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Choujiang.Column... paramVarArgs);

    public abstract Choujiang selectByPrimaryKey(Integer paramInteger);

    public abstract Choujiang selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Choujiang paramChoujiang, @Param("example") ChoujiangExample paramChoujiangExample);

    public abstract int updateByExample(@Param("record") Choujiang paramChoujiang, @Param("example") ChoujiangExample paramChoujiangExample);

    public abstract int updateByPrimaryKeySelective(Choujiang paramChoujiang);

    public abstract int updateByPrimaryKey(Choujiang paramChoujiang);

    public abstract int logicalDeleteByExample(@Param("example") ChoujiangExample paramChoujiangExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ChoujiangMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */