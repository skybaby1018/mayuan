package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.ChangeCard;
import org.springframework.stereotype.Repository;

@Repository
public interface ChangeCardMapper extends BaseCustomMapper<ChangeCard> {
}