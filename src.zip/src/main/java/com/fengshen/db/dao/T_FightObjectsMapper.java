package com.fengshen.db.dao;

import com.fengshen.db.domain.example.T_FightObjectExample;
import com.fengshen.server.domain.T_FightObject;

import java.util.*;

import org.apache.ibatis.annotations.*;

@CacheNamespace
public interface T_FightObjectsMapper {
    long countByExample(final T_FightObjectExample paramT_FightObjectExample);

    int deleteByExample(final T_FightObjectExample paramT_FightObjectExample);

    int deleteByPrimaryKey(final Integer paramInteger);

    int insert(final T_FightObject paramT_FightObject);

    int insertSelective(final T_FightObject paramT_FightObject);

    List<T_FightObject> selectByExample(final T_FightObjectExample paramT_FightObjectExample);

    T_FightObject selectByPrimaryKey(final Integer paramInteger);

    int updateByExampleSelective(@Param("record") final T_FightObject paramT_FightObject, @Param("example") final T_FightObjectExample paramT_FightObjectExample);

    int updateByExample(@Param("record") final T_FightObject paramT_FightObject, @Param("example") final T_FightObjectExample paramT_FightObjectExample);

    int updateByPrimaryKeySelective(final T_FightObject paramT_FightObject);

    int updateByPrimaryKey(final T_FightObject paramT_FightObject);
}
