package com.fengshen.db.dao;

import com.fengshen.db.domain.Maps;
import com.fengshen.db.domain.Maps.Column;
import com.fengshen.db.domain.example.MapsExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface MapsMapper {
    public abstract long countByExample(MapsExample paramMapsExample);

    public abstract int deleteByExample(MapsExample paramMapsExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Maps paramMaps);

    public abstract int insertSelective(Maps paramMaps);

    public abstract Maps selectOneByExample(MapsExample paramMapsExample);

    public abstract Maps selectOneByExampleSelective(@Param("example") MapsExample paramMapsExample, @Param("selective") Maps.Column... paramVarArgs);

    public abstract List<Maps> selectByExampleSelective(@Param("example") MapsExample paramMapsExample, @Param("selective") Maps.Column... paramVarArgs);

    public abstract List<Maps> selectByExample(MapsExample paramMapsExample);

    public abstract Maps selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Maps.Column... paramVarArgs);

    public abstract Maps selectByPrimaryKey(Integer paramInteger);

    public abstract Maps selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Maps paramMaps, @Param("example") MapsExample paramMapsExample);

    public abstract int updateByExample(@Param("record") Maps paramMaps, @Param("example") MapsExample paramMapsExample);

    public abstract int updateByPrimaryKeySelective(Maps paramMaps);

    public abstract int updateByPrimaryKey(Maps paramMaps);

    public abstract int logicalDeleteByExample(@Param("example") MapsExample paramMapsExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\MapsMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */