package com.fengshen.db.dao;

import com.fengshen.db.domain.Title;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface TitleMapper {
    @Select({"select * from title where name = #{name}"})
    Title getTilteByName(final int name);

    @Select({"select * from title where event = #{event}"})
    List<Title> getTiltesByEvent(final String event);

    @Select({"select * from title where title = #{title}"})
    List<Title> getTiltesByTitle(final String title);

    @Select({"select * from title where des = #{des}"})
    Title getTitleBydes(final String des);

    @Insert({"insert into title(`name`,`event`,`title`,`des`) values(#{name},#{event},#{title},#{des})"})
    int addTitle(final Map<Object, Object> map);

    @Insert({"delete from title where title = #{title}"})
    int delByTitle(final String title);

    @Insert({"delete from title where event = #{event}"})
    int delByEvent(final String event);

    @Insert({"delete from title where des = #{des}"})
    int delByDes(final String des);
}
