package com.fengshen.db.dao;


import com.fengshen.server.domain.arena.LeiTaiRank;

import java.util.List;

public interface LeiTaiRankMapper {
    int insert(LeiTaiRank record);

    int delete();

    List<LeiTaiRank> selectAll();
}
