package com.fengshen.db.dao;

import com.fengshen.db.domain.ShowTasks;
import com.fengshen.db.domain.ShowTasks.Column;
import com.fengshen.db.domain.example.ShowTasksExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public abstract interface ShowTasksMapper {
    public abstract long countByExample(ShowTasksExample paramShowTasksExample);

    public abstract int deleteByExample(ShowTasksExample paramShowTasksExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(ShowTasks paramShowTasks);

    public abstract int insertSelective(ShowTasks paramShowTasks);

    public abstract ShowTasks selectOneByExample(ShowTasksExample paramShowTasksExample);

    public abstract ShowTasks selectOneByExampleSelective(@Param("example") ShowTasksExample paramShowTasksExample, @Param("selective") ShowTasks.Column... paramVarArgs);

    public abstract List<ShowTasks> selectByExampleSelective(@Param("example") ShowTasksExample paramShowTasksExample, @Param("selective") ShowTasks.Column... paramVarArgs);

    public abstract List<ShowTasks> selectByExample(ShowTasksExample paramShowTasksExample);

    public abstract ShowTasks selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") ShowTasks.Column... paramVarArgs);

    public abstract ShowTasks selectByPrimaryKey(Integer paramInteger);

    public abstract ShowTasks selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") ShowTasks paramShowTasks, @Param("example") ShowTasksExample paramShowTasksExample);

    public abstract int updateByExample(@Param("record") ShowTasks paramShowTasks, @Param("example") ShowTasksExample paramShowTasksExample);

    public abstract int updateByPrimaryKeySelective(ShowTasks paramShowTasks);

    public abstract int updateByPrimaryKey(ShowTasks paramShowTasks);

    public abstract int logicalDeleteByExample(@Param("example") ShowTasksExample paramShowTasksExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\dao\ShowTasksMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */