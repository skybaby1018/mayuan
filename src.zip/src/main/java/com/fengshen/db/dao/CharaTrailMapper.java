package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.CharaTrail;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface CharaTrailMapper
        extends BaseCustomMapper<CharaTrail> {
    public abstract Map<Object, Object> getCount(Map<String, Object> paramMap);
}