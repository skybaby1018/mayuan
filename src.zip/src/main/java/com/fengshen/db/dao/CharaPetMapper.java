package com.fengshen.db.dao;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.CharaPet;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public abstract interface CharaPetMapper
        extends BaseCustomMapper<CharaPet> {
    public abstract int updateBatch(List<CharaPet> paramList);

    public abstract int inserBatch(List<CharaPet> paramList);
}