package com.fengshen.db.auth;

import com.fengshen.db.domain.Daili;
import com.fengshen.db.domain.example.DailiExample;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DailiMapper {
    public abstract long countByExample(DailiExample paramDailiExample);

    public abstract int deleteByExample(DailiExample paramDailiExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Daili paramDaili);

    public abstract int insertSelective(Daili paramDaili);

    public abstract Daili selectOneByExample(DailiExample paramDailiExample);

    public abstract Daili selectOneByExampleSelective(@Param("example") DailiExample paramDailiExample, @Param("selective") Daili.Column... paramVarArgs);

    public abstract List<Daili> selectByExampleSelective(@Param("example") DailiExample paramDailiExample, @Param("selective") Daili.Column... paramVarArgs);

    public abstract List<Daili> selectByExample(DailiExample paramDailiExample);

    public abstract Daili selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Daili.Column... paramVarArgs);

    public abstract Daili selectByPrimaryKey(Integer paramInteger);

    public abstract Daili selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Daili paramDaili, @Param("example") DailiExample paramDailiExample);

    public abstract int updateByExample(@Param("record") Daili paramDaili, @Param("example") DailiExample paramDailiExample);

    public abstract int updateByPrimaryKeySelective(Daili paramDaili);

    public abstract int updateByPrimaryKey(Daili paramDaili);

    public abstract int logicalDeleteByExample(@Param("example") DailiExample paramDailiExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\auth\DailiMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */