package com.fengshen.db.auth;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.Accounts;
import org.springframework.stereotype.Repository;

@Repository
public  interface AccountsMapper extends BaseCustomMapper<Accounts> {
}