//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.auth;

import com.fengshen.db.base.BaseCustomMapper;
import com.fengshen.db.domain.BlackList;
import org.springframework.stereotype.Repository;

@Repository
public interface BlackListMapper extends BaseCustomMapper<BlackList> {
}
