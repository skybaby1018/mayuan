package com.fengshen.db.auth;

import com.fengshen.db.domain.Charge;
import com.fengshen.db.domain.example.ChargeExample;
import com.fengshen.db.vo.ChargeRankVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChargeMapper {
    public abstract long countByExample(ChargeExample paramChargeExample);

    public abstract int deleteByExample(ChargeExample paramChargeExample);

    public abstract int deleteByPrimaryKey(Integer paramInteger);

    public abstract int insert(Charge paramCharge);

    public abstract int insertSelective(Charge paramCharge);

    public abstract Charge selectOneByExample(ChargeExample paramChargeExample);

    public abstract Charge selectOneByExampleSelective(@Param("example") ChargeExample paramChargeExample, @Param("selective") Charge.Column... paramVarArgs);

    public abstract List<Charge> selectByExampleSelective(@Param("example") ChargeExample paramChargeExample, @Param("selective") Charge.Column... paramVarArgs);

    public abstract List<Charge> selectByExample(ChargeExample paramChargeExample);

    public abstract Charge selectByPrimaryKeySelective(@Param("id") Integer paramInteger, @Param("selective") Charge.Column... paramVarArgs);

    public abstract Charge selectByPrimaryKey(Integer paramInteger);

    public abstract Charge selectByPrimaryKeyWithLogicalDelete(@Param("id") Integer paramInteger, @Param("andLogicalDeleted") boolean paramBoolean);

    public abstract int updateByExampleSelective(@Param("record") Charge paramCharge, @Param("example") ChargeExample paramChargeExample);

    public abstract int updateByExample(@Param("record") Charge paramCharge, @Param("example") ChargeExample paramChargeExample);

    public abstract int updateByPrimaryKeySelective(Charge paramCharge);

    public abstract int updateByPrimaryKey(Charge paramCharge);

    public abstract int logicalDeleteByExample(@Param("example") ChargeExample paramChargeExample);

    public abstract int logicalDeleteByPrimaryKey(Integer paramInteger);

    public abstract List<ChargeRankVo> queryChargeTop10(@Param("serverId") String serverId);

    public abstract Charge queryChargeByFirst(@Param("accountName") String accountName, @Param("serverId") String serverId);
}