//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Maps;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseMapsVo {
    public Integer id;
    public String name;
    public Integer type;
    public Integer map;
    public Float dir;
    public Float x;
    public Float y;

    public BaseMapsVo() {
    }

    public BaseMapsVo(final Maps vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.name = vo.getName();
            this.type = vo.getType();
            this.map = vo.getMap();
            this.dir = vo.getDir();
            this.x = vo.getX();
            this.y = vo.getY();
        }
    }

    public static final BaseMapsVo t(final Maps vo) {
        return new BaseMapsVo(vo);
    }

    public static final List<BaseMapsVo> t(final List<Maps> list) {
        List<BaseMapsVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Maps temp = (Maps) var3.next();
            listVo.add(new BaseMapsVo(temp));
        }

        return listVo;
    }
}
