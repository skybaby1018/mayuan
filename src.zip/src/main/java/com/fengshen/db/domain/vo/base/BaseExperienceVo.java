//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Experience;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseExperienceVo {
    public Integer attrib;
    public Integer maxLevel;

    public BaseExperienceVo() {
    }

    public BaseExperienceVo(final Experience vo) {
        if (vo != null) {
            this.attrib = vo.getAttrib();
            this.maxLevel = vo.getMaxLevel();
        }
    }

    public static final BaseExperienceVo t(final Experience vo) {
        return new BaseExperienceVo(vo);
    }

    public static final List<BaseExperienceVo> t(final List<Experience> list) {
        List<BaseExperienceVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Experience temp = (Experience) var3.next();
            listVo.add(new BaseExperienceVo(temp));
        }

        return listVo;
    }
}
