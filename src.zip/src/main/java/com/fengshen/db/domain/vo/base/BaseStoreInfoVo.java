//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.StoreInfo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseStoreInfoVo {
    public Integer id;
    public String quality;
    public Integer value;
    public Integer type;
    public String name;
    public Integer totalScore;
    public Integer recognizeRecognized;
    public Integer rebuildLevel;
    public Integer silverCoin;

    public BaseStoreInfoVo() {
    }

    public BaseStoreInfoVo(final StoreInfo vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.quality = vo.getQuality();
            this.value = vo.getValue();
            this.type = vo.getType();
            this.name = vo.getName();
            this.totalScore = vo.getTotalScore();
            this.recognizeRecognized = vo.getRecognizeRecognized();
            this.rebuildLevel = vo.getRebuildLevel();
            this.silverCoin = vo.getSilverCoin();
        }
    }

    public static final BaseStoreInfoVo t(final StoreInfo vo) {
        return new BaseStoreInfoVo(vo);
    }

    public static final List<BaseStoreInfoVo> t(final List<StoreInfo> list) {
        List<BaseStoreInfoVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            StoreInfo temp = (StoreInfo) var3.next();
            listVo.add(new BaseStoreInfoVo(temp));
        }

        return listVo;
    }
}
