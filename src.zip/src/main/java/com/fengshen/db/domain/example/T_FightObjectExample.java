//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.domain.example;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class T_FightObjectExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<Criteria> oredCriteria = new ArrayList();

    public T_FightObjectExample() {
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        return new Criteria();
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(String condition, Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    public static class Criteria extends GeneratedCriteria {
        public Criteria() {
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new Criterion(condition));
            }
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new Criterion(condition, value));
            }
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            this.addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            this.addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            this.addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            this.addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            this.addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            this.addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            this.addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(Integer value) {
            this.addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(Integer value) {
            this.addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(Integer value) {
            this.addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(Integer value) {
            this.addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(Integer value) {
            this.addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<Integer> values) {
            this.addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<Integer> values) {
            this.addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(Integer value1, Integer value2) {
            this.addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(Integer value1, Integer value2) {
            this.addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            this.addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            this.addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            this.addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            this.addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            this.addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            this.addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            this.addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            this.addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            this.addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            this.addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            this.addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            this.addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            this.addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            this.addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andLifeIsNull() {
            this.addCriterion("life is null");
            return (Criteria) this;
        }

        public Criteria andLifeIsNotNull() {
            this.addCriterion("life is not null");
            return (Criteria) this;
        }

        public Criteria andLifeEqualTo(Integer value) {
            this.addCriterion("life =", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeNotEqualTo(Integer value) {
            this.addCriterion("life <>", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeGreaterThan(Integer value) {
            this.addCriterion("life >", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("life >=", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeLessThan(Integer value) {
            this.addCriterion("life <", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeLessThanOrEqualTo(Integer value) {
            this.addCriterion("life <=", value, "life");
            return (Criteria) this;
        }

        public Criteria andLifeIn(List<Integer> values) {
            this.addCriterion("life in", values, "life");
            return (Criteria) this;
        }

        public Criteria andLifeNotIn(List<Integer> values) {
            this.addCriterion("life not in", values, "life");
            return (Criteria) this;
        }

        public Criteria andLifeBetween(Integer value1, Integer value2) {
            this.addCriterion("life between", value1, value2, "life");
            return (Criteria) this;
        }

        public Criteria andLifeNotBetween(Integer value1, Integer value2) {
            this.addCriterion("life not between", value1, value2, "life");
            return (Criteria) this;
        }

        public Criteria andManaIsNull() {
            this.addCriterion("mana is null");
            return (Criteria) this;
        }

        public Criteria andManaIsNotNull() {
            this.addCriterion("mana is not null");
            return (Criteria) this;
        }

        public Criteria andManaEqualTo(Integer value) {
            this.addCriterion("mana =", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaNotEqualTo(Integer value) {
            this.addCriterion("mana <>", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaGreaterThan(Integer value) {
            this.addCriterion("mana >", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("mana >=", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaLessThan(Integer value) {
            this.addCriterion("mana <", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaLessThanOrEqualTo(Integer value) {
            this.addCriterion("mana <=", value, "mana");
            return (Criteria) this;
        }

        public Criteria andManaIn(List<Integer> values) {
            this.addCriterion("mana in", values, "mana");
            return (Criteria) this;
        }

        public Criteria andManaNotIn(List<Integer> values) {
            this.addCriterion("mana not in", values, "mana");
            return (Criteria) this;
        }

        public Criteria andManaBetween(Integer value1, Integer value2) {
            this.addCriterion("mana between", value1, value2, "mana");
            return (Criteria) this;
        }

        public Criteria andManaNotBetween(Integer value1, Integer value2) {
            this.addCriterion("mana not between", value1, value2, "mana");
            return (Criteria) this;
        }

        public Criteria andPhyAttackIsNull() {
            this.addCriterion("phy_attack is null");
            return (Criteria) this;
        }

        public Criteria andPhyAttackIsNotNull() {
            this.addCriterion("phy_attack is not null");
            return (Criteria) this;
        }

        public Criteria andPhyAttackEqualTo(Integer value) {
            this.addCriterion("phy_attack =", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackNotEqualTo(Integer value) {
            this.addCriterion("phy_attack <>", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackGreaterThan(Integer value) {
            this.addCriterion("phy_attack >", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("phy_attack >=", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackLessThan(Integer value) {
            this.addCriterion("phy_attack <", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackLessThanOrEqualTo(Integer value) {
            this.addCriterion("phy_attack <=", value, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackIn(List<Integer> values) {
            this.addCriterion("phy_attack in", values, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackNotIn(List<Integer> values) {
            this.addCriterion("phy_attack not in", values, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackBetween(Integer value1, Integer value2) {
            this.addCriterion("phy_attack between", value1, value2, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andPhyAttackNotBetween(Integer value1, Integer value2) {
            this.addCriterion("phy_attack not between", value1, value2, "phyAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackIsNull() {
            this.addCriterion("mag_attack is null");
            return (Criteria) this;
        }

        public Criteria andMagAttackIsNotNull() {
            this.addCriterion("mag_attack is not null");
            return (Criteria) this;
        }

        public Criteria andMagAttackEqualTo(Integer value) {
            this.addCriterion("mag_attack =", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackNotEqualTo(Integer value) {
            this.addCriterion("mag_attack <>", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackGreaterThan(Integer value) {
            this.addCriterion("mag_attack >", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("mag_attack >=", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackLessThan(Integer value) {
            this.addCriterion("mag_attack <", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackLessThanOrEqualTo(Integer value) {
            this.addCriterion("mag_attack <=", value, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackIn(List<Integer> values) {
            this.addCriterion("mag_attack in", values, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackNotIn(List<Integer> values) {
            this.addCriterion("mag_attack not in", values, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackBetween(Integer value1, Integer value2) {
            this.addCriterion("mag_attack between", value1, value2, "magAttack");
            return (Criteria) this;
        }

        public Criteria andMagAttackNotBetween(Integer value1, Integer value2) {
            this.addCriterion("mag_attack not between", value1, value2, "magAttack");
            return (Criteria) this;
        }

        public Criteria andPolarIsNull() {
            this.addCriterion("polar is null");
            return (Criteria) this;
        }

        public Criteria andPolarIsNotNull() {
            this.addCriterion("polar is not null");
            return (Criteria) this;
        }

        public Criteria andPolarEqualTo(String value) {
            this.addCriterion("polar =", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarNotEqualTo(String value) {
            this.addCriterion("polar <>", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarGreaterThan(String value) {
            this.addCriterion("polar >", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarGreaterThanOrEqualTo(String value) {
            this.addCriterion("polar >=", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarLessThan(String value) {
            this.addCriterion("polar <", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarLessThanOrEqualTo(String value) {
            this.addCriterion("polar <=", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarLike(String value) {
            this.addCriterion("polar like", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarNotLike(String value) {
            this.addCriterion("polar not like", value, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarIn(List<String> values) {
            this.addCriterion("polar in", values, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarNotIn(List<String> values) {
            this.addCriterion("polar not in", values, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarBetween(String value1, String value2) {
            this.addCriterion("polar between", value1, value2, "polar");
            return (Criteria) this;
        }

        public Criteria andPolarNotBetween(String value1, String value2) {
            this.addCriterion("polar not between", value1, value2, "polar");
            return (Criteria) this;
        }

        public Criteria andSpeedIsNull() {
            this.addCriterion("speed is null");
            return (Criteria) this;
        }

        public Criteria andSpeedIsNotNull() {
            this.addCriterion("speed is not null");
            return (Criteria) this;
        }

        public Criteria andSpeedEqualTo(Integer value) {
            this.addCriterion("speed =", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedNotEqualTo(Integer value) {
            this.addCriterion("speed <>", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedGreaterThan(Integer value) {
            this.addCriterion("speed >", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("speed >=", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedLessThan(Integer value) {
            this.addCriterion("speed <", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedLessThanOrEqualTo(Integer value) {
            this.addCriterion("speed <=", value, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedIn(List<Integer> values) {
            this.addCriterion("speed in", values, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedNotIn(List<Integer> values) {
            this.addCriterion("speed not in", values, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedBetween(Integer value1, Integer value2) {
            this.addCriterion("speed between", value1, value2, "speed");
            return (Criteria) this;
        }

        public Criteria andSpeedNotBetween(Integer value1, Integer value2) {
            this.addCriterion("speed not between", value1, value2, "speed");
            return (Criteria) this;
        }

        public Criteria andDefIsNull() {
            this.addCriterion("def is null");
            return (Criteria) this;
        }

        public Criteria andDefIsNotNull() {
            this.addCriterion("def is not null");
            return (Criteria) this;
        }

        public Criteria andDefEqualTo(Integer value) {
            this.addCriterion("def =", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefNotEqualTo(Integer value) {
            this.addCriterion("def <>", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefGreaterThan(Integer value) {
            this.addCriterion("def >", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("def >=", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefLessThan(Integer value) {
            this.addCriterion("def <", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefLessThanOrEqualTo(Integer value) {
            this.addCriterion("def <=", value, "def");
            return (Criteria) this;
        }

        public Criteria andDefIn(List<Integer> values) {
            this.addCriterion("def in", values, "def");
            return (Criteria) this;
        }

        public Criteria andDefNotIn(List<Integer> values) {
            this.addCriterion("def not in", values, "def");
            return (Criteria) this;
        }

        public Criteria andDefBetween(Integer value1, Integer value2) {
            this.addCriterion("def between", value1, value2, "def");
            return (Criteria) this;
        }

        public Criteria andDefNotBetween(Integer value1, Integer value2) {
            this.addCriterion("def not between", value1, value2, "def");
            return (Criteria) this;
        }

        public Criteria andIconIsNull() {
            this.addCriterion("icon is null");
            return (Criteria) this;
        }

        public Criteria andIconIsNotNull() {
            this.addCriterion("icon is not null");
            return (Criteria) this;
        }

        public Criteria andIconEqualTo(Integer value) {
            this.addCriterion("icon =", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconNotEqualTo(Integer value) {
            this.addCriterion("icon <>", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconGreaterThan(Integer value) {
            this.addCriterion("icon >", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("icon >=", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconLessThan(Integer value) {
            this.addCriterion("icon <", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconLessThanOrEqualTo(Integer value) {
            this.addCriterion("icon <=", value, "icon");
            return (Criteria) this;
        }

        public Criteria andIconIn(List<Integer> values) {
            this.addCriterion("icon in", values, "icon");
            return (Criteria) this;
        }

        public Criteria andIconNotIn(List<Integer> values) {
            this.addCriterion("icon not in", values, "icon");
            return (Criteria) this;
        }

        public Criteria andIconBetween(Integer value1, Integer value2) {
            this.addCriterion("icon between", value1, value2, "icon");
            return (Criteria) this;
        }

        public Criteria andIconNotBetween(Integer value1, Integer value2) {
            this.addCriterion("icon not between", value1, value2, "icon");
            return (Criteria) this;
        }

        public Criteria andDaohangIsNull() {
            this.addCriterion("daohang is null");
            return (Criteria) this;
        }

        public Criteria andDaohangIsNotNull() {
            this.addCriterion("daohang is not null");
            return (Criteria) this;
        }

        public Criteria andDaohangEqualTo(Integer value) {
            this.addCriterion("daohang =", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangNotEqualTo(Integer value) {
            this.addCriterion("daohang <>", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangGreaterThan(Integer value) {
            this.addCriterion("daohang >", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("daohang >=", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangLessThan(Integer value) {
            this.addCriterion("daohang <", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangLessThanOrEqualTo(Integer value) {
            this.addCriterion("daohang <=", value, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangIn(List<Integer> values) {
            this.addCriterion("daohang in", values, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangNotIn(List<Integer> values) {
            this.addCriterion("daohang not in", values, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangBetween(Integer value1, Integer value2) {
            this.addCriterion("daohang between", value1, value2, "daohang");
            return (Criteria) this;
        }

        public Criteria andDaohangNotBetween(Integer value1, Integer value2) {
            this.addCriterion("daohang not between", value1, value2, "daohang");
            return (Criteria) this;
        }

        public Criteria andPetMartialIsNull() {
            this.addCriterion("pet_martial is null");
            return (Criteria) this;
        }

        public Criteria andPetMartialIsNotNull() {
            this.addCriterion("pet_martial is not null");
            return (Criteria) this;
        }

        public Criteria andPetMartialEqualTo(Integer value) {
            this.addCriterion("pet_martial =", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialNotEqualTo(Integer value) {
            this.addCriterion("pet_martial <>", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialGreaterThan(Integer value) {
            this.addCriterion("pet_martial >", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("pet_martial >=", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialLessThan(Integer value) {
            this.addCriterion("pet_martial <", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialLessThanOrEqualTo(Integer value) {
            this.addCriterion("pet_martial <=", value, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialIn(List<Integer> values) {
            this.addCriterion("pet_martial in", values, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialNotIn(List<Integer> values) {
            this.addCriterion("pet_martial not in", values, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialBetween(Integer value1, Integer value2) {
            this.addCriterion("pet_martial between", value1, value2, "petMartial");
            return (Criteria) this;
        }

        public Criteria andPetMartialNotBetween(Integer value1, Integer value2) {
            this.addCriterion("pet_martial not between", value1, value2, "petMartial");
            return (Criteria) this;
        }

        public Criteria andSkillIsNull() {
            this.addCriterion("skill is null");
            return (Criteria) this;
        }

        public Criteria andSkillIsNotNull() {
            this.addCriterion("skill is not null");
            return (Criteria) this;
        }

        public Criteria andSkillEqualTo(String value) {
            this.addCriterion("skill =", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillNotEqualTo(String value) {
            this.addCriterion("skill <>", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillGreaterThan(String value) {
            this.addCriterion("skill >", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillGreaterThanOrEqualTo(String value) {
            this.addCriterion("skill >=", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillLessThan(String value) {
            this.addCriterion("skill <", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillLessThanOrEqualTo(String value) {
            this.addCriterion("skill <=", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillLike(String value) {
            this.addCriterion("skill like", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillNotLike(String value) {
            this.addCriterion("skill not like", value, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillIn(List<String> values) {
            this.addCriterion("skill in", values, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillNotIn(List<String> values) {
            this.addCriterion("skill not in", values, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillBetween(String value1, String value2) {
            this.addCriterion("skill between", value1, value2, "skill");
            return (Criteria) this;
        }

        public Criteria andSkillNotBetween(String value1, String value2) {
            this.addCriterion("skill not between", value1, value2, "skill");
            return (Criteria) this;
        }

        public Criteria andPetTianshuIsNull() {
            this.addCriterion("pet_tianshu is null");
            return (Criteria) this;
        }

        public Criteria andPetTianshuIsNotNull() {
            this.addCriterion("pet_tianshu is not null");
            return (Criteria) this;
        }

        public Criteria andPetTianshuEqualTo(String value) {
            this.addCriterion("pet_tianshu =", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuNotEqualTo(String value) {
            this.addCriterion("pet_tianshu <>", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuGreaterThan(String value) {
            this.addCriterion("pet_tianshu >", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuGreaterThanOrEqualTo(String value) {
            this.addCriterion("pet_tianshu >=", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuLessThan(String value) {
            this.addCriterion("pet_tianshu <", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuLessThanOrEqualTo(String value) {
            this.addCriterion("pet_tianshu <=", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuLike(String value) {
            this.addCriterion("pet_tianshu like", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuNotLike(String value) {
            this.addCriterion("pet_tianshu not like", value, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuIn(List<String> values) {
            this.addCriterion("pet_tianshu in", values, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuNotIn(List<String> values) {
            this.addCriterion("pet_tianshu not in", values, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuBetween(String value1, String value2) {
            this.addCriterion("pet_tianshu between", value1, value2, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andPetTianshuNotBetween(String value1, String value2) {
            this.addCriterion("pet_tianshu not between", value1, value2, "petTianshu");
            return (Criteria) this;
        }

        public Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (Criteria) this;
        }

        public Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (Criteria) this;
        }

        public Criteria andAddTimeEqualTo(Date value) {
            this.addCriterion("add_time =", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotEqualTo(Date value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeGreaterThan(Date value) {
            this.addCriterion("add_time >", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeGreaterThanOrEqualTo(Date value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeLessThan(Date value) {
            this.addCriterion("add_time <", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeLessThanOrEqualTo(Date value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeIn(List<Date> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotIn(List<Date> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeBetween(Date value1, Date value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotBetween(Date value1, Date value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (Criteria) this;
        }

        public Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (Criteria) this;
        }

        public Criteria andDeletedEqualTo(Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotEqualTo(Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedGreaterThan(Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedGreaterThanOrEqualTo(Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedLessThan(Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedLessThanOrEqualTo(Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedIn(List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotIn(List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedBetween(Boolean value1, Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (Criteria) this;
        }

        public Criteria andDeletedNotBetween(Boolean value1, Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (Criteria) this;
        }
    }
}
