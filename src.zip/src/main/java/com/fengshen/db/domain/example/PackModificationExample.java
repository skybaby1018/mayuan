//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.PackModification.Column;
import com.fengshen.db.domain.PackModification.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PackModificationExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<PackModificationExample.Criteria> oredCriteria = new ArrayList();

    public PackModificationExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<PackModificationExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final PackModificationExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public PackModificationExample.Criteria or() {
        PackModificationExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public PackModificationExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public PackModificationExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public PackModificationExample.Criteria createCriteria() {
        PackModificationExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected PackModificationExample.Criteria createCriteriaInternal() {
        PackModificationExample.Criteria criteria = new PackModificationExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static PackModificationExample.Criteria newAndCreateCriteria() {
        PackModificationExample example = new PackModificationExample();
        return example.createCriteria();
    }

    public PackModificationExample when(final boolean condition, final PackModificationExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public PackModificationExample when(final boolean condition, final PackModificationExample.IExampleWhen then, final PackModificationExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends PackModificationExample.GeneratedCriteria {
        private PackModificationExample example;

        protected Criteria(final PackModificationExample example) {
            this.example = example;
        }

        public PackModificationExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public PackModificationExample.Criteria andIf(final boolean ifAdd, final PackModificationExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public PackModificationExample.Criteria when(final boolean condition, final PackModificationExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public PackModificationExample.Criteria when(final boolean condition, final PackModificationExample.ICriteriaWhen then, final PackModificationExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public PackModificationExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            PackModificationExample.Criteria add(final PackModificationExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<PackModificationExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<PackModificationExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<PackModificationExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new PackModificationExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new PackModificationExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new PackModificationExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public PackModificationExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasIsNull() {
            this.addCriterion("`alias` is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasIsNotNull() {
            this.addCriterion("`alias` is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasEqualTo(final String value) {
            this.addCriterion("`alias` =", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasEqualToColumn(final Column column) {
            this.addCriterion("`alias` = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasNotEqualTo(final String value) {
            this.addCriterion("`alias` <>", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasNotEqualToColumn(final Column column) {
            this.addCriterion("`alias` <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasGreaterThan(final String value) {
            this.addCriterion("`alias` >", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasGreaterThanColumn(final Column column) {
            this.addCriterion("`alias` > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`alias` >=", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`alias` >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasLessThan(final String value) {
            this.addCriterion("`alias` <", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasLessThanColumn(final Column column) {
            this.addCriterion("`alias` < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasLessThanOrEqualTo(final String value) {
            this.addCriterion("`alias` <=", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`alias` <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasLike(final String value) {
            this.addCriterion("`alias` like", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasNotLike(final String value) {
            this.addCriterion("`alias` not like", value, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasIn(final List<String> values) {
            this.addCriterion("`alias` in", values, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasNotIn(final List<String> values) {
            this.addCriterion("`alias` not in", values, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasBetween(final String value1, final String value2) {
            this.addCriterion("`alias` between", value1, value2, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAliasNotBetween(final String value1, final String value2) {
            this.addCriterion("`alias` not between", value1, value2, "alias");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeIsNull() {
            this.addCriterion("fasion_type is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeIsNotNull() {
            this.addCriterion("fasion_type is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeEqualTo(final String value) {
            this.addCriterion("fasion_type =", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeEqualToColumn(final Column column) {
            this.addCriterion("fasion_type = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeNotEqualTo(final String value) {
            this.addCriterion("fasion_type <>", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeNotEqualToColumn(final Column column) {
            this.addCriterion("fasion_type <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeGreaterThan(final String value) {
            this.addCriterion("fasion_type >", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeGreaterThanColumn(final Column column) {
            this.addCriterion("fasion_type > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("fasion_type >=", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("fasion_type >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeLessThan(final String value) {
            this.addCriterion("fasion_type <", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeLessThanColumn(final Column column) {
            this.addCriterion("fasion_type < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeLessThanOrEqualTo(final String value) {
            this.addCriterion("fasion_type <=", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("fasion_type <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeLike(final String value) {
            this.addCriterion("fasion_type like", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeNotLike(final String value) {
            this.addCriterion("fasion_type not like", value, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeIn(final List<String> values) {
            this.addCriterion("fasion_type in", values, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeNotIn(final List<String> values) {
            this.addCriterion("fasion_type not in", values, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeBetween(final String value1, final String value2) {
            this.addCriterion("fasion_type between", value1, value2, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFasionTypeNotBetween(final String value1, final String value2) {
            this.addCriterion("fasion_type not between", value1, value2, "fasionType");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrIsNull() {
            this.addCriterion("str is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrIsNotNull() {
            this.addCriterion("str is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrEqualTo(final String value) {
            this.addCriterion("str =", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrEqualToColumn(final Column column) {
            this.addCriterion("str = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrNotEqualTo(final String value) {
            this.addCriterion("str <>", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrNotEqualToColumn(final Column column) {
            this.addCriterion("str <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrGreaterThan(final String value) {
            this.addCriterion("str >", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrGreaterThanColumn(final Column column) {
            this.addCriterion("str > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrGreaterThanOrEqualTo(final String value) {
            this.addCriterion("str >=", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("str >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrLessThan(final String value) {
            this.addCriterion("str <", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrLessThanColumn(final Column column) {
            this.addCriterion("str < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrLessThanOrEqualTo(final String value) {
            this.addCriterion("str <=", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("str <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrLike(final String value) {
            this.addCriterion("str like", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrNotLike(final String value) {
            this.addCriterion("str not like", value, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrIn(final List<String> values) {
            this.addCriterion("str in", values, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrNotIn(final List<String> values) {
            this.addCriterion("str not in", values, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrBetween(final String value1, final String value2) {
            this.addCriterion("str between", value1, value2, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andStrNotBetween(final String value1, final String value2) {
            this.addCriterion("str not between", value1, value2, "str");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeEqualTo(final String value) {
            this.addCriterion("`type` =", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeNotEqualTo(final String value) {
            this.addCriterion("`type` <>", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeGreaterThan(final String value) {
            this.addCriterion("`type` >", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`type` >=", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeLessThan(final String value) {
            this.addCriterion("`type` <", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeLessThanOrEqualTo(final String value) {
            this.addCriterion("`type` <=", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeLike(final String value) {
            this.addCriterion("`type` like", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeNotLike(final String value) {
            this.addCriterion("`type` not like", value, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeIn(final List<String> values) {
            this.addCriterion("`type` in", values, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeNotIn(final List<String> values) {
            this.addCriterion("`type` not in", values, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeBetween(final String value1, final String value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andTypeNotBetween(final String value1, final String value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumIsNull() {
            this.addCriterion("food_num is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumIsNotNull() {
            this.addCriterion("food_num is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumEqualTo(final Integer value) {
            this.addCriterion("food_num =", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumEqualToColumn(final Column column) {
            this.addCriterion("food_num = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumNotEqualTo(final Integer value) {
            this.addCriterion("food_num <>", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumNotEqualToColumn(final Column column) {
            this.addCriterion("food_num <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumGreaterThan(final Integer value) {
            this.addCriterion("food_num >", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumGreaterThanColumn(final Column column) {
            this.addCriterion("food_num > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("food_num >=", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("food_num >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumLessThan(final Integer value) {
            this.addCriterion("food_num <", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumLessThanColumn(final Column column) {
            this.addCriterion("food_num < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumLessThanOrEqualTo(final Integer value) {
            this.addCriterion("food_num <=", value, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("food_num <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumIn(final List<Integer> values) {
            this.addCriterion("food_num in", values, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumNotIn(final List<Integer> values) {
            this.addCriterion("food_num not in", values, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumBetween(final Integer value1, final Integer value2) {
            this.addCriterion("food_num between", value1, value2, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andFoodNumNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("food_num not between", value1, value2, "foodNum");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceIsNull() {
            this.addCriterion("goods_price is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceIsNotNull() {
            this.addCriterion("goods_price is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceEqualTo(final Integer value) {
            this.addCriterion("goods_price =", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceEqualToColumn(final Column column) {
            this.addCriterion("goods_price = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceNotEqualTo(final Integer value) {
            this.addCriterion("goods_price <>", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceNotEqualToColumn(final Column column) {
            this.addCriterion("goods_price <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceGreaterThan(final Integer value) {
            this.addCriterion("goods_price >", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceGreaterThanColumn(final Column column) {
            this.addCriterion("goods_price > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_price >=", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_price >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceLessThan(final Integer value) {
            this.addCriterion("goods_price <", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceLessThanColumn(final Column column) {
            this.addCriterion("goods_price < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceLessThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_price <=", value, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_price <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceIn(final List<Integer> values) {
            this.addCriterion("goods_price in", values, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceNotIn(final List<Integer> values) {
            this.addCriterion("goods_price not in", values, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_price between", value1, value2, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andGoodsPriceNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_price not between", value1, value2, "goodsPrice");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexIsNull() {
            this.addCriterion("sex is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexIsNotNull() {
            this.addCriterion("sex is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexEqualTo(final Integer value) {
            this.addCriterion("sex =", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexEqualToColumn(final Column column) {
            this.addCriterion("sex = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexNotEqualTo(final Integer value) {
            this.addCriterion("sex <>", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexNotEqualToColumn(final Column column) {
            this.addCriterion("sex <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexGreaterThan(final Integer value) {
            this.addCriterion("sex >", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexGreaterThanColumn(final Column column) {
            this.addCriterion("sex > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("sex >=", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("sex >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexLessThan(final Integer value) {
            this.addCriterion("sex <", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexLessThanColumn(final Column column) {
            this.addCriterion("sex < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexLessThanOrEqualTo(final Integer value) {
            this.addCriterion("sex <=", value, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("sex <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexIn(final List<Integer> values) {
            this.addCriterion("sex in", values, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexNotIn(final List<Integer> values) {
            this.addCriterion("sex not in", values, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexBetween(final Integer value1, final Integer value2) {
            this.addCriterion("sex between", value1, value2, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andSexNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("sex not between", value1, value2, "sex");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionIsNull() {
            this.addCriterion("`position` is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionIsNotNull() {
            this.addCriterion("`position` is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionEqualTo(final Integer value) {
            this.addCriterion("`position` =", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionEqualToColumn(final Column column) {
            this.addCriterion("`position` = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionNotEqualTo(final Integer value) {
            this.addCriterion("`position` <>", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionNotEqualToColumn(final Column column) {
            this.addCriterion("`position` <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionGreaterThan(final Integer value) {
            this.addCriterion("`position` >", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionGreaterThanColumn(final Column column) {
            this.addCriterion("`position` > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`position` >=", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`position` >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionLessThan(final Integer value) {
            this.addCriterion("`position` <", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionLessThanColumn(final Column column) {
            this.addCriterion("`position` < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`position` <=", value, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`position` <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionIn(final List<Integer> values) {
            this.addCriterion("`position` in", values, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionNotIn(final List<Integer> values) {
            this.addCriterion("`position` not in", values, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`position` between", value1, value2, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andPositionNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`position` not between", value1, value2, "position");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryIsNull() {
            this.addCriterion("category is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryIsNotNull() {
            this.addCriterion("category is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryEqualTo(final Integer value) {
            this.addCriterion("category =", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryEqualToColumn(final Column column) {
            this.addCriterion("category = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryNotEqualTo(final Integer value) {
            this.addCriterion("category <>", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryNotEqualToColumn(final Column column) {
            this.addCriterion("category <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryGreaterThan(final Integer value) {
            this.addCriterion("category >", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryGreaterThanColumn(final Column column) {
            this.addCriterion("category > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("category >=", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("category >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryLessThan(final Integer value) {
            this.addCriterion("category <", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryLessThanColumn(final Column column) {
            this.addCriterion("category < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryLessThanOrEqualTo(final Integer value) {
            this.addCriterion("category <=", value, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("category <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryIn(final List<Integer> values) {
            this.addCriterion("category in", values, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryNotIn(final List<Integer> values) {
            this.addCriterion("category not in", values, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryBetween(final Integer value1, final Integer value2) {
            this.addCriterion("category between", value1, value2, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andCategoryNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("category not between", value1, value2, "category");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (PackModificationExample.Criteria) this;
        }

        public PackModificationExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (PackModificationExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final PackModificationExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final PackModificationExample paramPackModificationExample);
    }
}
