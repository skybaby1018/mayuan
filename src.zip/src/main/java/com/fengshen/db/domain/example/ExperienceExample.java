//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Experience.Column;
import com.fengshen.db.domain.Experience.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ExperienceExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ExperienceExample.Criteria> oredCriteria = new ArrayList();

    public ExperienceExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ExperienceExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final ExperienceExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ExperienceExample.Criteria or() {
        ExperienceExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ExperienceExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public ExperienceExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public ExperienceExample.Criteria createCriteria() {
        ExperienceExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ExperienceExample.Criteria createCriteriaInternal() {
        ExperienceExample.Criteria criteria = new ExperienceExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static ExperienceExample.Criteria newAndCreateCriteria() {
        ExperienceExample example = new ExperienceExample();
        return example.createCriteria();
    }

    public ExperienceExample when(final boolean condition, final ExperienceExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public ExperienceExample when(final boolean condition, final ExperienceExample.IExampleWhen then, final ExperienceExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends ExperienceExample.GeneratedCriteria {
        private ExperienceExample example;

        protected Criteria(final ExperienceExample example) {
            this.example = example;
        }

        public ExperienceExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ExperienceExample.Criteria andIf(final boolean ifAdd, final ExperienceExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public ExperienceExample.Criteria when(final boolean condition, final ExperienceExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public ExperienceExample.Criteria when(final boolean condition, final ExperienceExample.ICriteriaWhen then, final ExperienceExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public ExperienceExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            ExperienceExample.Criteria add(final ExperienceExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ExperienceExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ExperienceExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ExperienceExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ExperienceExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ExperienceExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ExperienceExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ExperienceExample.Criteria andAttribIsNull() {
            this.addCriterion("attrib is null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribIsNotNull() {
            this.addCriterion("attrib is not null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribEqualTo(final Integer value) {
            this.addCriterion("attrib =", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribEqualToColumn(final Column column) {
            this.addCriterion("attrib = " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribNotEqualTo(final Integer value) {
            this.addCriterion("attrib <>", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribNotEqualToColumn(final Column column) {
            this.addCriterion("attrib <> " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribGreaterThan(final Integer value) {
            this.addCriterion("attrib >", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribGreaterThanColumn(final Column column) {
            this.addCriterion("attrib > " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib >=", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib >= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribLessThan(final Integer value) {
            this.addCriterion("attrib <", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribLessThanColumn(final Column column) {
            this.addCriterion("attrib < " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribLessThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib <=", value, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib <= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribIn(final List<Integer> values) {
            this.addCriterion("attrib in", values, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribNotIn(final List<Integer> values) {
            this.addCriterion("attrib not in", values, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib between", value1, value2, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAttribNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib not between", value1, value2, "attrib");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelIsNull() {
            this.addCriterion("max_level is null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelIsNotNull() {
            this.addCriterion("max_level is not null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelEqualTo(final Integer value) {
            this.addCriterion("max_level =", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelEqualToColumn(final Column column) {
            this.addCriterion("max_level = " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelNotEqualTo(final Integer value) {
            this.addCriterion("max_level <>", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelNotEqualToColumn(final Column column) {
            this.addCriterion("max_level <> " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelGreaterThan(final Integer value) {
            this.addCriterion("max_level >", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelGreaterThanColumn(final Column column) {
            this.addCriterion("max_level > " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("max_level >=", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("max_level >= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelLessThan(final Integer value) {
            this.addCriterion("max_level <", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelLessThanColumn(final Column column) {
            this.addCriterion("max_level < " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("max_level <=", value, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("max_level <= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelIn(final List<Integer> values) {
            this.addCriterion("max_level in", values, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelNotIn(final List<Integer> values) {
            this.addCriterion("max_level not in", values, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("max_level between", value1, value2, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andMaxLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("max_level not between", value1, value2, "maxLevel");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (ExperienceExample.Criteria) this;
        }

        public ExperienceExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (ExperienceExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final ExperienceExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final ExperienceExample paramExperienceExample);
    }
}
