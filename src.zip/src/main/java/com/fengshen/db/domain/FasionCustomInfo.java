//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "fasion_custom_info"
)
public class FasionCustomInfo {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private Integer equipPos;
    private Integer fasionPart;
    private Integer fasionDye;
    private String name;
    private Integer gift;
    private Integer icon;
    private Integer goodsPrice;
    private Integer sex;
    private Integer position;
    private Integer category;
    private Date addTime;
    private Date updateTime;
    private Boolean deleted;

    public FasionCustomInfo() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEquipPos() {
        return this.equipPos;
    }

    public void setEquipPos(Integer equipPos) {
        this.equipPos = equipPos;
    }

    public Integer getFasionPart() {
        return this.fasionPart;
    }

    public void setFasionPart(Integer fasionPart) {
        this.fasionPart = fasionPart;
    }

    public Integer getFasionDye() {
        return this.fasionDye;
    }

    public void setFasionDye(Integer fasionDye) {
        this.fasionDye = fasionDye;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getGift() {
        return this.gift;
    }

    public void setGift(Integer gift) {
        this.gift = gift;
    }

    public Integer getIcon() {
        return this.icon;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    public Integer getGoodsPrice() {
        return this.goodsPrice;
    }

    public void setGoodsPrice(Integer goodsPrice) {
        this.goodsPrice = goodsPrice;
    }

    public Integer getSex() {
        return this.sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getPosition() {
        return this.position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getCategory() {
        return this.category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
