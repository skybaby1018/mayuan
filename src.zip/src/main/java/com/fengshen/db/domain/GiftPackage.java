//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.domain;

import com.alibaba.fastjson.JSONObject;

public class GiftPackage {
    private Integer id;
    private String name;
    private String config;

    public JSONObject getJsonObject() {
        return JSONObject.parseObject(this.config);
    }

    public GiftPackage() {
    }

    public Integer getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getConfig() {
        return this.config;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setConfig(final String config) {
        this.config = config;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof GiftPackage)) {
            return false;
        } else {
            GiftPackage other = (GiftPackage) o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label47:
                {
                    Object this$id = this.getId();
                    Object other$id = other.getId();
                    if (this$id == null) {
                        if (other$id == null) {
                            break label47;
                        }
                    } else if (this$id.equals(other$id)) {
                        break label47;
                    }

                    return false;
                }

                Object this$name = this.getName();
                Object other$name = other.getName();
                if (this$name == null) {
                    if (other$name != null) {
                        return false;
                    }
                } else if (!this$name.equals(other$name)) {
                    return false;
                }

                Object this$config = this.getConfig();
                Object other$config = other.getConfig();
                if (this$config == null) {
                    if (other$config != null) {
                        return false;
                    }
                } else if (!this$config.equals(other$config)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof GiftPackage;
    }

    public int hashCode() {
        int result = 1;
        Object $id = this.getId();
        result = result * 59 + ($id == null ? 43 : $id.hashCode());
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $config = this.getConfig();
        result = result * 59 + ($config == null ? 43 : $config.hashCode());
        return result;
    }

    public String toString() {
        return "GiftPackage(id=" + this.getId() + ", name=" + this.getName() + ", config=" + this.getConfig() + ")";
    }
}
