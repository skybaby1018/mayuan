//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "sale_good"
)
public class SaleGood {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private String goodsId;
    private String name;
    private String alias;
    private Integer price;
    private Integer reqLevel;
    private String gid;
    private Date addTime;
    private Date updateTime;
    private Boolean deleted;
    private Integer level;
    private Integer type;
    private String extra;
    private Integer status;
    private Integer startTime;
    private Integer endTime;
    private String goods;
    private Integer icon;
    private Integer unidentified;
    private Integer itemPolar;
    private Integer cgPriceCount;
    private Integer sgId;

    public SaleGood() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGoodsId() {
        return this.goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPrice() {
        return this.price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getReqLevel() {
        return this.reqLevel;
    }

    public void setReqLevel(Integer reqLevel) {
        this.reqLevel = reqLevel;
    }

    public String getGid() {
        return this.gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getLevel() {
        return this.level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getType() {
        return this.type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getExtra() {
        return this.extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public Integer getStatus() {
        return this.status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStartTime() {
        return this.startTime;
    }

    public void setStartTime(Integer startTime) {
        this.startTime = startTime;
    }

    public Integer getEndTime() {
        return this.endTime;
    }

    public void setEndTime(Integer endTime) {
        this.endTime = endTime;
    }

    public String getGoods() {
        return this.goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public String getAlias() {
        return this.alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Integer getIcon() {
        return this.icon;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    public Integer getUnidentified() {
        return this.unidentified;
    }

    public void setUnidentified(Integer unidentified) {
        this.unidentified = unidentified;
    }

    public Integer getItemPolar() {
        return this.itemPolar;
    }

    public void setItemPolar(Integer itemPolar) {
        this.itemPolar = itemPolar;
    }

    public Integer getCgPriceCount() {
        return this.cgPriceCount;
    }

    public void setCgPriceCount(Integer cgPriceCount) {
        this.cgPriceCount = cgPriceCount;
    }

    public Integer getSgId() {
        return this.sgId;
    }

    public void setSgId(Integer sgId) {
        this.sgId = sgId;
    }
}
