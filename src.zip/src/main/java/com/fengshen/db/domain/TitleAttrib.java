//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.domain;

import com.alibaba.fastjson.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class TitleAttrib {
    private int id;
    private String name;
    private String attribs;

    public Map<String, Integer> toMap() {
        LinkedHashMap map = (LinkedHashMap) JSONObject.parseObject(this.attribs, LinkedHashMap.class);
        return map;
    }

    public TitleAttrib() {
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getAttribs() {
        return this.attribs;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setAttribs(final String attribs) {
        this.attribs = attribs;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof TitleAttrib)) {
            return false;
        } else {
            TitleAttrib other = (TitleAttrib) o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.getId() != other.getId()) {
                return false;
            } else {
                Object this$name = this.getName();
                Object other$name = other.getName();
                if (this$name == null) {
                    if (other$name != null) {
                        return false;
                    }
                } else if (!this$name.equals(other$name)) {
                    return false;
                }

                Object this$attribs = this.getAttribs();
                Object other$attribs = other.getAttribs();
                if (this$attribs == null) {
                    if (other$attribs != null) {
                        return false;
                    }
                } else if (!this$attribs.equals(other$attribs)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof TitleAttrib;
    }

    public int hashCode() {
        int result = 1;
        result = result * 59 + this.getId();
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $attribs = this.getAttribs();
        result = result * 59 + ($attribs == null ? 43 : $attribs.hashCode());
        return result;
    }

    public String toString() {
        return "TitleAttrib(id=" + this.getId() + ", name=" + this.getName() + ", attribs=" + this.getAttribs() + ")";
    }
}
