//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Pets.Column;
import com.fengshen.db.domain.Pets.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PetsExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<PetsExample.Criteria> oredCriteria = new ArrayList();

    public PetsExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<PetsExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final PetsExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public PetsExample.Criteria or() {
        PetsExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public PetsExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public PetsExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public PetsExample.Criteria createCriteria() {
        PetsExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected PetsExample.Criteria createCriteriaInternal() {
        PetsExample.Criteria criteria = new PetsExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static PetsExample.Criteria newAndCreateCriteria() {
        PetsExample example = new PetsExample();
        return example.createCriteria();
    }

    public PetsExample when(final boolean condition, final PetsExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public PetsExample when(final boolean condition, final PetsExample.IExampleWhen then, final PetsExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends PetsExample.GeneratedCriteria {
        private PetsExample example;

        protected Criteria(final PetsExample example) {
            this.example = example;
        }

        public PetsExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public PetsExample.Criteria andIf(final boolean ifAdd, final PetsExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public PetsExample.Criteria when(final boolean condition, final PetsExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public PetsExample.Criteria when(final boolean condition, final PetsExample.ICriteriaWhen then, final PetsExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public PetsExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            PetsExample.Criteria add(final PetsExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<PetsExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<PetsExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<PetsExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new PetsExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new PetsExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new PetsExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public PetsExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridIsNull() {
            this.addCriterion("ownerid is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridIsNotNull() {
            this.addCriterion("ownerid is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridEqualTo(final String value) {
            this.addCriterion("ownerid =", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridEqualToColumn(final Column column) {
            this.addCriterion("ownerid = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridNotEqualTo(final String value) {
            this.addCriterion("ownerid <>", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridNotEqualToColumn(final Column column) {
            this.addCriterion("ownerid <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridGreaterThan(final String value) {
            this.addCriterion("ownerid >", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridGreaterThanColumn(final Column column) {
            this.addCriterion("ownerid > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridGreaterThanOrEqualTo(final String value) {
            this.addCriterion("ownerid >=", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("ownerid >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridLessThan(final String value) {
            this.addCriterion("ownerid <", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridLessThanColumn(final Column column) {
            this.addCriterion("ownerid < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridLessThanOrEqualTo(final String value) {
            this.addCriterion("ownerid <=", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("ownerid <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridLike(final String value) {
            this.addCriterion("ownerid like", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridNotLike(final String value) {
            this.addCriterion("ownerid not like", value, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridIn(final List<String> values) {
            this.addCriterion("ownerid in", values, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridNotIn(final List<String> values) {
            this.addCriterion("ownerid not in", values, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridBetween(final String value1, final String value2) {
            this.addCriterion("ownerid between", value1, value2, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andOwneridNotBetween(final String value1, final String value2) {
            this.addCriterion("ownerid not between", value1, value2, "ownerid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidIsNull() {
            this.addCriterion("petid is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidIsNotNull() {
            this.addCriterion("petid is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidEqualTo(final String value) {
            this.addCriterion("petid =", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidEqualToColumn(final Column column) {
            this.addCriterion("petid = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidNotEqualTo(final String value) {
            this.addCriterion("petid <>", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidNotEqualToColumn(final Column column) {
            this.addCriterion("petid <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidGreaterThan(final String value) {
            this.addCriterion("petid >", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidGreaterThanColumn(final Column column) {
            this.addCriterion("petid > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidGreaterThanOrEqualTo(final String value) {
            this.addCriterion("petid >=", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("petid >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidLessThan(final String value) {
            this.addCriterion("petid <", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidLessThanColumn(final Column column) {
            this.addCriterion("petid < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidLessThanOrEqualTo(final String value) {
            this.addCriterion("petid <=", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("petid <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidLike(final String value) {
            this.addCriterion("petid like", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidNotLike(final String value) {
            this.addCriterion("petid not like", value, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidIn(final List<String> values) {
            this.addCriterion("petid in", values, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidNotIn(final List<String> values) {
            this.addCriterion("petid not in", values, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidBetween(final String value1, final String value2) {
            this.addCriterion("petid between", value1, value2, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andPetidNotBetween(final String value1, final String value2) {
            this.addCriterion("petid not between", value1, value2, "petid");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameIsNull() {
            this.addCriterion("nickname is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameIsNotNull() {
            this.addCriterion("nickname is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameEqualTo(final String value) {
            this.addCriterion("nickname =", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameEqualToColumn(final Column column) {
            this.addCriterion("nickname = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameNotEqualTo(final String value) {
            this.addCriterion("nickname <>", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameNotEqualToColumn(final Column column) {
            this.addCriterion("nickname <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameGreaterThan(final String value) {
            this.addCriterion("nickname >", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameGreaterThanColumn(final Column column) {
            this.addCriterion("nickname > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("nickname >=", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("nickname >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameLessThan(final String value) {
            this.addCriterion("nickname <", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameLessThanColumn(final Column column) {
            this.addCriterion("nickname < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameLessThanOrEqualTo(final String value) {
            this.addCriterion("nickname <=", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("nickname <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameLike(final String value) {
            this.addCriterion("nickname like", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameNotLike(final String value) {
            this.addCriterion("nickname not like", value, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameIn(final List<String> values) {
            this.addCriterion("nickname in", values, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameNotIn(final List<String> values) {
            this.addCriterion("nickname not in", values, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameBetween(final String value1, final String value2) {
            this.addCriterion("nickname between", value1, value2, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNicknameNotBetween(final String value1, final String value2) {
            this.addCriterion("nickname not between", value1, value2, "nickname");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeIsNull() {
            this.addCriterion("horsetype is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeIsNotNull() {
            this.addCriterion("horsetype is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeEqualTo(final Integer value) {
            this.addCriterion("horsetype =", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeEqualToColumn(final Column column) {
            this.addCriterion("horsetype = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeNotEqualTo(final Integer value) {
            this.addCriterion("horsetype <>", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeNotEqualToColumn(final Column column) {
            this.addCriterion("horsetype <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeGreaterThan(final Integer value) {
            this.addCriterion("horsetype >", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeGreaterThanColumn(final Column column) {
            this.addCriterion("horsetype > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("horsetype >=", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("horsetype >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeLessThan(final Integer value) {
            this.addCriterion("horsetype <", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeLessThanColumn(final Column column) {
            this.addCriterion("horsetype < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("horsetype <=", value, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("horsetype <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeIn(final List<Integer> values) {
            this.addCriterion("horsetype in", values, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeNotIn(final List<Integer> values) {
            this.addCriterion("horsetype not in", values, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("horsetype between", value1, value2, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andHorsetypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("horsetype not between", value1, value2, "horsetype");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelIsNull() {
            this.addCriterion("`level` is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelIsNotNull() {
            this.addCriterion("`level` is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelEqualTo(final Integer value) {
            this.addCriterion("`level` =", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelEqualToColumn(final Column column) {
            this.addCriterion("`level` = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelNotEqualTo(final Integer value) {
            this.addCriterion("`level` <>", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelNotEqualToColumn(final Column column) {
            this.addCriterion("`level` <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelGreaterThan(final Integer value) {
            this.addCriterion("`level` >", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelGreaterThanColumn(final Column column) {
            this.addCriterion("`level` > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` >=", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelLessThan(final Integer value) {
            this.addCriterion("`level` <", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelLessThanColumn(final Column column) {
            this.addCriterion("`level` < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` <=", value, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelIn(final List<Integer> values) {
            this.addCriterion("`level` in", values, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelNotIn(final List<Integer> values) {
            this.addCriterion("`level` not in", values, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` between", value1, value2, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` not between", value1, value2, "level");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangIsNull() {
            this.addCriterion("liliang is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangIsNotNull() {
            this.addCriterion("liliang is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangEqualTo(final Integer value) {
            this.addCriterion("liliang =", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangEqualToColumn(final Column column) {
            this.addCriterion("liliang = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangNotEqualTo(final Integer value) {
            this.addCriterion("liliang <>", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangNotEqualToColumn(final Column column) {
            this.addCriterion("liliang <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangGreaterThan(final Integer value) {
            this.addCriterion("liliang >", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangGreaterThanColumn(final Column column) {
            this.addCriterion("liliang > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("liliang >=", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("liliang >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangLessThan(final Integer value) {
            this.addCriterion("liliang <", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangLessThanColumn(final Column column) {
            this.addCriterion("liliang < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangLessThanOrEqualTo(final Integer value) {
            this.addCriterion("liliang <=", value, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("liliang <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangIn(final List<Integer> values) {
            this.addCriterion("liliang in", values, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangNotIn(final List<Integer> values) {
            this.addCriterion("liliang not in", values, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangBetween(final Integer value1, final Integer value2) {
            this.addCriterion("liliang between", value1, value2, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLiliangNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("liliang not between", value1, value2, "liliang");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieIsNull() {
            this.addCriterion("minjie is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieIsNotNull() {
            this.addCriterion("minjie is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieEqualTo(final Integer value) {
            this.addCriterion("minjie =", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieEqualToColumn(final Column column) {
            this.addCriterion("minjie = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieNotEqualTo(final Integer value) {
            this.addCriterion("minjie <>", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieNotEqualToColumn(final Column column) {
            this.addCriterion("minjie <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieGreaterThan(final Integer value) {
            this.addCriterion("minjie >", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieGreaterThanColumn(final Column column) {
            this.addCriterion("minjie > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("minjie >=", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("minjie >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieLessThan(final Integer value) {
            this.addCriterion("minjie <", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieLessThanColumn(final Column column) {
            this.addCriterion("minjie < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieLessThanOrEqualTo(final Integer value) {
            this.addCriterion("minjie <=", value, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("minjie <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieIn(final List<Integer> values) {
            this.addCriterion("minjie in", values, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieNotIn(final List<Integer> values) {
            this.addCriterion("minjie not in", values, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieBetween(final Integer value1, final Integer value2) {
            this.addCriterion("minjie between", value1, value2, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andMinjieNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("minjie not between", value1, value2, "minjie");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliIsNull() {
            this.addCriterion("lingli is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliIsNotNull() {
            this.addCriterion("lingli is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliEqualTo(final Integer value) {
            this.addCriterion("lingli =", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliEqualToColumn(final Column column) {
            this.addCriterion("lingli = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliNotEqualTo(final Integer value) {
            this.addCriterion("lingli <>", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliNotEqualToColumn(final Column column) {
            this.addCriterion("lingli <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliGreaterThan(final Integer value) {
            this.addCriterion("lingli >", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliGreaterThanColumn(final Column column) {
            this.addCriterion("lingli > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("lingli >=", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("lingli >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliLessThan(final Integer value) {
            this.addCriterion("lingli <", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliLessThanColumn(final Column column) {
            this.addCriterion("lingli < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliLessThanOrEqualTo(final Integer value) {
            this.addCriterion("lingli <=", value, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("lingli <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliIn(final List<Integer> values) {
            this.addCriterion("lingli in", values, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliNotIn(final List<Integer> values) {
            this.addCriterion("lingli not in", values, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliBetween(final Integer value1, final Integer value2) {
            this.addCriterion("lingli between", value1, value2, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andLingliNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("lingli not between", value1, value2, "lingli");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliIsNull() {
            this.addCriterion("tili is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliIsNotNull() {
            this.addCriterion("tili is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliEqualTo(final Integer value) {
            this.addCriterion("tili =", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliEqualToColumn(final Column column) {
            this.addCriterion("tili = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliNotEqualTo(final Integer value) {
            this.addCriterion("tili <>", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliNotEqualToColumn(final Column column) {
            this.addCriterion("tili <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliGreaterThan(final Integer value) {
            this.addCriterion("tili >", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliGreaterThanColumn(final Column column) {
            this.addCriterion("tili > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("tili >=", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("tili >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliLessThan(final Integer value) {
            this.addCriterion("tili <", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliLessThanColumn(final Column column) {
            this.addCriterion("tili < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliLessThanOrEqualTo(final Integer value) {
            this.addCriterion("tili <=", value, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("tili <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliIn(final List<Integer> values) {
            this.addCriterion("tili in", values, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliNotIn(final List<Integer> values) {
            this.addCriterion("tili not in", values, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliBetween(final Integer value1, final Integer value2) {
            this.addCriterion("tili between", value1, value2, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andTiliNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("tili not between", value1, value2, "tili");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxIsNull() {
            this.addCriterion("dianhualx is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxIsNotNull() {
            this.addCriterion("dianhualx is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxEqualTo(final Integer value) {
            this.addCriterion("dianhualx =", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxEqualToColumn(final Column column) {
            this.addCriterion("dianhualx = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxNotEqualTo(final Integer value) {
            this.addCriterion("dianhualx <>", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxNotEqualToColumn(final Column column) {
            this.addCriterion("dianhualx <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxGreaterThan(final Integer value) {
            this.addCriterion("dianhualx >", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxGreaterThanColumn(final Column column) {
            this.addCriterion("dianhualx > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhualx >=", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhualx >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxLessThan(final Integer value) {
            this.addCriterion("dianhualx <", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxLessThanColumn(final Column column) {
            this.addCriterion("dianhualx < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhualx <=", value, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhualx <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxIn(final List<Integer> values) {
            this.addCriterion("dianhualx in", values, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxNotIn(final List<Integer> values) {
            this.addCriterion("dianhualx not in", values, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhualx between", value1, value2, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhualxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhualx not between", value1, value2, "dianhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdIsNull() {
            this.addCriterion("dianhuazd is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdIsNotNull() {
            this.addCriterion("dianhuazd is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdEqualTo(final Integer value) {
            this.addCriterion("dianhuazd =", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdEqualToColumn(final Column column) {
            this.addCriterion("dianhuazd = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdNotEqualTo(final Integer value) {
            this.addCriterion("dianhuazd <>", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdNotEqualToColumn(final Column column) {
            this.addCriterion("dianhuazd <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdGreaterThan(final Integer value) {
            this.addCriterion("dianhuazd >", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdGreaterThanColumn(final Column column) {
            this.addCriterion("dianhuazd > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhuazd >=", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhuazd >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdLessThan(final Integer value) {
            this.addCriterion("dianhuazd <", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdLessThanColumn(final Column column) {
            this.addCriterion("dianhuazd < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhuazd <=", value, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhuazd <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdIn(final List<Integer> values) {
            this.addCriterion("dianhuazd in", values, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdNotIn(final List<Integer> values) {
            this.addCriterion("dianhuazd not in", values, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhuazd between", value1, value2, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhuazd not between", value1, value2, "dianhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxIsNull() {
            this.addCriterion("dianhuazx is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxIsNotNull() {
            this.addCriterion("dianhuazx is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxEqualTo(final Integer value) {
            this.addCriterion("dianhuazx =", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxEqualToColumn(final Column column) {
            this.addCriterion("dianhuazx = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxNotEqualTo(final Integer value) {
            this.addCriterion("dianhuazx <>", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxNotEqualToColumn(final Column column) {
            this.addCriterion("dianhuazx <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxGreaterThan(final Integer value) {
            this.addCriterion("dianhuazx >", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxGreaterThanColumn(final Column column) {
            this.addCriterion("dianhuazx > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhuazx >=", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhuazx >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxLessThan(final Integer value) {
            this.addCriterion("dianhuazx <", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxLessThanColumn(final Column column) {
            this.addCriterion("dianhuazx < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("dianhuazx <=", value, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("dianhuazx <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxIn(final List<Integer> values) {
            this.addCriterion("dianhuazx in", values, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxNotIn(final List<Integer> values) {
            this.addCriterion("dianhuazx not in", values, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhuazx between", value1, value2, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDianhuazxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dianhuazx not between", value1, value2, "dianhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxIsNull() {
            this.addCriterion("yuhualx is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxIsNotNull() {
            this.addCriterion("yuhualx is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxEqualTo(final Integer value) {
            this.addCriterion("yuhualx =", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxEqualToColumn(final Column column) {
            this.addCriterion("yuhualx = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxNotEqualTo(final Integer value) {
            this.addCriterion("yuhualx <>", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxNotEqualToColumn(final Column column) {
            this.addCriterion("yuhualx <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxGreaterThan(final Integer value) {
            this.addCriterion("yuhualx >", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxGreaterThanColumn(final Column column) {
            this.addCriterion("yuhualx > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhualx >=", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhualx >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxLessThan(final Integer value) {
            this.addCriterion("yuhualx <", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxLessThanColumn(final Column column) {
            this.addCriterion("yuhualx < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhualx <=", value, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhualx <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxIn(final List<Integer> values) {
            this.addCriterion("yuhualx in", values, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxNotIn(final List<Integer> values) {
            this.addCriterion("yuhualx not in", values, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhualx between", value1, value2, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhualxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhualx not between", value1, value2, "yuhualx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdIsNull() {
            this.addCriterion("yuhuazd is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdIsNotNull() {
            this.addCriterion("yuhuazd is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdEqualTo(final Integer value) {
            this.addCriterion("yuhuazd =", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdEqualToColumn(final Column column) {
            this.addCriterion("yuhuazd = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdNotEqualTo(final Integer value) {
            this.addCriterion("yuhuazd <>", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdNotEqualToColumn(final Column column) {
            this.addCriterion("yuhuazd <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdGreaterThan(final Integer value) {
            this.addCriterion("yuhuazd >", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdGreaterThanColumn(final Column column) {
            this.addCriterion("yuhuazd > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhuazd >=", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhuazd >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdLessThan(final Integer value) {
            this.addCriterion("yuhuazd <", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdLessThanColumn(final Column column) {
            this.addCriterion("yuhuazd < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhuazd <=", value, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhuazd <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdIn(final List<Integer> values) {
            this.addCriterion("yuhuazd in", values, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdNotIn(final List<Integer> values) {
            this.addCriterion("yuhuazd not in", values, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhuazd between", value1, value2, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhuazd not between", value1, value2, "yuhuazd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxIsNull() {
            this.addCriterion("yuhuazx is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxIsNotNull() {
            this.addCriterion("yuhuazx is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxEqualTo(final Integer value) {
            this.addCriterion("yuhuazx =", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxEqualToColumn(final Column column) {
            this.addCriterion("yuhuazx = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxNotEqualTo(final Integer value) {
            this.addCriterion("yuhuazx <>", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxNotEqualToColumn(final Column column) {
            this.addCriterion("yuhuazx <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxGreaterThan(final Integer value) {
            this.addCriterion("yuhuazx >", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxGreaterThanColumn(final Column column) {
            this.addCriterion("yuhuazx > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhuazx >=", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhuazx >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxLessThan(final Integer value) {
            this.addCriterion("yuhuazx <", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxLessThanColumn(final Column column) {
            this.addCriterion("yuhuazx < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("yuhuazx <=", value, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("yuhuazx <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxIn(final List<Integer> values) {
            this.addCriterion("yuhuazx in", values, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxNotIn(final List<Integer> values) {
            this.addCriterion("yuhuazx not in", values, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhuazx between", value1, value2, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andYuhuazxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("yuhuazx not between", value1, value2, "yuhuazx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxIsNull() {
            this.addCriterion("cwjyzx is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxIsNotNull() {
            this.addCriterion("cwjyzx is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxEqualTo(final Integer value) {
            this.addCriterion("cwjyzx =", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxEqualToColumn(final Column column) {
            this.addCriterion("cwjyzx = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxNotEqualTo(final Integer value) {
            this.addCriterion("cwjyzx <>", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxNotEqualToColumn(final Column column) {
            this.addCriterion("cwjyzx <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxGreaterThan(final Integer value) {
            this.addCriterion("cwjyzx >", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxGreaterThanColumn(final Column column) {
            this.addCriterion("cwjyzx > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cwjyzx >=", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cwjyzx >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxLessThan(final Integer value) {
            this.addCriterion("cwjyzx <", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxLessThanColumn(final Column column) {
            this.addCriterion("cwjyzx < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cwjyzx <=", value, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cwjyzx <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxIn(final List<Integer> values) {
            this.addCriterion("cwjyzx in", values, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxNotIn(final List<Integer> values) {
            this.addCriterion("cwjyzx not in", values, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cwjyzx between", value1, value2, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cwjyzx not between", value1, value2, "cwjyzx");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdIsNull() {
            this.addCriterion("cwjyzd is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdIsNotNull() {
            this.addCriterion("cwjyzd is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdEqualTo(final Integer value) {
            this.addCriterion("cwjyzd =", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdEqualToColumn(final Column column) {
            this.addCriterion("cwjyzd = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdNotEqualTo(final Integer value) {
            this.addCriterion("cwjyzd <>", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdNotEqualToColumn(final Column column) {
            this.addCriterion("cwjyzd <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdGreaterThan(final Integer value) {
            this.addCriterion("cwjyzd >", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdGreaterThanColumn(final Column column) {
            this.addCriterion("cwjyzd > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cwjyzd >=", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cwjyzd >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdLessThan(final Integer value) {
            this.addCriterion("cwjyzd <", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdLessThanColumn(final Column column) {
            this.addCriterion("cwjyzd < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cwjyzd <=", value, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cwjyzd <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdIn(final List<Integer> values) {
            this.addCriterion("cwjyzd in", values, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdNotIn(final List<Integer> values) {
            this.addCriterion("cwjyzd not in", values, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cwjyzd between", value1, value2, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwjyzdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cwjyzd not between", value1, value2, "cwjyzd");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengIsNull() {
            this.addCriterion("feisheng is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengIsNotNull() {
            this.addCriterion("feisheng is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengEqualTo(final Integer value) {
            this.addCriterion("feisheng =", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengEqualToColumn(final Column column) {
            this.addCriterion("feisheng = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengNotEqualTo(final Integer value) {
            this.addCriterion("feisheng <>", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengNotEqualToColumn(final Column column) {
            this.addCriterion("feisheng <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengGreaterThan(final Integer value) {
            this.addCriterion("feisheng >", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengGreaterThanColumn(final Column column) {
            this.addCriterion("feisheng > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("feisheng >=", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("feisheng >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengLessThan(final Integer value) {
            this.addCriterion("feisheng <", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengLessThanColumn(final Column column) {
            this.addCriterion("feisheng < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengLessThanOrEqualTo(final Integer value) {
            this.addCriterion("feisheng <=", value, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("feisheng <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengIn(final List<Integer> values) {
            this.addCriterion("feisheng in", values, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengNotIn(final List<Integer> values) {
            this.addCriterion("feisheng not in", values, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengBetween(final Integer value1, final Integer value2) {
            this.addCriterion("feisheng between", value1, value2, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFeishengNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("feisheng not between", value1, value2, "feisheng");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduIsNull() {
            this.addCriterion("fsudu is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduIsNotNull() {
            this.addCriterion("fsudu is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduEqualTo(final Integer value) {
            this.addCriterion("fsudu =", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduEqualToColumn(final Column column) {
            this.addCriterion("fsudu = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduNotEqualTo(final Integer value) {
            this.addCriterion("fsudu <>", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduNotEqualToColumn(final Column column) {
            this.addCriterion("fsudu <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduGreaterThan(final Integer value) {
            this.addCriterion("fsudu >", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduGreaterThanColumn(final Column column) {
            this.addCriterion("fsudu > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("fsudu >=", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("fsudu >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduLessThan(final Integer value) {
            this.addCriterion("fsudu <", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduLessThanColumn(final Column column) {
            this.addCriterion("fsudu < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduLessThanOrEqualTo(final Integer value) {
            this.addCriterion("fsudu <=", value, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("fsudu <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduIn(final List<Integer> values) {
            this.addCriterion("fsudu in", values, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduNotIn(final List<Integer> values) {
            this.addCriterion("fsudu not in", values, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduBetween(final Integer value1, final Integer value2) {
            this.addCriterion("fsudu between", value1, value2, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andFsuduNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("fsudu not between", value1, value2, "fsudu");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgIsNull() {
            this.addCriterion("qhcw_wg is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgIsNotNull() {
            this.addCriterion("qhcw_wg is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgEqualTo(final Integer value) {
            this.addCriterion("qhcw_wg =", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgEqualToColumn(final Column column) {
            this.addCriterion("qhcw_wg = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgNotEqualTo(final Integer value) {
            this.addCriterion("qhcw_wg <>", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgNotEqualToColumn(final Column column) {
            this.addCriterion("qhcw_wg <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgGreaterThan(final Integer value) {
            this.addCriterion("qhcw_wg >", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgGreaterThanColumn(final Column column) {
            this.addCriterion("qhcw_wg > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("qhcw_wg >=", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("qhcw_wg >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgLessThan(final Integer value) {
            this.addCriterion("qhcw_wg <", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgLessThanColumn(final Column column) {
            this.addCriterion("qhcw_wg < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgLessThanOrEqualTo(final Integer value) {
            this.addCriterion("qhcw_wg <=", value, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("qhcw_wg <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgIn(final List<Integer> values) {
            this.addCriterion("qhcw_wg in", values, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgNotIn(final List<Integer> values) {
            this.addCriterion("qhcw_wg not in", values, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgBetween(final Integer value1, final Integer value2) {
            this.addCriterion("qhcw_wg between", value1, value2, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwWgNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("qhcw_wg not between", value1, value2, "qhcwWg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgIsNull() {
            this.addCriterion("qhcw_fg is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgIsNotNull() {
            this.addCriterion("qhcw_fg is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgEqualTo(final Integer value) {
            this.addCriterion("qhcw_fg =", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgEqualToColumn(final Column column) {
            this.addCriterion("qhcw_fg = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgNotEqualTo(final Integer value) {
            this.addCriterion("qhcw_fg <>", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgNotEqualToColumn(final Column column) {
            this.addCriterion("qhcw_fg <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgGreaterThan(final Integer value) {
            this.addCriterion("qhcw_fg >", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgGreaterThanColumn(final Column column) {
            this.addCriterion("qhcw_fg > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("qhcw_fg >=", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("qhcw_fg >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgLessThan(final Integer value) {
            this.addCriterion("qhcw_fg <", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgLessThanColumn(final Column column) {
            this.addCriterion("qhcw_fg < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgLessThanOrEqualTo(final Integer value) {
            this.addCriterion("qhcw_fg <=", value, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("qhcw_fg <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgIn(final List<Integer> values) {
            this.addCriterion("qhcw_fg in", values, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgNotIn(final List<Integer> values) {
            this.addCriterion("qhcw_fg not in", values, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgBetween(final Integer value1, final Integer value2) {
            this.addCriterion("qhcw_fg between", value1, value2, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andQhcwFgNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("qhcw_fg not between", value1, value2, "qhcwFg");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingIsNull() {
            this.addCriterion("cw_xiangxing is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingIsNotNull() {
            this.addCriterion("cw_xiangxing is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingEqualTo(final Integer value) {
            this.addCriterion("cw_xiangxing =", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingEqualToColumn(final Column column) {
            this.addCriterion("cw_xiangxing = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingNotEqualTo(final Integer value) {
            this.addCriterion("cw_xiangxing <>", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingNotEqualToColumn(final Column column) {
            this.addCriterion("cw_xiangxing <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingGreaterThan(final Integer value) {
            this.addCriterion("cw_xiangxing >", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingGreaterThanColumn(final Column column) {
            this.addCriterion("cw_xiangxing > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_xiangxing >=", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_xiangxing >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingLessThan(final Integer value) {
            this.addCriterion("cw_xiangxing <", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingLessThanColumn(final Column column) {
            this.addCriterion("cw_xiangxing < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_xiangxing <=", value, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_xiangxing <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingIn(final List<Integer> values) {
            this.addCriterion("cw_xiangxing in", values, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingNotIn(final List<Integer> values) {
            this.addCriterion("cw_xiangxing not in", values, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_xiangxing between", value1, value2, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXiangxingNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_xiangxing not between", value1, value2, "cwXiangxing");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueIsNull() {
            this.addCriterion("cw_wuxue is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueIsNotNull() {
            this.addCriterion("cw_wuxue is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueEqualTo(final Integer value) {
            this.addCriterion("cw_wuxue =", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueEqualToColumn(final Column column) {
            this.addCriterion("cw_wuxue = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueNotEqualTo(final Integer value) {
            this.addCriterion("cw_wuxue <>", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueNotEqualToColumn(final Column column) {
            this.addCriterion("cw_wuxue <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueGreaterThan(final Integer value) {
            this.addCriterion("cw_wuxue >", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueGreaterThanColumn(final Column column) {
            this.addCriterion("cw_wuxue > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_wuxue >=", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_wuxue >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueLessThan(final Integer value) {
            this.addCriterion("cw_wuxue <", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueLessThanColumn(final Column column) {
            this.addCriterion("cw_wuxue < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_wuxue <=", value, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_wuxue <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueIn(final List<Integer> values) {
            this.addCriterion("cw_wuxue in", values, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueNotIn(final List<Integer> values) {
            this.addCriterion("cw_wuxue not in", values, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_wuxue between", value1, value2, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwWuxueNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_wuxue not between", value1, value2, "cwWuxue");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconIsNull() {
            this.addCriterion("cw_icon is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconIsNotNull() {
            this.addCriterion("cw_icon is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconEqualTo(final String value) {
            this.addCriterion("cw_icon =", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconEqualToColumn(final Column column) {
            this.addCriterion("cw_icon = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconNotEqualTo(final String value) {
            this.addCriterion("cw_icon <>", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconNotEqualToColumn(final Column column) {
            this.addCriterion("cw_icon <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconGreaterThan(final String value) {
            this.addCriterion("cw_icon >", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconGreaterThanColumn(final Column column) {
            this.addCriterion("cw_icon > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconGreaterThanOrEqualTo(final String value) {
            this.addCriterion("cw_icon >=", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_icon >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconLessThan(final String value) {
            this.addCriterion("cw_icon <", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconLessThanColumn(final Column column) {
            this.addCriterion("cw_icon < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconLessThanOrEqualTo(final String value) {
            this.addCriterion("cw_icon <=", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_icon <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconLike(final String value) {
            this.addCriterion("cw_icon like", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconNotLike(final String value) {
            this.addCriterion("cw_icon not like", value, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconIn(final List<String> values) {
            this.addCriterion("cw_icon in", values, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconNotIn(final List<String> values) {
            this.addCriterion("cw_icon not in", values, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconBetween(final String value1, final String value2) {
            this.addCriterion("cw_icon between", value1, value2, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwIconNotBetween(final String value1, final String value2) {
            this.addCriterion("cw_icon not between", value1, value2, "cwIcon");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaIsNull() {
            this.addCriterion("cw_xinfa is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaIsNotNull() {
            this.addCriterion("cw_xinfa is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaEqualTo(final Integer value) {
            this.addCriterion("cw_xinfa =", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaEqualToColumn(final Column column) {
            this.addCriterion("cw_xinfa = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaNotEqualTo(final Integer value) {
            this.addCriterion("cw_xinfa <>", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaNotEqualToColumn(final Column column) {
            this.addCriterion("cw_xinfa <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaGreaterThan(final Integer value) {
            this.addCriterion("cw_xinfa >", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaGreaterThanColumn(final Column column) {
            this.addCriterion("cw_xinfa > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_xinfa >=", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_xinfa >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaLessThan(final Integer value) {
            this.addCriterion("cw_xinfa <", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaLessThanColumn(final Column column) {
            this.addCriterion("cw_xinfa < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_xinfa <=", value, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_xinfa <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaIn(final List<Integer> values) {
            this.addCriterion("cw_xinfa in", values, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaNotIn(final List<Integer> values) {
            this.addCriterion("cw_xinfa not in", values, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_xinfa between", value1, value2, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwXinfaNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_xinfa not between", value1, value2, "cwXinfa");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiIsNull() {
            this.addCriterion("cw_qinmi is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiIsNotNull() {
            this.addCriterion("cw_qinmi is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiEqualTo(final Integer value) {
            this.addCriterion("cw_qinmi =", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiEqualToColumn(final Column column) {
            this.addCriterion("cw_qinmi = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiNotEqualTo(final Integer value) {
            this.addCriterion("cw_qinmi <>", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiNotEqualToColumn(final Column column) {
            this.addCriterion("cw_qinmi <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiGreaterThan(final Integer value) {
            this.addCriterion("cw_qinmi >", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiGreaterThanColumn(final Column column) {
            this.addCriterion("cw_qinmi > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_qinmi >=", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_qinmi >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiLessThan(final Integer value) {
            this.addCriterion("cw_qinmi <", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiLessThanColumn(final Column column) {
            this.addCriterion("cw_qinmi < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiLessThanOrEqualTo(final Integer value) {
            this.addCriterion("cw_qinmi <=", value, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("cw_qinmi <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiIn(final List<Integer> values) {
            this.addCriterion("cw_qinmi in", values, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiNotIn(final List<Integer> values) {
            this.addCriterion("cw_qinmi not in", values, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_qinmi between", value1, value2, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andCwQinmiNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("cw_qinmi not between", value1, value2, "cwQinmi");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (PetsExample.Criteria) this;
        }

        public PetsExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (PetsExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final PetsExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final PetsExample paramPetsExample);
    }
}
