//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Skilldata.Column;
import com.fengshen.db.domain.Skilldata.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SkilldataExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<SkilldataExample.Criteria> oredCriteria = new ArrayList();

    public SkilldataExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<SkilldataExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final SkilldataExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public SkilldataExample.Criteria or() {
        SkilldataExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public SkilldataExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public SkilldataExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public SkilldataExample.Criteria createCriteria() {
        SkilldataExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected SkilldataExample.Criteria createCriteriaInternal() {
        SkilldataExample.Criteria criteria = new SkilldataExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static SkilldataExample.Criteria newAndCreateCriteria() {
        SkilldataExample example = new SkilldataExample();
        return example.createCriteria();
    }

    public SkilldataExample when(final boolean condition, final SkilldataExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public SkilldataExample when(final boolean condition, final SkilldataExample.IExampleWhen then, final SkilldataExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends SkilldataExample.GeneratedCriteria {
        private SkilldataExample example;

        protected Criteria(final SkilldataExample example) {
            this.example = example;
        }

        public SkilldataExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public SkilldataExample.Criteria andIf(final boolean ifAdd, final SkilldataExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public SkilldataExample.Criteria when(final boolean condition, final SkilldataExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public SkilldataExample.Criteria when(final boolean condition, final SkilldataExample.ICriteriaWhen then, final SkilldataExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public SkilldataExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            SkilldataExample.Criteria add(final SkilldataExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<SkilldataExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<SkilldataExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<SkilldataExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new SkilldataExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new SkilldataExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new SkilldataExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public SkilldataExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidIsNull() {
            this.addCriterion("pid is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidIsNotNull() {
            this.addCriterion("pid is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidEqualTo(final String value) {
            this.addCriterion("pid =", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidEqualToColumn(final Column column) {
            this.addCriterion("pid = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidNotEqualTo(final String value) {
            this.addCriterion("pid <>", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidNotEqualToColumn(final Column column) {
            this.addCriterion("pid <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidGreaterThan(final String value) {
            this.addCriterion("pid >", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidGreaterThanColumn(final Column column) {
            this.addCriterion("pid > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidGreaterThanOrEqualTo(final String value) {
            this.addCriterion("pid >=", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidLessThan(final String value) {
            this.addCriterion("pid <", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidLessThanColumn(final Column column) {
            this.addCriterion("pid < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidLessThanOrEqualTo(final String value) {
            this.addCriterion("pid <=", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidLike(final String value) {
            this.addCriterion("pid like", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidNotLike(final String value) {
            this.addCriterion("pid not like", value, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidIn(final List<String> values) {
            this.addCriterion("pid in", values, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidNotIn(final List<String> values) {
            this.addCriterion("pid not in", values, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidBetween(final String value1, final String value2) {
            this.addCriterion("pid between", value1, value2, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andPidNotBetween(final String value1, final String value2) {
            this.addCriterion("pid not between", value1, value2, "pid");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameIsNull() {
            this.addCriterion("skill_name is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameIsNotNull() {
            this.addCriterion("skill_name is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameEqualTo(final String value) {
            this.addCriterion("skill_name =", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameEqualToColumn(final Column column) {
            this.addCriterion("skill_name = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameNotEqualTo(final String value) {
            this.addCriterion("skill_name <>", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameNotEqualToColumn(final Column column) {
            this.addCriterion("skill_name <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameGreaterThan(final String value) {
            this.addCriterion("skill_name >", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameGreaterThanColumn(final Column column) {
            this.addCriterion("skill_name > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_name >=", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameLessThan(final String value) {
            this.addCriterion("skill_name <", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameLessThanColumn(final Column column) {
            this.addCriterion("skill_name < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_name <=", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameLike(final String value) {
            this.addCriterion("skill_name like", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameNotLike(final String value) {
            this.addCriterion("skill_name not like", value, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameIn(final List<String> values) {
            this.addCriterion("skill_name in", values, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameNotIn(final List<String> values) {
            this.addCriterion("skill_name not in", values, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameBetween(final String value1, final String value2) {
            this.addCriterion("skill_name between", value1, value2, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillNameNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_name not between", value1, value2, "skillName");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelIsNull() {
            this.addCriterion("skill_level is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelIsNotNull() {
            this.addCriterion("skill_level is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelEqualTo(final Integer value) {
            this.addCriterion("skill_level =", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelEqualToColumn(final Column column) {
            this.addCriterion("skill_level = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelNotEqualTo(final Integer value) {
            this.addCriterion("skill_level <>", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelNotEqualToColumn(final Column column) {
            this.addCriterion("skill_level <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelGreaterThan(final Integer value) {
            this.addCriterion("skill_level >", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelGreaterThanColumn(final Column column) {
            this.addCriterion("skill_level > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level >=", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelLessThan(final Integer value) {
            this.addCriterion("skill_level <", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelLessThanColumn(final Column column) {
            this.addCriterion("skill_level < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level <=", value, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelIn(final List<Integer> values) {
            this.addCriterion("skill_level in", values, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelNotIn(final List<Integer> values) {
            this.addCriterion("skill_level not in", values, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level between", value1, value2, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level not between", value1, value2, "skillLevel");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoIsNull() {
            this.addCriterion("skill_mubiao is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoIsNotNull() {
            this.addCriterion("skill_mubiao is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao =", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoNotEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <>", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoNotEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoGreaterThan(final Integer value) {
            this.addCriterion("skill_mubiao >", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoGreaterThanColumn(final Column column) {
            this.addCriterion("skill_mubiao > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao >=", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoLessThan(final Integer value) {
            this.addCriterion("skill_mubiao <", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoLessThanColumn(final Column column) {
            this.addCriterion("skill_mubiao < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <=", value, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao in", values, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoNotIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao not in", values, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao between", value1, value2, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andSkillMubiaoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao not between", value1, value2, "skillMubiao");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (SkilldataExample.Criteria) this;
        }

        public SkilldataExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (SkilldataExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final SkilldataExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final SkilldataExample paramSkilldataExample);
    }
}
