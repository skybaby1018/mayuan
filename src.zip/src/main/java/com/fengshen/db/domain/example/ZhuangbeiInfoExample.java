//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.ZhuangbeiInfo.Column;
import com.fengshen.db.domain.ZhuangbeiInfo.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ZhuangbeiInfoExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ZhuangbeiInfoExample.Criteria> oredCriteria = new ArrayList();

    public ZhuangbeiInfoExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ZhuangbeiInfoExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final ZhuangbeiInfoExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ZhuangbeiInfoExample.Criteria or() {
        ZhuangbeiInfoExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ZhuangbeiInfoExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public ZhuangbeiInfoExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public ZhuangbeiInfoExample.Criteria createCriteria() {
        ZhuangbeiInfoExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ZhuangbeiInfoExample.Criteria createCriteriaInternal() {
        ZhuangbeiInfoExample.Criteria criteria = new ZhuangbeiInfoExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static ZhuangbeiInfoExample.Criteria newAndCreateCriteria() {
        ZhuangbeiInfoExample example = new ZhuangbeiInfoExample();
        return example.createCriteria();
    }

    public ZhuangbeiInfoExample when(final boolean condition, final ZhuangbeiInfoExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public ZhuangbeiInfoExample when(final boolean condition, final ZhuangbeiInfoExample.IExampleWhen then, final ZhuangbeiInfoExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends ZhuangbeiInfoExample.GeneratedCriteria {
        private ZhuangbeiInfoExample example;

        protected Criteria(final ZhuangbeiInfoExample example) {
            this.example = example;
        }

        public ZhuangbeiInfoExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ZhuangbeiInfoExample.Criteria andIf(final boolean ifAdd, final ZhuangbeiInfoExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public ZhuangbeiInfoExample.Criteria when(final boolean condition, final ZhuangbeiInfoExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public ZhuangbeiInfoExample.Criteria when(final boolean condition, final ZhuangbeiInfoExample.ICriteriaWhen then, final ZhuangbeiInfoExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public ZhuangbeiInfoExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            ZhuangbeiInfoExample.Criteria add(final ZhuangbeiInfoExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ZhuangbeiInfoExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ZhuangbeiInfoExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ZhuangbeiInfoExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ZhuangbeiInfoExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ZhuangbeiInfoExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ZhuangbeiInfoExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ZhuangbeiInfoExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribIsNull() {
            this.addCriterion("attrib is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribIsNotNull() {
            this.addCriterion("attrib is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribEqualTo(final Integer value) {
            this.addCriterion("attrib =", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribEqualToColumn(final Column column) {
            this.addCriterion("attrib = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribNotEqualTo(final Integer value) {
            this.addCriterion("attrib <>", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribNotEqualToColumn(final Column column) {
            this.addCriterion("attrib <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribGreaterThan(final Integer value) {
            this.addCriterion("attrib >", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribGreaterThanColumn(final Column column) {
            this.addCriterion("attrib > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib >=", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribLessThan(final Integer value) {
            this.addCriterion("attrib <", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribLessThanColumn(final Column column) {
            this.addCriterion("attrib < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribLessThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib <=", value, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribIn(final List<Integer> values) {
            this.addCriterion("attrib in", values, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribNotIn(final List<Integer> values) {
            this.addCriterion("attrib not in", values, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib between", value1, value2, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAttribNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib not between", value1, value2, "attrib");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountIsNull() {
            this.addCriterion("amount is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountIsNotNull() {
            this.addCriterion("amount is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountEqualTo(final Integer value) {
            this.addCriterion("amount =", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountEqualToColumn(final Column column) {
            this.addCriterion("amount = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountNotEqualTo(final Integer value) {
            this.addCriterion("amount <>", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountNotEqualToColumn(final Column column) {
            this.addCriterion("amount <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountGreaterThan(final Integer value) {
            this.addCriterion("amount >", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountGreaterThanColumn(final Column column) {
            this.addCriterion("amount > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("amount >=", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("amount >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountLessThan(final Integer value) {
            this.addCriterion("amount <", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountLessThanColumn(final Column column) {
            this.addCriterion("amount < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountLessThanOrEqualTo(final Integer value) {
            this.addCriterion("amount <=", value, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("amount <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountIn(final List<Integer> values) {
            this.addCriterion("amount in", values, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountNotIn(final List<Integer> values) {
            this.addCriterion("amount not in", values, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountBetween(final Integer value1, final Integer value2) {
            this.addCriterion("amount between", value1, value2, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAmountNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("amount not between", value1, value2, "amount");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrIsNull() {
            this.addCriterion("str is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrIsNotNull() {
            this.addCriterion("str is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrEqualTo(final String value) {
            this.addCriterion("str =", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrEqualToColumn(final Column column) {
            this.addCriterion("str = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrNotEqualTo(final String value) {
            this.addCriterion("str <>", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrNotEqualToColumn(final Column column) {
            this.addCriterion("str <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrGreaterThan(final String value) {
            this.addCriterion("str >", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrGreaterThanColumn(final Column column) {
            this.addCriterion("str > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrGreaterThanOrEqualTo(final String value) {
            this.addCriterion("str >=", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("str >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrLessThan(final String value) {
            this.addCriterion("str <", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrLessThanColumn(final Column column) {
            this.addCriterion("str < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrLessThanOrEqualTo(final String value) {
            this.addCriterion("str <=", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("str <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrLike(final String value) {
            this.addCriterion("str like", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrNotLike(final String value) {
            this.addCriterion("str not like", value, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrIn(final List<String> values) {
            this.addCriterion("str in", values, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrNotIn(final List<String> values) {
            this.addCriterion("str not in", values, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrBetween(final String value1, final String value2) {
            this.addCriterion("str between", value1, value2, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andStrNotBetween(final String value1, final String value2) {
            this.addCriterion("str not between", value1, value2, "str");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityIsNull() {
            this.addCriterion("quality is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityIsNotNull() {
            this.addCriterion("quality is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityEqualTo(final String value) {
            this.addCriterion("quality =", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityEqualToColumn(final Column column) {
            this.addCriterion("quality = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityNotEqualTo(final String value) {
            this.addCriterion("quality <>", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityNotEqualToColumn(final Column column) {
            this.addCriterion("quality <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityGreaterThan(final String value) {
            this.addCriterion("quality >", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityGreaterThanColumn(final Column column) {
            this.addCriterion("quality > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityGreaterThanOrEqualTo(final String value) {
            this.addCriterion("quality >=", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("quality >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityLessThan(final String value) {
            this.addCriterion("quality <", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityLessThanColumn(final Column column) {
            this.addCriterion("quality < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityLessThanOrEqualTo(final String value) {
            this.addCriterion("quality <=", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("quality <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityLike(final String value) {
            this.addCriterion("quality like", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityNotLike(final String value) {
            this.addCriterion("quality not like", value, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityIn(final List<String> values) {
            this.addCriterion("quality in", values, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityNotIn(final List<String> values) {
            this.addCriterion("quality not in", values, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityBetween(final String value1, final String value2) {
            this.addCriterion("quality between", value1, value2, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andQualityNotBetween(final String value1, final String value2) {
            this.addCriterion("quality not between", value1, value2, "quality");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterIsNull() {
            this.addCriterion("master is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterIsNotNull() {
            this.addCriterion("master is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterEqualTo(final Integer value) {
            this.addCriterion("master =", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterEqualToColumn(final Column column) {
            this.addCriterion("master = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterNotEqualTo(final Integer value) {
            this.addCriterion("master <>", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterNotEqualToColumn(final Column column) {
            this.addCriterion("master <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterGreaterThan(final Integer value) {
            this.addCriterion("master >", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterGreaterThanColumn(final Column column) {
            this.addCriterion("master > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("master >=", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("master >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterLessThan(final Integer value) {
            this.addCriterion("master <", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterLessThanColumn(final Column column) {
            this.addCriterion("master < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterLessThanOrEqualTo(final Integer value) {
            this.addCriterion("master <=", value, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("master <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterIn(final List<Integer> values) {
            this.addCriterion("master in", values, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterNotIn(final List<Integer> values) {
            this.addCriterion("master not in", values, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterBetween(final Integer value1, final Integer value2) {
            this.addCriterion("master between", value1, value2, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMasterNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("master not between", value1, value2, "master");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalIsNull() {
            this.addCriterion("metal is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalIsNotNull() {
            this.addCriterion("metal is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalEqualTo(final Integer value) {
            this.addCriterion("metal =", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalEqualToColumn(final Column column) {
            this.addCriterion("metal = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalNotEqualTo(final Integer value) {
            this.addCriterion("metal <>", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalNotEqualToColumn(final Column column) {
            this.addCriterion("metal <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalGreaterThan(final Integer value) {
            this.addCriterion("metal >", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalGreaterThanColumn(final Column column) {
            this.addCriterion("metal > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("metal >=", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("metal >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalLessThan(final Integer value) {
            this.addCriterion("metal <", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalLessThanColumn(final Column column) {
            this.addCriterion("metal < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalLessThanOrEqualTo(final Integer value) {
            this.addCriterion("metal <=", value, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("metal <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalIn(final List<Integer> values) {
            this.addCriterion("metal in", values, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalNotIn(final List<Integer> values) {
            this.addCriterion("metal not in", values, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalBetween(final Integer value1, final Integer value2) {
            this.addCriterion("metal between", value1, value2, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andMetalNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("metal not between", value1, value2, "metal");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaIsNull() {
            this.addCriterion("mana is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaIsNotNull() {
            this.addCriterion("mana is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaEqualTo(final Integer value) {
            this.addCriterion("mana =", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaEqualToColumn(final Column column) {
            this.addCriterion("mana = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaNotEqualTo(final Integer value) {
            this.addCriterion("mana <>", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaNotEqualToColumn(final Column column) {
            this.addCriterion("mana <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaGreaterThan(final Integer value) {
            this.addCriterion("mana >", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaGreaterThanColumn(final Column column) {
            this.addCriterion("mana > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("mana >=", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("mana >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaLessThan(final Integer value) {
            this.addCriterion("mana <", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaLessThanColumn(final Column column) {
            this.addCriterion("mana < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaLessThanOrEqualTo(final Integer value) {
            this.addCriterion("mana <=", value, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("mana <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaIn(final List<Integer> values) {
            this.addCriterion("mana in", values, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaNotIn(final List<Integer> values) {
            this.addCriterion("mana not in", values, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mana between", value1, value2, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andManaNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mana not between", value1, value2, "mana");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateIsNull() {
            this.addCriterion("accurate is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateIsNotNull() {
            this.addCriterion("accurate is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateEqualTo(final Integer value) {
            this.addCriterion("accurate =", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateEqualToColumn(final Column column) {
            this.addCriterion("accurate = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateNotEqualTo(final Integer value) {
            this.addCriterion("accurate <>", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateNotEqualToColumn(final Column column) {
            this.addCriterion("accurate <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateGreaterThan(final Integer value) {
            this.addCriterion("accurate >", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateGreaterThanColumn(final Column column) {
            this.addCriterion("accurate > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("accurate >=", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("accurate >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateLessThan(final Integer value) {
            this.addCriterion("accurate <", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateLessThanColumn(final Column column) {
            this.addCriterion("accurate < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateLessThanOrEqualTo(final Integer value) {
            this.addCriterion("accurate <=", value, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("accurate <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateIn(final List<Integer> values) {
            this.addCriterion("accurate in", values, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateNotIn(final List<Integer> values) {
            this.addCriterion("accurate not in", values, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateBetween(final Integer value1, final Integer value2) {
            this.addCriterion("accurate between", value1, value2, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAccurateNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("accurate not between", value1, value2, "accurate");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefIsNull() {
            this.addCriterion("def is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefIsNotNull() {
            this.addCriterion("def is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefEqualTo(final Integer value) {
            this.addCriterion("def =", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefEqualToColumn(final Column column) {
            this.addCriterion("def = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefNotEqualTo(final Integer value) {
            this.addCriterion("def <>", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefNotEqualToColumn(final Column column) {
            this.addCriterion("def <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefGreaterThan(final Integer value) {
            this.addCriterion("def >", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefGreaterThanColumn(final Column column) {
            this.addCriterion("def > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("def >=", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("def >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefLessThan(final Integer value) {
            this.addCriterion("def <", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefLessThanColumn(final Column column) {
            this.addCriterion("def < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefLessThanOrEqualTo(final Integer value) {
            this.addCriterion("def <=", value, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("def <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefIn(final List<Integer> values) {
            this.addCriterion("def in", values, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefNotIn(final List<Integer> values) {
            this.addCriterion("def not in", values, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefBetween(final Integer value1, final Integer value2) {
            this.addCriterion("def between", value1, value2, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDefNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("def not between", value1, value2, "def");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexIsNull() {
            this.addCriterion("dex is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexIsNotNull() {
            this.addCriterion("dex is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexEqualTo(final Integer value) {
            this.addCriterion("dex =", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexEqualToColumn(final Column column) {
            this.addCriterion("dex = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexNotEqualTo(final Integer value) {
            this.addCriterion("dex <>", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexNotEqualToColumn(final Column column) {
            this.addCriterion("dex <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexGreaterThan(final Integer value) {
            this.addCriterion("dex >", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexGreaterThanColumn(final Column column) {
            this.addCriterion("dex > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("dex >=", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("dex >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexLessThan(final Integer value) {
            this.addCriterion("dex <", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexLessThanColumn(final Column column) {
            this.addCriterion("dex < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexLessThanOrEqualTo(final Integer value) {
            this.addCriterion("dex <=", value, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("dex <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexIn(final List<Integer> values) {
            this.addCriterion("dex in", values, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexNotIn(final List<Integer> values) {
            this.addCriterion("dex not in", values, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dex between", value1, value2, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDexNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("dex not between", value1, value2, "dex");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizIsNull() {
            this.addCriterion("wiz is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizIsNotNull() {
            this.addCriterion("wiz is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizEqualTo(final Integer value) {
            this.addCriterion("wiz =", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizEqualToColumn(final Column column) {
            this.addCriterion("wiz = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizNotEqualTo(final Integer value) {
            this.addCriterion("wiz <>", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizNotEqualToColumn(final Column column) {
            this.addCriterion("wiz <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizGreaterThan(final Integer value) {
            this.addCriterion("wiz >", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizGreaterThanColumn(final Column column) {
            this.addCriterion("wiz > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("wiz >=", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("wiz >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizLessThan(final Integer value) {
            this.addCriterion("wiz <", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizLessThanColumn(final Column column) {
            this.addCriterion("wiz < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizLessThanOrEqualTo(final Integer value) {
            this.addCriterion("wiz <=", value, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("wiz <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizIn(final List<Integer> values) {
            this.addCriterion("wiz in", values, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizNotIn(final List<Integer> values) {
            this.addCriterion("wiz not in", values, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizBetween(final Integer value1, final Integer value2) {
            this.addCriterion("wiz between", value1, value2, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andWizNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("wiz not between", value1, value2, "wiz");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryIsNull() {
            this.addCriterion("parry is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryIsNotNull() {
            this.addCriterion("parry is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryEqualTo(final Integer value) {
            this.addCriterion("parry =", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryEqualToColumn(final Column column) {
            this.addCriterion("parry = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryNotEqualTo(final Integer value) {
            this.addCriterion("parry <>", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryNotEqualToColumn(final Column column) {
            this.addCriterion("parry <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryGreaterThan(final Integer value) {
            this.addCriterion("parry >", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryGreaterThanColumn(final Column column) {
            this.addCriterion("parry > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("parry >=", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("parry >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryLessThan(final Integer value) {
            this.addCriterion("parry <", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryLessThanColumn(final Column column) {
            this.addCriterion("parry < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryLessThanOrEqualTo(final Integer value) {
            this.addCriterion("parry <=", value, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("parry <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryIn(final List<Integer> values) {
            this.addCriterion("parry in", values, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryNotIn(final List<Integer> values) {
            this.addCriterion("parry not in", values, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryBetween(final Integer value1, final Integer value2) {
            this.addCriterion("parry between", value1, value2, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andParryNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("parry not between", value1, value2, "parry");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }

        public ZhuangbeiInfoExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (ZhuangbeiInfoExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final ZhuangbeiInfoExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final ZhuangbeiInfoExample paramZhuangbeiInfoExample);
    }
}
