//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Shuxingduiying.Column;
import com.fengshen.db.domain.Shuxingduiying.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ShuxingduiyingExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ShuxingduiyingExample.Criteria> oredCriteria = new ArrayList();

    public ShuxingduiyingExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ShuxingduiyingExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final ShuxingduiyingExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ShuxingduiyingExample.Criteria or() {
        ShuxingduiyingExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ShuxingduiyingExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public ShuxingduiyingExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public ShuxingduiyingExample.Criteria createCriteria() {
        ShuxingduiyingExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ShuxingduiyingExample.Criteria createCriteriaInternal() {
        ShuxingduiyingExample.Criteria criteria = new ShuxingduiyingExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static ShuxingduiyingExample.Criteria newAndCreateCriteria() {
        ShuxingduiyingExample example = new ShuxingduiyingExample();
        return example.createCriteria();
    }

    public ShuxingduiyingExample when(final boolean condition, final ShuxingduiyingExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public ShuxingduiyingExample when(final boolean condition, final ShuxingduiyingExample.IExampleWhen then, final ShuxingduiyingExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends ShuxingduiyingExample.GeneratedCriteria {
        private ShuxingduiyingExample example;

        protected Criteria(final ShuxingduiyingExample example) {
            this.example = example;
        }

        public ShuxingduiyingExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ShuxingduiyingExample.Criteria andIf(final boolean ifAdd, final ShuxingduiyingExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public ShuxingduiyingExample.Criteria when(final boolean condition, final ShuxingduiyingExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public ShuxingduiyingExample.Criteria when(final boolean condition, final ShuxingduiyingExample.ICriteriaWhen then, final ShuxingduiyingExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public ShuxingduiyingExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            ShuxingduiyingExample.Criteria add(final ShuxingduiyingExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ShuxingduiyingExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ShuxingduiyingExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ShuxingduiyingExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ShuxingduiyingExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ShuxingduiyingExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ShuxingduiyingExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ShuxingduiyingExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenIsNull() {
            this.addCriterion("yingwen is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenIsNotNull() {
            this.addCriterion("yingwen is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenEqualTo(final String value) {
            this.addCriterion("yingwen =", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenEqualToColumn(final Column column) {
            this.addCriterion("yingwen = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenNotEqualTo(final String value) {
            this.addCriterion("yingwen <>", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenNotEqualToColumn(final Column column) {
            this.addCriterion("yingwen <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenGreaterThan(final String value) {
            this.addCriterion("yingwen >", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenGreaterThanColumn(final Column column) {
            this.addCriterion("yingwen > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenGreaterThanOrEqualTo(final String value) {
            this.addCriterion("yingwen >=", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("yingwen >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenLessThan(final String value) {
            this.addCriterion("yingwen <", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenLessThanColumn(final Column column) {
            this.addCriterion("yingwen < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenLessThanOrEqualTo(final String value) {
            this.addCriterion("yingwen <=", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("yingwen <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenLike(final String value) {
            this.addCriterion("yingwen like", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenNotLike(final String value) {
            this.addCriterion("yingwen not like", value, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenIn(final List<String> values) {
            this.addCriterion("yingwen in", values, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenNotIn(final List<String> values) {
            this.addCriterion("yingwen not in", values, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenBetween(final String value1, final String value2) {
            this.addCriterion("yingwen between", value1, value2, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andYingwenNotBetween(final String value1, final String value2) {
            this.addCriterion("yingwen not between", value1, value2, "yingwen");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }

        public ShuxingduiyingExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (ShuxingduiyingExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final ShuxingduiyingExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final ShuxingduiyingExample paramShuxingduiyingExample);
    }
}
