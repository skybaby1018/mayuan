package com.fengshen.db.domain;

import lombok.Data;

@Data
public class ChargePoint {
    private Integer id;
    private Integer no;
    private String awardstr;
    private String reward;
    private Integer point;
    private Integer leftNum;

    public ChargePoint(Integer id, Integer no, String awardstr, String reward, Integer point, Integer leftNum) {
        this.id = id;
        this.no = no;
        this.awardstr = awardstr;
        this.reward = reward;
        this.point = point;
        this.leftNum = leftNum;
    }

    public ChargePoint() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNo() {
        return this.no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public String getAwardstr() {
        return this.awardstr;
    }

    public void setAwardstr(String awardstr) {
        this.awardstr = awardstr == null ? null : awardstr.trim();
    }

    public Integer getPoint() {
        return this.point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public Integer getLeftNum() {
        return this.leftNum;
    }

    public void setLeftNum(Integer leftNum) {
        this.leftNum = leftNum;
    }
}
