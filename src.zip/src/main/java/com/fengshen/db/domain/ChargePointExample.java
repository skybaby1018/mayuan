//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.ArrayList;
import java.util.List;

public class ChargePointExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ChargePointExample.Criteria> oredCriteria = new ArrayList();

    public ChargePointExample() {
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ChargePointExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(ChargePointExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ChargePointExample.Criteria or() {
        ChargePointExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ChargePointExample.Criteria createCriteria() {
        ChargePointExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ChargePointExample.Criteria createCriteriaInternal() {
        ChargePointExample.Criteria criteria = new ChargePointExample.Criteria();
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static class Criteria extends ChargePointExample.GeneratedCriteria {
        protected Criteria() {
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(String condition, Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ChargePointExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ChargePointExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ChargePointExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ChargePointExample.Criterion(condition));
            }
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ChargePointExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ChargePointExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ChargePointExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdEqualTo(Integer value) {
            this.addCriterion("id =", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdNotEqualTo(Integer value) {
            this.addCriterion("id <>", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdGreaterThan(Integer value) {
            this.addCriterion("id >", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("id >=", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdLessThan(Integer value) {
            this.addCriterion("id <", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdLessThanOrEqualTo(Integer value) {
            this.addCriterion("id <=", value, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdIn(List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdNotIn(List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdBetween(Integer value1, Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andIdNotBetween(Integer value1, Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoIsNull() {
            this.addCriterion("no is null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoIsNotNull() {
            this.addCriterion("no is not null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoEqualTo(Integer value) {
            this.addCriterion("no =", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoNotEqualTo(Integer value) {
            this.addCriterion("no <>", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoGreaterThan(Integer value) {
            this.addCriterion("no >", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("no >=", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoLessThan(Integer value) {
            this.addCriterion("no <", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoLessThanOrEqualTo(Integer value) {
            this.addCriterion("no <=", value, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoIn(List<Integer> values) {
            this.addCriterion("no in", values, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoNotIn(List<Integer> values) {
            this.addCriterion("no not in", values, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoBetween(Integer value1, Integer value2) {
            this.addCriterion("no between", value1, value2, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andNoNotBetween(Integer value1, Integer value2) {
            this.addCriterion("no not between", value1, value2, "no");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrIsNull() {
            this.addCriterion("awardStr is null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrIsNotNull() {
            this.addCriterion("awardStr is not null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrEqualTo(String value) {
            this.addCriterion("awardStr =", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrNotEqualTo(String value) {
            this.addCriterion("awardStr <>", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrGreaterThan(String value) {
            this.addCriterion("awardStr >", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrGreaterThanOrEqualTo(String value) {
            this.addCriterion("awardStr >=", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrLessThan(String value) {
            this.addCriterion("awardStr <", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrLessThanOrEqualTo(String value) {
            this.addCriterion("awardStr <=", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrLike(String value) {
            this.addCriterion("awardStr like", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrNotLike(String value) {
            this.addCriterion("awardStr not like", value, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrIn(List<String> values) {
            this.addCriterion("awardStr in", values, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrNotIn(List<String> values) {
            this.addCriterion("awardStr not in", values, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrBetween(String value1, String value2) {
            this.addCriterion("awardStr between", value1, value2, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andAwardstrNotBetween(String value1, String value2) {
            this.addCriterion("awardStr not between", value1, value2, "awardstr");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointIsNull() {
            this.addCriterion("point is null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointIsNotNull() {
            this.addCriterion("point is not null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointEqualTo(Integer value) {
            this.addCriterion("point =", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointNotEqualTo(Integer value) {
            this.addCriterion("point <>", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointGreaterThan(Integer value) {
            this.addCriterion("point >", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("point >=", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointLessThan(Integer value) {
            this.addCriterion("point <", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointLessThanOrEqualTo(Integer value) {
            this.addCriterion("point <=", value, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointIn(List<Integer> values) {
            this.addCriterion("point in", values, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointNotIn(List<Integer> values) {
            this.addCriterion("point not in", values, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointBetween(Integer value1, Integer value2) {
            this.addCriterion("point between", value1, value2, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andPointNotBetween(Integer value1, Integer value2) {
            this.addCriterion("point not between", value1, value2, "point");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumIsNull() {
            this.addCriterion("left_num is null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumIsNotNull() {
            this.addCriterion("left_num is not null");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumEqualTo(Integer value) {
            this.addCriterion("left_num =", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumNotEqualTo(Integer value) {
            this.addCriterion("left_num <>", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumGreaterThan(Integer value) {
            this.addCriterion("left_num >", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("left_num >=", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumLessThan(Integer value) {
            this.addCriterion("left_num <", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumLessThanOrEqualTo(Integer value) {
            this.addCriterion("left_num <=", value, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumIn(List<Integer> values) {
            this.addCriterion("left_num in", values, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumNotIn(List<Integer> values) {
            this.addCriterion("left_num not in", values, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumBetween(Integer value1, Integer value2) {
            this.addCriterion("left_num between", value1, value2, "leftNum");
            return (ChargePointExample.Criteria) this;
        }

        public ChargePointExample.Criteria andLeftNumNotBetween(Integer value1, Integer value2) {
            this.addCriterion("left_num not between", value1, value2, "leftNum");
            return (ChargePointExample.Criteria) this;
        }
    }
}
