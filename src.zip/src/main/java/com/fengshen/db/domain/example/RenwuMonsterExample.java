//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.RenwuMonster.Column;
import com.fengshen.db.domain.RenwuMonster.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RenwuMonsterExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<RenwuMonsterExample.Criteria> oredCriteria = new ArrayList();

    public RenwuMonsterExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<RenwuMonsterExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final RenwuMonsterExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public RenwuMonsterExample.Criteria or() {
        RenwuMonsterExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public RenwuMonsterExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public RenwuMonsterExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public RenwuMonsterExample.Criteria createCriteria() {
        RenwuMonsterExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected RenwuMonsterExample.Criteria createCriteriaInternal() {
        RenwuMonsterExample.Criteria criteria = new RenwuMonsterExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static RenwuMonsterExample.Criteria newAndCreateCriteria() {
        RenwuMonsterExample example = new RenwuMonsterExample();
        return example.createCriteria();
    }

    public RenwuMonsterExample when(final boolean condition, final RenwuMonsterExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public RenwuMonsterExample when(final boolean condition, final RenwuMonsterExample.IExampleWhen then, final RenwuMonsterExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends RenwuMonsterExample.GeneratedCriteria {
        private RenwuMonsterExample example;

        protected Criteria(final RenwuMonsterExample example) {
            this.example = example;
        }

        public RenwuMonsterExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public RenwuMonsterExample.Criteria andIf(final boolean ifAdd, final RenwuMonsterExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public RenwuMonsterExample.Criteria when(final boolean condition, final RenwuMonsterExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public RenwuMonsterExample.Criteria when(final boolean condition, final RenwuMonsterExample.ICriteriaWhen then, final RenwuMonsterExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public RenwuMonsterExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            RenwuMonsterExample.Criteria add(final RenwuMonsterExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<RenwuMonsterExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<RenwuMonsterExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<RenwuMonsterExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new RenwuMonsterExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new RenwuMonsterExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new RenwuMonsterExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public RenwuMonsterExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameIsNull() {
            this.addCriterion("map_name is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameIsNotNull() {
            this.addCriterion("map_name is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameEqualTo(final String value) {
            this.addCriterion("map_name =", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameEqualToColumn(final Column column) {
            this.addCriterion("map_name = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameNotEqualTo(final String value) {
            this.addCriterion("map_name <>", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameNotEqualToColumn(final Column column) {
            this.addCriterion("map_name <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameGreaterThan(final String value) {
            this.addCriterion("map_name >", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameGreaterThanColumn(final Column column) {
            this.addCriterion("map_name > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("map_name >=", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("map_name >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameLessThan(final String value) {
            this.addCriterion("map_name <", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameLessThanColumn(final Column column) {
            this.addCriterion("map_name < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameLessThanOrEqualTo(final String value) {
            this.addCriterion("map_name <=", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("map_name <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameLike(final String value) {
            this.addCriterion("map_name like", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameNotLike(final String value) {
            this.addCriterion("map_name not like", value, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameIn(final List<String> values) {
            this.addCriterion("map_name in", values, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameNotIn(final List<String> values) {
            this.addCriterion("map_name not in", values, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameBetween(final String value1, final String value2) {
            this.addCriterion("map_name between", value1, value2, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andMapNameNotBetween(final String value1, final String value2) {
            this.addCriterion("map_name not between", value1, value2, "mapName");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXIsNull() {
            this.addCriterion("x is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXIsNotNull() {
            this.addCriterion("x is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXEqualTo(final Integer value) {
            this.addCriterion("x =", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXEqualToColumn(final Column column) {
            this.addCriterion("x = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXNotEqualTo(final Integer value) {
            this.addCriterion("x <>", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXNotEqualToColumn(final Column column) {
            this.addCriterion("x <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXGreaterThan(final Integer value) {
            this.addCriterion("x >", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXGreaterThanColumn(final Column column) {
            this.addCriterion("x > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("x >=", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("x >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXLessThan(final Integer value) {
            this.addCriterion("x <", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXLessThanColumn(final Column column) {
            this.addCriterion("x < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXLessThanOrEqualTo(final Integer value) {
            this.addCriterion("x <=", value, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("x <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXIn(final List<Integer> values) {
            this.addCriterion("x in", values, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXNotIn(final List<Integer> values) {
            this.addCriterion("x not in", values, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x between", value1, value2, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andXNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x not between", value1, value2, "x");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYIsNull() {
            this.addCriterion("y is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYIsNotNull() {
            this.addCriterion("y is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYEqualTo(final Integer value) {
            this.addCriterion("y =", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYEqualToColumn(final Column column) {
            this.addCriterion("y = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYNotEqualTo(final Integer value) {
            this.addCriterion("y <>", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYNotEqualToColumn(final Column column) {
            this.addCriterion("y <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYGreaterThan(final Integer value) {
            this.addCriterion("y >", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYGreaterThanColumn(final Column column) {
            this.addCriterion("y > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("y >=", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("y >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYLessThan(final Integer value) {
            this.addCriterion("y <", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYLessThanColumn(final Column column) {
            this.addCriterion("y < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYLessThanOrEqualTo(final Integer value) {
            this.addCriterion("y <=", value, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("y <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYIn(final List<Integer> values) {
            this.addCriterion("y in", values, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYNotIn(final List<Integer> values) {
            this.addCriterion("y not in", values, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y between", value1, value2, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andYNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y not between", value1, value2, "y");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconIsNull() {
            this.addCriterion("icon is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconIsNotNull() {
            this.addCriterion("icon is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconEqualTo(final Integer value) {
            this.addCriterion("icon =", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconEqualToColumn(final Column column) {
            this.addCriterion("icon = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconNotEqualTo(final Integer value) {
            this.addCriterion("icon <>", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconNotEqualToColumn(final Column column) {
            this.addCriterion("icon <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconGreaterThan(final Integer value) {
            this.addCriterion("icon >", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconGreaterThanColumn(final Column column) {
            this.addCriterion("icon > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("icon >=", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconLessThan(final Integer value) {
            this.addCriterion("icon <", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconLessThanColumn(final Column column) {
            this.addCriterion("icon < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconLessThanOrEqualTo(final Integer value) {
            this.addCriterion("icon <=", value, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconIn(final List<Integer> values) {
            this.addCriterion("icon in", values, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconNotIn(final List<Integer> values) {
            this.addCriterion("icon not in", values, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon between", value1, value2, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andIconNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon not between", value1, value2, "icon");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsIsNull() {
            this.addCriterion("skills is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsIsNotNull() {
            this.addCriterion("skills is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsEqualTo(final String value) {
            this.addCriterion("skills =", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsEqualToColumn(final Column column) {
            this.addCriterion("skills = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsNotEqualTo(final String value) {
            this.addCriterion("skills <>", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsNotEqualToColumn(final Column column) {
            this.addCriterion("skills <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsGreaterThan(final String value) {
            this.addCriterion("skills >", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsGreaterThanColumn(final Column column) {
            this.addCriterion("skills > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skills >=", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skills >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsLessThan(final String value) {
            this.addCriterion("skills <", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsLessThanColumn(final Column column) {
            this.addCriterion("skills < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsLessThanOrEqualTo(final String value) {
            this.addCriterion("skills <=", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skills <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsLike(final String value) {
            this.addCriterion("skills like", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsNotLike(final String value) {
            this.addCriterion("skills not like", value, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsIn(final List<String> values) {
            this.addCriterion("skills in", values, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsNotIn(final List<String> values) {
            this.addCriterion("skills not in", values, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsBetween(final String value1, final String value2) {
            this.addCriterion("skills between", value1, value2, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andSkillsNotBetween(final String value1, final String value2) {
            this.addCriterion("skills not between", value1, value2, "skills");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }

        public RenwuMonsterExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (RenwuMonsterExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final RenwuMonsterExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final RenwuMonsterExample paramRenwuMonsterExample);
    }
}
