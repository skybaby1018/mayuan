//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class Charge implements Cloneable, Serializable {
    public static final Boolean IS_DELETED;
    public static final Boolean NOT_DELETED;
    private Integer id;
    private String accountname;
    private Integer coin;
    private Integer state;
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime addTime;
    @JsonDeserialize(
            using = LocalDateTimeDeserializer.class
    )
    @JsonSerialize(
            using = LocalDateTimeSerializer.class
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime updateTime;
    private Integer type;
    private Boolean deleted;
    private Integer money;
    private Integer score;
    private String code;
    private Integer serverId;
    private Integer charaId;
    private String lingquren;
    /**
     * 支付订单号
     */
    private String tradeNo;

    /**
     * 商家订单号
     */
    private String outTradeNo;
    private String curr_date;
    private Date charge_time;
    private static final long serialVersionUID = 1L;

    static {
        IS_DELETED = Charge.Deleted.IS_DELETED.value();
        NOT_DELETED = Charge.Deleted.NOT_DELETED.value();
    }

    public Charge() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public String getAccountname() {
        return this.accountname;
    }

    public void setAccountname(final String accountname) {
        this.accountname = accountname;
    }

    public Integer getCoin() {
        return this.coin;
    }

    public void setCoin(final Integer coin) {
        this.coin = coin;
    }

    public Integer getState() {
        return this.state;
    }

    public void setState(final Integer state) {
        this.state = state;
    }

    public LocalDateTime getAddTime() {
        return this.addTime;
    }

    public void setAddTime(final LocalDateTime addTime) {
        this.addTime = addTime;
    }

    public LocalDateTime getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(final LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public void andLogicalDeleted(final boolean deleted) {
        this.setDeleted(deleted ? Charge.Deleted.IS_DELETED.value() : Charge.Deleted.NOT_DELETED.value());
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getMoney() {
        return this.money;
    }

    public void setMoney(final Integer money) {
        this.money = money;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getLingquren() {
        return lingquren;
    }

    public void setLingquren(String lingquren) {
        this.lingquren = lingquren;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }


    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }


    public String getCurr_date() {
        return curr_date;
    }

    public void setCurr_date(String curr_date) {
        this.curr_date = curr_date;
    }

    public Date getCharge_time() {
        return charge_time;
    }

    public void setCharge_time(Date charge_time) {
        this.charge_time = charge_time;
    }

    public Integer getServerId() {
        return serverId;
    }

    public void setServerId(Integer serverId) {
        this.serverId = serverId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(this.hashCode());
        sb.append(", IS_DELETED=").append(IS_DELETED);
        sb.append(", NOT_DELETED=").append(NOT_DELETED);
        sb.append(", id=").append(this.id);
        sb.append(", accountname=").append(this.accountname);
        sb.append(", coin=").append(this.coin);
        sb.append(", state=").append(this.state);
        sb.append(", addTime=").append(this.addTime);
        sb.append(", updateTime=").append(this.updateTime);
        sb.append(", deleted=").append(this.deleted);
        sb.append(", money=").append(this.money);
        sb.append(", score=").append(this.score);
        sb.append(", code=").append(this.code);
        sb.append(", tradeNo=").append(this.tradeNo);
        sb.append(", outTradeNo=").append(this.outTradeNo);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(final Object that) {
        if (this == that) {
            return true;
        } else if (that == null) {
            return false;
        } else if (this.getClass() != that.getClass()) {
            return false;
        } else {
            Charge other = (Charge) that;
            if (this.getId() == null) {
                if (other.getId() != null) {
                    return false;
                }
            } else if (!this.getId().equals(other.getId())) {
                return false;
            }

            if (this.getAccountname() == null) {
                if (other.getAccountname() != null) {
                    return false;
                }
            } else if (!this.getAccountname().equals(other.getAccountname())) {
                return false;
            }

            if (this.getCoin() == null) {
                if (other.getCoin() != null) {
                    return false;
                }
            } else if (!this.getCoin().equals(other.getCoin())) {
                return false;
            }

            if (this.getState() == null) {
                if (other.getState() != null) {
                    return false;
                }
            } else if (!this.getState().equals(other.getState())) {
                return false;
            }

            if (this.getAddTime() == null) {
                if (other.getAddTime() != null) {
                    return false;
                }
            } else if (!this.getAddTime().equals(other.getAddTime())) {
                return false;
            }

            if (this.getUpdateTime() == null) {
                if (other.getUpdateTime() != null) {
                    return false;
                }
            } else if (!this.getUpdateTime().equals(other.getUpdateTime())) {
                return false;
            }

            if (this.getDeleted() == null) {
                if (other.getDeleted() != null) {
                    return false;
                }
            } else if (!this.getDeleted().equals(other.getDeleted())) {
                return false;
            }

            if (this.getMoney() == null) {
                if (other.getMoney() != null) {
                    return false;
                }
            } else if (!this.getMoney().equals(other.getMoney())) {
                return false;
            }

            if (this.getCode() == null) {
                if (other.getCode() != null) {
                    return false;
                }
            } else if (!this.getCode().equals(other.getCode())) {
                return false;
            }

            return true;
        }
    }

    public Integer getCharaId() {
        return charaId;
    }

    public void setCharaId(Integer charaId) {
        this.charaId = charaId;
    }

    @Override
    public int hashCode() {
        int prime = 1;
        int result = 1;
        result = 31 * result + (this.getId() == null ? 0 : this.getId().hashCode());
        result = 31 * result + (this.getAccountname() == null ? 0 : this.getAccountname().hashCode());
        result = 31 * result + (this.getCoin() == null ? 0 : this.getCoin().hashCode());
        result = 31 * result + (this.getState() == null ? 0 : this.getState().hashCode());
        result = 31 * result + (this.getAddTime() == null ? 0 : this.getAddTime().hashCode());
        result = 31 * result + (this.getUpdateTime() == null ? 0 : this.getUpdateTime().hashCode());
        result = 31 * result + (this.getDeleted() == null ? 0 : this.getDeleted().hashCode());
        result = 31 * result + (this.getMoney() == null ? 0 : this.getMoney().hashCode());
        result = 31 * result + (this.getCode() == null ? 0 : this.getCode().hashCode());
        return result;
    }

    @Override
    public Charge clone() throws CloneNotSupportedException {
        return (Charge) super.clone();
    }

    public static enum Column {
        id("id", "id", "INTEGER", false),
        accountname("accountname", "accountname", "VARCHAR", false),
        coin("coin", "coin", "INTEGER", false),
        state("state", "state", "INTEGER", true),
        addTime("add_time", "addTime", "TIMESTAMP", false),
        updateTime("update_time", "updateTime", "TIMESTAMP", false),
        deleted("deleted", "deleted", "BIT", false),
        server_id("server_id", "server_id", "INTEGER", false),
        money("money", "money", "INTEGER", false),
        score("score", "score", "INTEGER", false),
        code("code", "code", "VARCHAR", false),
        trade_no("trade_no", "trade_no", "VARCHAR", false),
        out_trade_No("out_trade_No", "out_trade_No", "VARCHAR", false);

        private static final String BEGINNING_DELIMITER = "`";
        private static final String ENDING_DELIMITER = "`";
        private final String column;
        private final boolean isColumnNameDelimited;
        private final String javaProperty;
        private final String jdbcType;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        public String getJavaProperty() {
            return this.javaProperty;
        }

        public String getJdbcType() {
            return this.jdbcType;
        }

        private Column(final String column, final String javaProperty, final String jdbcType, final boolean isColumnNameDelimited) {
            this.column = column;
            this.javaProperty = javaProperty;
            this.jdbcType = jdbcType;
            this.isColumnNameDelimited = isColumnNameDelimited;
        }

        public String desc() {
            return String.valueOf(this.getEscapedColumnName()) + " DESC";
        }

        public String asc() {
            return String.valueOf(this.getEscapedColumnName()) + " ASC";
        }

        public static Charge.Column[] excludes(final Charge.Column... excludes) {
            ArrayList<Charge.Column> columns = new ArrayList(Arrays.asList(values()));
            if (excludes != null && excludes.length > 0) {
                columns.removeAll(new ArrayList(Arrays.asList(excludes)));
            }

            return (Charge.Column[]) columns.toArray(new Charge.Column[0]);
        }

        public String getEscapedColumnName() {
            return this.isColumnNameDelimited ? "`" + this.column + "`" : this.column;
        }
    }

    public static enum Deleted {
        NOT_DELETED(new Boolean("0"), "未删除"),
        IS_DELETED(new Boolean("1"), "已删除");

        private final Boolean value;
        private final String name;

        private Deleted(final Boolean value, final String name) {
            this.value = value;
            this.name = name;
        }

        public Boolean getValue() {
            return this.value;
        }

        public Boolean value() {
            return this.value;
        }

        public String getName() {
            return this.name;
        }


    }
}
