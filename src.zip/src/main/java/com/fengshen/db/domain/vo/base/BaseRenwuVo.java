//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Renwu;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseRenwuVo {
    public Integer id;
    public String uncontent;
    public String npcName;
    public String currentTask;
    public String showName;
    public String taskPrompt;
    public String reward;

    public BaseRenwuVo() {
    }

    public BaseRenwuVo(final Renwu vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.uncontent = vo.getUncontent();
            this.npcName = vo.getNpcName();
            this.currentTask = vo.getCurrentTask();
            this.showName = vo.getShowName();
            this.taskPrompt = vo.getTaskPrompt();
            this.reward = vo.getReward();
        }
    }

    public static final BaseRenwuVo t(final Renwu vo) {
        return new BaseRenwuVo(vo);
    }

    public static final List<BaseRenwuVo> t(final List<Renwu> list) {
        List<BaseRenwuVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Renwu temp = (Renwu) var3.next();
            listVo.add(new BaseRenwuVo(temp));
        }

        return listVo;
    }
}
