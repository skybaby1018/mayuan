//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Charge.Column;
import com.fengshen.db.domain.Charge.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChargeExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ChargeExample.Criteria> oredCriteria = new ArrayList();

    public ChargeExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ChargeExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final ChargeExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ChargeExample.Criteria or() {
        ChargeExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ChargeExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public ChargeExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public ChargeExample.Criteria createCriteria() {
        ChargeExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ChargeExample.Criteria createCriteriaInternal() {
        ChargeExample.Criteria criteria = new ChargeExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static ChargeExample.Criteria newAndCreateCriteria() {
        ChargeExample example = new ChargeExample();
        return example.createCriteria();
    }

    public ChargeExample when(final boolean condition, final ChargeExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public ChargeExample when(final boolean condition, final ChargeExample.IExampleWhen then, final ChargeExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends ChargeExample.GeneratedCriteria {
        private ChargeExample example;

        protected Criteria(final ChargeExample example) {
            this.example = example;
        }

        public ChargeExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ChargeExample.Criteria andIf(final boolean ifAdd, final ChargeExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public ChargeExample.Criteria when(final boolean condition, final ChargeExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public ChargeExample.Criteria when(final boolean condition, final ChargeExample.ICriteriaWhen then, final ChargeExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public ChargeExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            ChargeExample.Criteria add(final ChargeExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ChargeExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ChargeExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ChargeExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ChargeExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ChargeExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ChargeExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ChargeExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCharaIdEqualToColumn(final Integer charaId) {
            this.addCriterion("chara_id =", charaId, "charaId");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andServerIdEqualToColumn(final String serverId) {
            this.addCriterion("server_id =", serverId, "serverId");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenIsNull() {
            this.addCriterion("lingquren is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenIsNotNull() {
            this.addCriterion("lingquren is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenEqualTo(final String value) {
            this.addCriterion("lingquren =", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenEqualToColumn(final Column column) {
            this.addCriterion("lingquren = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenNotEqualTo(final String value) {
            this.addCriterion("lingquren <>", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenNotEqualToColumn(final Column column) {
            this.addCriterion("lingquren <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenGreaterThan(final String value) {
            this.addCriterion("lingquren >", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenGreaterThanColumn(final Column column) {
            this.addCriterion("lingquren > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenGreaterThanOrEqualTo(final String value) {
            this.addCriterion("lingquren >=", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("lingquren >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenLessThan(final String value) {
            this.addCriterion("lingquren <", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenLessThanColumn(final Column column) {
            this.addCriterion("lingquren < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenLessThanOrEqualTo(final String value) {
            this.addCriterion("lingquren <=", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("lingquren <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenLike(final String value) {
            this.addCriterion("lingquren like", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenNotLike(final String value) {
            this.addCriterion("lingquren not like", value, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenIn(final List<String> values) {
            this.addCriterion("lingquren in", values, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenNotIn(final List<String> values) {
            this.addCriterion("lingquren not in", values, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenBetween(final String value1, final String value2) {
            this.addCriterion("lingquren between", value1, value2, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andLingqurenNotBetween(final String value1, final String value2) {
            this.addCriterion("lingquren not between", value1, value2, "lingquren");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameIsNull() {
            this.addCriterion("accountname is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameIsNotNull() {
            this.addCriterion("accountname is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameEqualTo(final String value) {
            this.addCriterion("accountname =", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameEqualToColumn(final Column column) {
            this.addCriterion("accountname = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameNotEqualTo(final String value) {
            this.addCriterion("accountname <>", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameNotEqualToColumn(final Column column) {
            this.addCriterion("accountname <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameGreaterThan(final String value) {
            this.addCriterion("accountname >", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameGreaterThanColumn(final Column column) {
            this.addCriterion("accountname > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("accountname >=", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("accountname >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameLessThan(final String value) {
            this.addCriterion("accountname <", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameLessThanColumn(final Column column) {
            this.addCriterion("accountname < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameLessThanOrEqualTo(final String value) {
            this.addCriterion("accountname <=", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("accountname <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameLike(final String value) {
            this.addCriterion("accountname like", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameNotLike(final String value) {
            this.addCriterion("accountname not like", value, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameIn(final List<String> values) {
            this.addCriterion("accountname in", values, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameNotIn(final List<String> values) {
            this.addCriterion("accountname not in", values, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameBetween(final String value1, final String value2) {
            this.addCriterion("accountname between", value1, value2, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAccountnameNotBetween(final String value1, final String value2) {
            this.addCriterion("accountname not between", value1, value2, "accountname");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinIsNull() {
            this.addCriterion("coin is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinIsNotNull() {
            this.addCriterion("coin is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinEqualTo(final Integer value) {
            this.addCriterion("coin =", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinEqualToColumn(final Column column) {
            this.addCriterion("coin = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinNotEqualTo(final Integer value) {
            this.addCriterion("coin <>", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinNotEqualToColumn(final Column column) {
            this.addCriterion("coin <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinGreaterThan(final Integer value) {
            this.addCriterion("coin >", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinGreaterThanColumn(final Column column) {
            this.addCriterion("coin > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("coin >=", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("coin >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinLessThan(final Integer value) {
            this.addCriterion("coin <", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinLessThanColumn(final Column column) {
            this.addCriterion("coin < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinLessThanOrEqualTo(final Integer value) {
            this.addCriterion("coin <=", value, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("coin <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinIn(final List<Integer> values) {
            this.addCriterion("coin in", values, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinNotIn(final List<Integer> values) {
            this.addCriterion("coin not in", values, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinBetween(final Integer value1, final Integer value2) {
            this.addCriterion("coin between", value1, value2, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCoinNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("coin not between", value1, value2, "coin");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateIsNull() {
            this.addCriterion("`state` is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateIsNotNull() {
            this.addCriterion("`state` is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateEqualTo(final Integer value) {
            this.addCriterion("`state` =", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateEqualToColumn(final Column column) {
            this.addCriterion("`state` = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateNotEqualTo(final Integer value) {
            this.addCriterion("`state` <>", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateNotEqualToColumn(final Column column) {
            this.addCriterion("`state` <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateGreaterThan(final Integer value) {
            this.addCriterion("`state` >", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateGreaterThanColumn(final Column column) {
            this.addCriterion("`state` > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`state` >=", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`state` >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateLessThan(final Integer value) {
            this.addCriterion("`state` <", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateLessThanColumn(final Column column) {
            this.addCriterion("`state` < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`state` <=", value, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`state` <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateIn(final List<Integer> values) {
            this.addCriterion("`state` in", values, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateNotIn(final List<Integer> values) {
            this.addCriterion("`state` not in", values, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`state` between", value1, value2, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andStateNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`state` not between", value1, value2, "state");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyIsNull() {
            this.addCriterion("money is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyIsNotNull() {
            this.addCriterion("money is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyEqualTo(final Integer value) {
            this.addCriterion("money =", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyEqualToColumn(final Column column) {
            this.addCriterion("money = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyNotEqualTo(final Integer value) {
            this.addCriterion("money <>", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyNotEqualToColumn(final Column column) {
            this.addCriterion("money <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyGreaterThan(final Integer value) {
            this.addCriterion("money >", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyGreaterThanColumn(final Column column) {
            this.addCriterion("money > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("money >=", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("money >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyLessThan(final Integer value) {
            this.addCriterion("money <", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyLessThanColumn(final Column column) {
            this.addCriterion("money < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyLessThanOrEqualTo(final Integer value) {
            this.addCriterion("money <=", value, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("money <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyIn(final List<Integer> values) {
            this.addCriterion("money in", values, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyNotIn(final List<Integer> values) {
            this.addCriterion("money not in", values, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyBetween(final Integer value1, final Integer value2) {
            this.addCriterion("money between", value1, value2, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andMoneyNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("money not between", value1, value2, "money");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeIsNull() {
            this.addCriterion("code is null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeIsNotNull() {
            this.addCriterion("code is not null");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeEqualTo(final String value) {
            this.addCriterion("code =", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeEqualToColumn(final Column column) {
            this.addCriterion("code = " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeNotEqualTo(final String value) {
            this.addCriterion("code <>", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeNotEqualToColumn(final Column column) {
            this.addCriterion("code <> " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeGreaterThan(final String value) {
            this.addCriterion("code >", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeGreaterThanColumn(final Column column) {
            this.addCriterion("code > " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("code >=", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("code >= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeLessThan(final String value) {
            this.addCriterion("code <", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeLessThanColumn(final Column column) {
            this.addCriterion("code < " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeLessThanOrEqualTo(final String value) {
            this.addCriterion("code <=", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("code <= " + column.getEscapedColumnName());
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeLike(final String value) {
            this.addCriterion("code like", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeNotLike(final String value) {
            this.addCriterion("code not like", value, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeIn(final List<String> values) {
            this.addCriterion("code in", values, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeNotIn(final List<String> values) {
            this.addCriterion("code not in", values, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeBetween(final String value1, final String value2) {
            this.addCriterion("code between", value1, value2, "code");
            return (ChargeExample.Criteria) this;
        }

        public ChargeExample.Criteria andCodeNotBetween(final String value1, final String value2) {
            this.addCriterion("code not between", value1, value2, "code");
            return (ChargeExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final ChargeExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final ChargeExample paramChargeExample);
    }
}
