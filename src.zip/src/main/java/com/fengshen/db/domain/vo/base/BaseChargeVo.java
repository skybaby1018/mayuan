//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Charge;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseChargeVo {
    public Integer id;
    public String accountname;
    public Integer coin;
    public Integer state;
    public Integer money;
    public String code;

    public BaseChargeVo() {
    }

    public BaseChargeVo(final Charge vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.accountname = vo.getAccountname();
            this.coin = vo.getCoin();
            this.state = vo.getState();
            this.money = vo.getMoney();
            this.code = vo.getCode();
        }
    }

    public static final BaseChargeVo t(final Charge vo) {
        return new BaseChargeVo(vo);
    }

    public static final List<BaseChargeVo> t(final List<Charge> list) {
        List<BaseChargeVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Charge temp = (Charge) var3.next();
            listVo.add(new BaseChargeVo(temp));
        }

        return listVo;
    }
}
