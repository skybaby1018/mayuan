//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Notice.Column;
import com.fengshen.db.domain.Notice.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NoticeExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<NoticeExample.Criteria> oredCriteria = new ArrayList();

    public NoticeExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<NoticeExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final NoticeExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public NoticeExample.Criteria or() {
        NoticeExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public NoticeExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public NoticeExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public NoticeExample.Criteria createCriteria() {
        NoticeExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected NoticeExample.Criteria createCriteriaInternal() {
        NoticeExample.Criteria criteria = new NoticeExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static NoticeExample.Criteria newAndCreateCriteria() {
        NoticeExample example = new NoticeExample();
        return example.createCriteria();
    }

    public NoticeExample when(final boolean condition, final NoticeExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public NoticeExample when(final boolean condition, final NoticeExample.IExampleWhen then, final NoticeExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends NoticeExample.GeneratedCriteria {
        private NoticeExample example;

        protected Criteria(final NoticeExample example) {
            this.example = example;
        }

        public NoticeExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public NoticeExample.Criteria andIf(final boolean ifAdd, final NoticeExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public NoticeExample.Criteria when(final boolean condition, final NoticeExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public NoticeExample.Criteria when(final boolean condition, final NoticeExample.ICriteriaWhen then, final NoticeExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public NoticeExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            NoticeExample.Criteria add(final NoticeExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<NoticeExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<NoticeExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<NoticeExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new NoticeExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new NoticeExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new NoticeExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public NoticeExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageIsNull() {
            this.addCriterion("message is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageIsNotNull() {
            this.addCriterion("message is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageEqualTo(final String value) {
            this.addCriterion("message =", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageEqualToColumn(final Column column) {
            this.addCriterion("message = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageNotEqualTo(final String value) {
            this.addCriterion("message <>", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageNotEqualToColumn(final Column column) {
            this.addCriterion("message <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageGreaterThan(final String value) {
            this.addCriterion("message >", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageGreaterThanColumn(final Column column) {
            this.addCriterion("message > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageGreaterThanOrEqualTo(final String value) {
            this.addCriterion("message >=", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("message >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageLessThan(final String value) {
            this.addCriterion("message <", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageLessThanColumn(final Column column) {
            this.addCriterion("message < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageLessThanOrEqualTo(final String value) {
            this.addCriterion("message <=", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("message <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageLike(final String value) {
            this.addCriterion("message like", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageNotLike(final String value) {
            this.addCriterion("message not like", value, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageIn(final List<String> values) {
            this.addCriterion("message in", values, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageNotIn(final List<String> values) {
            this.addCriterion("message not in", values, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageBetween(final String value1, final String value2) {
            this.addCriterion("message between", value1, value2, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andMessageNotBetween(final String value1, final String value2) {
            this.addCriterion("message not between", value1, value2, "message");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeIsNull() {
            this.addCriterion("`time` is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeIsNotNull() {
            this.addCriterion("`time` is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeEqualTo(final Integer value) {
            this.addCriterion("`time` =", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeEqualToColumn(final Column column) {
            this.addCriterion("`time` = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeNotEqualTo(final Integer value) {
            this.addCriterion("`time` <>", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeNotEqualToColumn(final Column column) {
            this.addCriterion("`time` <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeGreaterThan(final Integer value) {
            this.addCriterion("`time` >", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeGreaterThanColumn(final Column column) {
            this.addCriterion("`time` > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`time` >=", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`time` >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeLessThan(final Integer value) {
            this.addCriterion("`time` <", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeLessThanColumn(final Column column) {
            this.addCriterion("`time` < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`time` <=", value, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`time` <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeIn(final List<Integer> values) {
            this.addCriterion("`time` in", values, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeNotIn(final List<Integer> values) {
            this.addCriterion("`time` not in", values, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`time` between", value1, value2, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andTimeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`time` not between", value1, value2, "time");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (NoticeExample.Criteria) this;
        }

        public NoticeExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (NoticeExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final NoticeExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final NoticeExample paramNoticeExample);
    }
}
