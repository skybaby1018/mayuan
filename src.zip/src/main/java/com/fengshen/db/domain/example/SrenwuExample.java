//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Srenwu.Column;
import com.fengshen.db.domain.Srenwu.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SrenwuExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<SrenwuExample.Criteria> oredCriteria = new ArrayList();

    public SrenwuExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<SrenwuExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final SrenwuExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public SrenwuExample.Criteria or() {
        SrenwuExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public SrenwuExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public SrenwuExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public SrenwuExample.Criteria createCriteria() {
        SrenwuExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected SrenwuExample.Criteria createCriteriaInternal() {
        SrenwuExample.Criteria criteria = new SrenwuExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static SrenwuExample.Criteria newAndCreateCriteria() {
        SrenwuExample example = new SrenwuExample();
        return example.createCriteria();
    }

    public SrenwuExample when(final boolean condition, final SrenwuExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public SrenwuExample when(final boolean condition, final SrenwuExample.IExampleWhen then, final SrenwuExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends SrenwuExample.GeneratedCriteria {
        private SrenwuExample example;

        protected Criteria(final SrenwuExample example) {
            this.example = example;
        }

        public SrenwuExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public SrenwuExample.Criteria andIf(final boolean ifAdd, final SrenwuExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public SrenwuExample.Criteria when(final boolean condition, final SrenwuExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public SrenwuExample.Criteria when(final boolean condition, final SrenwuExample.ICriteriaWhen then, final SrenwuExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public SrenwuExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            SrenwuExample.Criteria add(final SrenwuExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<SrenwuExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<SrenwuExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<SrenwuExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new SrenwuExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new SrenwuExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new SrenwuExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public SrenwuExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidIsNull() {
            this.addCriterion("pid is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidIsNotNull() {
            this.addCriterion("pid is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidEqualTo(final String value) {
            this.addCriterion("pid =", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidEqualToColumn(final Column column) {
            this.addCriterion("pid = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidNotEqualTo(final String value) {
            this.addCriterion("pid <>", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidNotEqualToColumn(final Column column) {
            this.addCriterion("pid <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidGreaterThan(final String value) {
            this.addCriterion("pid >", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidGreaterThanColumn(final Column column) {
            this.addCriterion("pid > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidGreaterThanOrEqualTo(final String value) {
            this.addCriterion("pid >=", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidLessThan(final String value) {
            this.addCriterion("pid <", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidLessThanColumn(final Column column) {
            this.addCriterion("pid < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidLessThanOrEqualTo(final String value) {
            this.addCriterion("pid <=", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidLike(final String value) {
            this.addCriterion("pid like", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidNotLike(final String value) {
            this.addCriterion("pid not like", value, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidIn(final List<String> values) {
            this.addCriterion("pid in", values, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidNotIn(final List<String> values) {
            this.addCriterion("pid not in", values, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidBetween(final String value1, final String value2) {
            this.addCriterion("pid between", value1, value2, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andPidNotBetween(final String value1, final String value2) {
            this.addCriterion("pid not between", value1, value2, "pid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidIsNull() {
            this.addCriterion("rid is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidIsNotNull() {
            this.addCriterion("rid is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidEqualTo(final Integer value) {
            this.addCriterion("rid =", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidEqualToColumn(final Column column) {
            this.addCriterion("rid = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidNotEqualTo(final Integer value) {
            this.addCriterion("rid <>", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidNotEqualToColumn(final Column column) {
            this.addCriterion("rid <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidGreaterThan(final Integer value) {
            this.addCriterion("rid >", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidGreaterThanColumn(final Column column) {
            this.addCriterion("rid > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("rid >=", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("rid >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidLessThan(final Integer value) {
            this.addCriterion("rid <", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidLessThanColumn(final Column column) {
            this.addCriterion("rid < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidLessThanOrEqualTo(final Integer value) {
            this.addCriterion("rid <=", value, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("rid <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidIn(final List<Integer> values) {
            this.addCriterion("rid in", values, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidNotIn(final List<Integer> values) {
            this.addCriterion("rid not in", values, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rid between", value1, value2, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andRidNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rid not between", value1, value2, "rid");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameIsNull() {
            this.addCriterion("skill_name is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameIsNotNull() {
            this.addCriterion("skill_name is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameEqualTo(final String value) {
            this.addCriterion("skill_name =", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameEqualToColumn(final Column column) {
            this.addCriterion("skill_name = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameNotEqualTo(final String value) {
            this.addCriterion("skill_name <>", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameNotEqualToColumn(final Column column) {
            this.addCriterion("skill_name <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameGreaterThan(final String value) {
            this.addCriterion("skill_name >", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameGreaterThanColumn(final Column column) {
            this.addCriterion("skill_name > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_name >=", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameLessThan(final String value) {
            this.addCriterion("skill_name <", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameLessThanColumn(final Column column) {
            this.addCriterion("skill_name < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_name <=", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameLike(final String value) {
            this.addCriterion("skill_name like", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameNotLike(final String value) {
            this.addCriterion("skill_name not like", value, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameIn(final List<String> values) {
            this.addCriterion("skill_name in", values, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameNotIn(final List<String> values) {
            this.addCriterion("skill_name not in", values, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameBetween(final String value1, final String value2) {
            this.addCriterion("skill_name between", value1, value2, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillNameNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_name not between", value1, value2, "skillName");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoIsNull() {
            this.addCriterion("skill_jieshao is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoIsNotNull() {
            this.addCriterion("skill_jieshao is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoEqualTo(final String value) {
            this.addCriterion("skill_jieshao =", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoEqualToColumn(final Column column) {
            this.addCriterion("skill_jieshao = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoNotEqualTo(final String value) {
            this.addCriterion("skill_jieshao <>", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoNotEqualToColumn(final Column column) {
            this.addCriterion("skill_jieshao <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoGreaterThan(final String value) {
            this.addCriterion("skill_jieshao >", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoGreaterThanColumn(final Column column) {
            this.addCriterion("skill_jieshao > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_jieshao >=", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_jieshao >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoLessThan(final String value) {
            this.addCriterion("skill_jieshao <", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoLessThanColumn(final Column column) {
            this.addCriterion("skill_jieshao < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_jieshao <=", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_jieshao <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoLike(final String value) {
            this.addCriterion("skill_jieshao like", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoNotLike(final String value) {
            this.addCriterion("skill_jieshao not like", value, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoIn(final List<String> values) {
            this.addCriterion("skill_jieshao in", values, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoNotIn(final List<String> values) {
            this.addCriterion("skill_jieshao not in", values, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoBetween(final String value1, final String value2) {
            this.addCriterion("skill_jieshao between", value1, value2, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillJieshaoNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_jieshao not between", value1, value2, "skillJieshao");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiIsNull() {
            this.addCriterion("skill_dqti is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiIsNotNull() {
            this.addCriterion("skill_dqti is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiEqualTo(final String value) {
            this.addCriterion("skill_dqti =", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiEqualToColumn(final Column column) {
            this.addCriterion("skill_dqti = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiNotEqualTo(final String value) {
            this.addCriterion("skill_dqti <>", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiNotEqualToColumn(final Column column) {
            this.addCriterion("skill_dqti <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiGreaterThan(final String value) {
            this.addCriterion("skill_dqti >", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiGreaterThanColumn(final Column column) {
            this.addCriterion("skill_dqti > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_dqti >=", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_dqti >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiLessThan(final String value) {
            this.addCriterion("skill_dqti <", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiLessThanColumn(final Column column) {
            this.addCriterion("skill_dqti < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_dqti <=", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_dqti <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiLike(final String value) {
            this.addCriterion("skill_dqti like", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiNotLike(final String value) {
            this.addCriterion("skill_dqti not like", value, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiIn(final List<String> values) {
            this.addCriterion("skill_dqti in", values, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiNotIn(final List<String> values) {
            this.addCriterion("skill_dqti not in", values, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiBetween(final String value1, final String value2) {
            this.addCriterion("skill_dqti between", value1, value2, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillDqtiNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_dqti not between", value1, value2, "skillDqti");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckIsNull() {
            this.addCriterion("skill_xck is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckIsNotNull() {
            this.addCriterion("skill_xck is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckEqualTo(final String value) {
            this.addCriterion("skill_xck =", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckEqualToColumn(final Column column) {
            this.addCriterion("skill_xck = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckNotEqualTo(final String value) {
            this.addCriterion("skill_xck <>", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckNotEqualToColumn(final Column column) {
            this.addCriterion("skill_xck <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckGreaterThan(final String value) {
            this.addCriterion("skill_xck >", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckGreaterThanColumn(final Column column) {
            this.addCriterion("skill_xck > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_xck >=", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_xck >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckLessThan(final String value) {
            this.addCriterion("skill_xck <", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckLessThanColumn(final Column column) {
            this.addCriterion("skill_xck < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_xck <=", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_xck <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckLike(final String value) {
            this.addCriterion("skill_xck like", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckNotLike(final String value) {
            this.addCriterion("skill_xck not like", value, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckIn(final List<String> values) {
            this.addCriterion("skill_xck in", values, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckNotIn(final List<String> values) {
            this.addCriterion("skill_xck not in", values, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckBetween(final String value1, final String value2) {
            this.addCriterion("skill_xck between", value1, value2, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andSkillXckNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_xck not between", value1, value2, "skillXck");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (SrenwuExample.Criteria) this;
        }

        public SrenwuExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (SrenwuExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final SrenwuExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final SrenwuExample paramSrenwuExample);
    }
}
