//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Choujiang;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseChoujiangVo {
    public Integer id;
    public Integer no;
    public String name;
    public String desc;
    public Integer level;

    public BaseChoujiangVo() {
    }

    public BaseChoujiangVo(final Choujiang vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.no = vo.getNo();
            this.name = vo.getName();
            this.desc = vo.getDesc();
            this.level = vo.getLevel();
        }
    }

    public static final BaseChoujiangVo t(final Choujiang vo) {
        return new BaseChoujiangVo(vo);
    }

    public static final List<BaseChoujiangVo> t(final List<Choujiang> list) {
        List<BaseChoujiangVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Choujiang temp = (Choujiang) var3.next();
            listVo.add(new BaseChoujiangVo(temp));
        }

        return listVo;
    }
}
