//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.ExperienceTreasure;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseExperienceTreasureVo {
    public Integer attrib;
    public Integer maxLevel;

    public BaseExperienceTreasureVo() {
    }

    public BaseExperienceTreasureVo(final ExperienceTreasure vo) {
        if (vo != null) {
            this.attrib = vo.getAttrib();
            this.maxLevel = vo.getMaxLevel();
        }
    }

    public static final BaseExperienceTreasureVo t(final ExperienceTreasure vo) {
        return new BaseExperienceTreasureVo(vo);
    }

    public static final List<BaseExperienceTreasureVo> t(final List<ExperienceTreasure> list) {
        List<BaseExperienceTreasureVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            ExperienceTreasure temp = (ExperienceTreasure) var3.next();
            listVo.add(new BaseExperienceTreasureVo(temp));
        }

        return listVo;
    }
}
