//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.StoreGoods;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseStoreGoodsVo {
    public Integer id;
    public String name;
    public String barcode;
    public Integer forSale;
    public Integer showPos;
    public Integer rpos;
    public Integer saleQuota;
    public Integer recommend;
    public Integer coin;
    public Integer discount;
    public Integer type;
    public Integer quotaLimit;
    public Integer mustVip;
    public Integer isGift;
    public Integer followPetType;

    public BaseStoreGoodsVo() {
    }

    public BaseStoreGoodsVo(final StoreGoods vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.name = vo.getName();
            this.barcode = vo.getBarcode();
            this.forSale = vo.getForSale();
            this.showPos = vo.getShowPos();
            this.rpos = vo.getRpos();
            this.saleQuota = vo.getSaleQuota();
            this.recommend = vo.getRecommend();
            this.coin = vo.getCoin();
            this.discount = vo.getDiscount();
            this.type = vo.getType();
            this.quotaLimit = vo.getQuotaLimit();
            this.mustVip = vo.getMustVip();
            this.isGift = vo.getIsGift();
            this.followPetType = vo.getFollowPetType();
        }
    }

    public static final BaseStoreGoodsVo t(final StoreGoods vo) {
        return new BaseStoreGoodsVo(vo);
    }

    public static final List<BaseStoreGoodsVo> t(final List<StoreGoods> list) {
        List<BaseStoreGoodsVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            StoreGoods temp = (StoreGoods) var3.next();
            listVo.add(new BaseStoreGoodsVo(temp));
        }

        return listVo;
    }
}
