//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.NpcDialogue.Column;
import com.fengshen.db.domain.NpcDialogue.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NpcDialogueExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<NpcDialogueExample.Criteria> oredCriteria = new ArrayList();

    public NpcDialogueExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<NpcDialogueExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final NpcDialogueExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public NpcDialogueExample.Criteria or() {
        NpcDialogueExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public NpcDialogueExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public NpcDialogueExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public NpcDialogueExample.Criteria createCriteria() {
        NpcDialogueExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected NpcDialogueExample.Criteria createCriteriaInternal() {
        NpcDialogueExample.Criteria criteria = new NpcDialogueExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static NpcDialogueExample.Criteria newAndCreateCriteria() {
        NpcDialogueExample example = new NpcDialogueExample();
        return example.createCriteria();
    }

    public NpcDialogueExample when(final boolean condition, final NpcDialogueExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public NpcDialogueExample when(final boolean condition, final NpcDialogueExample.IExampleWhen then, final NpcDialogueExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends NpcDialogueExample.GeneratedCriteria {
        private NpcDialogueExample example;

        protected Criteria(final NpcDialogueExample example) {
            this.example = example;
        }

        public NpcDialogueExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public NpcDialogueExample.Criteria andIf(final boolean ifAdd, final NpcDialogueExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public NpcDialogueExample.Criteria when(final boolean condition, final NpcDialogueExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public NpcDialogueExample.Criteria when(final boolean condition, final NpcDialogueExample.ICriteriaWhen then, final NpcDialogueExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public NpcDialogueExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            NpcDialogueExample.Criteria add(final NpcDialogueExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<NpcDialogueExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<NpcDialogueExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<NpcDialogueExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new NpcDialogueExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new NpcDialogueExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new NpcDialogueExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public NpcDialogueExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitIsNull() {
            this.addCriterion("portranit is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitIsNotNull() {
            this.addCriterion("portranit is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitEqualTo(final Integer value) {
            this.addCriterion("portranit =", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitEqualToColumn(final Column column) {
            this.addCriterion("portranit = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitNotEqualTo(final Integer value) {
            this.addCriterion("portranit <>", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitNotEqualToColumn(final Column column) {
            this.addCriterion("portranit <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitGreaterThan(final Integer value) {
            this.addCriterion("portranit >", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitGreaterThanColumn(final Column column) {
            this.addCriterion("portranit > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("portranit >=", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("portranit >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitLessThan(final Integer value) {
            this.addCriterion("portranit <", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitLessThanColumn(final Column column) {
            this.addCriterion("portranit < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitLessThanOrEqualTo(final Integer value) {
            this.addCriterion("portranit <=", value, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("portranit <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitIn(final List<Integer> values) {
            this.addCriterion("portranit in", values, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitNotIn(final List<Integer> values) {
            this.addCriterion("portranit not in", values, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitBetween(final Integer value1, final Integer value2) {
            this.addCriterion("portranit between", value1, value2, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPortranitNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("portranit not between", value1, value2, "portranit");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoIsNull() {
            this.addCriterion("pic_no is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoIsNotNull() {
            this.addCriterion("pic_no is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoEqualTo(final Integer value) {
            this.addCriterion("pic_no =", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoEqualToColumn(final Column column) {
            this.addCriterion("pic_no = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoNotEqualTo(final Integer value) {
            this.addCriterion("pic_no <>", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoNotEqualToColumn(final Column column) {
            this.addCriterion("pic_no <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoGreaterThan(final Integer value) {
            this.addCriterion("pic_no >", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoGreaterThanColumn(final Column column) {
            this.addCriterion("pic_no > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("pic_no >=", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pic_no >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoLessThan(final Integer value) {
            this.addCriterion("pic_no <", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoLessThanColumn(final Column column) {
            this.addCriterion("pic_no < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("pic_no <=", value, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pic_no <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoIn(final List<Integer> values) {
            this.addCriterion("pic_no in", values, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoNotIn(final List<Integer> values) {
            this.addCriterion("pic_no not in", values, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pic_no between", value1, value2, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPicNoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pic_no not between", value1, value2, "picNo");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentIsNull() {
            this.addCriterion("content is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentIsNotNull() {
            this.addCriterion("content is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentEqualTo(final String value) {
            this.addCriterion("content =", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentEqualToColumn(final Column column) {
            this.addCriterion("content = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentNotEqualTo(final String value) {
            this.addCriterion("content <>", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentNotEqualToColumn(final Column column) {
            this.addCriterion("content <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentGreaterThan(final String value) {
            this.addCriterion("content >", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentGreaterThanColumn(final Column column) {
            this.addCriterion("content > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentGreaterThanOrEqualTo(final String value) {
            this.addCriterion("content >=", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("content >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentLessThan(final String value) {
            this.addCriterion("content <", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentLessThanColumn(final Column column) {
            this.addCriterion("content < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentLessThanOrEqualTo(final String value) {
            this.addCriterion("content <=", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("content <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentLike(final String value) {
            this.addCriterion("content like", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentNotLike(final String value) {
            this.addCriterion("content not like", value, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentIn(final List<String> values) {
            this.addCriterion("content in", values, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentNotIn(final List<String> values) {
            this.addCriterion("content not in", values, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentBetween(final String value1, final String value2) {
            this.addCriterion("content between", value1, value2, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andContentNotBetween(final String value1, final String value2) {
            this.addCriterion("content not between", value1, value2, "content");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteIsNull() {
            this.addCriterion("isconmlete is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteIsNotNull() {
            this.addCriterion("isconmlete is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteEqualTo(final Integer value) {
            this.addCriterion("isconmlete =", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteEqualToColumn(final Column column) {
            this.addCriterion("isconmlete = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteNotEqualTo(final Integer value) {
            this.addCriterion("isconmlete <>", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteNotEqualToColumn(final Column column) {
            this.addCriterion("isconmlete <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteGreaterThan(final Integer value) {
            this.addCriterion("isconmlete >", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteGreaterThanColumn(final Column column) {
            this.addCriterion("isconmlete > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("isconmlete >=", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("isconmlete >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteLessThan(final Integer value) {
            this.addCriterion("isconmlete <", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteLessThanColumn(final Column column) {
            this.addCriterion("isconmlete < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteLessThanOrEqualTo(final Integer value) {
            this.addCriterion("isconmlete <=", value, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("isconmlete <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteIn(final List<Integer> values) {
            this.addCriterion("isconmlete in", values, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteNotIn(final List<Integer> values) {
            this.addCriterion("isconmlete not in", values, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteBetween(final Integer value1, final Integer value2) {
            this.addCriterion("isconmlete between", value1, value2, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsconmleteNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("isconmlete not between", value1, value2, "isconmlete");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatIsNull() {
            this.addCriterion("isincombat is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatIsNotNull() {
            this.addCriterion("isincombat is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatEqualTo(final Integer value) {
            this.addCriterion("isincombat =", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatEqualToColumn(final Column column) {
            this.addCriterion("isincombat = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatNotEqualTo(final Integer value) {
            this.addCriterion("isincombat <>", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatNotEqualToColumn(final Column column) {
            this.addCriterion("isincombat <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatGreaterThan(final Integer value) {
            this.addCriterion("isincombat >", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatGreaterThanColumn(final Column column) {
            this.addCriterion("isincombat > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("isincombat >=", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("isincombat >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatLessThan(final Integer value) {
            this.addCriterion("isincombat <", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatLessThanColumn(final Column column) {
            this.addCriterion("isincombat < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatLessThanOrEqualTo(final Integer value) {
            this.addCriterion("isincombat <=", value, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("isincombat <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatIn(final List<Integer> values) {
            this.addCriterion("isincombat in", values, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatNotIn(final List<Integer> values) {
            this.addCriterion("isincombat not in", values, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatBetween(final Integer value1, final Integer value2) {
            this.addCriterion("isincombat between", value1, value2, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIsincombatNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("isincombat not between", value1, value2, "isincombat");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeIsNull() {
            this.addCriterion("palytime is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeIsNotNull() {
            this.addCriterion("palytime is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeEqualTo(final Integer value) {
            this.addCriterion("palytime =", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeEqualToColumn(final Column column) {
            this.addCriterion("palytime = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeNotEqualTo(final Integer value) {
            this.addCriterion("palytime <>", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeNotEqualToColumn(final Column column) {
            this.addCriterion("palytime <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeGreaterThan(final Integer value) {
            this.addCriterion("palytime >", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeGreaterThanColumn(final Column column) {
            this.addCriterion("palytime > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("palytime >=", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("palytime >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeLessThan(final Integer value) {
            this.addCriterion("palytime <", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeLessThanColumn(final Column column) {
            this.addCriterion("palytime < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("palytime <=", value, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("palytime <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeIn(final List<Integer> values) {
            this.addCriterion("palytime in", values, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeNotIn(final List<Integer> values) {
            this.addCriterion("palytime not in", values, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("palytime between", value1, value2, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andPalytimeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("palytime not between", value1, value2, "palytime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeIsNull() {
            this.addCriterion("task_type is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeIsNotNull() {
            this.addCriterion("task_type is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeEqualTo(final String value) {
            this.addCriterion("task_type =", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeEqualToColumn(final Column column) {
            this.addCriterion("task_type = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeNotEqualTo(final String value) {
            this.addCriterion("task_type <>", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeNotEqualToColumn(final Column column) {
            this.addCriterion("task_type <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeGreaterThan(final String value) {
            this.addCriterion("task_type >", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeGreaterThanColumn(final Column column) {
            this.addCriterion("task_type > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("task_type >=", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("task_type >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeLessThan(final String value) {
            this.addCriterion("task_type <", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeLessThanColumn(final Column column) {
            this.addCriterion("task_type < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeLessThanOrEqualTo(final String value) {
            this.addCriterion("task_type <=", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("task_type <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeLike(final String value) {
            this.addCriterion("task_type like", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeNotLike(final String value) {
            this.addCriterion("task_type not like", value, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeIn(final List<String> values) {
            this.addCriterion("task_type in", values, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeNotIn(final List<String> values) {
            this.addCriterion("task_type not in", values, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeBetween(final String value1, final String value2) {
            this.addCriterion("task_type between", value1, value2, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andTaskTypeNotBetween(final String value1, final String value2) {
            this.addCriterion("task_type not between", value1, value2, "taskType");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameIsNull() {
            this.addCriterion("idname is null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameIsNotNull() {
            this.addCriterion("idname is not null");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameEqualTo(final String value) {
            this.addCriterion("idname =", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameEqualToColumn(final Column column) {
            this.addCriterion("idname = " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameNotEqualTo(final String value) {
            this.addCriterion("idname <>", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameNotEqualToColumn(final Column column) {
            this.addCriterion("idname <> " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameGreaterThan(final String value) {
            this.addCriterion("idname >", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameGreaterThanColumn(final Column column) {
            this.addCriterion("idname > " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("idname >=", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("idname >= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameLessThan(final String value) {
            this.addCriterion("idname <", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameLessThanColumn(final Column column) {
            this.addCriterion("idname < " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameLessThanOrEqualTo(final String value) {
            this.addCriterion("idname <=", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("idname <= " + column.getEscapedColumnName());
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameLike(final String value) {
            this.addCriterion("idname like", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameNotLike(final String value) {
            this.addCriterion("idname not like", value, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameIn(final List<String> values) {
            this.addCriterion("idname in", values, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameNotIn(final List<String> values) {
            this.addCriterion("idname not in", values, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameBetween(final String value1, final String value2) {
            this.addCriterion("idname between", value1, value2, "idname");
            return (NpcDialogueExample.Criteria) this;
        }

        public NpcDialogueExample.Criteria andIdnameNotBetween(final String value1, final String value2) {
            this.addCriterion("idname not between", value1, value2, "idname");
            return (NpcDialogueExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final NpcDialogueExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final NpcDialogueExample paramNpcDialogueExample);
    }
}
