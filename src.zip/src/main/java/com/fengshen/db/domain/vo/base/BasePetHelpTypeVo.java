//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.PetHelpType;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BasePetHelpTypeVo {
    public Integer id;
    public Integer type;
    public String name;
    public Integer quality;
    public Integer money;
    public Integer polar;

    public BasePetHelpTypeVo() {
    }

    public BasePetHelpTypeVo(final PetHelpType vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.type = vo.getType();
            this.name = vo.getName();
            this.quality = vo.getQuality();
            this.money = vo.getMoney();
            this.polar = vo.getPolar();
        }
    }

    public static final BasePetHelpTypeVo t(final PetHelpType vo) {
        return new BasePetHelpTypeVo(vo);
    }

    public static final List<BasePetHelpTypeVo> t(final List<PetHelpType> list) {
        List<BasePetHelpTypeVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            PetHelpType temp = (PetHelpType) var3.next();
            listVo.add(new BasePetHelpTypeVo(temp));
        }

        return listVo;
    }
}
