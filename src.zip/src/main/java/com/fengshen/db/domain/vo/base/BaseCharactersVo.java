//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Characters;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseCharactersVo {
    public Integer id;
    public Integer polar;
    public String name;
    public Integer accountId;
    public String gid;
    public String data;

    public BaseCharactersVo() {
    }

    public BaseCharactersVo(final Characters vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.polar = vo.getPolar();
            this.name = vo.getName();
            this.accountId = vo.getAccountId();
            this.gid = vo.getGid();
            this.data = vo.getData();
        }
    }

    public static final BaseCharactersVo t(final Characters vo) {
        return new BaseCharactersVo(vo);
    }

    public static final List<BaseCharactersVo> t(final List<Characters> list) {
        List<BaseCharactersVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Characters temp = (Characters) var3.next();
            listVo.add(new BaseCharactersVo(temp));
        }

        return listVo;
    }
}
