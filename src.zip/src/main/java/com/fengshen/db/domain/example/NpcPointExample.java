//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.NpcPoint.Column;
import com.fengshen.db.domain.NpcPoint.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NpcPointExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<NpcPointExample.Criteria> oredCriteria = new ArrayList();

    public NpcPointExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<NpcPointExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final NpcPointExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public NpcPointExample.Criteria or() {
        NpcPointExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public NpcPointExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public NpcPointExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public NpcPointExample.Criteria createCriteria() {
        NpcPointExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected NpcPointExample.Criteria createCriteriaInternal() {
        NpcPointExample.Criteria criteria = new NpcPointExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static NpcPointExample.Criteria newAndCreateCriteria() {
        NpcPointExample example = new NpcPointExample();
        return example.createCriteria();
    }

    public NpcPointExample when(final boolean condition, final NpcPointExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public NpcPointExample when(final boolean condition, final NpcPointExample.IExampleWhen then, final NpcPointExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends NpcPointExample.GeneratedCriteria {
        private NpcPointExample example;

        protected Criteria(final NpcPointExample example) {
            this.example = example;
        }

        public NpcPointExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public NpcPointExample.Criteria andIf(final boolean ifAdd, final NpcPointExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public NpcPointExample.Criteria when(final boolean condition, final NpcPointExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public NpcPointExample.Criteria when(final boolean condition, final NpcPointExample.ICriteriaWhen then, final NpcPointExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public NpcPointExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            NpcPointExample.Criteria add(final NpcPointExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<NpcPointExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<NpcPointExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<NpcPointExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new NpcPointExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new NpcPointExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new NpcPointExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public NpcPointExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameIsNull() {
            this.addCriterion("mapname is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameIsNotNull() {
            this.addCriterion("mapname is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameEqualTo(final String value) {
            this.addCriterion("mapname =", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameEqualToColumn(final Column column) {
            this.addCriterion("mapname = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameNotEqualTo(final String value) {
            this.addCriterion("mapname <>", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameNotEqualToColumn(final Column column) {
            this.addCriterion("mapname <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameGreaterThan(final String value) {
            this.addCriterion("mapname >", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameGreaterThanColumn(final Column column) {
            this.addCriterion("mapname > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("mapname >=", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("mapname >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameLessThan(final String value) {
            this.addCriterion("mapname <", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameLessThanColumn(final Column column) {
            this.addCriterion("mapname < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameLessThanOrEqualTo(final String value) {
            this.addCriterion("mapname <=", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("mapname <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameLike(final String value) {
            this.addCriterion("mapname like", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameNotLike(final String value) {
            this.addCriterion("mapname not like", value, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameIn(final List<String> values) {
            this.addCriterion("mapname in", values, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameNotIn(final List<String> values) {
            this.addCriterion("mapname not in", values, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameBetween(final String value1, final String value2) {
            this.addCriterion("mapname between", value1, value2, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andMapnameNotBetween(final String value1, final String value2) {
            this.addCriterion("mapname not between", value1, value2, "mapname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameIsNull() {
            this.addCriterion("doorname is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameIsNotNull() {
            this.addCriterion("doorname is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameEqualTo(final String value) {
            this.addCriterion("doorname =", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameEqualToColumn(final Column column) {
            this.addCriterion("doorname = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameNotEqualTo(final String value) {
            this.addCriterion("doorname <>", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameNotEqualToColumn(final Column column) {
            this.addCriterion("doorname <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameGreaterThan(final String value) {
            this.addCriterion("doorname >", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameGreaterThanColumn(final Column column) {
            this.addCriterion("doorname > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("doorname >=", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("doorname >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameLessThan(final String value) {
            this.addCriterion("doorname <", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameLessThanColumn(final Column column) {
            this.addCriterion("doorname < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameLessThanOrEqualTo(final String value) {
            this.addCriterion("doorname <=", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("doorname <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameLike(final String value) {
            this.addCriterion("doorname like", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameNotLike(final String value) {
            this.addCriterion("doorname not like", value, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameIn(final List<String> values) {
            this.addCriterion("doorname in", values, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameNotIn(final List<String> values) {
            this.addCriterion("doorname not in", values, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameBetween(final String value1, final String value2) {
            this.addCriterion("doorname between", value1, value2, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDoornameNotBetween(final String value1, final String value2) {
            this.addCriterion("doorname not between", value1, value2, "doorname");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXIsNull() {
            this.addCriterion("x is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXIsNotNull() {
            this.addCriterion("x is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXEqualTo(final Integer value) {
            this.addCriterion("x =", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXEqualToColumn(final Column column) {
            this.addCriterion("x = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXNotEqualTo(final Integer value) {
            this.addCriterion("x <>", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXNotEqualToColumn(final Column column) {
            this.addCriterion("x <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXGreaterThan(final Integer value) {
            this.addCriterion("x >", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXGreaterThanColumn(final Column column) {
            this.addCriterion("x > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("x >=", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("x >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXLessThan(final Integer value) {
            this.addCriterion("x <", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXLessThanColumn(final Column column) {
            this.addCriterion("x < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXLessThanOrEqualTo(final Integer value) {
            this.addCriterion("x <=", value, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("x <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXIn(final List<Integer> values) {
            this.addCriterion("x in", values, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXNotIn(final List<Integer> values) {
            this.addCriterion("x not in", values, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x between", value1, value2, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andXNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x not between", value1, value2, "x");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYIsNull() {
            this.addCriterion("y is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYIsNotNull() {
            this.addCriterion("y is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYEqualTo(final Integer value) {
            this.addCriterion("y =", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYEqualToColumn(final Column column) {
            this.addCriterion("y = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYNotEqualTo(final Integer value) {
            this.addCriterion("y <>", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYNotEqualToColumn(final Column column) {
            this.addCriterion("y <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYGreaterThan(final Integer value) {
            this.addCriterion("y >", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYGreaterThanColumn(final Column column) {
            this.addCriterion("y > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("y >=", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("y >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYLessThan(final Integer value) {
            this.addCriterion("y <", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYLessThanColumn(final Column column) {
            this.addCriterion("y < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYLessThanOrEqualTo(final Integer value) {
            this.addCriterion("y <=", value, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("y <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYIn(final List<Integer> values) {
            this.addCriterion("y in", values, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYNotIn(final List<Integer> values) {
            this.addCriterion("y not in", values, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y between", value1, value2, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andYNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y not between", value1, value2, "y");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZIsNull() {
            this.addCriterion("z is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZIsNotNull() {
            this.addCriterion("z is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZEqualTo(final Integer value) {
            this.addCriterion("z =", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZEqualToColumn(final Column column) {
            this.addCriterion("z = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZNotEqualTo(final Integer value) {
            this.addCriterion("z <>", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZNotEqualToColumn(final Column column) {
            this.addCriterion("z <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZGreaterThan(final Integer value) {
            this.addCriterion("z >", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZGreaterThanColumn(final Column column) {
            this.addCriterion("z > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("z >=", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("z >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZLessThan(final Integer value) {
            this.addCriterion("z <", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZLessThanColumn(final Column column) {
            this.addCriterion("z < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZLessThanOrEqualTo(final Integer value) {
            this.addCriterion("z <=", value, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("z <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZIn(final List<Integer> values) {
            this.addCriterion("z in", values, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZNotIn(final List<Integer> values) {
            this.addCriterion("z not in", values, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZBetween(final Integer value1, final Integer value2) {
            this.addCriterion("z between", value1, value2, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andZNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("z not between", value1, value2, "z");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxIsNull() {
            this.addCriterion("inx is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxIsNotNull() {
            this.addCriterion("inx is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxEqualTo(final Integer value) {
            this.addCriterion("inx =", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxEqualToColumn(final Column column) {
            this.addCriterion("inx = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxNotEqualTo(final Integer value) {
            this.addCriterion("inx <>", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxNotEqualToColumn(final Column column) {
            this.addCriterion("inx <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxGreaterThan(final Integer value) {
            this.addCriterion("inx >", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxGreaterThanColumn(final Column column) {
            this.addCriterion("inx > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("inx >=", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("inx >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxLessThan(final Integer value) {
            this.addCriterion("inx <", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxLessThanColumn(final Column column) {
            this.addCriterion("inx < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxLessThanOrEqualTo(final Integer value) {
            this.addCriterion("inx <=", value, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("inx <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxIn(final List<Integer> values) {
            this.addCriterion("inx in", values, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxNotIn(final List<Integer> values) {
            this.addCriterion("inx not in", values, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxBetween(final Integer value1, final Integer value2) {
            this.addCriterion("inx between", value1, value2, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInxNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("inx not between", value1, value2, "inx");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyIsNull() {
            this.addCriterion("iny is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyIsNotNull() {
            this.addCriterion("iny is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyEqualTo(final Integer value) {
            this.addCriterion("iny =", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyEqualToColumn(final Column column) {
            this.addCriterion("iny = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyNotEqualTo(final Integer value) {
            this.addCriterion("iny <>", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyNotEqualToColumn(final Column column) {
            this.addCriterion("iny <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyGreaterThan(final Integer value) {
            this.addCriterion("iny >", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyGreaterThanColumn(final Column column) {
            this.addCriterion("iny > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("iny >=", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("iny >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyLessThan(final Integer value) {
            this.addCriterion("iny <", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyLessThanColumn(final Column column) {
            this.addCriterion("iny < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyLessThanOrEqualTo(final Integer value) {
            this.addCriterion("iny <=", value, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("iny <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyIn(final List<Integer> values) {
            this.addCriterion("iny in", values, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyNotIn(final List<Integer> values) {
            this.addCriterion("iny not in", values, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyBetween(final Integer value1, final Integer value2) {
            this.addCriterion("iny between", value1, value2, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andInyNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("iny not between", value1, value2, "iny");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (NpcPointExample.Criteria) this;
        }

        public NpcPointExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (NpcPointExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final NpcPointExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final NpcPointExample paramNpcPointExample);
    }
}
