//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.NpcDialogueFrame.Column;
import com.fengshen.db.domain.NpcDialogueFrame.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NpcDialogueFrameExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<NpcDialogueFrameExample.Criteria> oredCriteria = new ArrayList();

    public NpcDialogueFrameExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<NpcDialogueFrameExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final NpcDialogueFrameExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public NpcDialogueFrameExample.Criteria or() {
        NpcDialogueFrameExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public NpcDialogueFrameExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public NpcDialogueFrameExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public NpcDialogueFrameExample.Criteria createCriteria() {
        NpcDialogueFrameExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected NpcDialogueFrameExample.Criteria createCriteriaInternal() {
        NpcDialogueFrameExample.Criteria criteria = new NpcDialogueFrameExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static NpcDialogueFrameExample.Criteria newAndCreateCriteria() {
        NpcDialogueFrameExample example = new NpcDialogueFrameExample();
        return example.createCriteria();
    }

    public NpcDialogueFrameExample when(final boolean condition, final NpcDialogueFrameExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public NpcDialogueFrameExample when(final boolean condition, final NpcDialogueFrameExample.IExampleWhen then, final NpcDialogueFrameExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends NpcDialogueFrameExample.GeneratedCriteria {
        private NpcDialogueFrameExample example;

        protected Criteria(final NpcDialogueFrameExample example) {
            this.example = example;
        }

        public NpcDialogueFrameExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public NpcDialogueFrameExample.Criteria andIf(final boolean ifAdd, final NpcDialogueFrameExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public NpcDialogueFrameExample.Criteria when(final boolean condition, final NpcDialogueFrameExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public NpcDialogueFrameExample.Criteria when(final boolean condition, final NpcDialogueFrameExample.ICriteriaWhen then, final NpcDialogueFrameExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public NpcDialogueFrameExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            NpcDialogueFrameExample.Criteria add(final NpcDialogueFrameExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<NpcDialogueFrameExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<NpcDialogueFrameExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<NpcDialogueFrameExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new NpcDialogueFrameExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new NpcDialogueFrameExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new NpcDialogueFrameExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public NpcDialogueFrameExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitIsNull() {
            this.addCriterion("portrait is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitIsNotNull() {
            this.addCriterion("portrait is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitEqualTo(final Integer value) {
            this.addCriterion("portrait =", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitEqualToColumn(final Column column) {
            this.addCriterion("portrait = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitNotEqualTo(final Integer value) {
            this.addCriterion("portrait <>", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitNotEqualToColumn(final Column column) {
            this.addCriterion("portrait <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitGreaterThan(final Integer value) {
            this.addCriterion("portrait >", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitGreaterThanColumn(final Column column) {
            this.addCriterion("portrait > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("portrait >=", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("portrait >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitLessThan(final Integer value) {
            this.addCriterion("portrait <", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitLessThanColumn(final Column column) {
            this.addCriterion("portrait < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitLessThanOrEqualTo(final Integer value) {
            this.addCriterion("portrait <=", value, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("portrait <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitIn(final List<Integer> values) {
            this.addCriterion("portrait in", values, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitNotIn(final List<Integer> values) {
            this.addCriterion("portrait not in", values, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitBetween(final Integer value1, final Integer value2) {
            this.addCriterion("portrait between", value1, value2, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPortraitNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("portrait not between", value1, value2, "portrait");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoIsNull() {
            this.addCriterion("pic_no is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoIsNotNull() {
            this.addCriterion("pic_no is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoEqualTo(final Integer value) {
            this.addCriterion("pic_no =", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoEqualToColumn(final Column column) {
            this.addCriterion("pic_no = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoNotEqualTo(final Integer value) {
            this.addCriterion("pic_no <>", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoNotEqualToColumn(final Column column) {
            this.addCriterion("pic_no <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoGreaterThan(final Integer value) {
            this.addCriterion("pic_no >", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoGreaterThanColumn(final Column column) {
            this.addCriterion("pic_no > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("pic_no >=", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pic_no >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoLessThan(final Integer value) {
            this.addCriterion("pic_no <", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoLessThanColumn(final Column column) {
            this.addCriterion("pic_no < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("pic_no <=", value, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pic_no <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoIn(final List<Integer> values) {
            this.addCriterion("pic_no in", values, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoNotIn(final List<Integer> values) {
            this.addCriterion("pic_no not in", values, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pic_no between", value1, value2, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andPicNoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pic_no not between", value1, value2, "picNo");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentIsNull() {
            this.addCriterion("content is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentIsNotNull() {
            this.addCriterion("content is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentEqualTo(final String value) {
            this.addCriterion("content =", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentEqualToColumn(final Column column) {
            this.addCriterion("content = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentNotEqualTo(final String value) {
            this.addCriterion("content <>", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentNotEqualToColumn(final Column column) {
            this.addCriterion("content <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentGreaterThan(final String value) {
            this.addCriterion("content >", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentGreaterThanColumn(final Column column) {
            this.addCriterion("content > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentGreaterThanOrEqualTo(final String value) {
            this.addCriterion("content >=", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("content >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentLessThan(final String value) {
            this.addCriterion("content <", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentLessThanColumn(final Column column) {
            this.addCriterion("content < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentLessThanOrEqualTo(final String value) {
            this.addCriterion("content <=", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("content <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentLike(final String value) {
            this.addCriterion("content like", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentNotLike(final String value) {
            this.addCriterion("content not like", value, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentIn(final List<String> values) {
            this.addCriterion("content in", values, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentNotIn(final List<String> values) {
            this.addCriterion("content not in", values, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentBetween(final String value1, final String value2) {
            this.addCriterion("content between", value1, value2, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andContentNotBetween(final String value1, final String value2) {
            this.addCriterion("content not between", value1, value2, "content");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyIsNull() {
            this.addCriterion("secret_key is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyIsNotNull() {
            this.addCriterion("secret_key is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyEqualTo(final String value) {
            this.addCriterion("secret_key =", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyEqualToColumn(final Column column) {
            this.addCriterion("secret_key = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyNotEqualTo(final String value) {
            this.addCriterion("secret_key <>", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyNotEqualToColumn(final Column column) {
            this.addCriterion("secret_key <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyGreaterThan(final String value) {
            this.addCriterion("secret_key >", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyGreaterThanColumn(final Column column) {
            this.addCriterion("secret_key > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyGreaterThanOrEqualTo(final String value) {
            this.addCriterion("secret_key >=", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("secret_key >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyLessThan(final String value) {
            this.addCriterion("secret_key <", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyLessThanColumn(final Column column) {
            this.addCriterion("secret_key < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyLessThanOrEqualTo(final String value) {
            this.addCriterion("secret_key <=", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("secret_key <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyLike(final String value) {
            this.addCriterion("secret_key like", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyNotLike(final String value) {
            this.addCriterion("secret_key not like", value, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyIn(final List<String> values) {
            this.addCriterion("secret_key in", values, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyNotIn(final List<String> values) {
            this.addCriterion("secret_key not in", values, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyBetween(final String value1, final String value2) {
            this.addCriterion("secret_key between", value1, value2, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andSecretKeyNotBetween(final String value1, final String value2) {
            this.addCriterion("secret_key not between", value1, value2, "secretKey");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribIsNull() {
            this.addCriterion("attrib is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribIsNotNull() {
            this.addCriterion("attrib is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribEqualTo(final Integer value) {
            this.addCriterion("attrib =", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribEqualToColumn(final Column column) {
            this.addCriterion("attrib = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribNotEqualTo(final Integer value) {
            this.addCriterion("attrib <>", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribNotEqualToColumn(final Column column) {
            this.addCriterion("attrib <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribGreaterThan(final Integer value) {
            this.addCriterion("attrib >", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribGreaterThanColumn(final Column column) {
            this.addCriterion("attrib > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib >=", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribLessThan(final Integer value) {
            this.addCriterion("attrib <", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribLessThanColumn(final Column column) {
            this.addCriterion("attrib < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribLessThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib <=", value, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribIn(final List<Integer> values) {
            this.addCriterion("attrib in", values, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribNotIn(final List<Integer> values) {
            this.addCriterion("attrib not in", values, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib between", value1, value2, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAttribNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib not between", value1, value2, "attrib");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesIsNull() {
            this.addCriterion("update_times is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesIsNotNull() {
            this.addCriterion("update_times is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesEqualTo(final LocalDateTime value) {
            this.addCriterion("update_times =", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesEqualToColumn(final Column column) {
            this.addCriterion("update_times = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_times <>", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesNotEqualToColumn(final Column column) {
            this.addCriterion("update_times <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_times >", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesGreaterThanColumn(final Column column) {
            this.addCriterion("update_times > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_times >=", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_times >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesLessThan(final LocalDateTime value) {
            this.addCriterion("update_times <", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesLessThanColumn(final Column column) {
            this.addCriterion("update_times < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_times <=", value, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_times <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesIn(final List<LocalDateTime> values) {
            this.addCriterion("update_times in", values, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_times not in", values, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_times between", value1, value2, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimesNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_times not between", value1, value2, "updateTimes");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameIsNull() {
            this.addCriterion("idname is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameIsNotNull() {
            this.addCriterion("idname is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameEqualTo(final Integer value) {
            this.addCriterion("idname =", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameEqualToColumn(final Column column) {
            this.addCriterion("idname = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameNotEqualTo(final Integer value) {
            this.addCriterion("idname <>", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameNotEqualToColumn(final Column column) {
            this.addCriterion("idname <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameGreaterThan(final Integer value) {
            this.addCriterion("idname >", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameGreaterThanColumn(final Column column) {
            this.addCriterion("idname > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("idname >=", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("idname >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameLessThan(final Integer value) {
            this.addCriterion("idname <", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameLessThanColumn(final Column column) {
            this.addCriterion("idname < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameLessThanOrEqualTo(final Integer value) {
            this.addCriterion("idname <=", value, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("idname <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameIn(final List<Integer> values) {
            this.addCriterion("idname in", values, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameNotIn(final List<Integer> values) {
            this.addCriterion("idname not in", values, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameBetween(final Integer value1, final Integer value2) {
            this.addCriterion("idname between", value1, value2, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andIdnameNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("idname not between", value1, value2, "idname");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextIsNull() {
            this.addCriterion("`next` is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextIsNotNull() {
            this.addCriterion("`next` is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextEqualTo(final String value) {
            this.addCriterion("`next` =", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextEqualToColumn(final Column column) {
            this.addCriterion("`next` = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextNotEqualTo(final String value) {
            this.addCriterion("`next` <>", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextNotEqualToColumn(final Column column) {
            this.addCriterion("`next` <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextGreaterThan(final String value) {
            this.addCriterion("`next` >", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextGreaterThanColumn(final Column column) {
            this.addCriterion("`next` > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`next` >=", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`next` >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextLessThan(final String value) {
            this.addCriterion("`next` <", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextLessThanColumn(final Column column) {
            this.addCriterion("`next` < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextLessThanOrEqualTo(final String value) {
            this.addCriterion("`next` <=", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`next` <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextLike(final String value) {
            this.addCriterion("`next` like", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextNotLike(final String value) {
            this.addCriterion("`next` not like", value, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextIn(final List<String> values) {
            this.addCriterion("`next` in", values, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextNotIn(final List<String> values) {
            this.addCriterion("`next` not in", values, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextBetween(final String value1, final String value2) {
            this.addCriterion("`next` between", value1, value2, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andNextNotBetween(final String value1, final String value2) {
            this.addCriterion("`next` not between", value1, value2, "next");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskIsNull() {
            this.addCriterion("current_task is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskIsNotNull() {
            this.addCriterion("current_task is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskEqualTo(final String value) {
            this.addCriterion("current_task =", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskEqualToColumn(final Column column) {
            this.addCriterion("current_task = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskNotEqualTo(final String value) {
            this.addCriterion("current_task <>", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskNotEqualToColumn(final Column column) {
            this.addCriterion("current_task <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskGreaterThan(final String value) {
            this.addCriterion("current_task >", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskGreaterThanColumn(final Column column) {
            this.addCriterion("current_task > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskGreaterThanOrEqualTo(final String value) {
            this.addCriterion("current_task >=", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("current_task >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskLessThan(final String value) {
            this.addCriterion("current_task <", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskLessThanColumn(final Column column) {
            this.addCriterion("current_task < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskLessThanOrEqualTo(final String value) {
            this.addCriterion("current_task <=", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("current_task <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskLike(final String value) {
            this.addCriterion("current_task like", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskNotLike(final String value) {
            this.addCriterion("current_task not like", value, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskIn(final List<String> values) {
            this.addCriterion("current_task in", values, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskNotIn(final List<String> values) {
            this.addCriterion("current_task not in", values, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskBetween(final String value1, final String value2) {
            this.addCriterion("current_task between", value1, value2, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andCurrentTaskNotBetween(final String value1, final String value2) {
            this.addCriterion("current_task not between", value1, value2, "currentTask");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentIsNull() {
            this.addCriterion("uncontent is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentIsNotNull() {
            this.addCriterion("uncontent is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentEqualTo(final String value) {
            this.addCriterion("uncontent =", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentEqualToColumn(final Column column) {
            this.addCriterion("uncontent = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentNotEqualTo(final String value) {
            this.addCriterion("uncontent <>", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentNotEqualToColumn(final Column column) {
            this.addCriterion("uncontent <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentGreaterThan(final String value) {
            this.addCriterion("uncontent >", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentGreaterThanColumn(final Column column) {
            this.addCriterion("uncontent > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentGreaterThanOrEqualTo(final String value) {
            this.addCriterion("uncontent >=", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("uncontent >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentLessThan(final String value) {
            this.addCriterion("uncontent <", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentLessThanColumn(final Column column) {
            this.addCriterion("uncontent < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentLessThanOrEqualTo(final String value) {
            this.addCriterion("uncontent <=", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("uncontent <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentLike(final String value) {
            this.addCriterion("uncontent like", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentNotLike(final String value) {
            this.addCriterion("uncontent not like", value, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentIn(final List<String> values) {
            this.addCriterion("uncontent in", values, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentNotIn(final List<String> values) {
            this.addCriterion("uncontent not in", values, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentBetween(final String value1, final String value2) {
            this.addCriterion("uncontent between", value1, value2, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andUncontentNotBetween(final String value1, final String value2) {
            this.addCriterion("uncontent not between", value1, value2, "uncontent");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiIsNull() {
            this.addCriterion("zhuangbei is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiIsNotNull() {
            this.addCriterion("zhuangbei is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiEqualTo(final String value) {
            this.addCriterion("zhuangbei =", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiEqualToColumn(final Column column) {
            this.addCriterion("zhuangbei = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiNotEqualTo(final String value) {
            this.addCriterion("zhuangbei <>", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiNotEqualToColumn(final Column column) {
            this.addCriterion("zhuangbei <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiGreaterThan(final String value) {
            this.addCriterion("zhuangbei >", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiGreaterThanColumn(final Column column) {
            this.addCriterion("zhuangbei > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiGreaterThanOrEqualTo(final String value) {
            this.addCriterion("zhuangbei >=", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("zhuangbei >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiLessThan(final String value) {
            this.addCriterion("zhuangbei <", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiLessThanColumn(final Column column) {
            this.addCriterion("zhuangbei < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiLessThanOrEqualTo(final String value) {
            this.addCriterion("zhuangbei <=", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("zhuangbei <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiLike(final String value) {
            this.addCriterion("zhuangbei like", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiNotLike(final String value) {
            this.addCriterion("zhuangbei not like", value, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiIn(final List<String> values) {
            this.addCriterion("zhuangbei in", values, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiNotIn(final List<String> values) {
            this.addCriterion("zhuangbei not in", values, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiBetween(final String value1, final String value2) {
            this.addCriterion("zhuangbei between", value1, value2, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andZhuangbeiNotBetween(final String value1, final String value2) {
            this.addCriterion("zhuangbei not between", value1, value2, "zhuangbei");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanIsNull() {
            this.addCriterion("jingyan is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanIsNotNull() {
            this.addCriterion("jingyan is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanEqualTo(final Integer value) {
            this.addCriterion("jingyan =", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanEqualToColumn(final Column column) {
            this.addCriterion("jingyan = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanNotEqualTo(final Integer value) {
            this.addCriterion("jingyan <>", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanNotEqualToColumn(final Column column) {
            this.addCriterion("jingyan <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanGreaterThan(final Integer value) {
            this.addCriterion("jingyan >", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanGreaterThanColumn(final Column column) {
            this.addCriterion("jingyan > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("jingyan >=", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("jingyan >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanLessThan(final Integer value) {
            this.addCriterion("jingyan <", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanLessThanColumn(final Column column) {
            this.addCriterion("jingyan < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanLessThanOrEqualTo(final Integer value) {
            this.addCriterion("jingyan <=", value, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("jingyan <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanIn(final List<Integer> values) {
            this.addCriterion("jingyan in", values, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanNotIn(final List<Integer> values) {
            this.addCriterion("jingyan not in", values, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanBetween(final Integer value1, final Integer value2) {
            this.addCriterion("jingyan between", value1, value2, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andJingyanNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("jingyan not between", value1, value2, "jingyan");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyIsNull() {
            this.addCriterion("money is null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyIsNotNull() {
            this.addCriterion("money is not null");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyEqualTo(final Integer value) {
            this.addCriterion("money =", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyEqualToColumn(final Column column) {
            this.addCriterion("money = " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyNotEqualTo(final Integer value) {
            this.addCriterion("money <>", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyNotEqualToColumn(final Column column) {
            this.addCriterion("money <> " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyGreaterThan(final Integer value) {
            this.addCriterion("money >", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyGreaterThanColumn(final Column column) {
            this.addCriterion("money > " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("money >=", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("money >= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyLessThan(final Integer value) {
            this.addCriterion("money <", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyLessThanColumn(final Column column) {
            this.addCriterion("money < " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyLessThanOrEqualTo(final Integer value) {
            this.addCriterion("money <=", value, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("money <= " + column.getEscapedColumnName());
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyIn(final List<Integer> values) {
            this.addCriterion("money in", values, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyNotIn(final List<Integer> values) {
            this.addCriterion("money not in", values, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyBetween(final Integer value1, final Integer value2) {
            this.addCriterion("money between", value1, value2, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }

        public NpcDialogueFrameExample.Criteria andMoneyNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("money not between", value1, value2, "money");
            return (NpcDialogueFrameExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final NpcDialogueFrameExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final NpcDialogueFrameExample paramNpcDialogueFrameExample);
    }
}
