//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "fight_object_info"
)
public class FightObjectInfo {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private String type;
    private String name;
    private Integer level;
    private String showName;
    private Integer life;
    private Integer mana;
    private Integer phyAttack;
    private Integer magAttack;
    private String polar;
    private Integer speed;
    private Integer def;
    private Integer icon;
    private Integer daohang;
    private Integer petMartial;
    private String skill;
    private String petTianshu;
    private Integer allResistPolar;
    private Integer resistMetal;
    private Integer resistWood;
    private Integer resistWater;
    private Integer resistFire;
    private Integer resistEarth;
    private Integer doubleHitRate;
    private Integer doubleHit;
    private Integer mstuntRate;
    private Date addTime;
    private Date updateTime;
    private Boolean deleted;

    public FightObjectInfo() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getLife() {
        return this.life;
    }

    public void setLife(Integer life) {
        this.life = life;
    }

    public Integer getMana() {
        return this.mana;
    }

    public void setMana(Integer mana) {
        this.mana = mana;
    }

    public Integer getPhyAttack() {
        return this.phyAttack;
    }

    public void setPhyAttack(Integer phyAttack) {
        this.phyAttack = phyAttack;
    }

    public Integer getMagAttack() {
        return this.magAttack;
    }

    public void setMagAttack(Integer magAttack) {
        this.magAttack = magAttack;
    }

    public String getPolar() {
        return this.polar;
    }

    public void setPolar(String polar) {
        this.polar = polar == null ? null : polar.trim();
    }

    public Integer getSpeed() {
        return this.speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Integer getDef() {
        return this.def;
    }

    public void setDef(Integer def) {
        this.def = def;
    }

    public Integer getIcon() {
        return this.icon;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    public Integer getDaohang() {
        return this.daohang;
    }

    public void setDaohang(Integer daohang) {
        this.daohang = daohang;
    }

    public Integer getPetMartial() {
        return this.petMartial;
    }

    public void setPetMartial(Integer petMartial) {
        this.petMartial = petMartial;
    }

    public String getSkill() {
        return this.skill;
    }

    public void setSkill(String skill) {
        this.skill = skill == null ? null : skill.trim();
    }

    public String getPetTianshu() {
        return this.petTianshu;
    }

    public void setPetTianshu(String petTianshu) {
        this.petTianshu = petTianshu == null ? null : petTianshu.trim();
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getShowName() {
        return this.showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public Integer getLevel() {
        return this.level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getAllResistPolar() {
        return this.allResistPolar;
    }

    public void setAllResistPolar(Integer allResistPolar) {
        this.allResistPolar = allResistPolar;
    }

    public Integer getResistMetal() {
        return this.resistMetal;
    }

    public void setResistMetal(Integer resistMetal) {
        this.resistMetal = resistMetal;
    }

    public Integer getResistWood() {
        return this.resistWood;
    }

    public void setResistWood(Integer resistWood) {
        this.resistWood = resistWood;
    }

    public Integer getResistWater() {
        return this.resistWater;
    }

    public void setResistWater(Integer resistWater) {
        this.resistWater = resistWater;
    }

    public Integer getResistFire() {
        return this.resistFire;
    }

    public void setResistFire(Integer resistFire) {
        this.resistFire = resistFire;
    }

    public Integer getResistEarth() {
        return this.resistEarth;
    }

    public void setResistEarth(Integer resistEarth) {
        this.resistEarth = resistEarth;
    }

    public Integer getDoubleHitRate() {
        return this.doubleHitRate;
    }

    public void setDoubleHitRate(Integer doubleHitRate) {
        this.doubleHitRate = doubleHitRate;
    }

    public Integer getDoubleHit() {
        return this.doubleHit;
    }

    public void setDoubleHit(Integer doubleHit) {
        this.doubleHit = doubleHit;
    }

    public Integer getMstuntRate() {
        return this.mstuntRate;
    }

    public void setMstuntRate(Integer mstuntRate) {
        this.mstuntRate = mstuntRate;
    }
}
