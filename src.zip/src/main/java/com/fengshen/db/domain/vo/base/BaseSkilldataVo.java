//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Skilldata;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseSkilldataVo {
    public Integer id;
    public String pid;
    public String skillName;
    public Integer skillLevel;
    public Integer skillMubiao;

    public BaseSkilldataVo() {
    }

    public BaseSkilldataVo(final Skilldata vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.pid = vo.getPid();
            this.skillName = vo.getSkillName();
            this.skillLevel = vo.getSkillLevel();
            this.skillMubiao = vo.getSkillMubiao();
        }
    }

    public static final BaseSkilldataVo t(final Skilldata vo) {
        return new BaseSkilldataVo(vo);
    }

    public static final List<BaseSkilldataVo> t(final List<Skilldata> list) {
        List<BaseSkilldataVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Skilldata temp = (Skilldata) var3.next();
            listVo.add(new BaseSkilldataVo(temp));
        }

        return listVo;
    }
}
