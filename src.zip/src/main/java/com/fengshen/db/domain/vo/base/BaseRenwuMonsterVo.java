//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.RenwuMonster;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseRenwuMonsterVo {
    public Integer id;
    public String mapName;
    public Integer x;
    public Integer y;
    public String name;
    public Integer icon;
    public String skills;
    public Integer type;

    public BaseRenwuMonsterVo() {
    }

    public BaseRenwuMonsterVo(final RenwuMonster vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.mapName = vo.getMapName();
            this.x = vo.getX();
            this.y = vo.getY();
            this.name = vo.getName();
            this.icon = vo.getIcon();
            this.skills = vo.getSkills();
            this.type = vo.getType();
        }
    }

    public static final BaseRenwuMonsterVo t(final RenwuMonster vo) {
        return new BaseRenwuMonsterVo(vo);
    }

    public static final List<BaseRenwuMonsterVo> t(final List<RenwuMonster> list) {
        List<BaseRenwuMonsterVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            RenwuMonster temp = (RenwuMonster) var3.next();
            listVo.add(new BaseRenwuMonsterVo(temp));
        }

        return listVo;
    }
}
