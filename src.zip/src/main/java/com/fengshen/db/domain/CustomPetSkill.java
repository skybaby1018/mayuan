//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "custom_pet_skill"
)
public class CustomPetSkill {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private String petName;
    private String skillName;
    private Integer skillLevel;
    private Integer skillRange;
    private Integer skillRound;
    private Date addTime;

    public CustomPetSkill() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPetName() {
        return this.petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getSkillName() {
        return this.skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public Integer getSkillRange() {
        return this.skillRange;
    }

    public void setSkillRange(Integer skillRange) {
        this.skillRange = skillRange;
    }

    public Integer getSkillRound() {
        return this.skillRound;
    }

    public void setSkillRound(Integer skillRound) {
        this.skillRound = skillRound;
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Integer getSkillLevel() {
        return this.skillLevel;
    }

    public void setSkillLevel(Integer skillLevel) {
        this.skillLevel = skillLevel;
    }
}
