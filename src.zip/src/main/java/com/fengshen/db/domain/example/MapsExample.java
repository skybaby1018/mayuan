//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Maps.Column;
import com.fengshen.db.domain.Maps.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MapsExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<MapsExample.Criteria> oredCriteria = new ArrayList();

    public MapsExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<MapsExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final MapsExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public MapsExample.Criteria or() {
        MapsExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public MapsExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public MapsExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public MapsExample.Criteria createCriteria() {
        MapsExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected MapsExample.Criteria createCriteriaInternal() {
        MapsExample.Criteria criteria = new MapsExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static MapsExample.Criteria newAndCreateCriteria() {
        MapsExample example = new MapsExample();
        return example.createCriteria();
    }

    public MapsExample when(final boolean condition, final MapsExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public MapsExample when(final boolean condition, final MapsExample.IExampleWhen then, final MapsExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends MapsExample.GeneratedCriteria {
        private MapsExample example;

        protected Criteria(final MapsExample example) {
            this.example = example;
        }

        public MapsExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public MapsExample.Criteria andIf(final boolean ifAdd, final MapsExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public MapsExample.Criteria when(final boolean condition, final MapsExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public MapsExample.Criteria when(final boolean condition, final MapsExample.ICriteriaWhen then, final MapsExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public MapsExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            MapsExample.Criteria add(final MapsExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<MapsExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<MapsExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<MapsExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new MapsExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new MapsExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new MapsExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public MapsExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapIsNull() {
            this.addCriterion("`map` is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapIsNotNull() {
            this.addCriterion("`map` is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapEqualTo(final Integer value) {
            this.addCriterion("`map` =", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapEqualToColumn(final Column column) {
            this.addCriterion("`map` = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapNotEqualTo(final Integer value) {
            this.addCriterion("`map` <>", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapNotEqualToColumn(final Column column) {
            this.addCriterion("`map` <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapGreaterThan(final Integer value) {
            this.addCriterion("`map` >", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapGreaterThanColumn(final Column column) {
            this.addCriterion("`map` > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`map` >=", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`map` >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapLessThan(final Integer value) {
            this.addCriterion("`map` <", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapLessThanColumn(final Column column) {
            this.addCriterion("`map` < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`map` <=", value, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`map` <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapIn(final List<Integer> values) {
            this.addCriterion("`map` in", values, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapNotIn(final List<Integer> values) {
            this.addCriterion("`map` not in", values, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`map` between", value1, value2, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andMapNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`map` not between", value1, value2, "map");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirIsNull() {
            this.addCriterion("dir is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirIsNotNull() {
            this.addCriterion("dir is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirEqualTo(final Float value) {
            this.addCriterion("dir =", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirEqualToColumn(final Column column) {
            this.addCriterion("dir = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirNotEqualTo(final Float value) {
            this.addCriterion("dir <>", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirNotEqualToColumn(final Column column) {
            this.addCriterion("dir <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirGreaterThan(final Float value) {
            this.addCriterion("dir >", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirGreaterThanColumn(final Column column) {
            this.addCriterion("dir > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirGreaterThanOrEqualTo(final Float value) {
            this.addCriterion("dir >=", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("dir >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirLessThan(final Float value) {
            this.addCriterion("dir <", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirLessThanColumn(final Column column) {
            this.addCriterion("dir < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirLessThanOrEqualTo(final Float value) {
            this.addCriterion("dir <=", value, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("dir <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirIn(final List<Float> values) {
            this.addCriterion("dir in", values, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirNotIn(final List<Float> values) {
            this.addCriterion("dir not in", values, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirBetween(final Float value1, final Float value2) {
            this.addCriterion("dir between", value1, value2, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDirNotBetween(final Float value1, final Float value2) {
            this.addCriterion("dir not between", value1, value2, "dir");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXIsNull() {
            this.addCriterion("x is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXIsNotNull() {
            this.addCriterion("x is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXEqualTo(final Float value) {
            this.addCriterion("x =", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXEqualToColumn(final Column column) {
            this.addCriterion("x = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXNotEqualTo(final Float value) {
            this.addCriterion("x <>", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXNotEqualToColumn(final Column column) {
            this.addCriterion("x <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXGreaterThan(final Float value) {
            this.addCriterion("x >", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXGreaterThanColumn(final Column column) {
            this.addCriterion("x > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXGreaterThanOrEqualTo(final Float value) {
            this.addCriterion("x >=", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("x >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXLessThan(final Float value) {
            this.addCriterion("x <", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXLessThanColumn(final Column column) {
            this.addCriterion("x < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXLessThanOrEqualTo(final Float value) {
            this.addCriterion("x <=", value, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("x <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXIn(final List<Float> values) {
            this.addCriterion("x in", values, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXNotIn(final List<Float> values) {
            this.addCriterion("x not in", values, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXBetween(final Float value1, final Float value2) {
            this.addCriterion("x between", value1, value2, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andXNotBetween(final Float value1, final Float value2) {
            this.addCriterion("x not between", value1, value2, "x");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYIsNull() {
            this.addCriterion("y is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYIsNotNull() {
            this.addCriterion("y is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYEqualTo(final Float value) {
            this.addCriterion("y =", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYEqualToColumn(final Column column) {
            this.addCriterion("y = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYNotEqualTo(final Float value) {
            this.addCriterion("y <>", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYNotEqualToColumn(final Column column) {
            this.addCriterion("y <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYGreaterThan(final Float value) {
            this.addCriterion("y >", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYGreaterThanColumn(final Column column) {
            this.addCriterion("y > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYGreaterThanOrEqualTo(final Float value) {
            this.addCriterion("y >=", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("y >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYLessThan(final Float value) {
            this.addCriterion("y <", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYLessThanColumn(final Column column) {
            this.addCriterion("y < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYLessThanOrEqualTo(final Float value) {
            this.addCriterion("y <=", value, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("y <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYIn(final List<Float> values) {
            this.addCriterion("y in", values, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYNotIn(final List<Float> values) {
            this.addCriterion("y not in", values, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYBetween(final Float value1, final Float value2) {
            this.addCriterion("y between", value1, value2, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andYNotBetween(final Float value1, final Float value2) {
            this.addCriterion("y not between", value1, value2, "y");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (MapsExample.Criteria) this;
        }

        public MapsExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (MapsExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final MapsExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final MapsExample paramMapsExample);
    }
}
