//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Shuxingduiying;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseShuxingduiyingVo {
    public Integer id;
    public String name;
    public String yingwen;

    public BaseShuxingduiyingVo() {
    }

    public BaseShuxingduiyingVo(final Shuxingduiying vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.name = vo.getName();
            this.yingwen = vo.getYingwen();
        }
    }

    public static final BaseShuxingduiyingVo t(final Shuxingduiying vo) {
        return new BaseShuxingduiyingVo(vo);
    }

    public static final List<BaseShuxingduiyingVo> t(final List<Shuxingduiying> list) {
        List<BaseShuxingduiyingVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Shuxingduiying temp = (Shuxingduiying) var3.next();
            listVo.add(new BaseShuxingduiyingVo(temp));
        }

        return listVo;
    }
}
