//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Npc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseNpcVo {
    public Integer id;
    public Integer icon;
    public Integer x;
    public Integer y;
    public String name;
    public Integer mapId;

    public BaseNpcVo() {
    }

    public BaseNpcVo(final Npc vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.icon = vo.getIcon();
            this.x = vo.getX();
            this.y = vo.getY();
            this.name = vo.getName();
            this.mapId = vo.getMapId();
        }
    }

    public static final BaseNpcVo t(final Npc vo) {
        return new BaseNpcVo(vo);
    }

    public static final List<BaseNpcVo> t(final List<Npc> list) {
        List<BaseNpcVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Npc temp = (Npc) var3.next();
            listVo.add(new BaseNpcVo(temp));
        }

        return listVo;
    }
}
