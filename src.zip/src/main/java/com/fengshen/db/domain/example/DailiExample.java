//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Daili.Column;
import com.fengshen.db.domain.Daili.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DailiExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<DailiExample.Criteria> oredCriteria = new ArrayList();

    public DailiExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<DailiExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final DailiExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public DailiExample.Criteria or() {
        DailiExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public DailiExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public DailiExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public DailiExample.Criteria createCriteria() {
        DailiExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected DailiExample.Criteria createCriteriaInternal() {
        DailiExample.Criteria criteria = new DailiExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static DailiExample.Criteria newAndCreateCriteria() {
        DailiExample example = new DailiExample();
        return example.createCriteria();
    }

    public DailiExample when(final boolean condition, final DailiExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public DailiExample when(final boolean condition, final DailiExample.IExampleWhen then, final DailiExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends DailiExample.GeneratedCriteria {
        private DailiExample example;

        protected Criteria(final DailiExample example) {
            this.example = example;
        }

        public DailiExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public DailiExample.Criteria andIf(final boolean ifAdd, final DailiExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public DailiExample.Criteria when(final boolean condition, final DailiExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public DailiExample.Criteria when(final boolean condition, final DailiExample.ICriteriaWhen then, final DailiExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public DailiExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            DailiExample.Criteria add(final DailiExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<DailiExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<DailiExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<DailiExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new DailiExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new DailiExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new DailiExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public DailiExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountIsNull() {
            this.addCriterion("account is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountIsNotNull() {
            this.addCriterion("account is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountEqualTo(final String value) {
            this.addCriterion("account =", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountEqualToColumn(final Column column) {
            this.addCriterion("account = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountNotEqualTo(final String value) {
            this.addCriterion("account <>", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountNotEqualToColumn(final Column column) {
            this.addCriterion("account <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountGreaterThan(final String value) {
            this.addCriterion("account >", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountGreaterThanColumn(final Column column) {
            this.addCriterion("account > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountGreaterThanOrEqualTo(final String value) {
            this.addCriterion("account >=", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("account >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountLessThan(final String value) {
            this.addCriterion("account <", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountLessThanColumn(final Column column) {
            this.addCriterion("account < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountLessThanOrEqualTo(final String value) {
            this.addCriterion("account <=", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("account <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountLike(final String value) {
            this.addCriterion("account like", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountNotLike(final String value) {
            this.addCriterion("account not like", value, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountIn(final List<String> values) {
            this.addCriterion("account in", values, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountNotIn(final List<String> values) {
            this.addCriterion("account not in", values, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountBetween(final String value1, final String value2) {
            this.addCriterion("account between", value1, value2, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAccountNotBetween(final String value1, final String value2) {
            this.addCriterion("account not between", value1, value2, "account");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdIsNull() {
            this.addCriterion("passwd is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdIsNotNull() {
            this.addCriterion("passwd is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdEqualTo(final String value) {
            this.addCriterion("passwd =", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdEqualToColumn(final Column column) {
            this.addCriterion("passwd = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdNotEqualTo(final String value) {
            this.addCriterion("passwd <>", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdNotEqualToColumn(final Column column) {
            this.addCriterion("passwd <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdGreaterThan(final String value) {
            this.addCriterion("passwd >", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdGreaterThanColumn(final Column column) {
            this.addCriterion("passwd > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdGreaterThanOrEqualTo(final String value) {
            this.addCriterion("passwd >=", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("passwd >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdLessThan(final String value) {
            this.addCriterion("passwd <", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdLessThanColumn(final Column column) {
            this.addCriterion("passwd < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdLessThanOrEqualTo(final String value) {
            this.addCriterion("passwd <=", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("passwd <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdLike(final String value) {
            this.addCriterion("passwd like", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdNotLike(final String value) {
            this.addCriterion("passwd not like", value, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdIn(final List<String> values) {
            this.addCriterion("passwd in", values, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdNotIn(final List<String> values) {
            this.addCriterion("passwd not in", values, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdBetween(final String value1, final String value2) {
            this.addCriterion("passwd between", value1, value2, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andPasswdNotBetween(final String value1, final String value2) {
            this.addCriterion("passwd not between", value1, value2, "passwd");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeIsNull() {
            this.addCriterion("code is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeIsNotNull() {
            this.addCriterion("code is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeEqualTo(final String value) {
            this.addCriterion("code =", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeEqualToColumn(final Column column) {
            this.addCriterion("code = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeNotEqualTo(final String value) {
            this.addCriterion("code <>", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeNotEqualToColumn(final Column column) {
            this.addCriterion("code <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeGreaterThan(final String value) {
            this.addCriterion("code >", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeGreaterThanColumn(final Column column) {
            this.addCriterion("code > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("code >=", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("code >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeLessThan(final String value) {
            this.addCriterion("code <", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeLessThanColumn(final Column column) {
            this.addCriterion("code < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeLessThanOrEqualTo(final String value) {
            this.addCriterion("code <=", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("code <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeLike(final String value) {
            this.addCriterion("code like", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeNotLike(final String value) {
            this.addCriterion("code not like", value, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeIn(final List<String> values) {
            this.addCriterion("code in", values, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeNotIn(final List<String> values) {
            this.addCriterion("code not in", values, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeBetween(final String value1, final String value2) {
            this.addCriterion("code between", value1, value2, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andCodeNotBetween(final String value1, final String value2) {
            this.addCriterion("code not between", value1, value2, "code");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenIsNull() {
            this.addCriterion("token is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenIsNotNull() {
            this.addCriterion("token is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenEqualTo(final String value) {
            this.addCriterion("token =", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenEqualToColumn(final Column column) {
            this.addCriterion("token = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenNotEqualTo(final String value) {
            this.addCriterion("token <>", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenNotEqualToColumn(final Column column) {
            this.addCriterion("token <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenGreaterThan(final String value) {
            this.addCriterion("token >", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenGreaterThanColumn(final Column column) {
            this.addCriterion("token > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenGreaterThanOrEqualTo(final String value) {
            this.addCriterion("token >=", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("token >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenLessThan(final String value) {
            this.addCriterion("token <", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenLessThanColumn(final Column column) {
            this.addCriterion("token < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenLessThanOrEqualTo(final String value) {
            this.addCriterion("token <=", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("token <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenLike(final String value) {
            this.addCriterion("token like", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenNotLike(final String value) {
            this.addCriterion("token not like", value, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenIn(final List<String> values) {
            this.addCriterion("token in", values, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenNotIn(final List<String> values) {
            this.addCriterion("token not in", values, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenBetween(final String value1, final String value2) {
            this.addCriterion("token between", value1, value2, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andTokenNotBetween(final String value1, final String value2) {
            this.addCriterion("token not between", value1, value2, "token");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (DailiExample.Criteria) this;
        }

        public DailiExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (DailiExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final DailiExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final DailiExample paramDailiExample);
    }
}
