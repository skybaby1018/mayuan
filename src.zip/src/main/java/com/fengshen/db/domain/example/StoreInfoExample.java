//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.StoreInfo.Column;
import com.fengshen.db.domain.StoreInfo.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class StoreInfoExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<StoreInfoExample.Criteria> oredCriteria = new ArrayList();

    public StoreInfoExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<StoreInfoExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final StoreInfoExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public StoreInfoExample.Criteria or() {
        StoreInfoExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public StoreInfoExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public StoreInfoExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public StoreInfoExample.Criteria createCriteria() {
        StoreInfoExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected StoreInfoExample.Criteria createCriteriaInternal() {
        StoreInfoExample.Criteria criteria = new StoreInfoExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static StoreInfoExample.Criteria newAndCreateCriteria() {
        StoreInfoExample example = new StoreInfoExample();
        return example.createCriteria();
    }

    public StoreInfoExample when(final boolean condition, final StoreInfoExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public StoreInfoExample when(final boolean condition, final StoreInfoExample.IExampleWhen then, final StoreInfoExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends StoreInfoExample.GeneratedCriteria {
        private StoreInfoExample example;

        protected Criteria(final StoreInfoExample example) {
            this.example = example;
        }

        public StoreInfoExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public StoreInfoExample.Criteria andIf(final boolean ifAdd, final StoreInfoExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public StoreInfoExample.Criteria when(final boolean condition, final StoreInfoExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public StoreInfoExample.Criteria when(final boolean condition, final StoreInfoExample.ICriteriaWhen then, final StoreInfoExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public StoreInfoExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            StoreInfoExample.Criteria add(final StoreInfoExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<StoreInfoExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<StoreInfoExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<StoreInfoExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new StoreInfoExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new StoreInfoExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new StoreInfoExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public StoreInfoExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityIsNull() {
            this.addCriterion("quality is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityIsNotNull() {
            this.addCriterion("quality is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityEqualTo(final String value) {
            this.addCriterion("quality =", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityEqualToColumn(final Column column) {
            this.addCriterion("quality = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityNotEqualTo(final String value) {
            this.addCriterion("quality <>", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityNotEqualToColumn(final Column column) {
            this.addCriterion("quality <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityGreaterThan(final String value) {
            this.addCriterion("quality >", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityGreaterThanColumn(final Column column) {
            this.addCriterion("quality > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityGreaterThanOrEqualTo(final String value) {
            this.addCriterion("quality >=", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("quality >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityLessThan(final String value) {
            this.addCriterion("quality <", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityLessThanColumn(final Column column) {
            this.addCriterion("quality < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityLessThanOrEqualTo(final String value) {
            this.addCriterion("quality <=", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("quality <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityLike(final String value) {
            this.addCriterion("quality like", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityNotLike(final String value) {
            this.addCriterion("quality not like", value, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityIn(final List<String> values) {
            this.addCriterion("quality in", values, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityNotIn(final List<String> values) {
            this.addCriterion("quality not in", values, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityBetween(final String value1, final String value2) {
            this.addCriterion("quality between", value1, value2, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andQualityNotBetween(final String value1, final String value2) {
            this.addCriterion("quality not between", value1, value2, "quality");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueIsNull() {
            this.addCriterion("`value` is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueIsNotNull() {
            this.addCriterion("`value` is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueEqualTo(final Integer value) {
            this.addCriterion("`value` =", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueEqualToColumn(final Column column) {
            this.addCriterion("`value` = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueNotEqualTo(final Integer value) {
            this.addCriterion("`value` <>", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueNotEqualToColumn(final Column column) {
            this.addCriterion("`value` <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueGreaterThan(final Integer value) {
            this.addCriterion("`value` >", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueGreaterThanColumn(final Column column) {
            this.addCriterion("`value` > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` >=", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueLessThan(final Integer value) {
            this.addCriterion("`value` <", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueLessThanColumn(final Column column) {
            this.addCriterion("`value` < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` <=", value, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueIn(final List<Integer> values) {
            this.addCriterion("`value` in", values, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueNotIn(final List<Integer> values) {
            this.addCriterion("`value` not in", values, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` between", value1, value2, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andValueNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` not between", value1, value2, "value");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreIsNull() {
            this.addCriterion("total_score is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreIsNotNull() {
            this.addCriterion("total_score is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreEqualTo(final Integer value) {
            this.addCriterion("total_score =", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreEqualToColumn(final Column column) {
            this.addCriterion("total_score = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreNotEqualTo(final Integer value) {
            this.addCriterion("total_score <>", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreNotEqualToColumn(final Column column) {
            this.addCriterion("total_score <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreGreaterThan(final Integer value) {
            this.addCriterion("total_score >", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreGreaterThanColumn(final Column column) {
            this.addCriterion("total_score > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("total_score >=", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("total_score >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreLessThan(final Integer value) {
            this.addCriterion("total_score <", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreLessThanColumn(final Column column) {
            this.addCriterion("total_score < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreLessThanOrEqualTo(final Integer value) {
            this.addCriterion("total_score <=", value, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("total_score <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreIn(final List<Integer> values) {
            this.addCriterion("total_score in", values, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreNotIn(final List<Integer> values) {
            this.addCriterion("total_score not in", values, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreBetween(final Integer value1, final Integer value2) {
            this.addCriterion("total_score between", value1, value2, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andTotalScoreNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("total_score not between", value1, value2, "totalScore");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedIsNull() {
            this.addCriterion("recognize_recognized is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedIsNotNull() {
            this.addCriterion("recognize_recognized is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedEqualTo(final Integer value) {
            this.addCriterion("recognize_recognized =", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedEqualToColumn(final Column column) {
            this.addCriterion("recognize_recognized = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedNotEqualTo(final Integer value) {
            this.addCriterion("recognize_recognized <>", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedNotEqualToColumn(final Column column) {
            this.addCriterion("recognize_recognized <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedGreaterThan(final Integer value) {
            this.addCriterion("recognize_recognized >", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedGreaterThanColumn(final Column column) {
            this.addCriterion("recognize_recognized > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("recognize_recognized >=", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("recognize_recognized >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedLessThan(final Integer value) {
            this.addCriterion("recognize_recognized <", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedLessThanColumn(final Column column) {
            this.addCriterion("recognize_recognized < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedLessThanOrEqualTo(final Integer value) {
            this.addCriterion("recognize_recognized <=", value, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("recognize_recognized <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedIn(final List<Integer> values) {
            this.addCriterion("recognize_recognized in", values, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedNotIn(final List<Integer> values) {
            this.addCriterion("recognize_recognized not in", values, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedBetween(final Integer value1, final Integer value2) {
            this.addCriterion("recognize_recognized between", value1, value2, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRecognizeRecognizedNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("recognize_recognized not between", value1, value2, "recognizeRecognized");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelIsNull() {
            this.addCriterion("rebuild_level is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelIsNotNull() {
            this.addCriterion("rebuild_level is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelEqualTo(final Integer value) {
            this.addCriterion("rebuild_level =", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelEqualToColumn(final Column column) {
            this.addCriterion("rebuild_level = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelNotEqualTo(final Integer value) {
            this.addCriterion("rebuild_level <>", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelNotEqualToColumn(final Column column) {
            this.addCriterion("rebuild_level <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelGreaterThan(final Integer value) {
            this.addCriterion("rebuild_level >", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelGreaterThanColumn(final Column column) {
            this.addCriterion("rebuild_level > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("rebuild_level >=", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("rebuild_level >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelLessThan(final Integer value) {
            this.addCriterion("rebuild_level <", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelLessThanColumn(final Column column) {
            this.addCriterion("rebuild_level < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("rebuild_level <=", value, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("rebuild_level <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelIn(final List<Integer> values) {
            this.addCriterion("rebuild_level in", values, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelNotIn(final List<Integer> values) {
            this.addCriterion("rebuild_level not in", values, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rebuild_level between", value1, value2, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andRebuildLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rebuild_level not between", value1, value2, "rebuildLevel");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinIsNull() {
            this.addCriterion("silver_coin is null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinIsNotNull() {
            this.addCriterion("silver_coin is not null");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinEqualTo(final Integer value) {
            this.addCriterion("silver_coin =", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinEqualToColumn(final Column column) {
            this.addCriterion("silver_coin = " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinNotEqualTo(final Integer value) {
            this.addCriterion("silver_coin <>", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinNotEqualToColumn(final Column column) {
            this.addCriterion("silver_coin <> " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinGreaterThan(final Integer value) {
            this.addCriterion("silver_coin >", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinGreaterThanColumn(final Column column) {
            this.addCriterion("silver_coin > " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("silver_coin >=", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("silver_coin >= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinLessThan(final Integer value) {
            this.addCriterion("silver_coin <", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinLessThanColumn(final Column column) {
            this.addCriterion("silver_coin < " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinLessThanOrEqualTo(final Integer value) {
            this.addCriterion("silver_coin <=", value, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("silver_coin <= " + column.getEscapedColumnName());
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinIn(final List<Integer> values) {
            this.addCriterion("silver_coin in", values, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinNotIn(final List<Integer> values) {
            this.addCriterion("silver_coin not in", values, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinBetween(final Integer value1, final Integer value2) {
            this.addCriterion("silver_coin between", value1, value2, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }

        public StoreInfoExample.Criteria andSilverCoinNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("silver_coin not between", value1, value2, "silverCoin");
            return (StoreInfoExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final StoreInfoExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final StoreInfoExample paramStoreInfoExample);
    }
}
