//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;

public class Renwu {
    private Integer id;
    private String uncontent;
    private String npcName;
    private String currentTask;
    private String showName;
    private String taskPrompt;
    private String reward;
    private String showReward;
    private String taskDesc;
    private Integer attrib;
    private Integer taskEndTime;
    private String taskState;
    private Date addTime;
    private Date updateTime;
    private Boolean deleted;

    public Renwu() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUncontent() {
        return this.uncontent;
    }

    public void setUncontent(String uncontent) {
        this.uncontent = uncontent;
    }

    public String getNpcName() {
        return this.npcName;
    }

    public void setNpcName(String npcName) {
        this.npcName = npcName;
    }

    public String getCurrentTask() {
        return this.currentTask;
    }

    public void setCurrentTask(String currentTask) {
        this.currentTask = currentTask;
    }

    public String getShowName() {
        return this.showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getTaskPrompt() {
        return this.taskPrompt;
    }

    public void setTaskPrompt(String taskPrompt) {
        this.taskPrompt = taskPrompt;
    }

    public String getReward() {
        return this.reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getShowReward() {
        return this.showReward;
    }

    public void setShowReward(String showReward) {
        this.showReward = showReward;
    }

    public String getTaskDesc() {
        return this.taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc;
    }

    public Integer getAttrib() {
        return this.attrib;
    }

    public void setAttrib(Integer attrib) {
        this.attrib = attrib;
    }

    public Integer getTaskEndTime() {
        return this.taskEndTime;
    }

    public void setTaskEndTime(Integer taskEndTime) {
        this.taskEndTime = taskEndTime;
    }

    public String getTaskState() {
        return this.taskState;
    }

    public void setTaskState(String taskState) {
        this.taskState = taskState;
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
