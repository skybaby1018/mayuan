//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.CreepsStore.Column;
import com.fengshen.db.domain.CreepsStore.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CreepsStoreExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<CreepsStoreExample.Criteria> oredCriteria = new ArrayList();

    public CreepsStoreExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<CreepsStoreExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final CreepsStoreExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public CreepsStoreExample.Criteria or() {
        CreepsStoreExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public CreepsStoreExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public CreepsStoreExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public CreepsStoreExample.Criteria createCriteria() {
        CreepsStoreExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected CreepsStoreExample.Criteria createCriteriaInternal() {
        CreepsStoreExample.Criteria criteria = new CreepsStoreExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static CreepsStoreExample.Criteria newAndCreateCriteria() {
        CreepsStoreExample example = new CreepsStoreExample();
        return example.createCriteria();
    }

    public CreepsStoreExample when(final boolean condition, final CreepsStoreExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public CreepsStoreExample when(final boolean condition, final CreepsStoreExample.IExampleWhen then, final CreepsStoreExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends CreepsStoreExample.GeneratedCriteria {
        private CreepsStoreExample example;

        protected Criteria(final CreepsStoreExample example) {
            this.example = example;
        }

        public CreepsStoreExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public CreepsStoreExample.Criteria andIf(final boolean ifAdd, final CreepsStoreExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public CreepsStoreExample.Criteria when(final boolean condition, final CreepsStoreExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public CreepsStoreExample.Criteria when(final boolean condition, final CreepsStoreExample.ICriteriaWhen then, final CreepsStoreExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public CreepsStoreExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            CreepsStoreExample.Criteria add(final CreepsStoreExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<CreepsStoreExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<CreepsStoreExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<CreepsStoreExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new CreepsStoreExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new CreepsStoreExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new CreepsStoreExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public CreepsStoreExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceIsNull() {
            this.addCriterion("price is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceIsNotNull() {
            this.addCriterion("price is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceEqualTo(final Integer value) {
            this.addCriterion("price =", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceEqualToColumn(final Column column) {
            this.addCriterion("price = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceNotEqualTo(final Integer value) {
            this.addCriterion("price <>", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceNotEqualToColumn(final Column column) {
            this.addCriterion("price <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceGreaterThan(final Integer value) {
            this.addCriterion("price >", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceGreaterThanColumn(final Column column) {
            this.addCriterion("price > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("price >=", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("price >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceLessThan(final Integer value) {
            this.addCriterion("price <", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceLessThanColumn(final Column column) {
            this.addCriterion("price < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceLessThanOrEqualTo(final Integer value) {
            this.addCriterion("price <=", value, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("price <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceIn(final List<Integer> values) {
            this.addCriterion("price in", values, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceNotIn(final List<Integer> values) {
            this.addCriterion("price not in", values, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceBetween(final Integer value1, final Integer value2) {
            this.addCriterion("price between", value1, value2, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andPriceNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("price not between", value1, value2, "price");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }

        public CreepsStoreExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (CreepsStoreExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final CreepsStoreExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final CreepsStoreExample paramCreepsStoreExample);
    }
}
