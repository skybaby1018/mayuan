/*    */
package com.fengshen.db.domain;
/*    */
/*    */

import java.util.Date;
/*    */ import javax.persistence.GeneratedValue;
/*    */ import javax.persistence.Id;
/*    */ import javax.persistence.Table;

/*    */
/*    */
/*    */
/*    */
/*    */
@Table(name = "luck_draw_item")
/*    */ public class LuckDrawItem
        /*    */ {
    /*    */
    @Id
    /*    */
    @GeneratedValue(generator = "JDBC")
    /*    */ private Integer id;
    /*    */   private String item;
    /*    */   private Integer level;
    /*    */   private Date addTime;

    /*    */
    /*    */
    public Integer getId()
    /*    */ {
        /* 23 */
        return this.id;
        /*    */
    }

    /*    */
    /*    */
    public void setId(Integer id) {
        /* 27 */
        this.id = id;
        /*    */
    }

    /*    */
    /*    */
    public String getItem() {
        /* 31 */
        return this.item;
        /*    */
    }

    /*    */
    /*    */
    public void setItem(String item) {
        /* 35 */
        this.item = item;
        /*    */
    }

    /*    */
    /*    */
    public Integer getLevel() {
        /* 39 */
        return this.level;
        /*    */
    }

    /*    */
    /*    */
    public void setLevel(Integer level) {
        /* 43 */
        this.level = level;
        /*    */
    }

    /*    */
    /*    */
    public Date getAddTime() {
        /* 47 */
        return this.addTime;
        /*    */
    }

    /*    */
    /*    */
    public void setAddTime(Date addTime) {
        /* 51 */
        this.addTime = addTime;
        /*    */
    }
    /*    */
}


/* Location:              C:\Users\X\Desktop\gamew-db-4.0.0.jar!\com\fengshen\db\domain\LuckDrawItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */