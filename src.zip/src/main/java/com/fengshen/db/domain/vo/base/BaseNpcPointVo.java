//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.NpcPoint;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseNpcPointVo {
    public Integer id;
    public String mapname;
    public String doorname;
    public Integer x;
    public Integer y;
    public Integer z;
    public Integer inx;
    public Integer iny;

    public BaseNpcPointVo() {
    }

    public BaseNpcPointVo(final NpcPoint vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.mapname = vo.getMapname();
            this.doorname = vo.getDoorname();
            this.x = vo.getX();
            this.y = vo.getY();
            this.z = vo.getZ();
            this.inx = vo.getInx();
            this.iny = vo.getIny();
        }
    }

    public static final BaseNpcPointVo t(final NpcPoint vo) {
        return new BaseNpcPointVo(vo);
    }

    public static final List<BaseNpcPointVo> t(final List<NpcPoint> list) {
        List<BaseNpcPointVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            NpcPoint temp = (NpcPoint) var3.next();
            listVo.add(new BaseNpcPointVo(temp));
        }

        return listVo;
    }
}
