//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "shidao_history"
)
public class ShidaoHistory {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private String leader;
    private String leaderUuid;
    private Integer level;
    private Integer rank;
    private Integer score;
    private Integer totalTao;
    private Integer shidaoTime;
    private Date createTime;

    public ShidaoHistory() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLeader() {
        return this.leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public String getLeaderUuid() {
        return this.leaderUuid;
    }

    public void setLeaderUuid(String leaderUuid) {
        this.leaderUuid = leaderUuid;
    }

    public Integer getLevel() {
        return this.level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getRank() {
        return this.rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Integer getScore() {
        return this.score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getTotalTao() {
        return this.totalTao;
    }

    public void setTotalTao(Integer totalTao) {
        this.totalTao = totalTao;
    }

    public Integer getShidaoTime() {
        return this.shidaoTime;
    }

    public void setShidaoTime(Integer shidaoTime) {
        this.shidaoTime = shidaoTime;
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
