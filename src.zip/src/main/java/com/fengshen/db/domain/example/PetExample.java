//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Pet.Column;
import com.fengshen.db.domain.Pet.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PetExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<PetExample.Criteria> oredCriteria = new ArrayList();

    public PetExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<PetExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final PetExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public PetExample.Criteria or() {
        PetExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public PetExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public PetExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public PetExample.Criteria createCriteria() {
        PetExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected PetExample.Criteria createCriteriaInternal() {
        PetExample.Criteria criteria = new PetExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static PetExample.Criteria newAndCreateCriteria() {
        PetExample example = new PetExample();
        return example.createCriteria();
    }

    public PetExample when(final boolean condition, final PetExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public PetExample when(final boolean condition, final PetExample.IExampleWhen then, final PetExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends PetExample.GeneratedCriteria {
        private PetExample example;

        protected Criteria(final PetExample example) {
            this.example = example;
        }

        public PetExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public PetExample.Criteria andIf(final boolean ifAdd, final PetExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public PetExample.Criteria when(final boolean condition, final PetExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public PetExample.Criteria when(final boolean condition, final PetExample.ICriteriaWhen then, final PetExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public PetExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            PetExample.Criteria add(final PetExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<PetExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<PetExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<PetExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new PetExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new PetExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new PetExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public PetExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexIsNull() {
            this.addCriterion("`index` is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexIsNotNull() {
            this.addCriterion("`index` is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexEqualTo(final Integer value) {
            this.addCriterion("`index` =", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexEqualToColumn(final Column column) {
            this.addCriterion("`index` = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexNotEqualTo(final Integer value) {
            this.addCriterion("`index` <>", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexNotEqualToColumn(final Column column) {
            this.addCriterion("`index` <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexGreaterThan(final Integer value) {
            this.addCriterion("`index` >", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexGreaterThanColumn(final Column column) {
            this.addCriterion("`index` > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`index` >=", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`index` >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexLessThan(final Integer value) {
            this.addCriterion("`index` <", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexLessThanColumn(final Column column) {
            this.addCriterion("`index` < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`index` <=", value, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`index` <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexIn(final List<Integer> values) {
            this.addCriterion("`index` in", values, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexNotIn(final List<Integer> values) {
            this.addCriterion("`index` not in", values, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`index` between", value1, value2, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIndexNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`index` not between", value1, value2, "index");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqIsNull() {
            this.addCriterion("level_req is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqIsNotNull() {
            this.addCriterion("level_req is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqEqualTo(final Integer value) {
            this.addCriterion("level_req =", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqEqualToColumn(final Column column) {
            this.addCriterion("level_req = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqNotEqualTo(final Integer value) {
            this.addCriterion("level_req <>", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqNotEqualToColumn(final Column column) {
            this.addCriterion("level_req <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqGreaterThan(final Integer value) {
            this.addCriterion("level_req >", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqGreaterThanColumn(final Column column) {
            this.addCriterion("level_req > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("level_req >=", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("level_req >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqLessThan(final Integer value) {
            this.addCriterion("level_req <", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqLessThanColumn(final Column column) {
            this.addCriterion("level_req < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqLessThanOrEqualTo(final Integer value) {
            this.addCriterion("level_req <=", value, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("level_req <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqIn(final List<Integer> values) {
            this.addCriterion("level_req in", values, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqNotIn(final List<Integer> values) {
            this.addCriterion("level_req not in", values, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqBetween(final Integer value1, final Integer value2) {
            this.addCriterion("level_req between", value1, value2, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLevelReqNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("level_req not between", value1, value2, "levelReq");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeIsNull() {
            this.addCriterion("life is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeIsNotNull() {
            this.addCriterion("life is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeEqualTo(final Integer value) {
            this.addCriterion("life =", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeEqualToColumn(final Column column) {
            this.addCriterion("life = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeNotEqualTo(final Integer value) {
            this.addCriterion("life <>", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeNotEqualToColumn(final Column column) {
            this.addCriterion("life <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeGreaterThan(final Integer value) {
            this.addCriterion("life >", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeGreaterThanColumn(final Column column) {
            this.addCriterion("life > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("life >=", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("life >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeLessThan(final Integer value) {
            this.addCriterion("life <", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeLessThanColumn(final Column column) {
            this.addCriterion("life < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("life <=", value, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("life <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeIn(final List<Integer> values) {
            this.addCriterion("life in", values, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeNotIn(final List<Integer> values) {
            this.addCriterion("life not in", values, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("life between", value1, value2, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andLifeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("life not between", value1, value2, "life");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaIsNull() {
            this.addCriterion("mana is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaIsNotNull() {
            this.addCriterion("mana is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaEqualTo(final Integer value) {
            this.addCriterion("mana =", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaEqualToColumn(final Column column) {
            this.addCriterion("mana = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaNotEqualTo(final Integer value) {
            this.addCriterion("mana <>", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaNotEqualToColumn(final Column column) {
            this.addCriterion("mana <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaGreaterThan(final Integer value) {
            this.addCriterion("mana >", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaGreaterThanColumn(final Column column) {
            this.addCriterion("mana > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("mana >=", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("mana >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaLessThan(final Integer value) {
            this.addCriterion("mana <", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaLessThanColumn(final Column column) {
            this.addCriterion("mana < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaLessThanOrEqualTo(final Integer value) {
            this.addCriterion("mana <=", value, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("mana <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaIn(final List<Integer> values) {
            this.addCriterion("mana in", values, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaNotIn(final List<Integer> values) {
            this.addCriterion("mana not in", values, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mana between", value1, value2, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andManaNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mana not between", value1, value2, "mana");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedIsNull() {
            this.addCriterion("speed is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedIsNotNull() {
            this.addCriterion("speed is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedEqualTo(final Integer value) {
            this.addCriterion("speed =", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedEqualToColumn(final Column column) {
            this.addCriterion("speed = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedNotEqualTo(final Integer value) {
            this.addCriterion("speed <>", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedNotEqualToColumn(final Column column) {
            this.addCriterion("speed <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedGreaterThan(final Integer value) {
            this.addCriterion("speed >", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedGreaterThanColumn(final Column column) {
            this.addCriterion("speed > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("speed >=", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("speed >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedLessThan(final Integer value) {
            this.addCriterion("speed <", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedLessThanColumn(final Column column) {
            this.addCriterion("speed < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedLessThanOrEqualTo(final Integer value) {
            this.addCriterion("speed <=", value, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("speed <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedIn(final List<Integer> values) {
            this.addCriterion("speed in", values, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedNotIn(final List<Integer> values) {
            this.addCriterion("speed not in", values, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedBetween(final Integer value1, final Integer value2) {
            this.addCriterion("speed between", value1, value2, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSpeedNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("speed not between", value1, value2, "speed");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackIsNull() {
            this.addCriterion("phy_attack is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackIsNotNull() {
            this.addCriterion("phy_attack is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackEqualTo(final Integer value) {
            this.addCriterion("phy_attack =", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackEqualToColumn(final Column column) {
            this.addCriterion("phy_attack = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackNotEqualTo(final Integer value) {
            this.addCriterion("phy_attack <>", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackNotEqualToColumn(final Column column) {
            this.addCriterion("phy_attack <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackGreaterThan(final Integer value) {
            this.addCriterion("phy_attack >", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackGreaterThanColumn(final Column column) {
            this.addCriterion("phy_attack > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("phy_attack >=", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("phy_attack >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackLessThan(final Integer value) {
            this.addCriterion("phy_attack <", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackLessThanColumn(final Column column) {
            this.addCriterion("phy_attack < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackLessThanOrEqualTo(final Integer value) {
            this.addCriterion("phy_attack <=", value, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("phy_attack <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackIn(final List<Integer> values) {
            this.addCriterion("phy_attack in", values, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackNotIn(final List<Integer> values) {
            this.addCriterion("phy_attack not in", values, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackBetween(final Integer value1, final Integer value2) {
            this.addCriterion("phy_attack between", value1, value2, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPhyAttackNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("phy_attack not between", value1, value2, "phyAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackIsNull() {
            this.addCriterion("mag_attack is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackIsNotNull() {
            this.addCriterion("mag_attack is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackEqualTo(final Integer value) {
            this.addCriterion("mag_attack =", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackEqualToColumn(final Column column) {
            this.addCriterion("mag_attack = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackNotEqualTo(final Integer value) {
            this.addCriterion("mag_attack <>", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackNotEqualToColumn(final Column column) {
            this.addCriterion("mag_attack <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackGreaterThan(final Integer value) {
            this.addCriterion("mag_attack >", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackGreaterThanColumn(final Column column) {
            this.addCriterion("mag_attack > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("mag_attack >=", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("mag_attack >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackLessThan(final Integer value) {
            this.addCriterion("mag_attack <", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackLessThanColumn(final Column column) {
            this.addCriterion("mag_attack < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackLessThanOrEqualTo(final Integer value) {
            this.addCriterion("mag_attack <=", value, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("mag_attack <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackIn(final List<Integer> values) {
            this.addCriterion("mag_attack in", values, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackNotIn(final List<Integer> values) {
            this.addCriterion("mag_attack not in", values, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mag_attack between", value1, value2, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andMagAttackNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("mag_attack not between", value1, value2, "magAttack");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarIsNull() {
            this.addCriterion("polar is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarIsNotNull() {
            this.addCriterion("polar is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarEqualTo(final String value) {
            this.addCriterion("polar =", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarEqualToColumn(final Column column) {
            this.addCriterion("polar = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarNotEqualTo(final String value) {
            this.addCriterion("polar <>", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarNotEqualToColumn(final Column column) {
            this.addCriterion("polar <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarGreaterThan(final String value) {
            this.addCriterion("polar >", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarGreaterThanColumn(final Column column) {
            this.addCriterion("polar > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarGreaterThanOrEqualTo(final String value) {
            this.addCriterion("polar >=", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("polar >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarLessThan(final String value) {
            this.addCriterion("polar <", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarLessThanColumn(final Column column) {
            this.addCriterion("polar < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarLessThanOrEqualTo(final String value) {
            this.addCriterion("polar <=", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("polar <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarLike(final String value) {
            this.addCriterion("polar like", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarNotLike(final String value) {
            this.addCriterion("polar not like", value, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarIn(final List<String> values) {
            this.addCriterion("polar in", values, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarNotIn(final List<String> values) {
            this.addCriterion("polar not in", values, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarBetween(final String value1, final String value2) {
            this.addCriterion("polar between", value1, value2, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andPolarNotBetween(final String value1, final String value2) {
            this.addCriterion("polar not between", value1, value2, "polar");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsIsNull() {
            this.addCriterion("skiils is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsIsNotNull() {
            this.addCriterion("skiils is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsEqualTo(final String value) {
            this.addCriterion("skiils =", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsEqualToColumn(final Column column) {
            this.addCriterion("skiils = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsNotEqualTo(final String value) {
            this.addCriterion("skiils <>", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsNotEqualToColumn(final Column column) {
            this.addCriterion("skiils <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsGreaterThan(final String value) {
            this.addCriterion("skiils >", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsGreaterThanColumn(final Column column) {
            this.addCriterion("skiils > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skiils >=", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skiils >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsLessThan(final String value) {
            this.addCriterion("skiils <", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsLessThanColumn(final Column column) {
            this.addCriterion("skiils < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsLessThanOrEqualTo(final String value) {
            this.addCriterion("skiils <=", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skiils <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsLike(final String value) {
            this.addCriterion("skiils like", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsNotLike(final String value) {
            this.addCriterion("skiils not like", value, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsIn(final List<String> values) {
            this.addCriterion("skiils in", values, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsNotIn(final List<String> values) {
            this.addCriterion("skiils not in", values, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsBetween(final String value1, final String value2) {
            this.addCriterion("skiils between", value1, value2, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andSkiilsNotBetween(final String value1, final String value2) {
            this.addCriterion("skiils not between", value1, value2, "skiils");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonIsNull() {
            this.addCriterion("zoon is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonIsNotNull() {
            this.addCriterion("zoon is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonEqualTo(final String value) {
            this.addCriterion("zoon =", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonEqualToColumn(final Column column) {
            this.addCriterion("zoon = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonNotEqualTo(final String value) {
            this.addCriterion("zoon <>", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonNotEqualToColumn(final Column column) {
            this.addCriterion("zoon <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonGreaterThan(final String value) {
            this.addCriterion("zoon >", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonGreaterThanColumn(final Column column) {
            this.addCriterion("zoon > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonGreaterThanOrEqualTo(final String value) {
            this.addCriterion("zoon >=", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("zoon >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonLessThan(final String value) {
            this.addCriterion("zoon <", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonLessThanColumn(final Column column) {
            this.addCriterion("zoon < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonLessThanOrEqualTo(final String value) {
            this.addCriterion("zoon <=", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("zoon <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonLike(final String value) {
            this.addCriterion("zoon like", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonNotLike(final String value) {
            this.addCriterion("zoon not like", value, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonIn(final List<String> values) {
            this.addCriterion("zoon in", values, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonNotIn(final List<String> values) {
            this.addCriterion("zoon not in", values, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonBetween(final String value1, final String value2) {
            this.addCriterion("zoon between", value1, value2, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andZoonNotBetween(final String value1, final String value2) {
            this.addCriterion("zoon not between", value1, value2, "zoon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconIsNull() {
            this.addCriterion("icon is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconIsNotNull() {
            this.addCriterion("icon is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconEqualTo(final Integer value) {
            this.addCriterion("icon =", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconEqualToColumn(final Column column) {
            this.addCriterion("icon = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconNotEqualTo(final Integer value) {
            this.addCriterion("icon <>", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconNotEqualToColumn(final Column column) {
            this.addCriterion("icon <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconGreaterThan(final Integer value) {
            this.addCriterion("icon >", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconGreaterThanColumn(final Column column) {
            this.addCriterion("icon > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("icon >=", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconLessThan(final Integer value) {
            this.addCriterion("icon <", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconLessThanColumn(final Column column) {
            this.addCriterion("icon < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconLessThanOrEqualTo(final Integer value) {
            this.addCriterion("icon <=", value, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconIn(final List<Integer> values) {
            this.addCriterion("icon in", values, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconNotIn(final List<Integer> values) {
            this.addCriterion("icon not in", values, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon between", value1, value2, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andIconNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon not between", value1, value2, "icon");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (PetExample.Criteria) this;
        }

        public PetExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (PetExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final PetExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final PetExample paramPetExample);
    }
}
