//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.domain;

public class SysConfig {
    private Integer id;
    private String parentKey;
    private String Des;
    private String key;
    private String value;

    public SysConfig() {
    }

    public Integer getId() {
        return this.id;
    }

    public String getParentKey() {
        return this.parentKey;
    }

    public String getDes() {
        return this.Des;
    }

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public void setParentKey(final String parentKey) {
        this.parentKey = parentKey;
    }

    public void setDes(final String Des) {
        this.Des = Des;
    }

    public void setKey(final String key) {
        this.key = key;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof SysConfig)) {
            return false;
        } else {
            SysConfig other = (SysConfig) o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label71:
                {
                    Object this$id = this.getId();
                    Object other$id = other.getId();
                    if (this$id == null) {
                        if (other$id == null) {
                            break label71;
                        }
                    } else if (this$id.equals(other$id)) {
                        break label71;
                    }

                    return false;
                }

                Object this$parentKey = this.getParentKey();
                Object other$parentKey = other.getParentKey();
                if (this$parentKey == null) {
                    if (other$parentKey != null) {
                        return false;
                    }
                } else if (!this$parentKey.equals(other$parentKey)) {
                    return false;
                }

                label57:
                {
                    Object this$Des = this.getDes();
                    Object other$Des = other.getDes();
                    if (this$Des == null) {
                        if (other$Des == null) {
                            break label57;
                        }
                    } else if (this$Des.equals(other$Des)) {
                        break label57;
                    }

                    return false;
                }

                Object this$key = this.getKey();
                Object other$key = other.getKey();
                if (this$key == null) {
                    if (other$key != null) {
                        return false;
                    }
                } else if (!this$key.equals(other$key)) {
                    return false;
                }

                Object this$value = this.getValue();
                Object other$value = other.getValue();
                if (this$value == null) {
                    if (other$value == null) {
                        return true;
                    }
                } else if (this$value.equals(other$value)) {
                    return true;
                }

                return false;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof SysConfig;
    }

    public int hashCode() {
        int result = 1;
        Object $id = this.getId();
        result = result * 59 + ($id == null ? 43 : $id.hashCode());
        Object $parentKey = this.getParentKey();
        result = result * 59 + ($parentKey == null ? 43 : $parentKey.hashCode());
        Object $Des = this.getDes();
        result = result * 59 + ($Des == null ? 43 : $Des.hashCode());
        Object $key = this.getKey();
        result = result * 59 + ($key == null ? 43 : $key.hashCode());
        Object $value = this.getValue();
        result = result * 59 + ($value == null ? 43 : $value.hashCode());
        return result;
    }

    public String toString() {
        return "SysConfig(id=" + this.getId() + ", parentKey=" + this.getParentKey() + ", Des=" + this.getDes() + ", key=" + this.getKey() + ", value=" + this.getValue() + ")";
    }
}
