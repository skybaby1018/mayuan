//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Chara_StatueExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<Chara_StatueExample.Criteria> oredCriteria = new ArrayList();

    public Chara_StatueExample() {
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<Chara_StatueExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(Chara_StatueExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public Chara_StatueExample.Criteria or() {
        Chara_StatueExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public Chara_StatueExample.Criteria createCriteria() {
        Chara_StatueExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected Chara_StatueExample.Criteria createCriteriaInternal() {
        Chara_StatueExample.Criteria criteria = new Chara_StatueExample.Criteria();
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static class Criteria extends Chara_StatueExample.GeneratedCriteria {
        protected Criteria() {
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(String condition, Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<Chara_StatueExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<Chara_StatueExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<Chara_StatueExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new Chara_StatueExample.Criterion(condition));
            }
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new Chara_StatueExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new Chara_StatueExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public Chara_StatueExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdEqualTo(Integer value) {
            this.addCriterion("id =", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdNotEqualTo(Integer value) {
            this.addCriterion("id <>", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdGreaterThan(Integer value) {
            this.addCriterion("id >", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdGreaterThanOrEqualTo(Integer value) {
            this.addCriterion("id >=", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdLessThan(Integer value) {
            this.addCriterion("id <", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdLessThanOrEqualTo(Integer value) {
            this.addCriterion("id <=", value, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdIn(List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdNotIn(List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdBetween(Integer value1, Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andIdNotBetween(Integer value1, Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridIsNull() {
            this.addCriterion("serverId is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridIsNotNull() {
            this.addCriterion("serverId is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridEqualTo(String value) {
            this.addCriterion("serverId =", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridNotEqualTo(String value) {
            this.addCriterion("serverId <>", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridGreaterThan(String value) {
            this.addCriterion("serverId >", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridGreaterThanOrEqualTo(String value) {
            this.addCriterion("serverId >=", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridLessThan(String value) {
            this.addCriterion("serverId <", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridLessThanOrEqualTo(String value) {
            this.addCriterion("serverId <=", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridLike(String value) {
            this.addCriterion("serverId like", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridNotLike(String value) {
            this.addCriterion("serverId not like", value, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridIn(List<String> values) {
            this.addCriterion("serverId in", values, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridNotIn(List<String> values) {
            this.addCriterion("serverId not in", values, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridBetween(String value1, String value2) {
            this.addCriterion("serverId between", value1, value2, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andServeridNotBetween(String value1, String value2) {
            this.addCriterion("serverId not between", value1, value2, "serverid");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameIsNull() {
            this.addCriterion("npc_name is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameIsNotNull() {
            this.addCriterion("npc_name is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameEqualTo(String value) {
            this.addCriterion("npc_name =", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameNotEqualTo(String value) {
            this.addCriterion("npc_name <>", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameGreaterThan(String value) {
            this.addCriterion("npc_name >", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameGreaterThanOrEqualTo(String value) {
            this.addCriterion("npc_name >=", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameLessThan(String value) {
            this.addCriterion("npc_name <", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameLessThanOrEqualTo(String value) {
            this.addCriterion("npc_name <=", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameLike(String value) {
            this.addCriterion("npc_name like", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameNotLike(String value) {
            this.addCriterion("npc_name not like", value, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameIn(List<String> values) {
            this.addCriterion("npc_name in", values, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameNotIn(List<String> values) {
            this.addCriterion("npc_name not in", values, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameBetween(String value1, String value2) {
            this.addCriterion("npc_name between", value1, value2, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andNpcNameNotBetween(String value1, String value2) {
            this.addCriterion("npc_name not between", value1, value2, "npcName");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeEqualTo(Date value) {
            this.addCriterion("add_time =", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeNotEqualTo(Date value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeGreaterThan(Date value) {
            this.addCriterion("add_time >", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeGreaterThanOrEqualTo(Date value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeLessThan(Date value) {
            this.addCriterion("add_time <", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeLessThanOrEqualTo(Date value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeIn(List<Date> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeNotIn(List<Date> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeBetween(Date value1, Date value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andAddTimeNotBetween(Date value1, Date value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeEqualTo(Date value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeNotEqualTo(Date value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeGreaterThan(Date value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeLessThan(Date value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeIn(List<Date> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeNotIn(List<Date> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeBetween(Date value1, Date value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedEqualTo(Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedNotEqualTo(Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedGreaterThan(Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedGreaterThanOrEqualTo(Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedLessThan(Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedLessThanOrEqualTo(Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedIn(List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedNotIn(List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedBetween(Boolean value1, Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }

        public Chara_StatueExample.Criteria andDeletedNotBetween(Boolean value1, Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (Chara_StatueExample.Criteria) this;
        }
    }
}
