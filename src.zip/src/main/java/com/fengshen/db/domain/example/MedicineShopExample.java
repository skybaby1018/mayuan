//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.MedicineShop.Column;
import com.fengshen.db.domain.MedicineShop.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MedicineShopExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<MedicineShopExample.Criteria> oredCriteria = new ArrayList();

    public MedicineShopExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<MedicineShopExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final MedicineShopExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public MedicineShopExample.Criteria or() {
        MedicineShopExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public MedicineShopExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public MedicineShopExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public MedicineShopExample.Criteria createCriteria() {
        MedicineShopExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected MedicineShopExample.Criteria createCriteriaInternal() {
        MedicineShopExample.Criteria criteria = new MedicineShopExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static MedicineShopExample.Criteria newAndCreateCriteria() {
        MedicineShopExample example = new MedicineShopExample();
        return example.createCriteria();
    }

    public MedicineShopExample when(final boolean condition, final MedicineShopExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public MedicineShopExample when(final boolean condition, final MedicineShopExample.IExampleWhen then, final MedicineShopExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends MedicineShopExample.GeneratedCriteria {
        private MedicineShopExample example;

        protected Criteria(final MedicineShopExample example) {
            this.example = example;
        }

        public MedicineShopExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public MedicineShopExample.Criteria andIf(final boolean ifAdd, final MedicineShopExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public MedicineShopExample.Criteria when(final boolean condition, final MedicineShopExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public MedicineShopExample.Criteria when(final boolean condition, final MedicineShopExample.ICriteriaWhen then, final MedicineShopExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public MedicineShopExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            MedicineShopExample.Criteria add(final MedicineShopExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<MedicineShopExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<MedicineShopExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<MedicineShopExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new MedicineShopExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new MedicineShopExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new MedicineShopExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public MedicineShopExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoIsNull() {
            this.addCriterion("goods_no is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoIsNotNull() {
            this.addCriterion("goods_no is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoEqualTo(final Integer value) {
            this.addCriterion("goods_no =", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoEqualToColumn(final Column column) {
            this.addCriterion("goods_no = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoNotEqualTo(final Integer value) {
            this.addCriterion("goods_no <>", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoNotEqualToColumn(final Column column) {
            this.addCriterion("goods_no <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoGreaterThan(final Integer value) {
            this.addCriterion("goods_no >", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoGreaterThanColumn(final Column column) {
            this.addCriterion("goods_no > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_no >=", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_no >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoLessThan(final Integer value) {
            this.addCriterion("goods_no <", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoLessThanColumn(final Column column) {
            this.addCriterion("goods_no < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_no <=", value, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_no <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoIn(final List<Integer> values) {
            this.addCriterion("goods_no in", values, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoNotIn(final List<Integer> values) {
            this.addCriterion("goods_no not in", values, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_no between", value1, value2, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andGoodsNoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_no not between", value1, value2, "goodsNo");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeIsNull() {
            this.addCriterion("pay_type is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeIsNotNull() {
            this.addCriterion("pay_type is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeEqualTo(final Integer value) {
            this.addCriterion("pay_type =", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeEqualToColumn(final Column column) {
            this.addCriterion("pay_type = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeNotEqualTo(final Integer value) {
            this.addCriterion("pay_type <>", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeNotEqualToColumn(final Column column) {
            this.addCriterion("pay_type <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeGreaterThan(final Integer value) {
            this.addCriterion("pay_type >", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeGreaterThanColumn(final Column column) {
            this.addCriterion("pay_type > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("pay_type >=", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pay_type >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeLessThan(final Integer value) {
            this.addCriterion("pay_type <", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeLessThanColumn(final Column column) {
            this.addCriterion("pay_type < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("pay_type <=", value, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pay_type <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeIn(final List<Integer> values) {
            this.addCriterion("pay_type in", values, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeNotIn(final List<Integer> values) {
            this.addCriterion("pay_type not in", values, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pay_type between", value1, value2, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andPayTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pay_type not between", value1, value2, "payType");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueIsNull() {
            this.addCriterion("`value` is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueIsNotNull() {
            this.addCriterion("`value` is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueEqualTo(final Integer value) {
            this.addCriterion("`value` =", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueEqualToColumn(final Column column) {
            this.addCriterion("`value` = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueNotEqualTo(final Integer value) {
            this.addCriterion("`value` <>", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueNotEqualToColumn(final Column column) {
            this.addCriterion("`value` <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueGreaterThan(final Integer value) {
            this.addCriterion("`value` >", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueGreaterThanColumn(final Column column) {
            this.addCriterion("`value` > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` >=", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueLessThan(final Integer value) {
            this.addCriterion("`value` <", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueLessThanColumn(final Column column) {
            this.addCriterion("`value` < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` <=", value, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueIn(final List<Integer> values) {
            this.addCriterion("`value` in", values, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueNotIn(final List<Integer> values) {
            this.addCriterion("`value` not in", values, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` between", value1, value2, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andValueNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` not between", value1, value2, "value");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelIsNull() {
            this.addCriterion("`level` is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelIsNotNull() {
            this.addCriterion("`level` is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelEqualTo(final Integer value) {
            this.addCriterion("`level` =", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelEqualToColumn(final Column column) {
            this.addCriterion("`level` = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelNotEqualTo(final Integer value) {
            this.addCriterion("`level` <>", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelNotEqualToColumn(final Column column) {
            this.addCriterion("`level` <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelGreaterThan(final Integer value) {
            this.addCriterion("`level` >", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelGreaterThanColumn(final Column column) {
            this.addCriterion("`level` > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` >=", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelLessThan(final Integer value) {
            this.addCriterion("`level` <", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelLessThanColumn(final Column column) {
            this.addCriterion("`level` < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` <=", value, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelIn(final List<Integer> values) {
            this.addCriterion("`level` in", values, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelNotIn(final List<Integer> values) {
            this.addCriterion("`level` not in", values, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` between", value1, value2, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` not between", value1, value2, "level");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountIsNull() {
            this.addCriterion("itemCount is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountIsNotNull() {
            this.addCriterion("itemCount is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountEqualTo(final Integer value) {
            this.addCriterion("itemCount =", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountEqualToColumn(final Column column) {
            this.addCriterion("itemCount = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountNotEqualTo(final Integer value) {
            this.addCriterion("itemCount <>", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountNotEqualToColumn(final Column column) {
            this.addCriterion("itemCount <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountGreaterThan(final Integer value) {
            this.addCriterion("itemCount >", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountGreaterThanColumn(final Column column) {
            this.addCriterion("itemCount > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("itemCount >=", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("itemCount >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountLessThan(final Integer value) {
            this.addCriterion("itemCount <", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountLessThanColumn(final Column column) {
            this.addCriterion("itemCount < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountLessThanOrEqualTo(final Integer value) {
            this.addCriterion("itemCount <=", value, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("itemCount <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountIn(final List<Integer> values) {
            this.addCriterion("itemCount in", values, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountNotIn(final List<Integer> values) {
            this.addCriterion("itemCount not in", values, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountBetween(final Integer value1, final Integer value2) {
            this.addCriterion("itemCount between", value1, value2, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andItemcountNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("itemCount not between", value1, value2, "itemcount");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (MedicineShopExample.Criteria) this;
        }

        public MedicineShopExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (MedicineShopExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final MedicineShopExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final MedicineShopExample paramMedicineShopExample);
    }
}
