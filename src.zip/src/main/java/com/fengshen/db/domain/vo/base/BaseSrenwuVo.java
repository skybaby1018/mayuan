//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Srenwu;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseSrenwuVo {
    public Integer id;
    public String pid;
    public Integer rid;
    public String skillName;
    public String skillJieshao;
    public String skillDqti;
    public String skillXck;

    public BaseSrenwuVo() {
    }

    public BaseSrenwuVo(final Srenwu vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.pid = vo.getPid();
            this.rid = vo.getRid();
            this.skillName = vo.getSkillName();
            this.skillJieshao = vo.getSkillJieshao();
            this.skillDqti = vo.getSkillDqti();
            this.skillXck = vo.getSkillXck();
        }
    }

    public static final BaseSrenwuVo t(final Srenwu vo) {
        return new BaseSrenwuVo(vo);
    }

    public static final List<BaseSrenwuVo> t(final List<Srenwu> list) {
        List<BaseSrenwuVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Srenwu temp = (Srenwu) var3.next();
            listVo.add(new BaseSrenwuVo(temp));
        }

        return listVo;
    }
}
