//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.Reports;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseReportsVo {
    public Integer id;
    public String zhanghao;
    public Integer yuanbaoshu;
    public String shifouchongzhi;

    public BaseReportsVo() {
    }

    public BaseReportsVo(final Reports vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.zhanghao = vo.getZhanghao();
            this.yuanbaoshu = vo.getYuanbaoshu();
            this.shifouchongzhi = vo.getShifouchongzhi();
        }
    }

    public static final BaseReportsVo t(final Reports vo) {
        return new BaseReportsVo(vo);
    }

    public static final List<BaseReportsVo> t(final List<Reports> list) {
        List<BaseReportsVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            Reports temp = (Reports) var3.next();
            listVo.add(new BaseReportsVo(temp));
        }

        return listVo;
    }
}
