//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.vo.base;

import com.fengshen.db.domain.CreepsStore;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BaseCreepsStoreVo {
    public Integer id;
    public String name;
    public Integer price;

    public BaseCreepsStoreVo() {
    }

    public BaseCreepsStoreVo(final CreepsStore vo) {
        if (vo != null) {
            this.id = vo.getId();
            this.name = vo.getName();
            this.price = vo.getPrice();
        }
    }

    public static final BaseCreepsStoreVo t(final CreepsStore vo) {
        return new BaseCreepsStoreVo(vo);
    }

    public static final List<BaseCreepsStoreVo> t(final List<CreepsStore> list) {
        List<BaseCreepsStoreVo> listVo = new ArrayList();
        Iterator var3 = list.iterator();

        while (var3.hasNext()) {
            CreepsStore temp = (CreepsStore) var3.next();
            listVo.add(new BaseCreepsStoreVo(temp));
        }

        return listVo;
    }
}
