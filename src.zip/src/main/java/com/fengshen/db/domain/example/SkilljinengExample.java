//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Skilljineng.Column;
import com.fengshen.db.domain.Skilljineng.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SkilljinengExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<SkilljinengExample.Criteria> oredCriteria = new ArrayList();

    public SkilljinengExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<SkilljinengExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final SkilljinengExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public SkilljinengExample.Criteria or() {
        SkilljinengExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public SkilljinengExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public SkilljinengExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public SkilljinengExample.Criteria createCriteria() {
        SkilljinengExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected SkilljinengExample.Criteria createCriteriaInternal() {
        SkilljinengExample.Criteria criteria = new SkilljinengExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static SkilljinengExample.Criteria newAndCreateCriteria() {
        SkilljinengExample example = new SkilljinengExample();
        return example.createCriteria();
    }

    public SkilljinengExample when(final boolean condition, final SkilljinengExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public SkilljinengExample when(final boolean condition, final SkilljinengExample.IExampleWhen then, final SkilljinengExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends SkilljinengExample.GeneratedCriteria {
        private SkilljinengExample example;

        protected Criteria(final SkilljinengExample example) {
            this.example = example;
        }

        public SkilljinengExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public SkilljinengExample.Criteria andIf(final boolean ifAdd, final SkilljinengExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public SkilljinengExample.Criteria when(final boolean condition, final SkilljinengExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public SkilljinengExample.Criteria when(final boolean condition, final SkilljinengExample.ICriteriaWhen then, final SkilljinengExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public SkilljinengExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            SkilljinengExample.Criteria add(final SkilljinengExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<SkilljinengExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<SkilljinengExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<SkilljinengExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new SkilljinengExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new SkilljinengExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new SkilljinengExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public SkilljinengExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidIsNull() {
            this.addCriterion("rid is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidIsNotNull() {
            this.addCriterion("rid is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidEqualTo(final Integer value) {
            this.addCriterion("rid =", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidEqualToColumn(final Column column) {
            this.addCriterion("rid = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidNotEqualTo(final Integer value) {
            this.addCriterion("rid <>", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidNotEqualToColumn(final Column column) {
            this.addCriterion("rid <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidGreaterThan(final Integer value) {
            this.addCriterion("rid >", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidGreaterThanColumn(final Column column) {
            this.addCriterion("rid > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("rid >=", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("rid >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidLessThan(final Integer value) {
            this.addCriterion("rid <", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidLessThanColumn(final Column column) {
            this.addCriterion("rid < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidLessThanOrEqualTo(final Integer value) {
            this.addCriterion("rid <=", value, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("rid <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidIn(final List<Integer> values) {
            this.addCriterion("rid in", values, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidNotIn(final List<Integer> values) {
            this.addCriterion("rid not in", values, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rid between", value1, value2, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andRidNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rid not between", value1, value2, "rid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidIsNull() {
            this.addCriterion("pid is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidIsNotNull() {
            this.addCriterion("pid is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidEqualTo(final String value) {
            this.addCriterion("pid =", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidEqualToColumn(final Column column) {
            this.addCriterion("pid = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidNotEqualTo(final String value) {
            this.addCriterion("pid <>", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidNotEqualToColumn(final Column column) {
            this.addCriterion("pid <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidGreaterThan(final String value) {
            this.addCriterion("pid >", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidGreaterThanColumn(final Column column) {
            this.addCriterion("pid > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidGreaterThanOrEqualTo(final String value) {
            this.addCriterion("pid >=", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidLessThan(final String value) {
            this.addCriterion("pid <", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidLessThanColumn(final Column column) {
            this.addCriterion("pid < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidLessThanOrEqualTo(final String value) {
            this.addCriterion("pid <=", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pid <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidLike(final String value) {
            this.addCriterion("pid like", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidNotLike(final String value) {
            this.addCriterion("pid not like", value, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidIn(final List<String> values) {
            this.addCriterion("pid in", values, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidNotIn(final List<String> values) {
            this.addCriterion("pid not in", values, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidBetween(final String value1, final String value2) {
            this.addCriterion("pid between", value1, value2, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andPidNotBetween(final String value1, final String value2) {
            this.addCriterion("pid not between", value1, value2, "pid");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameIsNull() {
            this.addCriterion("skill_name is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameIsNotNull() {
            this.addCriterion("skill_name is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameEqualTo(final String value) {
            this.addCriterion("skill_name =", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameEqualToColumn(final Column column) {
            this.addCriterion("skill_name = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameNotEqualTo(final String value) {
            this.addCriterion("skill_name <>", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameNotEqualToColumn(final Column column) {
            this.addCriterion("skill_name <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameGreaterThan(final String value) {
            this.addCriterion("skill_name >", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameGreaterThanColumn(final Column column) {
            this.addCriterion("skill_name > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_name >=", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameLessThan(final String value) {
            this.addCriterion("skill_name <", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameLessThanColumn(final Column column) {
            this.addCriterion("skill_name < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_name <=", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameLike(final String value) {
            this.addCriterion("skill_name like", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameNotLike(final String value) {
            this.addCriterion("skill_name not like", value, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameIn(final List<String> values) {
            this.addCriterion("skill_name in", values, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameNotIn(final List<String> values) {
            this.addCriterion("skill_name not in", values, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameBetween(final String value1, final String value2) {
            this.addCriterion("skill_name between", value1, value2, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillNameNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_name not between", value1, value2, "skillName");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelIsNull() {
            this.addCriterion("skill_level is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelIsNotNull() {
            this.addCriterion("skill_level is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelEqualTo(final Integer value) {
            this.addCriterion("skill_level =", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelEqualToColumn(final Column column) {
            this.addCriterion("skill_level = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelNotEqualTo(final Integer value) {
            this.addCriterion("skill_level <>", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelNotEqualToColumn(final Column column) {
            this.addCriterion("skill_level <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelGreaterThan(final Integer value) {
            this.addCriterion("skill_level >", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelGreaterThanColumn(final Column column) {
            this.addCriterion("skill_level > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level >=", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelLessThan(final Integer value) {
            this.addCriterion("skill_level <", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelLessThanColumn(final Column column) {
            this.addCriterion("skill_level < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level <=", value, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelIn(final List<Integer> values) {
            this.addCriterion("skill_level in", values, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelNotIn(final List<Integer> values) {
            this.addCriterion("skill_level not in", values, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level between", value1, value2, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level not between", value1, value2, "skillLevel");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoIsNull() {
            this.addCriterion("skill_mubiao is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoIsNotNull() {
            this.addCriterion("skill_mubiao is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao =", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoNotEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <>", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoNotEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoGreaterThan(final Integer value) {
            this.addCriterion("skill_mubiao >", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoGreaterThanColumn(final Column column) {
            this.addCriterion("skill_mubiao > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao >=", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoLessThan(final Integer value) {
            this.addCriterion("skill_mubiao <", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoLessThanColumn(final Column column) {
            this.addCriterion("skill_mubiao < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <=", value, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao in", values, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoNotIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao not in", values, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao between", value1, value2, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMubiaoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao not between", value1, value2, "skillMubiao");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpIsNull() {
            this.addCriterion("skill_mp is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpIsNotNull() {
            this.addCriterion("skill_mp is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpEqualTo(final Integer value) {
            this.addCriterion("skill_mp =", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpEqualToColumn(final Column column) {
            this.addCriterion("skill_mp = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpNotEqualTo(final Integer value) {
            this.addCriterion("skill_mp <>", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpNotEqualToColumn(final Column column) {
            this.addCriterion("skill_mp <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpGreaterThan(final Integer value) {
            this.addCriterion("skill_mp >", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpGreaterThanColumn(final Column column) {
            this.addCriterion("skill_mp > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mp >=", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mp >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpLessThan(final Integer value) {
            this.addCriterion("skill_mp <", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpLessThanColumn(final Column column) {
            this.addCriterion("skill_mp < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mp <=", value, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mp <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpIn(final List<Integer> values) {
            this.addCriterion("skill_mp in", values, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpNotIn(final List<Integer> values) {
            this.addCriterion("skill_mp not in", values, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mp between", value1, value2, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andSkillMpNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mp not between", value1, value2, "skillMp");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (SkilljinengExample.Criteria) this;
        }

        public SkilljinengExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (SkilljinengExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final SkilljinengExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final SkilljinengExample paramSkilljinengExample);
    }
}
