//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import lombok.Data;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "characters"
)
@Data
public class Characters {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private Integer polar;
    private String name;
    private Integer sex;
    private Integer chargeScore;
    private Integer mapId;
    private String mapName;
    private Integer x;
    private Integer y;
    private Integer level;
    private Integer goldCoin;
    private Integer accountId;
    private Date addTime;
    private Date updateTime;
    private Boolean deleted;
    private String gid;
    private Integer online;
    private String data;
    private String cangku;
    private String texiao;
    private String genchong;
    private String backpack;
    private String petStore;
    private String listshouhu;
    private String tyzqStore;
    private String shizhuang;
    private String cardStore;
    private String customShizhuang;
    private Integer lastLoginTime;
    private Integer block;
    private Integer xiaozi;
    private String lastLoginIp;
    private Integer portrait;
    private Integer monthTao;
    private Integer voucher;

    public Characters() {
    }

    public boolean getNewbi() {
        return isNewbi;
    }

    public void setNewbi(boolean newbi) {
        isNewbi = newbi;
    }

    public boolean isNewbi = false;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPolar() {
        return this.polar;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAccountId() {
        return this.accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Date getAddTime() {
        return this.addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return this.deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getGid() {
        return this.gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public Integer getOnline() {
        return this.online;
    }

    public void setOnline(Integer online) {
        this.online = online;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCangku() {
        return this.cangku;
    }

    public void setCangku(String cangku) {
        this.cangku = cangku;
    }

    public String getTexiao() {
        return this.texiao;
    }

    public void setTexiao(String texiao) {
        this.texiao = texiao;
    }

    public String getGenchong() {
        return this.genchong;
    }

    public void setGenchong(String genchong) {
        this.genchong = genchong;
    }

    public String getBackpack() {
        return this.backpack;
    }

    public void setBackpack(String backpack) {
        this.backpack = backpack;
    }

    public String getPetStore() {
        return this.petStore;
    }

    public void setPetStore(String petStore) {
        this.petStore = petStore;
    }

    public void setPolar(Integer polar) {
        this.polar = polar;
    }

    public String getListshouhu() {
        return this.listshouhu;
    }

    public void setListshouhu(String listshouhu) {
        this.listshouhu = listshouhu;
    }

    public String getShizhuang() {
        return this.shizhuang;
    }

    public void setShizhuang(String shizhuang) {
        this.shizhuang = shizhuang;
    }

    public String getCardStore() {
        return this.cardStore;
    }

    public void setCardStore(String cardStore) {
        this.cardStore = cardStore;
    }

    public Integer getLastLoginTime() {
        return this.lastLoginTime;
    }

    public void setLastLoginTime(Integer lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public Integer getBlock() {
        return this.block;
    }

    public void setBlock(Integer block) {
        this.block = block;
    }

    public Integer getXiaozi() {
        return this.xiaozi;
    }

    public void setXiaozi(Integer xiaozi) {
        this.xiaozi = xiaozi;
    }

    public String getCustomShizhuang() {
        return this.customShizhuang;
    }

    public void setCustomShizhuang(String customShizhuang) {
        this.customShizhuang = customShizhuang;
    }

    public String getLastLoginIp() {
        return this.lastLoginIp;
    }

    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    public Integer getChargeScore() {
        return this.chargeScore;
    }

    public void setChargeScore(Integer chargeScore) {
        this.chargeScore = chargeScore;
    }

    public Integer getMapId() {
        return this.mapId;
    }

    public void setMapId(Integer mapId) {
        this.mapId = mapId;
    }

    public String getMapName() {
        return this.mapName;
    }

    public void setMapName(String mapName) {
        this.mapName = mapName;
    }

    public Integer getX() {
        return this.x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return this.y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getLevel() {
        return this.level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getSex() {
        return this.sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getGoldCoin() {
        return this.goldCoin;
    }

    public void setGoldCoin(Integer goldCoin) {
        this.goldCoin = goldCoin;
    }

    public Integer getPortrait() {
        return this.portrait;
    }

    public void setPortrait(Integer portrait) {
        this.portrait = portrait;
    }

    public Integer getMonthTao() {
        return this.monthTao;
    }

    public void setMonthTao(Integer monthTao) {
        this.monthTao = monthTao;
    }

    public Integer getVoucher() {
        return voucher;
    }

    public void setVoucher(Integer voucher) {
        this.voucher = voucher;
    }

    public String getTyzqStore() {
        return tyzqStore;
    }

    public void setTyzqStore(String tyzqStore) {
        this.tyzqStore = tyzqStore;
    }
}
