//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.SkillsChongw.Column;
import com.fengshen.db.domain.SkillsChongw.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SkillsChongwExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<SkillsChongwExample.Criteria> oredCriteria = new ArrayList();

    public SkillsChongwExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<SkillsChongwExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final SkillsChongwExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public SkillsChongwExample.Criteria or() {
        SkillsChongwExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public SkillsChongwExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public SkillsChongwExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public SkillsChongwExample.Criteria createCriteria() {
        SkillsChongwExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected SkillsChongwExample.Criteria createCriteriaInternal() {
        SkillsChongwExample.Criteria criteria = new SkillsChongwExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static SkillsChongwExample.Criteria newAndCreateCriteria() {
        SkillsChongwExample example = new SkillsChongwExample();
        return example.createCriteria();
    }

    public SkillsChongwExample when(final boolean condition, final SkillsChongwExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public SkillsChongwExample when(final boolean condition, final SkillsChongwExample.IExampleWhen then, final SkillsChongwExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends SkillsChongwExample.GeneratedCriteria {
        private SkillsChongwExample example;

        protected Criteria(final SkillsChongwExample example) {
            this.example = example;
        }

        public SkillsChongwExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public SkillsChongwExample.Criteria andIf(final boolean ifAdd, final SkillsChongwExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public SkillsChongwExample.Criteria when(final boolean condition, final SkillsChongwExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public SkillsChongwExample.Criteria when(final boolean condition, final SkillsChongwExample.ICriteriaWhen then, final SkillsChongwExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public SkillsChongwExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            SkillsChongwExample.Criteria add(final SkillsChongwExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<SkillsChongwExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<SkillsChongwExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<SkillsChongwExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new SkillsChongwExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new SkillsChongwExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new SkillsChongwExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public SkillsChongwExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridIsNull() {
            this.addCriterion("ownerid is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridIsNotNull() {
            this.addCriterion("ownerid is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridEqualTo(final String value) {
            this.addCriterion("ownerid =", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridEqualToColumn(final Column column) {
            this.addCriterion("ownerid = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridNotEqualTo(final String value) {
            this.addCriterion("ownerid <>", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridNotEqualToColumn(final Column column) {
            this.addCriterion("ownerid <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridGreaterThan(final String value) {
            this.addCriterion("ownerid >", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridGreaterThanColumn(final Column column) {
            this.addCriterion("ownerid > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridGreaterThanOrEqualTo(final String value) {
            this.addCriterion("ownerid >=", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("ownerid >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridLessThan(final String value) {
            this.addCriterion("ownerid <", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridLessThanColumn(final Column column) {
            this.addCriterion("ownerid < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridLessThanOrEqualTo(final String value) {
            this.addCriterion("ownerid <=", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("ownerid <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridLike(final String value) {
            this.addCriterion("ownerid like", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridNotLike(final String value) {
            this.addCriterion("ownerid not like", value, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridIn(final List<String> values) {
            this.addCriterion("ownerid in", values, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridNotIn(final List<String> values) {
            this.addCriterion("ownerid not in", values, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridBetween(final String value1, final String value2) {
            this.addCriterion("ownerid between", value1, value2, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andOwneridNotBetween(final String value1, final String value2) {
            this.addCriterion("ownerid not between", value1, value2, "ownerid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidIsNull() {
            this.addCriterion("skll_cwid is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidIsNotNull() {
            this.addCriterion("skll_cwid is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidEqualTo(final String value) {
            this.addCriterion("skll_cwid =", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidEqualToColumn(final Column column) {
            this.addCriterion("skll_cwid = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidNotEqualTo(final String value) {
            this.addCriterion("skll_cwid <>", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidNotEqualToColumn(final Column column) {
            this.addCriterion("skll_cwid <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidGreaterThan(final String value) {
            this.addCriterion("skll_cwid >", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidGreaterThanColumn(final Column column) {
            this.addCriterion("skll_cwid > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skll_cwid >=", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skll_cwid >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidLessThan(final String value) {
            this.addCriterion("skll_cwid <", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidLessThanColumn(final Column column) {
            this.addCriterion("skll_cwid < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidLessThanOrEqualTo(final String value) {
            this.addCriterion("skll_cwid <=", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skll_cwid <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidLike(final String value) {
            this.addCriterion("skll_cwid like", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidNotLike(final String value) {
            this.addCriterion("skll_cwid not like", value, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidIn(final List<String> values) {
            this.addCriterion("skll_cwid in", values, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidNotIn(final List<String> values) {
            this.addCriterion("skll_cwid not in", values, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidBetween(final String value1, final String value2) {
            this.addCriterion("skll_cwid between", value1, value2, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkllCwidNotBetween(final String value1, final String value2) {
            this.addCriterion("skll_cwid not between", value1, value2, "skllCwid");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexIsNull() {
            this.addCriterion("skill_id_hex is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexIsNotNull() {
            this.addCriterion("skill_id_hex is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexEqualTo(final String value) {
            this.addCriterion("skill_id_hex =", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexNotEqualTo(final String value) {
            this.addCriterion("skill_id_hex <>", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexNotEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexGreaterThan(final String value) {
            this.addCriterion("skill_id_hex >", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexGreaterThanColumn(final Column column) {
            this.addCriterion("skill_id_hex > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_id_hex >=", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexLessThan(final String value) {
            this.addCriterion("skill_id_hex <", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexLessThanColumn(final Column column) {
            this.addCriterion("skill_id_hex < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_id_hex <=", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexLike(final String value) {
            this.addCriterion("skill_id_hex like", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexNotLike(final String value) {
            this.addCriterion("skill_id_hex not like", value, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexIn(final List<String> values) {
            this.addCriterion("skill_id_hex in", values, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexNotIn(final List<String> values) {
            this.addCriterion("skill_id_hex not in", values, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexBetween(final String value1, final String value2) {
            this.addCriterion("skill_id_hex between", value1, value2, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillIdHexNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_id_hex not between", value1, value2, "skillIdHex");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameIsNull() {
            this.addCriterion("skill_name is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameIsNotNull() {
            this.addCriterion("skill_name is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameEqualTo(final String value) {
            this.addCriterion("skill_name =", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameEqualToColumn(final Column column) {
            this.addCriterion("skill_name = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameNotEqualTo(final String value) {
            this.addCriterion("skill_name <>", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameNotEqualToColumn(final Column column) {
            this.addCriterion("skill_name <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameGreaterThan(final String value) {
            this.addCriterion("skill_name >", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameGreaterThanColumn(final Column column) {
            this.addCriterion("skill_name > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_name >=", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameLessThan(final String value) {
            this.addCriterion("skill_name <", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameLessThanColumn(final Column column) {
            this.addCriterion("skill_name < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_name <=", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameLike(final String value) {
            this.addCriterion("skill_name like", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameNotLike(final String value) {
            this.addCriterion("skill_name not like", value, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameIn(final List<String> values) {
            this.addCriterion("skill_name in", values, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameNotIn(final List<String> values) {
            this.addCriterion("skill_name not in", values, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameBetween(final String value1, final String value2) {
            this.addCriterion("skill_name between", value1, value2, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillNameNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_name not between", value1, value2, "skillName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarIsNull() {
            this.addCriterion("skill_req_polar is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarIsNotNull() {
            this.addCriterion("skill_req_polar is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar =", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarNotEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar <>", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarNotEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarGreaterThan(final Integer value) {
            this.addCriterion("skill_req_polar >", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarGreaterThanColumn(final Column column) {
            this.addCriterion("skill_req_polar > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar >=", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarLessThan(final Integer value) {
            this.addCriterion("skill_req_polar <", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarLessThanColumn(final Column column) {
            this.addCriterion("skill_req_polar < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar <=", value, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarIn(final List<Integer> values) {
            this.addCriterion("skill_req_polar in", values, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarNotIn(final List<Integer> values) {
            this.addCriterion("skill_req_polar not in", values, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_polar between", value1, value2, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillReqpolarNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_polar not between", value1, value2, "skillReqpolar");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelIsNull() {
            this.addCriterion("skill_level is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelIsNotNull() {
            this.addCriterion("skill_level is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelEqualTo(final Integer value) {
            this.addCriterion("skill_level =", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelEqualToColumn(final Column column) {
            this.addCriterion("skill_level = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelNotEqualTo(final Integer value) {
            this.addCriterion("skill_level <>", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelNotEqualToColumn(final Column column) {
            this.addCriterion("skill_level <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelGreaterThan(final Integer value) {
            this.addCriterion("skill_level >", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelGreaterThanColumn(final Column column) {
            this.addCriterion("skill_level > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level >=", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelLessThan(final Integer value) {
            this.addCriterion("skill_level <", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelLessThanColumn(final Column column) {
            this.addCriterion("skill_level < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_level <=", value, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_level <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelIn(final List<Integer> values) {
            this.addCriterion("skill_level in", values, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelNotIn(final List<Integer> values) {
            this.addCriterion("skill_level not in", values, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level between", value1, value2, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_level not between", value1, value2, "skillLevel");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoIsNull() {
            this.addCriterion("skill_mubiao is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoIsNotNull() {
            this.addCriterion("skill_mubiao is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao =", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoNotEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <>", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoNotEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoGreaterThan(final Integer value) {
            this.addCriterion("skill_mubiao >", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoGreaterThanColumn(final Column column) {
            this.addCriterion("skill_mubiao > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao >=", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoLessThan(final Integer value) {
            this.addCriterion("skill_mubiao <", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoLessThanColumn(final Column column) {
            this.addCriterion("skill_mubiao < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_mubiao <=", value, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_mubiao <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao in", values, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoNotIn(final List<Integer> values) {
            this.addCriterion("skill_mubiao not in", values, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao between", value1, value2, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andSkillMubiaoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_mubiao not between", value1, value2, "skillMubiao");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdIsNull() {
            this.addCriterion("tianshu_id is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdIsNotNull() {
            this.addCriterion("tianshu_id is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdEqualTo(final String value) {
            this.addCriterion("tianshu_id =", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdEqualToColumn(final Column column) {
            this.addCriterion("tianshu_id = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdNotEqualTo(final String value) {
            this.addCriterion("tianshu_id <>", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdNotEqualToColumn(final Column column) {
            this.addCriterion("tianshu_id <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdGreaterThan(final String value) {
            this.addCriterion("tianshu_id >", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdGreaterThanColumn(final Column column) {
            this.addCriterion("tianshu_id > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdGreaterThanOrEqualTo(final String value) {
            this.addCriterion("tianshu_id >=", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("tianshu_id >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdLessThan(final String value) {
            this.addCriterion("tianshu_id <", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdLessThanColumn(final Column column) {
            this.addCriterion("tianshu_id < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdLessThanOrEqualTo(final String value) {
            this.addCriterion("tianshu_id <=", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("tianshu_id <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdLike(final String value) {
            this.addCriterion("tianshu_id like", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdNotLike(final String value) {
            this.addCriterion("tianshu_id not like", value, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdIn(final List<String> values) {
            this.addCriterion("tianshu_id in", values, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdNotIn(final List<String> values) {
            this.addCriterion("tianshu_id not in", values, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdBetween(final String value1, final String value2) {
            this.addCriterion("tianshu_id between", value1, value2, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuIdNotBetween(final String value1, final String value2) {
            this.addCriterion("tianshu_id not between", value1, value2, "tianshuId");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameIsNull() {
            this.addCriterion("tianshu_name is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameIsNotNull() {
            this.addCriterion("tianshu_name is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameEqualTo(final String value) {
            this.addCriterion("tianshu_name =", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameEqualToColumn(final Column column) {
            this.addCriterion("tianshu_name = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameNotEqualTo(final String value) {
            this.addCriterion("tianshu_name <>", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameNotEqualToColumn(final Column column) {
            this.addCriterion("tianshu_name <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameGreaterThan(final String value) {
            this.addCriterion("tianshu_name >", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameGreaterThanColumn(final Column column) {
            this.addCriterion("tianshu_name > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("tianshu_name >=", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("tianshu_name >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameLessThan(final String value) {
            this.addCriterion("tianshu_name <", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameLessThanColumn(final Column column) {
            this.addCriterion("tianshu_name < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameLessThanOrEqualTo(final String value) {
            this.addCriterion("tianshu_name <=", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("tianshu_name <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameLike(final String value) {
            this.addCriterion("tianshu_name like", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameNotLike(final String value) {
            this.addCriterion("tianshu_name not like", value, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameIn(final List<String> values) {
            this.addCriterion("tianshu_name in", values, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameNotIn(final List<String> values) {
            this.addCriterion("tianshu_name not in", values, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameBetween(final String value1, final String value2) {
            this.addCriterion("tianshu_name between", value1, value2, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andTianshuNameNotBetween(final String value1, final String value2) {
            this.addCriterion("tianshu_name not between", value1, value2, "tianshuName");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }

        public SkillsChongwExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (SkillsChongwExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final SkillsChongwExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final SkillsChongwExample paramSkillsChongwExample);
    }
}
