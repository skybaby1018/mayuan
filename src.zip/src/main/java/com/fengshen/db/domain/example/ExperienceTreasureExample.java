//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.ExperienceTreasure.Column;
import com.fengshen.db.domain.ExperienceTreasure.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ExperienceTreasureExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<ExperienceTreasureExample.Criteria> oredCriteria = new ArrayList();

    public ExperienceTreasureExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<ExperienceTreasureExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final ExperienceTreasureExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public ExperienceTreasureExample.Criteria or() {
        ExperienceTreasureExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public ExperienceTreasureExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public ExperienceTreasureExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public ExperienceTreasureExample.Criteria createCriteria() {
        ExperienceTreasureExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected ExperienceTreasureExample.Criteria createCriteriaInternal() {
        ExperienceTreasureExample.Criteria criteria = new ExperienceTreasureExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static ExperienceTreasureExample.Criteria newAndCreateCriteria() {
        ExperienceTreasureExample example = new ExperienceTreasureExample();
        return example.createCriteria();
    }

    public ExperienceTreasureExample when(final boolean condition, final ExperienceTreasureExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public ExperienceTreasureExample when(final boolean condition, final ExperienceTreasureExample.IExampleWhen then, final ExperienceTreasureExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends ExperienceTreasureExample.GeneratedCriteria {
        private ExperienceTreasureExample example;

        protected Criteria(final ExperienceTreasureExample example) {
            this.example = example;
        }

        public ExperienceTreasureExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public ExperienceTreasureExample.Criteria andIf(final boolean ifAdd, final ExperienceTreasureExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public ExperienceTreasureExample.Criteria when(final boolean condition, final ExperienceTreasureExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public ExperienceTreasureExample.Criteria when(final boolean condition, final ExperienceTreasureExample.ICriteriaWhen then, final ExperienceTreasureExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public ExperienceTreasureExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            ExperienceTreasureExample.Criteria add(final ExperienceTreasureExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<ExperienceTreasureExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<ExperienceTreasureExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<ExperienceTreasureExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new ExperienceTreasureExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new ExperienceTreasureExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new ExperienceTreasureExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public ExperienceTreasureExample.Criteria andAttribIsNull() {
            this.addCriterion("attrib is null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribIsNotNull() {
            this.addCriterion("attrib is not null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribEqualTo(final Integer value) {
            this.addCriterion("attrib =", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribEqualToColumn(final Column column) {
            this.addCriterion("attrib = " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribNotEqualTo(final Integer value) {
            this.addCriterion("attrib <>", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribNotEqualToColumn(final Column column) {
            this.addCriterion("attrib <> " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribGreaterThan(final Integer value) {
            this.addCriterion("attrib >", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribGreaterThanColumn(final Column column) {
            this.addCriterion("attrib > " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib >=", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib >= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribLessThan(final Integer value) {
            this.addCriterion("attrib <", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribLessThanColumn(final Column column) {
            this.addCriterion("attrib < " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribLessThanOrEqualTo(final Integer value) {
            this.addCriterion("attrib <=", value, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("attrib <= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribIn(final List<Integer> values) {
            this.addCriterion("attrib in", values, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribNotIn(final List<Integer> values) {
            this.addCriterion("attrib not in", values, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib between", value1, value2, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAttribNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("attrib not between", value1, value2, "attrib");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelIsNull() {
            this.addCriterion("max_level is null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelIsNotNull() {
            this.addCriterion("max_level is not null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelEqualTo(final Integer value) {
            this.addCriterion("max_level =", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelEqualToColumn(final Column column) {
            this.addCriterion("max_level = " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelNotEqualTo(final Integer value) {
            this.addCriterion("max_level <>", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelNotEqualToColumn(final Column column) {
            this.addCriterion("max_level <> " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelGreaterThan(final Integer value) {
            this.addCriterion("max_level >", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelGreaterThanColumn(final Column column) {
            this.addCriterion("max_level > " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("max_level >=", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("max_level >= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelLessThan(final Integer value) {
            this.addCriterion("max_level <", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelLessThanColumn(final Column column) {
            this.addCriterion("max_level < " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("max_level <=", value, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("max_level <= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelIn(final List<Integer> values) {
            this.addCriterion("max_level in", values, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelNotIn(final List<Integer> values) {
            this.addCriterion("max_level not in", values, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("max_level between", value1, value2, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andMaxLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("max_level not between", value1, value2, "maxLevel");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }

        public ExperienceTreasureExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (ExperienceTreasureExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final ExperienceTreasureExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final ExperienceTreasureExample paramExperienceTreasureExample);
    }
}
