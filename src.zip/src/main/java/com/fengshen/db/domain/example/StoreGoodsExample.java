//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.StoreGoods.Column;
import com.fengshen.db.domain.StoreGoods.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class StoreGoodsExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<StoreGoodsExample.Criteria> oredCriteria = new ArrayList();

    public StoreGoodsExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<StoreGoodsExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final StoreGoodsExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public StoreGoodsExample.Criteria or() {
        StoreGoodsExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public StoreGoodsExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public StoreGoodsExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public StoreGoodsExample.Criteria createCriteria() {
        StoreGoodsExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected StoreGoodsExample.Criteria createCriteriaInternal() {
        StoreGoodsExample.Criteria criteria = new StoreGoodsExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static StoreGoodsExample.Criteria newAndCreateCriteria() {
        StoreGoodsExample example = new StoreGoodsExample();
        return example.createCriteria();
    }

    public StoreGoodsExample when(final boolean condition, final StoreGoodsExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public StoreGoodsExample when(final boolean condition, final StoreGoodsExample.IExampleWhen then, final StoreGoodsExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends StoreGoodsExample.GeneratedCriteria {
        private StoreGoodsExample example;

        protected Criteria(final StoreGoodsExample example) {
            this.example = example;
        }

        public StoreGoodsExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public StoreGoodsExample.Criteria andIf(final boolean ifAdd, final StoreGoodsExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public StoreGoodsExample.Criteria when(final boolean condition, final StoreGoodsExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public StoreGoodsExample.Criteria when(final boolean condition, final StoreGoodsExample.ICriteriaWhen then, final StoreGoodsExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public StoreGoodsExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            StoreGoodsExample.Criteria add(final StoreGoodsExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<StoreGoodsExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<StoreGoodsExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<StoreGoodsExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new StoreGoodsExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new StoreGoodsExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new StoreGoodsExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public StoreGoodsExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeIsNull() {
            this.addCriterion("barcode is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeIsNotNull() {
            this.addCriterion("barcode is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeEqualTo(final String value) {
            this.addCriterion("barcode =", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeEqualToColumn(final Column column) {
            this.addCriterion("barcode = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeNotEqualTo(final String value) {
            this.addCriterion("barcode <>", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeNotEqualToColumn(final Column column) {
            this.addCriterion("barcode <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeGreaterThan(final String value) {
            this.addCriterion("barcode >", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeGreaterThanColumn(final Column column) {
            this.addCriterion("barcode > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeGreaterThanOrEqualTo(final String value) {
            this.addCriterion("barcode >=", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("barcode >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeLessThan(final String value) {
            this.addCriterion("barcode <", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeLessThanColumn(final Column column) {
            this.addCriterion("barcode < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeLessThanOrEqualTo(final String value) {
            this.addCriterion("barcode <=", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("barcode <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeLike(final String value) {
            this.addCriterion("barcode like", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeNotLike(final String value) {
            this.addCriterion("barcode not like", value, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeIn(final List<String> values) {
            this.addCriterion("barcode in", values, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeNotIn(final List<String> values) {
            this.addCriterion("barcode not in", values, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeBetween(final String value1, final String value2) {
            this.addCriterion("barcode between", value1, value2, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andBarcodeNotBetween(final String value1, final String value2) {
            this.addCriterion("barcode not between", value1, value2, "barcode");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleIsNull() {
            this.addCriterion("for_sale is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleIsNotNull() {
            this.addCriterion("for_sale is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleEqualTo(final Integer value) {
            this.addCriterion("for_sale =", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleEqualToColumn(final Column column) {
            this.addCriterion("for_sale = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleNotEqualTo(final Integer value) {
            this.addCriterion("for_sale <>", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleNotEqualToColumn(final Column column) {
            this.addCriterion("for_sale <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleGreaterThan(final Integer value) {
            this.addCriterion("for_sale >", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleGreaterThanColumn(final Column column) {
            this.addCriterion("for_sale > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("for_sale >=", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("for_sale >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleLessThan(final Integer value) {
            this.addCriterion("for_sale <", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleLessThanColumn(final Column column) {
            this.addCriterion("for_sale < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleLessThanOrEqualTo(final Integer value) {
            this.addCriterion("for_sale <=", value, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("for_sale <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleIn(final List<Integer> values) {
            this.addCriterion("for_sale in", values, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleNotIn(final List<Integer> values) {
            this.addCriterion("for_sale not in", values, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleBetween(final Integer value1, final Integer value2) {
            this.addCriterion("for_sale between", value1, value2, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andForSaleNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("for_sale not between", value1, value2, "forSale");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosIsNull() {
            this.addCriterion("show_pos is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosIsNotNull() {
            this.addCriterion("show_pos is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosEqualTo(final Integer value) {
            this.addCriterion("show_pos =", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosEqualToColumn(final Column column) {
            this.addCriterion("show_pos = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosNotEqualTo(final Integer value) {
            this.addCriterion("show_pos <>", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosNotEqualToColumn(final Column column) {
            this.addCriterion("show_pos <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosGreaterThan(final Integer value) {
            this.addCriterion("show_pos >", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosGreaterThanColumn(final Column column) {
            this.addCriterion("show_pos > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("show_pos >=", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("show_pos >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosLessThan(final Integer value) {
            this.addCriterion("show_pos <", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosLessThanColumn(final Column column) {
            this.addCriterion("show_pos < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosLessThanOrEqualTo(final Integer value) {
            this.addCriterion("show_pos <=", value, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("show_pos <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosIn(final List<Integer> values) {
            this.addCriterion("show_pos in", values, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosNotIn(final List<Integer> values) {
            this.addCriterion("show_pos not in", values, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosBetween(final Integer value1, final Integer value2) {
            this.addCriterion("show_pos between", value1, value2, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andShowPosNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("show_pos not between", value1, value2, "showPos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposIsNull() {
            this.addCriterion("rpos is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposIsNotNull() {
            this.addCriterion("rpos is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposEqualTo(final Integer value) {
            this.addCriterion("rpos =", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposEqualToColumn(final Column column) {
            this.addCriterion("rpos = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposNotEqualTo(final Integer value) {
            this.addCriterion("rpos <>", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposNotEqualToColumn(final Column column) {
            this.addCriterion("rpos <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposGreaterThan(final Integer value) {
            this.addCriterion("rpos >", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposGreaterThanColumn(final Column column) {
            this.addCriterion("rpos > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("rpos >=", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("rpos >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposLessThan(final Integer value) {
            this.addCriterion("rpos <", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposLessThanColumn(final Column column) {
            this.addCriterion("rpos < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposLessThanOrEqualTo(final Integer value) {
            this.addCriterion("rpos <=", value, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("rpos <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposIn(final List<Integer> values) {
            this.addCriterion("rpos in", values, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposNotIn(final List<Integer> values) {
            this.addCriterion("rpos not in", values, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rpos between", value1, value2, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRposNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("rpos not between", value1, value2, "rpos");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaIsNull() {
            this.addCriterion("sale_quota is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaIsNotNull() {
            this.addCriterion("sale_quota is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaEqualTo(final Integer value) {
            this.addCriterion("sale_quota =", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaEqualToColumn(final Column column) {
            this.addCriterion("sale_quota = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaNotEqualTo(final Integer value) {
            this.addCriterion("sale_quota <>", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaNotEqualToColumn(final Column column) {
            this.addCriterion("sale_quota <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaGreaterThan(final Integer value) {
            this.addCriterion("sale_quota >", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaGreaterThanColumn(final Column column) {
            this.addCriterion("sale_quota > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("sale_quota >=", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("sale_quota >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaLessThan(final Integer value) {
            this.addCriterion("sale_quota <", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaLessThanColumn(final Column column) {
            this.addCriterion("sale_quota < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaLessThanOrEqualTo(final Integer value) {
            this.addCriterion("sale_quota <=", value, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("sale_quota <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaIn(final List<Integer> values) {
            this.addCriterion("sale_quota in", values, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaNotIn(final List<Integer> values) {
            this.addCriterion("sale_quota not in", values, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaBetween(final Integer value1, final Integer value2) {
            this.addCriterion("sale_quota between", value1, value2, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andSaleQuotaNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("sale_quota not between", value1, value2, "saleQuota");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendIsNull() {
            this.addCriterion("recommend is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendIsNotNull() {
            this.addCriterion("recommend is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendEqualTo(final Integer value) {
            this.addCriterion("recommend =", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendEqualToColumn(final Column column) {
            this.addCriterion("recommend = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendNotEqualTo(final Integer value) {
            this.addCriterion("recommend <>", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendNotEqualToColumn(final Column column) {
            this.addCriterion("recommend <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendGreaterThan(final Integer value) {
            this.addCriterion("recommend >", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendGreaterThanColumn(final Column column) {
            this.addCriterion("recommend > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("recommend >=", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("recommend >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendLessThan(final Integer value) {
            this.addCriterion("recommend <", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendLessThanColumn(final Column column) {
            this.addCriterion("recommend < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendLessThanOrEqualTo(final Integer value) {
            this.addCriterion("recommend <=", value, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("recommend <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendIn(final List<Integer> values) {
            this.addCriterion("recommend in", values, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendNotIn(final List<Integer> values) {
            this.addCriterion("recommend not in", values, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendBetween(final Integer value1, final Integer value2) {
            this.addCriterion("recommend between", value1, value2, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andRecommendNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("recommend not between", value1, value2, "recommend");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinIsNull() {
            this.addCriterion("coin is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinIsNotNull() {
            this.addCriterion("coin is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinEqualTo(final Integer value) {
            this.addCriterion("coin =", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinEqualToColumn(final Column column) {
            this.addCriterion("coin = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinNotEqualTo(final Integer value) {
            this.addCriterion("coin <>", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinNotEqualToColumn(final Column column) {
            this.addCriterion("coin <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinGreaterThan(final Integer value) {
            this.addCriterion("coin >", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinGreaterThanColumn(final Column column) {
            this.addCriterion("coin > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("coin >=", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("coin >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinLessThan(final Integer value) {
            this.addCriterion("coin <", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinLessThanColumn(final Column column) {
            this.addCriterion("coin < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinLessThanOrEqualTo(final Integer value) {
            this.addCriterion("coin <=", value, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("coin <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinIn(final List<Integer> values) {
            this.addCriterion("coin in", values, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinNotIn(final List<Integer> values) {
            this.addCriterion("coin not in", values, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinBetween(final Integer value1, final Integer value2) {
            this.addCriterion("coin between", value1, value2, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andCoinNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("coin not between", value1, value2, "coin");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountIsNull() {
            this.addCriterion("discount is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountIsNotNull() {
            this.addCriterion("discount is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountEqualTo(final Integer value) {
            this.addCriterion("discount =", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountEqualToColumn(final Column column) {
            this.addCriterion("discount = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountNotEqualTo(final Integer value) {
            this.addCriterion("discount <>", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountNotEqualToColumn(final Column column) {
            this.addCriterion("discount <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountGreaterThan(final Integer value) {
            this.addCriterion("discount >", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountGreaterThanColumn(final Column column) {
            this.addCriterion("discount > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("discount >=", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("discount >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountLessThan(final Integer value) {
            this.addCriterion("discount <", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountLessThanColumn(final Column column) {
            this.addCriterion("discount < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountLessThanOrEqualTo(final Integer value) {
            this.addCriterion("discount <=", value, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("discount <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountIn(final List<Integer> values) {
            this.addCriterion("discount in", values, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountNotIn(final List<Integer> values) {
            this.addCriterion("discount not in", values, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountBetween(final Integer value1, final Integer value2) {
            this.addCriterion("discount between", value1, value2, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDiscountNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("discount not between", value1, value2, "discount");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitIsNull() {
            this.addCriterion("quota_limit is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitIsNotNull() {
            this.addCriterion("quota_limit is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitEqualTo(final Integer value) {
            this.addCriterion("quota_limit =", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitEqualToColumn(final Column column) {
            this.addCriterion("quota_limit = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitNotEqualTo(final Integer value) {
            this.addCriterion("quota_limit <>", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitNotEqualToColumn(final Column column) {
            this.addCriterion("quota_limit <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitGreaterThan(final Integer value) {
            this.addCriterion("quota_limit >", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitGreaterThanColumn(final Column column) {
            this.addCriterion("quota_limit > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("quota_limit >=", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("quota_limit >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitLessThan(final Integer value) {
            this.addCriterion("quota_limit <", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitLessThanColumn(final Column column) {
            this.addCriterion("quota_limit < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitLessThanOrEqualTo(final Integer value) {
            this.addCriterion("quota_limit <=", value, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("quota_limit <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitIn(final List<Integer> values) {
            this.addCriterion("quota_limit in", values, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitNotIn(final List<Integer> values) {
            this.addCriterion("quota_limit not in", values, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitBetween(final Integer value1, final Integer value2) {
            this.addCriterion("quota_limit between", value1, value2, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andQuotaLimitNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("quota_limit not between", value1, value2, "quotaLimit");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipIsNull() {
            this.addCriterion("must_vip is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipIsNotNull() {
            this.addCriterion("must_vip is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipEqualTo(final Integer value) {
            this.addCriterion("must_vip =", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipEqualToColumn(final Column column) {
            this.addCriterion("must_vip = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipNotEqualTo(final Integer value) {
            this.addCriterion("must_vip <>", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipNotEqualToColumn(final Column column) {
            this.addCriterion("must_vip <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipGreaterThan(final Integer value) {
            this.addCriterion("must_vip >", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipGreaterThanColumn(final Column column) {
            this.addCriterion("must_vip > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("must_vip >=", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("must_vip >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipLessThan(final Integer value) {
            this.addCriterion("must_vip <", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipLessThanColumn(final Column column) {
            this.addCriterion("must_vip < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipLessThanOrEqualTo(final Integer value) {
            this.addCriterion("must_vip <=", value, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("must_vip <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipIn(final List<Integer> values) {
            this.addCriterion("must_vip in", values, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipNotIn(final List<Integer> values) {
            this.addCriterion("must_vip not in", values, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipBetween(final Integer value1, final Integer value2) {
            this.addCriterion("must_vip between", value1, value2, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andMustVipNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("must_vip not between", value1, value2, "mustVip");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftIsNull() {
            this.addCriterion("is_gift is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftIsNotNull() {
            this.addCriterion("is_gift is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftEqualTo(final Integer value) {
            this.addCriterion("is_gift =", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftEqualToColumn(final Column column) {
            this.addCriterion("is_gift = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftNotEqualTo(final Integer value) {
            this.addCriterion("is_gift <>", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftNotEqualToColumn(final Column column) {
            this.addCriterion("is_gift <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftGreaterThan(final Integer value) {
            this.addCriterion("is_gift >", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftGreaterThanColumn(final Column column) {
            this.addCriterion("is_gift > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("is_gift >=", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("is_gift >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftLessThan(final Integer value) {
            this.addCriterion("is_gift <", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftLessThanColumn(final Column column) {
            this.addCriterion("is_gift < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftLessThanOrEqualTo(final Integer value) {
            this.addCriterion("is_gift <=", value, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("is_gift <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftIn(final List<Integer> values) {
            this.addCriterion("is_gift in", values, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftNotIn(final List<Integer> values) {
            this.addCriterion("is_gift not in", values, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftBetween(final Integer value1, final Integer value2) {
            this.addCriterion("is_gift between", value1, value2, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andIsGiftNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("is_gift not between", value1, value2, "isGift");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeIsNull() {
            this.addCriterion("follow_pet_type is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeIsNotNull() {
            this.addCriterion("follow_pet_type is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeEqualTo(final Integer value) {
            this.addCriterion("follow_pet_type =", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeEqualToColumn(final Column column) {
            this.addCriterion("follow_pet_type = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeNotEqualTo(final Integer value) {
            this.addCriterion("follow_pet_type <>", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeNotEqualToColumn(final Column column) {
            this.addCriterion("follow_pet_type <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeGreaterThan(final Integer value) {
            this.addCriterion("follow_pet_type >", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeGreaterThanColumn(final Column column) {
            this.addCriterion("follow_pet_type > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("follow_pet_type >=", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("follow_pet_type >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeLessThan(final Integer value) {
            this.addCriterion("follow_pet_type <", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeLessThanColumn(final Column column) {
            this.addCriterion("follow_pet_type < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("follow_pet_type <=", value, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("follow_pet_type <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeIn(final List<Integer> values) {
            this.addCriterion("follow_pet_type in", values, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeNotIn(final List<Integer> values) {
            this.addCriterion("follow_pet_type not in", values, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("follow_pet_type between", value1, value2, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andFollowPetTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("follow_pet_type not between", value1, value2, "followPetType");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }

        public StoreGoodsExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (StoreGoodsExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final StoreGoodsExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final StoreGoodsExample paramStoreGoodsExample);
    }
}
