//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Npc.Column;
import com.fengshen.db.domain.Npc.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NpcExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<NpcExample.Criteria> oredCriteria = new ArrayList();

    public NpcExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<NpcExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final NpcExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public NpcExample.Criteria or() {
        NpcExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public NpcExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public NpcExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public NpcExample.Criteria createCriteria() {
        NpcExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected NpcExample.Criteria createCriteriaInternal() {
        NpcExample.Criteria criteria = new NpcExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static NpcExample.Criteria newAndCreateCriteria() {
        NpcExample example = new NpcExample();
        return example.createCriteria();
    }

    public NpcExample when(final boolean condition, final NpcExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public NpcExample when(final boolean condition, final NpcExample.IExampleWhen then, final NpcExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends NpcExample.GeneratedCriteria {
        private NpcExample example;

        protected Criteria(final NpcExample example) {
            this.example = example;
        }

        public NpcExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public NpcExample.Criteria andIf(final boolean ifAdd, final NpcExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public NpcExample.Criteria when(final boolean condition, final NpcExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public NpcExample.Criteria when(final boolean condition, final NpcExample.ICriteriaWhen then, final NpcExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public NpcExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            NpcExample.Criteria add(final NpcExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<NpcExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<NpcExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<NpcExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new NpcExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new NpcExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new NpcExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public NpcExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconIsNull() {
            this.addCriterion("icon is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconIsNotNull() {
            this.addCriterion("icon is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconEqualTo(final Integer value) {
            this.addCriterion("icon =", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconEqualToColumn(final Column column) {
            this.addCriterion("icon = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconNotEqualTo(final Integer value) {
            this.addCriterion("icon <>", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconNotEqualToColumn(final Column column) {
            this.addCriterion("icon <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconGreaterThan(final Integer value) {
            this.addCriterion("icon >", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconGreaterThanColumn(final Column column) {
            this.addCriterion("icon > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("icon >=", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconLessThan(final Integer value) {
            this.addCriterion("icon <", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconLessThanColumn(final Column column) {
            this.addCriterion("icon < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconLessThanOrEqualTo(final Integer value) {
            this.addCriterion("icon <=", value, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("icon <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconIn(final List<Integer> values) {
            this.addCriterion("icon in", values, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconNotIn(final List<Integer> values) {
            this.addCriterion("icon not in", values, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon between", value1, value2, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andIconNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("icon not between", value1, value2, "icon");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXIsNull() {
            this.addCriterion("x is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXIsNotNull() {
            this.addCriterion("x is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXEqualTo(final Integer value) {
            this.addCriterion("x =", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXEqualToColumn(final Column column) {
            this.addCriterion("x = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXNotEqualTo(final Integer value) {
            this.addCriterion("x <>", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXNotEqualToColumn(final Column column) {
            this.addCriterion("x <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXGreaterThan(final Integer value) {
            this.addCriterion("x >", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXGreaterThanColumn(final Column column) {
            this.addCriterion("x > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("x >=", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("x >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXLessThan(final Integer value) {
            this.addCriterion("x <", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXLessThanColumn(final Column column) {
            this.addCriterion("x < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXLessThanOrEqualTo(final Integer value) {
            this.addCriterion("x <=", value, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("x <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXIn(final List<Integer> values) {
            this.addCriterion("x in", values, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXNotIn(final List<Integer> values) {
            this.addCriterion("x not in", values, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x between", value1, value2, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andXNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("x not between", value1, value2, "x");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYIsNull() {
            this.addCriterion("y is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYIsNotNull() {
            this.addCriterion("y is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYEqualTo(final Integer value) {
            this.addCriterion("y =", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYEqualToColumn(final Column column) {
            this.addCriterion("y = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYNotEqualTo(final Integer value) {
            this.addCriterion("y <>", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYNotEqualToColumn(final Column column) {
            this.addCriterion("y <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYGreaterThan(final Integer value) {
            this.addCriterion("y >", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYGreaterThanColumn(final Column column) {
            this.addCriterion("y > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("y >=", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("y >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYLessThan(final Integer value) {
            this.addCriterion("y <", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYLessThanColumn(final Column column) {
            this.addCriterion("y < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYLessThanOrEqualTo(final Integer value) {
            this.addCriterion("y <=", value, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("y <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYIn(final List<Integer> values) {
            this.addCriterion("y in", values, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYNotIn(final List<Integer> values) {
            this.addCriterion("y not in", values, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y between", value1, value2, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andYNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("y not between", value1, value2, "y");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdIsNull() {
            this.addCriterion("map_id is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdIsNotNull() {
            this.addCriterion("map_id is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdEqualTo(final Integer value) {
            this.addCriterion("map_id =", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdEqualToColumn(final Column column) {
            this.addCriterion("map_id = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdNotEqualTo(final Integer value) {
            this.addCriterion("map_id <>", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdNotEqualToColumn(final Column column) {
            this.addCriterion("map_id <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdGreaterThan(final Integer value) {
            this.addCriterion("map_id >", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdGreaterThanColumn(final Column column) {
            this.addCriterion("map_id > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("map_id >=", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("map_id >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdLessThan(final Integer value) {
            this.addCriterion("map_id <", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdLessThanColumn(final Column column) {
            this.addCriterion("map_id < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("map_id <=", value, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("map_id <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdIn(final List<Integer> values) {
            this.addCriterion("map_id in", values, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdNotIn(final List<Integer> values) {
            this.addCriterion("map_id not in", values, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("map_id between", value1, value2, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andMapIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("map_id not between", value1, value2, "mapId");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (NpcExample.Criteria) this;
        }

        public NpcExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (NpcExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final NpcExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final NpcExample paramNpcExample);
    }
}
