//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(
        name = "dialog"
)
public class Dialog {
    @Id
    @GeneratedValue(
            generator = "JDBC"
    )
    private Integer id;
    private String peerName;
    private String askType;
    private String applyGid;
    private Date createTime;
    private String extJson;

    public Dialog() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeerName() {
        return this.peerName;
    }

    public void setPeerName(String peerName) {
        this.peerName = peerName;
    }

    public String getAskType() {
        return this.askType;
    }

    public void setAskType(String askType) {
        this.askType = askType;
    }

    public String getApplyGid() {
        return this.applyGid;
    }

    public void setApplyGid(String applyGid) {
        this.applyGid = applyGid;
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getExtJson() {
        return this.extJson;
    }

    public void setExtJson(String extJson) {
        this.extJson = extJson;
    }
}
