//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.GroceriesShop.Column;
import com.fengshen.db.domain.GroceriesShop.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class GroceriesShopExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<GroceriesShopExample.Criteria> oredCriteria = new ArrayList();

    public GroceriesShopExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<GroceriesShopExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final GroceriesShopExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public GroceriesShopExample.Criteria or() {
        GroceriesShopExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public GroceriesShopExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public GroceriesShopExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public GroceriesShopExample.Criteria createCriteria() {
        GroceriesShopExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected GroceriesShopExample.Criteria createCriteriaInternal() {
        GroceriesShopExample.Criteria criteria = new GroceriesShopExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static GroceriesShopExample.Criteria newAndCreateCriteria() {
        GroceriesShopExample example = new GroceriesShopExample();
        return example.createCriteria();
    }

    public GroceriesShopExample when(final boolean condition, final GroceriesShopExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public GroceriesShopExample when(final boolean condition, final GroceriesShopExample.IExampleWhen then, final GroceriesShopExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends GroceriesShopExample.GeneratedCriteria {
        private GroceriesShopExample example;

        protected Criteria(final GroceriesShopExample example) {
            this.example = example;
        }

        public GroceriesShopExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public GroceriesShopExample.Criteria andIf(final boolean ifAdd, final GroceriesShopExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public GroceriesShopExample.Criteria when(final boolean condition, final GroceriesShopExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public GroceriesShopExample.Criteria when(final boolean condition, final GroceriesShopExample.ICriteriaWhen then, final GroceriesShopExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public GroceriesShopExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            GroceriesShopExample.Criteria add(final GroceriesShopExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<GroceriesShopExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<GroceriesShopExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<GroceriesShopExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new GroceriesShopExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new GroceriesShopExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new GroceriesShopExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public GroceriesShopExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoIsNull() {
            this.addCriterion("goods_no is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoIsNotNull() {
            this.addCriterion("goods_no is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoEqualTo(final Integer value) {
            this.addCriterion("goods_no =", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoEqualToColumn(final Column column) {
            this.addCriterion("goods_no = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoNotEqualTo(final Integer value) {
            this.addCriterion("goods_no <>", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoNotEqualToColumn(final Column column) {
            this.addCriterion("goods_no <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoGreaterThan(final Integer value) {
            this.addCriterion("goods_no >", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoGreaterThanColumn(final Column column) {
            this.addCriterion("goods_no > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_no >=", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_no >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoLessThan(final Integer value) {
            this.addCriterion("goods_no <", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoLessThanColumn(final Column column) {
            this.addCriterion("goods_no < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoLessThanOrEqualTo(final Integer value) {
            this.addCriterion("goods_no <=", value, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("goods_no <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoIn(final List<Integer> values) {
            this.addCriterion("goods_no in", values, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoNotIn(final List<Integer> values) {
            this.addCriterion("goods_no not in", values, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_no between", value1, value2, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andGoodsNoNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("goods_no not between", value1, value2, "goodsNo");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeIsNull() {
            this.addCriterion("pay_type is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeIsNotNull() {
            this.addCriterion("pay_type is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeEqualTo(final Integer value) {
            this.addCriterion("pay_type =", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeEqualToColumn(final Column column) {
            this.addCriterion("pay_type = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeNotEqualTo(final Integer value) {
            this.addCriterion("pay_type <>", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeNotEqualToColumn(final Column column) {
            this.addCriterion("pay_type <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeGreaterThan(final Integer value) {
            this.addCriterion("pay_type >", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeGreaterThanColumn(final Column column) {
            this.addCriterion("pay_type > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("pay_type >=", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("pay_type >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeLessThan(final Integer value) {
            this.addCriterion("pay_type <", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeLessThanColumn(final Column column) {
            this.addCriterion("pay_type < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("pay_type <=", value, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("pay_type <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeIn(final List<Integer> values) {
            this.addCriterion("pay_type in", values, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeNotIn(final List<Integer> values) {
            this.addCriterion("pay_type not in", values, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pay_type between", value1, value2, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andPayTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("pay_type not between", value1, value2, "payType");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameIsNull() {
            this.addCriterion("`name` is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameIsNotNull() {
            this.addCriterion("`name` is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameEqualTo(final String value) {
            this.addCriterion("`name` =", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameEqualToColumn(final Column column) {
            this.addCriterion("`name` = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameNotEqualTo(final String value) {
            this.addCriterion("`name` <>", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameNotEqualToColumn(final Column column) {
            this.addCriterion("`name` <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameGreaterThan(final String value) {
            this.addCriterion("`name` >", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameGreaterThanColumn(final Column column) {
            this.addCriterion("`name` > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("`name` >=", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameLessThan(final String value) {
            this.addCriterion("`name` <", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameLessThanColumn(final Column column) {
            this.addCriterion("`name` < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameLessThanOrEqualTo(final String value) {
            this.addCriterion("`name` <=", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`name` <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameLike(final String value) {
            this.addCriterion("`name` like", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameNotLike(final String value) {
            this.addCriterion("`name` not like", value, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameIn(final List<String> values) {
            this.addCriterion("`name` in", values, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameNotIn(final List<String> values) {
            this.addCriterion("`name` not in", values, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameBetween(final String value1, final String value2) {
            this.addCriterion("`name` between", value1, value2, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andNameNotBetween(final String value1, final String value2) {
            this.addCriterion("`name` not between", value1, value2, "name");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueIsNull() {
            this.addCriterion("`value` is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueIsNotNull() {
            this.addCriterion("`value` is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueEqualTo(final Integer value) {
            this.addCriterion("`value` =", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueEqualToColumn(final Column column) {
            this.addCriterion("`value` = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueNotEqualTo(final Integer value) {
            this.addCriterion("`value` <>", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueNotEqualToColumn(final Column column) {
            this.addCriterion("`value` <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueGreaterThan(final Integer value) {
            this.addCriterion("`value` >", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueGreaterThanColumn(final Column column) {
            this.addCriterion("`value` > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` >=", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueLessThan(final Integer value) {
            this.addCriterion("`value` <", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueLessThanColumn(final Column column) {
            this.addCriterion("`value` < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`value` <=", value, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`value` <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueIn(final List<Integer> values) {
            this.addCriterion("`value` in", values, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueNotIn(final List<Integer> values) {
            this.addCriterion("`value` not in", values, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` between", value1, value2, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andValueNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`value` not between", value1, value2, "value");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelIsNull() {
            this.addCriterion("`level` is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelIsNotNull() {
            this.addCriterion("`level` is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelEqualTo(final Integer value) {
            this.addCriterion("`level` =", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelEqualToColumn(final Column column) {
            this.addCriterion("`level` = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelNotEqualTo(final Integer value) {
            this.addCriterion("`level` <>", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelNotEqualToColumn(final Column column) {
            this.addCriterion("`level` <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelGreaterThan(final Integer value) {
            this.addCriterion("`level` >", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelGreaterThanColumn(final Column column) {
            this.addCriterion("`level` > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` >=", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelLessThan(final Integer value) {
            this.addCriterion("`level` <", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelLessThanColumn(final Column column) {
            this.addCriterion("`level` < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`level` <=", value, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`level` <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelIn(final List<Integer> values) {
            this.addCriterion("`level` in", values, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelNotIn(final List<Integer> values) {
            this.addCriterion("`level` not in", values, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` between", value1, value2, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`level` not between", value1, value2, "level");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeIsNull() {
            this.addCriterion("`type` is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeIsNotNull() {
            this.addCriterion("`type` is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeEqualTo(final Integer value) {
            this.addCriterion("`type` =", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeEqualToColumn(final Column column) {
            this.addCriterion("`type` = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeNotEqualTo(final Integer value) {
            this.addCriterion("`type` <>", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeNotEqualToColumn(final Column column) {
            this.addCriterion("`type` <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeGreaterThan(final Integer value) {
            this.addCriterion("`type` >", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeGreaterThanColumn(final Column column) {
            this.addCriterion("`type` > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` >=", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeLessThan(final Integer value) {
            this.addCriterion("`type` <", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeLessThanColumn(final Column column) {
            this.addCriterion("`type` < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("`type` <=", value, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("`type` <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeIn(final List<Integer> values) {
            this.addCriterion("`type` in", values, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeNotIn(final List<Integer> values) {
            this.addCriterion("`type` not in", values, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` between", value1, value2, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("`type` not between", value1, value2, "type");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountIsNull() {
            this.addCriterion("itemCount is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountIsNotNull() {
            this.addCriterion("itemCount is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountEqualTo(final Integer value) {
            this.addCriterion("itemCount =", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountEqualToColumn(final Column column) {
            this.addCriterion("itemCount = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountNotEqualTo(final Integer value) {
            this.addCriterion("itemCount <>", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountNotEqualToColumn(final Column column) {
            this.addCriterion("itemCount <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountGreaterThan(final Integer value) {
            this.addCriterion("itemCount >", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountGreaterThanColumn(final Column column) {
            this.addCriterion("itemCount > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("itemCount >=", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("itemCount >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountLessThan(final Integer value) {
            this.addCriterion("itemCount <", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountLessThanColumn(final Column column) {
            this.addCriterion("itemCount < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountLessThanOrEqualTo(final Integer value) {
            this.addCriterion("itemCount <=", value, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("itemCount <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountIn(final List<Integer> values) {
            this.addCriterion("itemCount in", values, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountNotIn(final List<Integer> values) {
            this.addCriterion("itemCount not in", values, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountBetween(final Integer value1, final Integer value2) {
            this.addCriterion("itemCount between", value1, value2, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andItemcountNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("itemCount not between", value1, value2, "itemcount");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }

        public GroceriesShopExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (GroceriesShopExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final GroceriesShopExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final GroceriesShopExample paramGroceriesShopExample);
    }
}
