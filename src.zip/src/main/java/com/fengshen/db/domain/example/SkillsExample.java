//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.domain.example;

import com.fengshen.db.domain.Skills.Column;
import com.fengshen.db.domain.Skills.Deleted;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SkillsExample {
    protected String orderByClause;
    protected boolean distinct;
    protected List<SkillsExample.Criteria> oredCriteria = new ArrayList();

    public SkillsExample() {
    }

    public void setOrderByClause(final String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return this.orderByClause;
    }

    public void setDistinct(final boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return this.distinct;
    }

    public List<SkillsExample.Criteria> getOredCriteria() {
        return this.oredCriteria;
    }

    public void or(final SkillsExample.Criteria criteria) {
        this.oredCriteria.add(criteria);
    }

    public SkillsExample.Criteria or() {
        SkillsExample.Criteria criteria = this.createCriteriaInternal();
        this.oredCriteria.add(criteria);
        return criteria;
    }

    public SkillsExample orderBy(final String orderByClause) {
        this.setOrderByClause(orderByClause);
        return this;
    }

    public SkillsExample orderBy(final String... orderByClauses) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < orderByClauses.length; ++i) {
            sb.append(orderByClauses[i]);
            if (i < orderByClauses.length - 1) {
                sb.append(" , ");
            }
        }

        this.setOrderByClause(sb.toString());
        return this;
    }

    public SkillsExample.Criteria createCriteria() {
        SkillsExample.Criteria criteria = this.createCriteriaInternal();
        if (this.oredCriteria.size() == 0) {
            this.oredCriteria.add(criteria);
        }

        return criteria;
    }

    protected SkillsExample.Criteria createCriteriaInternal() {
        SkillsExample.Criteria criteria = new SkillsExample.Criteria(this);
        return criteria;
    }

    public void clear() {
        this.oredCriteria.clear();
        this.orderByClause = null;
        this.distinct = false;
    }

    public static SkillsExample.Criteria newAndCreateCriteria() {
        SkillsExample example = new SkillsExample();
        return example.createCriteria();
    }

    public SkillsExample when(final boolean condition, final SkillsExample.IExampleWhen then) {
        if (condition) {
            then.example(this);
        }

        return this;
    }

    public SkillsExample when(final boolean condition, final SkillsExample.IExampleWhen then, final SkillsExample.IExampleWhen otherwise) {
        if (condition) {
            then.example(this);
        } else {
            otherwise.example(this);
        }

        return this;
    }

    public static class Criteria extends SkillsExample.GeneratedCriteria {
        private SkillsExample example;

        protected Criteria(final SkillsExample example) {
            this.example = example;
        }

        public SkillsExample example() {
            return this.example;
        }

        /**
         * @deprecated
         */
        @Deprecated
        public SkillsExample.Criteria andIf(final boolean ifAdd, final SkillsExample.Criteria.ICriteriaAdd add) {
            if (ifAdd) {
                add.add(this);
            }

            return this;
        }

        public SkillsExample.Criteria when(final boolean condition, final SkillsExample.ICriteriaWhen then) {
            if (condition) {
                then.criteria(this);
            }

            return this;
        }

        public SkillsExample.Criteria when(final boolean condition, final SkillsExample.ICriteriaWhen then, final SkillsExample.ICriteriaWhen otherwise) {
            if (condition) {
                then.criteria(this);
            } else {
                otherwise.criteria(this);
            }

            return this;
        }

        public SkillsExample.Criteria andLogicalDeleted(final boolean deleted) {
            return deleted ? this.andDeletedEqualTo(Deleted.IS_DELETED.value()) : this.andDeletedNotEqualTo(Deleted.IS_DELETED.value());
        }

        /**
         * @deprecated
         */
        @Deprecated
        public interface ICriteriaAdd {
            SkillsExample.Criteria add(final SkillsExample.Criteria paramCriteria);
        }
    }

    public static class Criterion {
        private String condition;
        private Object value;
        private Object secondValue;
        private boolean noValue;
        private boolean singleValue;
        private boolean betweenValue;
        private boolean listValue;
        private String typeHandler;

        public String getCondition() {
            return this.condition;
        }

        public Object getValue() {
            return this.value;
        }

        public Object getSecondValue() {
            return this.secondValue;
        }

        public boolean isNoValue() {
            return this.noValue;
        }

        public boolean isSingleValue() {
            return this.singleValue;
        }

        public boolean isBetweenValue() {
            return this.betweenValue;
        }

        public boolean isListValue() {
            return this.listValue;
        }

        public String getTypeHandler() {
            return this.typeHandler;
        }

        protected Criterion(final String condition) {
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(final String condition, final Object value, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }

        }

        protected Criterion(final String condition, final Object value) {
            this(condition, value, (String) null);
        }

        protected Criterion(final String condition, final Object value, final Object secondValue, final String typeHandler) {
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(final String condition, final Object value, final Object secondValue) {
            this(condition, value, secondValue, (String) null);
        }
    }

    protected abstract static class GeneratedCriteria {
        protected List<SkillsExample.Criterion> criteria = new ArrayList();

        protected GeneratedCriteria() {
        }

        public boolean isValid() {
            return this.criteria.size() > 0;
        }

        public List<SkillsExample.Criterion> getAllCriteria() {
            return this.criteria;
        }

        public List<SkillsExample.Criterion> getCriteria() {
            return this.criteria;
        }

        protected void addCriterion(final String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            } else {
                this.criteria.add(new SkillsExample.Criterion(condition));
            }
        }

        protected void addCriterion(final String condition, final Object value, final String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            } else {
                this.criteria.add(new SkillsExample.Criterion(condition, value));
            }
        }

        protected void addCriterion(final String condition, final Object value1, final Object value2, final String property) {
            if (value1 != null && value2 != null) {
                this.criteria.add(new SkillsExample.Criterion(condition, value1, value2));
            } else {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
        }

        public SkillsExample.Criteria andIdIsNull() {
            this.addCriterion("id is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdIsNotNull() {
            this.addCriterion("id is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdEqualTo(final Integer value) {
            this.addCriterion("id =", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdEqualToColumn(final Column column) {
            this.addCriterion("id = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdNotEqualTo(final Integer value) {
            this.addCriterion("id <>", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdNotEqualToColumn(final Column column) {
            this.addCriterion("id <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdGreaterThan(final Integer value) {
            this.addCriterion("id >", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdGreaterThanColumn(final Column column) {
            this.addCriterion("id > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("id >=", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("id >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdLessThan(final Integer value) {
            this.addCriterion("id <", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdLessThanColumn(final Column column) {
            this.addCriterion("id < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdLessThanOrEqualTo(final Integer value) {
            this.addCriterion("id <=", value, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("id <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdIn(final List<Integer> values) {
            this.addCriterion("id in", values, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdNotIn(final List<Integer> values) {
            this.addCriterion("id not in", values, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id between", value1, value2, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andIdNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("id not between", value1, value2, "id");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexIsNull() {
            this.addCriterion("skill_id_hex is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexIsNotNull() {
            this.addCriterion("skill_id_hex is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexEqualTo(final String value) {
            this.addCriterion("skill_id_hex =", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexNotEqualTo(final String value) {
            this.addCriterion("skill_id_hex <>", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexNotEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexGreaterThan(final String value) {
            this.addCriterion("skill_id_hex >", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexGreaterThanColumn(final Column column) {
            this.addCriterion("skill_id_hex > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_id_hex >=", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexLessThan(final String value) {
            this.addCriterion("skill_id_hex <", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexLessThanColumn(final Column column) {
            this.addCriterion("skill_id_hex < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_id_hex <=", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_id_hex <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexLike(final String value) {
            this.addCriterion("skill_id_hex like", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexNotLike(final String value) {
            this.addCriterion("skill_id_hex not like", value, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexIn(final List<String> values) {
            this.addCriterion("skill_id_hex in", values, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexNotIn(final List<String> values) {
            this.addCriterion("skill_id_hex not in", values, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexBetween(final String value1, final String value2) {
            this.addCriterion("skill_id_hex between", value1, value2, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillIdHexNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_id_hex not between", value1, value2, "skillIdHex");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameIsNull() {
            this.addCriterion("skill_name is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameIsNotNull() {
            this.addCriterion("skill_name is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameEqualTo(final String value) {
            this.addCriterion("skill_name =", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameEqualToColumn(final Column column) {
            this.addCriterion("skill_name = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameNotEqualTo(final String value) {
            this.addCriterion("skill_name <>", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameNotEqualToColumn(final Column column) {
            this.addCriterion("skill_name <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameGreaterThan(final String value) {
            this.addCriterion("skill_name >", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameGreaterThanColumn(final Column column) {
            this.addCriterion("skill_name > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_name >=", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameLessThan(final String value) {
            this.addCriterion("skill_name <", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameLessThanColumn(final Column column) {
            this.addCriterion("skill_name < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_name <=", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_name <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameLike(final String value) {
            this.addCriterion("skill_name like", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameNotLike(final String value) {
            this.addCriterion("skill_name not like", value, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameIn(final List<String> values) {
            this.addCriterion("skill_name in", values, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameNotIn(final List<String> values) {
            this.addCriterion("skill_name not in", values, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameBetween(final String value1, final String value2) {
            this.addCriterion("skill_name between", value1, value2, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillNameNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_name not between", value1, value2, "skillName");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarIsNull() {
            this.addCriterion("skill_req_polar is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarIsNotNull() {
            this.addCriterion("skill_req_polar is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar =", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarNotEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar <>", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarNotEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarGreaterThan(final Integer value) {
            this.addCriterion("skill_req_polar >", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarGreaterThanColumn(final Column column) {
            this.addCriterion("skill_req_polar > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar >=", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarLessThan(final Integer value) {
            this.addCriterion("skill_req_polar <", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarLessThanColumn(final Column column) {
            this.addCriterion("skill_req_polar < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_polar <=", value, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_polar <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarIn(final List<Integer> values) {
            this.addCriterion("skill_req_polar in", values, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarNotIn(final List<Integer> values) {
            this.addCriterion("skill_req_polar not in", values, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_polar between", value1, value2, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqpolarNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_polar not between", value1, value2, "skillReqpolar");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeIsNull() {
            this.addCriterion("skill_type is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeIsNotNull() {
            this.addCriterion("skill_type is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeEqualTo(final Integer value) {
            this.addCriterion("skill_type =", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeEqualToColumn(final Column column) {
            this.addCriterion("skill_type = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeNotEqualTo(final Integer value) {
            this.addCriterion("skill_type <>", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeNotEqualToColumn(final Column column) {
            this.addCriterion("skill_type <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeGreaterThan(final Integer value) {
            this.addCriterion("skill_type >", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeGreaterThanColumn(final Column column) {
            this.addCriterion("skill_type > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_type >=", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_type >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLessThan(final Integer value) {
            this.addCriterion("skill_type <", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLessThanColumn(final Column column) {
            this.addCriterion("skill_type < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_type <=", value, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_type <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeIn(final List<Integer> values) {
            this.addCriterion("skill_type in", values, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeNotIn(final List<Integer> values) {
            this.addCriterion("skill_type not in", values, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_type between", value1, value2, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_type not between", value1, value2, "skillType");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelIsNull() {
            this.addCriterion("skill_type_level is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelIsNotNull() {
            this.addCriterion("skill_type_level is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelEqualTo(final Integer value) {
            this.addCriterion("skill_type_level =", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelEqualToColumn(final Column column) {
            this.addCriterion("skill_type_level = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelNotEqualTo(final Integer value) {
            this.addCriterion("skill_type_level <>", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelNotEqualToColumn(final Column column) {
            this.addCriterion("skill_type_level <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelGreaterThan(final Integer value) {
            this.addCriterion("skill_type_level >", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelGreaterThanColumn(final Column column) {
            this.addCriterion("skill_type_level > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_type_level >=", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_type_level >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelLessThan(final Integer value) {
            this.addCriterion("skill_type_level <", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelLessThanColumn(final Column column) {
            this.addCriterion("skill_type_level < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_type_level <=", value, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_type_level <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelIn(final List<Integer> values) {
            this.addCriterion("skill_type_level in", values, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelNotIn(final List<Integer> values) {
            this.addCriterion("skill_type_level not in", values, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_type_level between", value1, value2, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillTypeLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_type_level not between", value1, value2, "skillTypeLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicIsNull() {
            this.addCriterion("skill_magic is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicIsNotNull() {
            this.addCriterion("skill_magic is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicEqualTo(final Integer value) {
            this.addCriterion("skill_magic =", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicEqualToColumn(final Column column) {
            this.addCriterion("skill_magic = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicNotEqualTo(final Integer value) {
            this.addCriterion("skill_magic <>", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicNotEqualToColumn(final Column column) {
            this.addCriterion("skill_magic <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicGreaterThan(final Integer value) {
            this.addCriterion("skill_magic >", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicGreaterThanColumn(final Column column) {
            this.addCriterion("skill_magic > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_magic >=", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_magic >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicLessThan(final Integer value) {
            this.addCriterion("skill_magic <", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicLessThanColumn(final Column column) {
            this.addCriterion("skill_magic < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_magic <=", value, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_magic <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicIn(final List<Integer> values) {
            this.addCriterion("skill_magic in", values, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicNotIn(final List<Integer> values) {
            this.addCriterion("skill_magic not in", values, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_magic between", value1, value2, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillMagicNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_magic not between", value1, value2, "skillMagic");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelIsNull() {
            this.addCriterion("skill_req_level is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelIsNotNull() {
            this.addCriterion("skill_req_level is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelEqualTo(final Integer value) {
            this.addCriterion("skill_req_level =", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelEqualToColumn(final Column column) {
            this.addCriterion("skill_req_level = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelNotEqualTo(final Integer value) {
            this.addCriterion("skill_req_level <>", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelNotEqualToColumn(final Column column) {
            this.addCriterion("skill_req_level <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelGreaterThan(final Integer value) {
            this.addCriterion("skill_req_level >", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelGreaterThanColumn(final Column column) {
            this.addCriterion("skill_req_level > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelGreaterThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_level >=", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_level >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelLessThan(final Integer value) {
            this.addCriterion("skill_req_level <", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelLessThanColumn(final Column column) {
            this.addCriterion("skill_req_level < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelLessThanOrEqualTo(final Integer value) {
            this.addCriterion("skill_req_level <=", value, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_req_level <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelIn(final List<Integer> values) {
            this.addCriterion("skill_req_level in", values, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelNotIn(final List<Integer> values) {
            this.addCriterion("skill_req_level not in", values, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_level between", value1, value2, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillReqLevelNotBetween(final Integer value1, final Integer value2) {
            this.addCriterion("skill_req_level not between", value1, value2, "skillReqLevel");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextIsNull() {
            this.addCriterion("skill_context is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextIsNotNull() {
            this.addCriterion("skill_context is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextEqualTo(final String value) {
            this.addCriterion("skill_context =", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextEqualToColumn(final Column column) {
            this.addCriterion("skill_context = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextNotEqualTo(final String value) {
            this.addCriterion("skill_context <>", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextNotEqualToColumn(final Column column) {
            this.addCriterion("skill_context <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextGreaterThan(final String value) {
            this.addCriterion("skill_context >", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextGreaterThanColumn(final Column column) {
            this.addCriterion("skill_context > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextGreaterThanOrEqualTo(final String value) {
            this.addCriterion("skill_context >=", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_context >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextLessThan(final String value) {
            this.addCriterion("skill_context <", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextLessThanColumn(final Column column) {
            this.addCriterion("skill_context < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextLessThanOrEqualTo(final String value) {
            this.addCriterion("skill_context <=", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("skill_context <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextLike(final String value) {
            this.addCriterion("skill_context like", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextNotLike(final String value) {
            this.addCriterion("skill_context not like", value, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextIn(final List<String> values) {
            this.addCriterion("skill_context in", values, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextNotIn(final List<String> values) {
            this.addCriterion("skill_context not in", values, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextBetween(final String value1, final String value2) {
            this.addCriterion("skill_context between", value1, value2, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andSkillContextNotBetween(final String value1, final String value2) {
            this.addCriterion("skill_context not between", value1, value2, "skillContext");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeIsNull() {
            this.addCriterion("add_time is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeIsNotNull() {
            this.addCriterion("add_time is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time =", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeEqualToColumn(final Column column) {
            this.addCriterion("add_time = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <>", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeNotEqualToColumn(final Column column) {
            this.addCriterion("add_time <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("add_time >", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeGreaterThanColumn(final Column column) {
            this.addCriterion("add_time > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time >=", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeLessThan(final LocalDateTime value) {
            this.addCriterion("add_time <", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeLessThanColumn(final Column column) {
            this.addCriterion("add_time < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("add_time <=", value, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("add_time <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time in", values, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("add_time not in", values, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time between", value1, value2, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andAddTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("add_time not between", value1, value2, "addTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeIsNull() {
            this.addCriterion("update_time is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeIsNotNull() {
            this.addCriterion("update_time is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time =", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeEqualToColumn(final Column column) {
            this.addCriterion("update_time = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeNotEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <>", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeNotEqualToColumn(final Column column) {
            this.addCriterion("update_time <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeGreaterThan(final LocalDateTime value) {
            this.addCriterion("update_time >", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeGreaterThanColumn(final Column column) {
            this.addCriterion("update_time > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeGreaterThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time >=", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeLessThan(final LocalDateTime value) {
            this.addCriterion("update_time <", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeLessThanColumn(final Column column) {
            this.addCriterion("update_time < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeLessThanOrEqualTo(final LocalDateTime value) {
            this.addCriterion("update_time <=", value, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("update_time <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time in", values, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeNotIn(final List<LocalDateTime> values) {
            this.addCriterion("update_time not in", values, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time between", value1, value2, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andUpdateTimeNotBetween(final LocalDateTime value1, final LocalDateTime value2) {
            this.addCriterion("update_time not between", value1, value2, "updateTime");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedIsNull() {
            this.addCriterion("deleted is null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedIsNotNull() {
            this.addCriterion("deleted is not null");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedEqualTo(final Boolean value) {
            this.addCriterion("deleted =", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedEqualToColumn(final Column column) {
            this.addCriterion("deleted = " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedNotEqualTo(final Boolean value) {
            this.addCriterion("deleted <>", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedNotEqualToColumn(final Column column) {
            this.addCriterion("deleted <> " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedGreaterThan(final Boolean value) {
            this.addCriterion("deleted >", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedGreaterThanColumn(final Column column) {
            this.addCriterion("deleted > " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedGreaterThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted >=", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedGreaterThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted >= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedLessThan(final Boolean value) {
            this.addCriterion("deleted <", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedLessThanColumn(final Column column) {
            this.addCriterion("deleted < " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedLessThanOrEqualTo(final Boolean value) {
            this.addCriterion("deleted <=", value, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedLessThanOrEqualToColumn(final Column column) {
            this.addCriterion("deleted <= " + column.getEscapedColumnName());
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedIn(final List<Boolean> values) {
            this.addCriterion("deleted in", values, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedNotIn(final List<Boolean> values) {
            this.addCriterion("deleted not in", values, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted between", value1, value2, "deleted");
            return (SkillsExample.Criteria) this;
        }

        public SkillsExample.Criteria andDeletedNotBetween(final Boolean value1, final Boolean value2) {
            this.addCriterion("deleted not between", value1, value2, "deleted");
            return (SkillsExample.Criteria) this;
        }
    }

    public interface ICriteriaWhen {
        void criteria(final SkillsExample.Criteria paramCriteria);
    }

    public interface IExampleWhen {
        void example(final SkillsExample paramSkillsExample);
    }
}
