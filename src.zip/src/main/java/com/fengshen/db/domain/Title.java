//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.fengshen.db.domain;

public class Title {
    private int id;
    private String name;
    private String event;
    private String title;
    private String des;

    public Title() {
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getEvent() {
        return this.event;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDes() {
        return this.des;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setEvent(final String event) {
        this.event = event;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public void setDes(final String des) {
        this.des = des;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Title)) {
            return false;
        } else {
            Title other = (Title) o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.getId() != other.getId()) {
                return false;
            } else {
                label61:
                {
                    Object this$name = this.getName();
                    Object other$name = other.getName();
                    if (this$name == null) {
                        if (other$name == null) {
                            break label61;
                        }
                    } else if (this$name.equals(other$name)) {
                        break label61;
                    }

                    return false;
                }

                label54:
                {
                    Object this$event = this.getEvent();
                    Object other$event = other.getEvent();
                    if (this$event == null) {
                        if (other$event == null) {
                            break label54;
                        }
                    } else if (this$event.equals(other$event)) {
                        break label54;
                    }

                    return false;
                }

                Object this$title = this.getTitle();
                Object other$title = other.getTitle();
                if (this$title == null) {
                    if (other$title != null) {
                        return false;
                    }
                } else if (!this$title.equals(other$title)) {
                    return false;
                }

                Object this$des = this.getDes();
                Object other$des = other.getDes();
                if (this$des == null) {
                    if (other$des != null) {
                        return false;
                    }
                } else if (!this$des.equals(other$des)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Title;
    }

    public int hashCode() {
        int result = 1;
        result = result * 59 + this.getId();
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $event = this.getEvent();
        result = result * 59 + ($event == null ? 43 : $event.hashCode());
        Object $title = this.getTitle();
        result = result * 59 + ($title == null ? 43 : $title.hashCode());
        Object $des = this.getDes();
        result = result * 59 + ($des == null ? 43 : $des.hashCode());
        return result;
    }

    public String toString() {
        return "Title(id=" + this.getId() + ", name=" + this.getName() + ", event=" + this.getEvent() + ", title=" + this.getTitle() + ", des=" + this.getDes() + ")";
    }
}
