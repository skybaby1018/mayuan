package com.fengshen.db.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChargeRankVo implements Serializable {
    private Integer rank_no;
    private String money;
    private String accountName;
    private String sumMoney;
    private Integer charaId;
    private String lingquren;
    private String chargeTime;
}
