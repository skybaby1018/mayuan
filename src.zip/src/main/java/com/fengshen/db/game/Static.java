//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.fengshen.db.game;

import java.util.HashMap;
import java.util.Map;

public class Static {
    public static Map<String, Integer> CHAR_TOKEN_DATA = new HashMap();
    public static final String CACHE_PERFIX_NAME = "GAMECACHE-";

    public Static() {
    }
}
